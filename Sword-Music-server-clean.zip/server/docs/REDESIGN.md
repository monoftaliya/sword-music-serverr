# Sword Music dashboard update

This update extends the existing Next.js, FastAPI and Electron application. Authentication, listening history, uploaded files, playlists, saved player state, rooms and the original audio engine are retained.

## Data and playback

The dashboard fetches `/api/home`, `/api/dashboard` and the existing recommendation endpoints. Monthly highlights use the signed-in listener's non-skipped plays of at least 30 seconds during the last 30 days. Weekly rankings use public tracks' qualified plays in Sword Music over seven days. When no such plays exist, Audius supplies its actual weekly chart; unavailable charts have an empty state. Genre labels describe the chart's metadata, not a claim about global market share. No listener counts or chart movement are invented.

MusicBrainz adds open recording metadata and artist/album browsing. These records are labeled unavailable for playback because MusicBrainz does not supply audio. Requests are serialized to approximately one per second. The source can be temporarily unavailable or rate-limited; the existing circuit breaker and source-status interface handle failures.

YouTube text search still requires `YOUTUBE_API_KEY`. The source now requests up to 50 candidates and includes artist uploads outside the Music category while retaining embeddability, age, live-stream and duration checks. Quotas and playback restrictions still apply.

The new `youtube_link` source accepts an explicit YouTube video URL in the search field. It obtains metadata from the official oEmbed endpoint and plays the video in the existing visible YouTube IFrame player. It does not require a Data API search key. It cannot enumerate an artist's catalog or bypass unavailable, private, region-restricted or non-embeddable videos. No audio is extracted or downloaded.

Keep `musicbrainz,youtube_link` in `PROVIDERS_ENABLED` when using an existing `.env` with an explicit provider list. Existing `.env` values are never overwritten by this update.

## Lyrics and metadata

`GENIUS_ACCESS_TOKEN` is optional and remains exclusively on the server. `GeniusMetadata` uses the official search/song endpoints to retrieve supported metadata and a matched lyrics-page URL. The adapter does not scrape or return full Genius lyrics. Without a token, the panel provides a clearly labeled Genius search link.

LRCLIB supplies lyrics through its public API. The adapter checks title, artist and recording duration. Only supplied LRC timestamps drive synchronization. Plain lyrics have no fabricated active line. The optional crimson effect applies to the current line, because word-level timestamps are not supplied. The preference is stored locally; reduced-motion settings disable animation. Set `LYRICS_ENABLED=false` to disable LRCLIB lookups.

The authenticated `/api/tracks/{id}/lyrics` endpoint checks private-track ownership before reading cached metadata. Responses are cached for one hour and never contain API tokens.

## Interface

The new home dashboard follows the supplied dark reference with a wide navigation sidebar, top search, personalized greeting, four widgets, recommendations, featured playback, history, discovery, chart and lyrics panels. The existing player remains the only playback state. An empty bottom player offers a real search link before the first track is selected.

Collection replacement uses a brief exit and a 20-pixel upward entrance. Incrementally appended results preserve existing rows. Playback position and likes do not trigger list entrances. A thin monochrome conic reflection travels once around the selected row; it does not run continuously. OS and application motion preferences are respected.

New core navigation copy is keyed in `frontend/src/lib/i18n.ts`, with Russian as the default dictionary. Artist names, titles and lyrics retain their original language.

The visible app name is Sword Music. The desktop wrapper preserves an existing legacy user-data directory when it contains settings, retaining the server address and browser session after the rename.

## Artwork

The background was generated with the built-in ImageGen tool using the supplied image solely as a style/composition reference. The deployable asset is `frontend/public/art/sword-nocturne.webp`. It is decorative artwork and is never presented as an album cover or recording metadata.

Final generation prompt:

> Wide cinematic backdrop for Sword Music, illustration only, no UI or text. An original dark fantasy adult swordsman with tousled black hair, charcoal armor, a slender sword and reflective obsidian shards. Black, graphite and pale silver with restrained cool gray-violet tones. Dark negative space on the left; the character slightly right of center; face and crown-like shards in the upper middle; the lower half dissolves into black. Intricate etched metal and glass, controlled silver rim lighting. No logos, frames, watermarks, neon or gore.

## Validation

Use `npm ci`, `npm run typecheck`, `npm test` and `npm run build` from `frontend`. Use `pip install -r requirements-dev.txt` and `python -m pytest -q` from `backend`. On Windows, tests need the inherited `SystemRoot` environment variable; the migration test now preserves the platform environment. API adapters are tested with deterministic upstream responses. Browser checks use a separate temporary database and synthetic fixture audio; no test account or fixture catalog is included in production configuration.

Official references: [Genius API](https://docs.genius.com/), [YouTube IFrame API](https://developers.google.com/youtube/iframe_api_reference), [MusicBrainz API](https://musicbrainz.org/doc/MusicBrainz_API), [LRCLIB](https://lrclib.net/docs).

An exhausted wave now waits at least 30 seconds before requesting another continuation; successful continuations are paced, and late responses cannot append tracks to a different playback context. This prevents audio time updates from repeatedly hitting the recommendation limit on a small or depleted catalog.
