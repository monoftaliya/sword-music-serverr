"""SQLAlchemy models (declarative only — business logic lives in the service modules)."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base, IdType, JSONType, UTCDateTime, new_id, utcnow

DEFAULT_USER_SETTINGS: dict[str, Any] = {
    "theme": "liquid",  # liquid | oled | midnight
    "accent": "adaptive",  # adaptive | violet | blue
    "intensity": "balanced",  # minimal | balanced | rich
    "motion": "system",  # system | full | reduced | off
    "crossfade": 0,  # seconds, 0 = off
    "quality": "high",  # high | data_saver (only where a source offers variants)
    "history_enabled": True,
    "show_listening_in_rooms": True,
    "seed_tags": [],
    "wave_lens": "main",  # main | shadow
}


# ---------------------------------------------------------------- users / auth
class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(IdType, primary_key=True, default=new_id)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    display_name: Mapped[str] = mapped_column(String(64))
    avatar_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    settings: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    player_state: Mapped[dict[str, Any] | None] = mapped_column(JSONType, nullable=True)
    invited_by: Mapped[str | None] = mapped_column(IdType, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class UserSession(Base):
    __tablename__ = "user_sessions"

    id: Mapped[str] = mapped_column(IdType, primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    user_agent: Mapped[str] = mapped_column(String(255), default="")
    ip: Mapped[str] = mapped_column(String(64), default="")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    last_used_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime)


class Invite(Base):
    __tablename__ = "invites"

    id: Mapped[str] = mapped_column(IdType, primary_key=True, default=new_id)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    note: Mapped[str] = mapped_column(String(120), default="")
    created_by: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    max_uses: Mapped[int] = mapped_column(Integer, default=1)
    uses: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class PasswordReset(Base):
    __tablename__ = "password_resets"

    id: Mapped[str] = mapped_column(IdType, primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime)
    used_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)


# ---------------------------------------------------------------- catalog
class Track(Base):
    """A track known to the system. `id` is stable: '<provider>:<provider_track_id>'."""

    __tablename__ = "tracks"

    id: Mapped[str] = mapped_column(String(200), primary_key=True)
    provider: Mapped[str] = mapped_column(String(32), index=True)
    provider_track_id: Mapped[str] = mapped_column(String(160))
    title: Mapped[str] = mapped_column(String(400))
    artist: Mapped[str] = mapped_column(String(300), default="")
    artist_ref: Mapped[str | None] = mapped_column(String(160), nullable=True)
    album: Mapped[str | None] = mapped_column(String(400), nullable=True)
    album_ref: Mapped[str | None] = mapped_column(String(160), nullable=True)
    duration: Mapped[float | None] = mapped_column(Float, nullable=True)
    artwork_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    artwork_small: Mapped[str | None] = mapped_column(Text, nullable=True)
    stream_kind: Mapped[str] = mapped_column(String(16), default="full")  # full | preview | none
    license: Mapped[str | None] = mapped_column(String(120), nullable=True)
    license_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    page_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    genres: Mapped[list[str]] = mapped_column(JSONType, default=list)
    tags: Mapped[list[str]] = mapped_column(JSONType, default=list)
    moods: Mapped[list[str]] = mapped_column(JSONType, default=list)
    instruments: Mapped[list[str]] = mapped_column(JSONType, default=list)
    canonical: Mapped[dict[str, float]] = mapped_column(JSONType, default=dict)
    bpm: Mapped[float | None] = mapped_column(Float, nullable=True)
    musical_key: Mapped[str | None] = mapped_column(String(40), nullable=True)
    speed: Mapped[str | None] = mapped_column(String(16), nullable=True)
    vocal: Mapped[str | None] = mapped_column(String(16), nullable=True)
    popularity: Mapped[float] = mapped_column(Float, default=0.0)
    release_date: Mapped[str | None] = mapped_column(String(32), nullable=True)
    norm_key: Mapped[str] = mapped_column(String(300), index=True, default="")
    artist_key: Mapped[str] = mapped_column(String(200), index=True, default="")
    extra: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    palette: Mapped[dict[str, Any] | None] = mapped_column(JSONType, nullable=True)
    owner_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True
    )
    unavailable_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    unavailable_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)

    __table_args__ = (
        UniqueConstraint("provider", "provider_track_id", name="uq_tracks_provider_pid"),
    )


# ---------------------------------------------------------------- library
class Favorite(Base):
    __tablename__ = "favorites"

    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    track_id: Mapped[str] = mapped_column(
        ForeignKey("tracks.id", ondelete="CASCADE"), primary_key=True
    )
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)


class Playlist(Base):
    __tablename__ = "playlists"

    id: Mapped[str] = mapped_column(IdType, primary_key=True, default=new_id)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(String(600), default="")
    cover_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    share_token: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    copied_from: Mapped[str | None] = mapped_column(IdType, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class PlaylistTrack(Base):
    __tablename__ = "playlist_tracks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    playlist_id: Mapped[str] = mapped_column(
        ForeignKey("playlists.id", ondelete="CASCADE"), index=True
    )
    track_id: Mapped[str] = mapped_column(ForeignKey("tracks.id", ondelete="CASCADE"))
    position: Mapped[int] = mapped_column(Integer, default=0)
    added_by: Mapped[str | None] = mapped_column(IdType, nullable=True)
    added_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    __table_args__ = (Index("ix_playlist_tracks_pos", "playlist_id", "position"),)


class SearchHistory(Base):
    __tablename__ = "search_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    query: Mapped[str] = mapped_column(String(300))
    kind: Mapped[str] = mapped_column(String(16), default="text")  # text | mood
    results: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)


# ---------------------------------------------------------------- listening signals
class PlayEvent(Base):
    __tablename__ = "play_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[str] = mapped_column(ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    started_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    played_ms: Mapped[int] = mapped_column(Integer, default=0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    end_reason: Mapped[str] = mapped_column(String(16), default="ended")
    completed: Mapped[bool] = mapped_column(Boolean, default=False)
    skipped: Mapped[bool] = mapped_column(Boolean, default=False)
    context: Mapped[str] = mapped_column(String(80), default="")
    mode: Mapped[str | None] = mapped_column(String(24), nullable=True)


class Feedback(Base):
    __tablename__ = "feedback"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[str] = mapped_column(ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # like | dislike | more | less
    context: Mapped[str] = mapped_column(String(80), default="")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)


class ArtistExclusion(Base):
    __tablename__ = "artist_exclusions"

    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    artist_key: Mapped[str] = mapped_column(String(200), primary_key=True)
    artist_name: Mapped[str] = mapped_column(String(300), default="")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class TagBias(Base):
    """Explicit 'more like this' / 'less of this sound' adjustments per canonical tag."""

    __tablename__ = "tag_bias"

    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    tag: Mapped[str] = mapped_column(String(40), primary_key=True)
    weight: Mapped[float] = mapped_column(Float, default=0.0)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class Impression(Base):
    """Tracks served by recommendation surfaces (prevents repeats, measures novelty)."""

    __tablename__ = "impressions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[str] = mapped_column(ForeignKey("tracks.id", ondelete="CASCADE"))
    surface: Mapped[str] = mapped_column(String(32))  # wave:flow, mode:rage, descent, ...
    served_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)


# ---------------------------------------------------------------- rooms
class Room(Base):
    __tablename__ = "rooms"

    id: Mapped[str] = mapped_column(IdType, primary_key=True, default=new_id)
    code: Mapped[str] = mapped_column(String(12), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(80))
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    allow_member_queue: Mapped[bool] = mapped_column(Boolean, default=False)
    allow_suggestions: Mapped[bool] = mapped_column(Boolean, default=True)
    state: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)


class RoomMember(Base):
    __tablename__ = "room_members"

    room_id: Mapped[str] = mapped_column(
        ForeignKey("rooms.id", ondelete="CASCADE"), primary_key=True
    )
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    role: Mapped[str] = mapped_column(String(16), default="member")  # owner | member
    joined_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class RoomQueueItem(Base):
    __tablename__ = "room_queue"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[str] = mapped_column(ForeignKey("rooms.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[str] = mapped_column(ForeignKey("tracks.id", ondelete="CASCADE"))
    added_by: Mapped[str | None] = mapped_column(IdType, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued|suggested|played|rejected
    position: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


# ---------------------------------------------------------------- system
class ProviderSetting(Base):
    __tablename__ = "provider_settings"

    provider_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str] = mapped_column(String(200), default="")
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
