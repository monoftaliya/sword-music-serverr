"""Sword Music — FastAPI application factory."""
from __future__ import annotations

import asyncio
import logging
import mimetypes
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .auth.router import router as auth_router
from .config import ROOT_DIR, get_settings
from .core.deps import CSRFGuard
from .core.errors import ApiError, install_error_handlers
from .core.storage import media_root
from .db import dispose_engine, get_engine, get_sessionmaker
from .library.playlists import router as playlists_router
from .library.router import router as library_router
from .library.uploads import router as uploads_router
from .models import ProviderSetting, User
from .music.registry import Registry, make_http_client, set_registry
from .music.router import router as tracks_router
from .music.dashboard import router as dashboard_router
from .recs.explore import router as explore_router
from .recs.router import router as recs_router
from .rooms.manager import hub, restore_rooms
from .rooms.router import router as rooms_router
from .search.router import router as search_router
from .users.admin import router as admin_router
from .users.router import router as me_router

log = logging.getLogger("sword")
mimetypes.add_type("application/manifest+json", ".webmanifest")
mimetypes.add_type("text/javascript", ".js")


def run_migrations() -> None:
    from alembic import command
    from alembic.config import Config

    cfg = Config(str(ROOT_DIR / "backend" / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT_DIR / "backend" / "alembic"))
    command.upgrade(cfg, "head")


async def _announce_setup() -> None:
    async with get_sessionmaker()() as session:
        users = (await session.execute(select(func.count()).select_from(User))).scalar_one()
        overrides = (await session.execute(select(ProviderSetting))).scalars().all()
    from .music.registry import get_registry

    for row in overrides:
        get_registry().set_admin_disabled(row.provider_id, not row.enabled)
    if users == 0:
        code = get_settings().setup_code
        banner = "=" * 64
        log.warning(
            "\n%s\n  Sword Music: первый запуск.\n  Откройте сайт и создайте аккаунт администратора с кодом настройки:\n\n      %s\n\n%s",
            banner,
            code,
            banner,
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    logging.basicConfig(level=s.log_level.upper(), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if s.is_production and not s.secret_key:
        raise RuntimeError("SECRET_KEY must be set when SWORD_ENV=production")
    s.data_dir.mkdir(parents=True, exist_ok=True)
    media_root()
    if getattr(app.state, "auto_migrate", True):
        await asyncio.to_thread(run_migrations)
    get_engine()
    client = make_http_client()
    set_registry(Registry(client))
    await _announce_setup()
    await restore_rooms()
    try:
        yield
    finally:
        await hub.shutdown()
        await client.aclose()
        set_registry(None)
        await dispose_engine()


class SecurityHeaders:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = message.setdefault("headers", [])
                existing = {k.lower() for k, _ in headers}
                extra = {
                    b"x-content-type-options": b"nosniff",
                    # YouTube's embedded player needs the page origin as referrer (error 153 without it)
                    b"referrer-policy": b"strict-origin-when-cross-origin",
                    b"x-frame-options": b"DENY",
                    b"permissions-policy": b"camera=(), microphone=(), geolocation=(), payment=()",
                    b"content-security-policy": (
                        b"default-src 'self'; img-src 'self' data: blob: https: http:; media-src 'self' blob: https: http:; "
                        b"connect-src 'self' ws: wss:; style-src 'self' 'unsafe-inline'; "
                        b"script-src 'self' 'unsafe-inline' https://www.youtube.com https://s.ytimg.com https://w.soundcloud.com; "
                        b"frame-src 'self' https://www.youtube.com https://www.youtube-nocookie.com https://w.soundcloud.com https://open.spotify.com; "
                        b"font-src 'self' data:; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'; base-uri 'self'"
                    ),
                }
                if scope.get("path") == "/players/spotify.html":
                    extra[b"x-frame-options"] = b"SAMEORIGIN"
                    extra[b"content-security-policy"] = (
                        b"default-src 'none'; script-src 'self' 'unsafe-eval' https://open.spotify.com https://embed-cdn.spotifycdn.com; "
                        b"style-src 'self'; frame-src https://open.spotify.com; connect-src 'none'; "
                        b"frame-ancestors 'self'; base-uri 'none'; form-action 'none'"
                    )
                for k, v in extra.items():
                    if k not in existing:
                        headers.append((k, v))
            await send(message)

        await self.app(scope, receive, send_wrapper)


def _frontend_response(dist: Path, path: str, *, rsc: bool = False) -> Response | None:
    root = dist.resolve()
    rel = path.lstrip("/")
    if rsc and not rel.endswith(".txt"):
        route = rel.rstrip("/")
        candidates = [f"{route}/index.txt" if route else "index.txt", f"{route}.txt"]
    else:
        candidates = [rel] if rel else []
        candidates += [f"{rel.rstrip('/')}/index.html" if rel else "index.html", f"{rel.rstrip('/')}.html"]
    for cand in candidates:
        if not cand:
            continue
        p = (root / cand).resolve()
        if root != p and root not in p.parents:
            return None
        if p.is_file():
            headers = {}
            is_flight = p.suffix == ".txt" and (rsc or p.name == "index.txt" or any(part.startswith("__next.") for part in p.relative_to(root).parts))
            if "/_next/static/" in f"/{cand}":
                headers["Cache-Control"] = "public, max-age=31536000, immutable"
            elif is_flight or p.suffix in (".html",) or p.name in ("sw.js", "manifest.webmanifest"):
                headers["Cache-Control"] = "no-cache"
            else:
                headers["Cache-Control"] = "public, max-age=86400"
            if is_flight or p.suffix == ".html":
                headers["Vary"] = "RSC"
            return FileResponse(p, headers=headers, media_type="text/x-component" if is_flight else None)
    return None


def create_app(*, auto_migrate: bool = True) -> FastAPI:
    s = get_settings()
    app = FastAPI(
        title="Sword Music",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/api/docs" if not s.is_production else None,
        redoc_url=None,
        openapi_url="/api/openapi.json" if not s.is_production else None,
    )
    app.state.auto_migrate = auto_migrate
    install_error_handlers(app)
    app.add_middleware(CSRFGuard)
    app.add_middleware(SecurityHeaders)
    origins = [o.strip() for o in s.cors_origins.split(",") if o.strip()]
    if origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    for r in (
        auth_router, me_router, admin_router, search_router, tracks_router, dashboard_router, library_router,
        playlists_router, uploads_router, recs_router, explore_router, rooms_router,
    ):
        app.include_router(r)

    @app.get("/api/health")
    async def health():
        from .music.registry import get_registry

        return {"ok": True, "providers": {p["id"]: p["state"] for p in get_registry().status()}}

    if s.is_test:
        fixtures = ROOT_DIR / "backend" / "tests" / "fixtures" / "audio"

        @app.get("/api/_test/audio/{name}")
        async def test_audio(name: str):
            p = (fixtures / name).resolve()
            if fixtures.resolve() not in p.parents or not p.exists():
                raise ApiError(404, "not_found", "Нет файла")
            return FileResponse(p, media_type="audio/ogg")

        art_dir = fixtures.parent / "art"

        @app.get("/api/_test/art/{name}")
        async def test_art(name: str):
            p = (art_dir / name).resolve()
            if art_dir.resolve() not in p.parents or not p.exists():
                raise ApiError(404, "not_found", "Нет файла")
            return FileResponse(p, media_type="image/png")

    app.mount("/media", StaticFiles(directory=str(media_root()), check_dir=False), name="media")

    @app.api_route("/api/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    async def api_not_found(rest: str):
        raise ApiError(404, "not_found", "Нет такого метода API.")

    @app.get("/.well-known/assetlinks.json", include_in_schema=False)
    async def android_asset_links():
        """Digital Asset Links for the Android app (TWA): place the file generated by PWABuilder/Bubblewrap in DATA_DIR."""
        f = s.data_dir / "assetlinks.json"
        if not f.is_file():
            return JSONResponse([], headers={"Cache-Control": "no-cache"})
        return FileResponse(f, media_type="application/json", headers={"Cache-Control": "no-cache"})

    @app.api_route("/{path:path}", methods=["GET", "HEAD"], include_in_schema=False)
    async def frontend(path: str, request: Request):
        dist = s.frontend_dist
        if not dist.exists():
            return HTMLResponse(
                "<h1>Sword Music API</h1><p>Фронтенд не собран. Выполните <code>npm run build</code> в папке "
                "<code>frontend</code> или запустите <code>npm run dev</code>.</p>",
                status_code=200,
            )
        resp = _frontend_response(dist, path, rsc=request.headers.get("rsc") == "1")
        if resp is not None:
            return resp
        not_found_page = dist / "404.html"
        if not_found_page.exists():
            return FileResponse(not_found_page, status_code=404, headers={"Cache-Control": "no-cache"})
        return JSONResponse({"error": {"code": "not_found", "message": "Страница не найдена."}}, status_code=404)

    return app


app = create_app()
