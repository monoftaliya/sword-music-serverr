"""Profile, avatar, settings, privacy controls, data export and account deletion."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, File, Response, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.deps import SESSION_COOKIE, current_user
from ..core.errors import ApiError
from ..core.security import verify_password
from ..core.storage import delete_media, media_url, save_image
from ..db import get_session
from ..models import Favorite, PlayEvent, Playlist, PlaylistTrack, SearchHistory, Track, User
from .schemas import merged_settings, user_out

router = APIRouter(prefix="/api/me", tags=["me"])

CHOICES = {
    "theme": {"liquid", "oled", "midnight"},
    "accent": {"adaptive", "violet", "blue"},
    "intensity": {"minimal", "balanced", "rich"},
    "motion": {"system", "full", "reduced", "off"},
    "quality": {"high", "data_saver"},
    "wave_lens": {"main", "shadow"},
}
BOOLS = {"history_enabled", "show_listening_in_rooms"}


class ProfileIn(BaseModel):
    display_name: str = Field(min_length=1, max_length=40)


@router.patch("")
async def update_profile(body: ProfileIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    db_user = await session.get(User, user.id)
    assert db_user is not None
    name = " ".join(body.display_name.split())
    if not name:
        raise ApiError(400, "bad_name", "Укажите имя.")
    db_user.display_name = name[:40]
    await session.commit()
    return {"user": user_out(db_user)}


@router.post("/avatar")
async def upload_avatar(file: UploadFile = File(...), session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    rel = await save_image(file, "avatars", 320)
    db_user = await session.get(User, user.id)
    assert db_user is not None
    old = db_user.avatar_path
    db_user.avatar_path = rel
    await session.commit()
    delete_media(old)
    return {"avatar_url": media_url(rel)}


@router.delete("/avatar")
async def remove_avatar(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    db_user = await session.get(User, user.id)
    assert db_user is not None
    old = db_user.avatar_path
    db_user.avatar_path = None
    await session.commit()
    delete_media(old)
    return {"ok": True}


@router.get("/settings")
async def get_settings_(user: User = Depends(current_user)):
    return {"settings": merged_settings(user)}


@router.patch("/settings")
async def patch_settings(body: dict[str, Any], session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    db_user = await session.get(User, user.id)
    assert db_user is not None
    current = dict(db_user.settings or {})
    for key, value in body.items():
        if key in CHOICES:
            if value not in CHOICES[key]:
                raise ApiError(400, "bad_setting", f"Недопустимое значение для «{key}».")
            current[key] = value
        elif key in BOOLS:
            if not isinstance(value, bool):
                raise ApiError(400, "bad_setting", f"Недопустимое значение для «{key}».")
            current[key] = value
        elif key == "crossfade":
            if not isinstance(value, (int, float)) or not 0 <= value <= 12:
                raise ApiError(400, "bad_setting", "Crossfade: от 0 до 12 секунд.")
            current[key] = int(value)
        else:
            raise ApiError(400, "unknown_setting", f"Неизвестная настройка «{key}».")
    db_user.settings = current
    await session.commit()
    return {"settings": merged_settings(db_user)}


@router.delete("/history")
async def clear_listening_history(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    await session.execute(delete(PlayEvent).where(PlayEvent.user_id == user.id))
    await session.commit()
    return {"ok": True}


@router.get("/export")
async def export_data(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    favs = await session.execute(select(Track).join(Favorite, Favorite.track_id == Track.id).where(Favorite.user_id == user.id))
    pls = list((await session.execute(select(Playlist).where(Playlist.owner_id == user.id))).scalars())
    playlists = []
    for pl in pls:
        rows = await session.execute(
            select(Track).join(PlaylistTrack, PlaylistTrack.track_id == Track.id).where(PlaylistTrack.playlist_id == pl.id).order_by(PlaylistTrack.position)
        )
        playlists.append({"name": pl.name, "description": pl.description, "tracks": [{"id": t.id, "title": t.title, "artist": t.artist, "source": t.page_url} for t in rows.scalars()]})
    history = await session.execute(
        select(PlayEvent, Track).join(Track, Track.id == PlayEvent.track_id).where(PlayEvent.user_id == user.id).order_by(PlayEvent.started_at.desc()).limit(5000)
    )
    searches = await session.execute(select(SearchHistory).where(SearchHistory.user_id == user.id).order_by(SearchHistory.created_at.desc()).limit(2000))
    return {
        "profile": user_out(user),
        "favorites": [{"id": t.id, "title": t.title, "artist": t.artist, "source": t.page_url} for t in favs.scalars()],
        "playlists": playlists,
        "listening_history": [
            {"at": p.started_at.isoformat(), "track": t.title, "artist": t.artist, "played_ms": p.played_ms, "skipped": p.skipped}
            for p, t in history.all()
        ],
        "search_history": [{"at": s.created_at.isoformat(), "query": s.query} for s in searches.scalars()],
    }


class DeleteAccountIn(BaseModel):
    password: str = Field(min_length=1, max_length=200)


@router.post("/delete")
async def delete_account(
    body: DeleteAccountIn, response: Response, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    db_user = await session.get(User, user.id)
    assert db_user is not None
    if not verify_password(db_user.password_hash, body.password):
        raise ApiError(400, "wrong_password", "Неверный пароль.")
    if db_user.is_admin:
        admins = (await session.execute(select(User.id).where(User.is_admin.is_(True), User.is_active.is_(True)))).all()
        if len(admins) <= 1:
            raise ApiError(400, "last_admin", "Нельзя удалить единственного администратора. Назначьте другого администратора.")
    avatar = db_user.avatar_path
    uploads = list((await session.execute(select(Track).where(Track.owner_id == user.id))).scalars())
    covers = [p.cover_path for p in (await session.execute(select(Playlist).where(Playlist.owner_id == user.id))).scalars()]
    await session.delete(db_user)
    await session.commit()
    delete_media(avatar)
    for c in covers:
        delete_media(c)
    from ..config import get_settings

    s = get_settings()
    for t in uploads:
        path = (s.data_dir / (t.extra or {}).get("path", "")).resolve()
        if s.data_dir.resolve() in path.parents:
            path.unlink(missing_ok=True)
        delete_media((t.extra or {}).get("art"))
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}
