"""Administrator endpoints: invites, users, music sources."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..auth.router import issue_reset_token, reset_link
from ..core.deps import admin_user
from ..core.errors import ApiError, not_found
from ..core.security import new_invite_code
from ..db import get_session, utcnow
from ..models import Invite, PlayEvent, ProviderSetting, User, UserSession
from ..music.registry import get_registry

router = APIRouter(prefix="/api/admin", tags=["admin"])


class InviteIn(BaseModel):
    note: str = Field("", max_length=120)
    max_uses: int = Field(1, ge=1, le=50)
    expires_in_days: int | None = Field(14, ge=1, le=365)


def invite_out(inv: Invite) -> dict:
    now = utcnow()
    state = "active"
    if inv.revoked_at:
        state = "revoked"
    elif inv.expires_at and inv.expires_at <= now:
        state = "expired"
    elif inv.uses >= inv.max_uses:
        state = "used"
    return {
        "id": inv.id,
        "code": inv.code,
        "note": inv.note,
        "max_uses": inv.max_uses,
        "uses": inv.uses,
        "expires_at": inv.expires_at.isoformat() if inv.expires_at else None,
        "created_at": inv.created_at.isoformat(),
        "state": state,
        "path": f"/register/?invite={inv.code}",
    }


@router.get("/invites")
async def list_invites(session: AsyncSession = Depends(get_session), _admin: User = Depends(admin_user)):
    rows = await session.execute(select(Invite).order_by(Invite.created_at.desc()).limit(300))
    return {"invites": [invite_out(i) for i in rows.scalars()]}


@router.post("/invites")
async def create_invite(body: InviteIn, session: AsyncSession = Depends(get_session), admin: User = Depends(admin_user)):
    inv = Invite(
        code=new_invite_code(),
        note=body.note.strip(),
        max_uses=body.max_uses,
        created_by=admin.id,
        expires_at=utcnow() + timedelta(days=body.expires_in_days) if body.expires_in_days else None,
    )
    session.add(inv)
    await session.commit()
    return invite_out(inv)


@router.delete("/invites/{invite_id}")
async def revoke_invite(invite_id: str, session: AsyncSession = Depends(get_session), _admin: User = Depends(admin_user)):
    inv = await session.get(Invite, invite_id)
    if inv is None:
        raise not_found("Приглашение не найдено.")
    inv.revoked_at = utcnow()
    await session.commit()
    return invite_out(inv)


@router.get("/users")
async def list_users(session: AsyncSession = Depends(get_session), _admin: User = Depends(admin_user)):
    users = list((await session.execute(select(User).order_by(User.created_at))).scalars())
    plays = dict(
        (await session.execute(select(PlayEvent.user_id, func.count(PlayEvent.id)).group_by(PlayEvent.user_id))).all()
    )
    last_seen = dict(
        (await session.execute(select(UserSession.user_id, func.max(UserSession.last_used_at)).group_by(UserSession.user_id))).all()
    )
    return {
        "users": [
            {
                "id": u.id,
                "email": u.email,
                "display_name": u.display_name,
                "is_admin": u.is_admin,
                "is_active": u.is_active,
                "created_at": u.created_at.isoformat(),
                "plays": plays.get(u.id, 0),
                "last_seen": last_seen[u.id].isoformat() if last_seen.get(u.id) else None,
            }
            for u in users
        ]
    }


class UserPatch(BaseModel):
    is_active: bool | None = None
    is_admin: bool | None = None


@router.patch("/users/{user_id}")
async def update_user(user_id: str, body: UserPatch, session: AsyncSession = Depends(get_session), admin: User = Depends(admin_user)):
    u = await session.get(User, user_id)
    if u is None:
        raise not_found("Пользователь не найден.")
    if u.id == admin.id and (body.is_active is False or body.is_admin is False):
        raise ApiError(400, "self_lockout", "Нельзя отключить или разжаловать самого себя.")
    if body.is_active is not None:
        u.is_active = body.is_active
        if not body.is_active:
            await session.execute(delete(UserSession).where(UserSession.user_id == u.id))
    if body.is_admin is not None:
        u.is_admin = body.is_admin
    await session.commit()
    return {"ok": True}


@router.post("/users/{user_id}/reset-link")
async def make_reset_link(user_id: str, session: AsyncSession = Depends(get_session), _admin: User = Depends(admin_user)):
    u = await session.get(User, user_id)
    if u is None:
        raise not_found("Пользователь не найден.")
    token = await issue_reset_token(session, u)
    await session.commit()
    return {"url": reset_link(token), "expires_in_hours": 2}


@router.get("/providers")
async def providers(_admin: User = Depends(admin_user)):
    return {"providers": get_registry().status()}


class ProviderPatch(BaseModel):
    enabled: bool


@router.patch("/providers/{provider_id}")
async def toggle_provider(provider_id: str, body: ProviderPatch, session: AsyncSession = Depends(get_session), _admin: User = Depends(admin_user)):
    reg = get_registry()
    if provider_id not in reg.providers:
        raise not_found("Источник не подключён в конфигурации сервера (PROVIDERS_ENABLED).")
    row = await session.get(ProviderSetting, provider_id)
    if row is None:
        session.add(ProviderSetting(provider_id=provider_id, enabled=body.enabled))
    else:
        row.enabled = body.enabled
    await session.commit()
    reg.set_admin_disabled(provider_id, not body.enabled)
    reg.cache.clear()
    return {"providers": reg.status()}
