from __future__ import annotations

from typing import Any

from ..core.storage import media_url
from ..models import DEFAULT_USER_SETTINGS, User


def merged_settings(user: User) -> dict[str, Any]:
    out = dict(DEFAULT_USER_SETTINGS)
    out.update(user.settings or {})
    return out


def user_out(user: User, *, private: bool = True) -> dict[str, Any]:
    data: dict[str, Any] = {
        "id": user.id,
        "display_name": user.display_name,
        "avatar_url": media_url(user.avatar_path),
    }
    if private:
        data.update(
            {
                "email": user.email,
                "is_admin": user.is_admin,
                "settings": merged_settings(user),
                "created_at": user.created_at.isoformat(),
            }
        )
    return data
