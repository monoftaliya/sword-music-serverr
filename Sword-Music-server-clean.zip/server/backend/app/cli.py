"""Command-line helpers.

    python -m app.cli setup-code                 # code for creating the first admin
    python -m app.cli create-admin EMAIL NAME    # asks for a password
    python -m app.cli invite [--uses N] [--days D] [--note TEXT]
    python -m app.cli reset-link EMAIL           # one-off password reset link
    python -m app.cli check-providers [QUERY]    # live check of every music source
    python -m app.cli migrate                    # apply database migrations
"""
from __future__ import annotations

import argparse
import asyncio
import getpass
import sys
import time
from datetime import timedelta

from sqlalchemy import select

from .config import get_settings
from .db import dispose_engine, get_sessionmaker, utcnow


async def _create_admin(email: str, name: str) -> None:
    from .core.security import hash_password, password_problem
    from .models import User

    pw = getpass.getpass("Пароль: ")
    if pw != getpass.getpass("Повторите пароль: "):
        sys.exit("Пароли не совпадают.")
    problem = password_problem(pw, email)
    if problem:
        sys.exit(problem)
    async with get_sessionmaker()() as s:
        email = email.strip().lower()
        user = (await s.execute(select(User).where(User.email == email))).scalar_one_or_none()
        if user:
            user.is_admin = True
            user.password_hash = hash_password(pw)
            print("Пользователь уже существовал — назначен администратором, пароль обновлён.")
        else:
            s.add(User(email=email, password_hash=hash_password(pw), display_name=name[:40], is_admin=True, settings={}))
            print("Администратор создан.")
        await s.commit()


async def _invite(uses: int, days: int, note: str) -> None:
    from .core.security import new_invite_code
    from .models import Invite

    async with get_sessionmaker()() as s:
        inv = Invite(code=new_invite_code(), max_uses=uses, note=note, expires_at=utcnow() + timedelta(days=days))
        s.add(inv)
        await s.commit()
    base = get_settings().public_url.rstrip("/")
    print(f"Код приглашения: {inv.code}\nСсылка: {base}/register/?invite={inv.code}")


async def _reset_link(email: str) -> None:
    from .auth.router import issue_reset_token, reset_link
    from .models import User

    async with get_sessionmaker()() as s:
        user = (await s.execute(select(User).where(User.email == email.strip().lower()))).scalar_one_or_none()
        if user is None:
            sys.exit("Пользователь не найден.")
        token = await issue_reset_token(s, user)
        await s.commit()
    print(f"Ссылка для сброса пароля (2 часа): {reset_link(token)}")


async def _check(query: str) -> None:
    from .music.providers.base import DiscoverSpec, ProviderError
    from .music.registry import Registry, make_http_client

    client = make_http_client()
    reg = Registry(client)
    print(f"User-Agent: {get_settings().user_agent}\n")
    for pid, p in reg.providers.items():
        if not p.configured():
            print(f"[--] {p.name}: не настроен. {p.config_hint()}")
            continue
        started = time.monotonic()
        try:
            res = await p.search(query, 5)
            ms = (time.monotonic() - started) * 1000
            playable = [t for t in res if t.stream_kind != "none"]
            print(f"[ok] {p.name}: {len(res)} результатов за {ms:.0f} мс, воспроизводимых: {len(playable)}")
            for t in res[:3]:
                print(f"      • {t.artist} — {t.title} ({t.stream_kind})")
            if playable:
                info = await p.resolve(playable[0].provider_track_id, {**playable[0].extra, "stream_kind": playable[0].stream_kind})
                head = await client.get(info.url, headers={"Range": "bytes=0-1"})
                print(f"      поток: HTTP {head.status_code} {head.headers.get('content-type', '')}")
            disc = await p.discover(DiscoverSpec(tags={"ambient": 1.0, "dark": 0.8}, limit=5))
            print(f"      discover(ambient+dark): {len(disc)} треков")
        except ProviderError as exc:
            print(f"[!!] {p.name}: {exc.kind} — {exc.message}")
        except Exception as exc:  # noqa: BLE001
            print(f"[!!] {p.name}: {exc.__class__.__name__}: {exc}")
    await client.aclose()


def main() -> None:
    parser = argparse.ArgumentParser(prog="python -m app.cli", description="Sword Music CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("setup-code")
    ca = sub.add_parser("create-admin")
    ca.add_argument("email")
    ca.add_argument("name")
    inv = sub.add_parser("invite")
    inv.add_argument("--uses", type=int, default=1)
    inv.add_argument("--days", type=int, default=14)
    inv.add_argument("--note", default="")
    rl = sub.add_parser("reset-link")
    rl.add_argument("email")
    chk = sub.add_parser("check-providers")
    chk.add_argument("query", nargs="?", default="night")
    sub.add_parser("migrate")
    args = parser.parse_args()

    if args.cmd == "setup-code":
        print(get_settings().setup_code)
        return
    if args.cmd == "migrate":
        from .main import run_migrations

        run_migrations()
        print("Миграции применены.")
        return

    async def runner() -> None:
        try:
            if args.cmd == "create-admin":
                await _create_admin(args.email, args.name)
            elif args.cmd == "invite":
                await _invite(args.uses, args.days, args.note)
            elif args.cmd == "reset-link":
                await _reset_link(args.email)
            elif args.cmd == "check-providers":
                await _check(args.query)
        finally:
            await dispose_engine()

    asyncio.run(runner())


if __name__ == "__main__":
    main()
