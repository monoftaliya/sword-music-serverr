"""Aggregated search across providers: text + natural-language mood search."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..models import SearchHistory, Track, User
from ..music.normalize import clean_words, durations_compatible, text_relevance, matches_version
from ..music.providers.base import DiscoverSpec, Provider, ProviderError, TrackResult
from ..music.registry import NAMES, PRIORITY, Registry
from ..music.store import liked_ids, save_results, track_out, track_point
from ..music.taxonomy import BY_KEY, label
from .interpreter import MoodSpec, apply_context, interpret, llm_refine


@dataclass
class SourceStatus:
    id: str
    name: str
    status: str  # ok | error | skipped
    count: int = 0
    message: str | None = None
    kind: str | None = None


@dataclass
class Scored:
    track: Track
    text: float = 0.0
    mood: float = 0.0
    rank: float = 0.0
    score: float = 0.0
    from_text: bool = False
    from_mood: bool = False
    alternatives: list[Track] = field(default_factory=list)


def spec_to_discover(spec: MoodSpec, limit: int = 30) -> DiscoverSpec:
    return DiscoverSpec(
        tags={k: v for k, v in spec.tags.items() if v > 0},
        avoid=set(spec.avoid),
        keywords=[k for k in spec.keywords if k.isascii()][:3],
        bpm_min=spec.bpm_min,
        bpm_max=spec.bpm_max,
        energy=spec.energy,
        vocal=spec.vocal,
        popular=True,
        limit=limit,
    )


def _match_reason(spec: MoodSpec, t: Track) -> str | None:
    if not spec.tags:
        return None
    common = [k for k, _ in sorted(spec.tags.items(), key=lambda kv: -kv[1]) if (t.canonical or {}).get(k, 0) > 0.15]
    parts = [label(k) for k in common[:3]]
    if t.bpm and (spec.bpm_min or spec.bpm_max):
        parts.append(f"{int(round(t.bpm))} BPM")
    return ", ".join(parts) if parts else None


def _availability_rank(t: Track) -> int:
    if t.unavailable_reason:
        return 3
    return {"full": 0, "preview": 1}.get(t.stream_kind, 2)


def _priority(t: Track) -> int:
    try:
        return PRIORITY.index(t.provider)
    except ValueError:
        return len(PRIORITY)


def group_versions(items: list[Scored]) -> list[Scored]:
    """Merge obvious duplicates (same normalised artist+title+version, similar length)."""
    groups: dict[str, list[Scored]] = {}
    order: list[str] = []
    for it in items:
        key = it.track.norm_key or it.track.id
        bucket = groups.get(key)
        if bucket is None:
            groups[key] = [it]
            order.append(key)
            continue
        if any(durations_compatible(b.track.duration, it.track.duration) for b in bucket):
            bucket.append(it)
        else:  # same name but clearly a different recording
            alt_key = f"{key}#{len(order)}"
            groups[alt_key] = [it]
            order.append(alt_key)
    out: list[Scored] = []
    for key in order:
        bucket = groups[key]
        bucket.sort(key=lambda s: (_availability_rank(s.track), _priority(s.track), -s.score))
        head = bucket[0]
        head.score = max(s.score for s in bucket)
        head.from_text = any(s.from_text for s in bucket)
        head.from_mood = any(s.from_mood for s in bucket)
        head.alternatives = [s.track for s in bucket[1:6]]
        out.append(head)
    return out


async def _uploads_matching(session: AsyncSession, user: User, query: str, limit: int = 10) -> list[Track]:
    q = clean_words(query)
    if not q:
        return []
    res = await session.execute(
        select(Track)
        .where(Track.provider == "upload", Track.owner_id == user.id, Track.norm_key.contains(q))
        .limit(limit)
    )
    return list(res.scalars())


async def run_search(
    session: AsyncSession,
    registry: Registry,
    user: User,
    query: str,
    *,
    mode: str = "auto",
    context_track_id: str | None = None,
    limit: int = 40,
    record: bool = False,
    provider_filter: set[str] | None = None,
    deep: bool = True,
    version: str = "all",
) -> dict[str, Any]:
    """`deep=False` (while the user is still typing) skips sources with a small daily quota (YouTube)."""
    started = time.monotonic()
    query = " ".join(query.split())[:200]
    from ..music.providers.youtube_link import video_id

    from ..music.providers.service_links import linked_service

    if video_id(query):
        provider_filter, mode = {"youtube_link"}, "text"
        version = "all"
    elif service := linked_service(query):
        provider_filter, mode = {service}, "text"
        version = "all"
    spec = interpret(query)
    if get_settings().llm_configured and (mode == "mood" or spec.descriptive or spec.confidence > 0):
        spec = await llm_refine(spec, registry.client)
    if spec.similar and context_track_id:
        ctx = await session.get(Track, context_track_id)
        if ctx is not None:
            spec = apply_context(spec, title=ctx.title, canonical=ctx.canonical or {}, bpm=ctx.bpm, speed=ctx.speed)

    do_mood = mode == "mood" or (mode == "auto" and spec.descriptive)
    do_text = mode == "text" or (mode == "auto" and (not spec.descriptive or bool(spec.keywords) or spec.confidence < 0.7))
    if mode == "mood" and not spec.tags and not spec.similar:
        do_text = True  # nothing recognised — fall back to plain text search

    providers: list[Provider] = [
        p for p in registry.providers.values() if provider_filter is None or p.id in provider_filter
    ]
    statuses: dict[str, SourceStatus] = {}
    tasks: list[tuple[str, str, Any]] = []
    deferred: list[str] = []
    for p in providers:
        quota_limited = getattr(p, "quota_limited", False)
        if quota_limited and not deep:
            if registry.usable(p.id):
                deferred.append(p.id)
            continue
        if not registry.usable(p.id):
            state = registry.state_of(p.id)
            statuses[p.id] = SourceStatus(
                p.id,
                NAMES.get(p.id, p.name),
                "skipped",
                message={
                    "not_configured": p.config_hint() or "Источник не настроен.",
                    "disabled": "Отключён администратором.",
                    "degraded": "Временно отключён после ошибок, повторим позже.",
                    "rate_limited": "Достигнут лимит запросов источника, повторим позже.",
                }.get(state, "Недоступен."),
                kind=state,
            )
            continue
        statuses[p.id] = SourceStatus(p.id, NAMES.get(p.id, p.name), "ok")
        if do_text or quota_limited:
            # quota-limited sources have no mood discovery: they get the user's words as a plain search
            tasks.append(
                (
                    p.id,
                    "text",
                    registry.run(
                        p, "search", lambda p=p: p.search(query, min(50, limit)), cache_key=f"{query if p.id in ('youtube_link', 'soundcloud', 'spotify_link') else clean_words(query)}:{min(50, limit)}", ttl=getattr(p, "search_ttl", 600)
                    ),
                )
            )
        if do_mood and not quota_limited:
            dspec = spec_to_discover(spec, 30)
            tasks.append(
                (p.id, "mood", registry.run(p, "discover", lambda p=p, d=dspec: p.discover(d), cache_key=dspec.cache_key(), ttl=1800))
            )

    outcomes = await asyncio.gather(*(t[2] for t in tasks), return_exceptions=True)
    text_results: list[tuple[TrackResult, int]] = []
    mood_results: list[tuple[TrackResult, int]] = []
    for (pid, kind, _), res in zip(tasks, outcomes):
        st = statuses[pid]
        if isinstance(res, ProviderError):
            if st.count == 0:
                st.status = "error"
                st.message = res.message
                st.kind = res.kind
            continue
        if isinstance(res, BaseException):
            st.status, st.message, st.kind = "error", "Ошибка источника", "bad_response"
            continue
        if st.status == "error" and res:
            st.status, st.message, st.kind = "ok", None, None
        res = [r for r in res if matches_version(r.title, version)]
        st.count += len(res)
        target = text_results if kind == "text" else mood_results
        target.extend((r, i) for i, r in enumerate(res))

    all_results = [r for r, _ in text_results] + [r for r, _ in mood_results]
    stored = await save_results(session, all_results)
    uploads = await _uploads_matching(session, user, query) if do_text and registry.uploads_enabled and (provider_filter is None or bool(provider_filter & {"upload", "uploads"})) else []

    scored: dict[str, Scored] = {}

    def entry(t: Track) -> Scored:
        s = scored.get(t.id)
        if s is None:
            s = scored[t.id] = Scored(track=t)
        return s

    for r, pos in text_results:
        t = stored.get(r.id)
        if t is None:
            continue
        s = entry(t)
        s.from_text = True
        rel = text_relevance(query, t.title, t.artist, t.album)
        s.text = max(s.text, rel * 0.82 + (t.popularity or 0) * 0.08 + 0.1 / (1 + pos * 0.5))
    for t in uploads:
        if not matches_version(t.title, version):
            continue
        s = entry(t)
        s.from_text = True
        s.text = max(s.text, text_relevance(query, t.title, t.artist, t.album) + 0.05)
    if do_mood:
        for r, _pos in mood_results:
            t = stored.get(r.id)
            if t is not None:
                entry(t).from_mood = True
        for s in scored.values():
            s.mood = spec.fit(s.track.canonical or {}, track_point(s.track), s.track.bpm, s.track.vocal)
            s.mood = s.mood * 0.92 + (s.track.popularity or 0) * 0.08

    items: list[Scored] = []
    for s in scored.values():
        hi, lo = max(s.text, s.mood), min(s.text, s.mood)
        s.score = hi + 0.12 * lo
        if s.track.unavailable_reason:
            s.score -= 0.4
        elif s.track.stream_kind == "none":
            s.score -= 0.3
        elif s.track.stream_kind == "preview":
            s.score -= 0.12
        if do_mood and not spec.keywords and s.from_text and not s.from_mood and s.mood < 0.2 and s.text < 0.5:
            continue  # incidental lexical match for a purely descriptive query
        items.append(s)

    items.sort(key=lambda s: -s.score)
    grouped = group_versions(items)
    grouped.sort(key=lambda s: -s.score)
    grouped = grouped[:limit]

    show_ids = [g.track.id for g in grouped] + [a.id for g in grouped for a in g.alternatives]
    liked = await liked_ids(session, user.id, show_ids)
    results = []
    for g in grouped:
        item = track_out(g.track, liked=g.track.id in liked, reason=_match_reason(spec, g.track) if do_mood else None)
        item["score"] = round(g.score, 3)
        item["alternatives"] = [track_out(a, liked=a.id in liked) for a in g.alternatives]
        results.append(item)

    if record and query and (user.settings or {}).get("history_enabled", True):
        session.add(SearchHistory(user_id=user.id, query=query[:300], kind="mood" if do_mood else "text", results=len(results)))
        await session.commit()

    return {
        "query": query,
        "mode": "mood" if do_mood and not do_text else ("mixed" if do_mood else "text"),
        "interpretation": spec.to_dict() if (do_mood or spec.tags) else None,
        "results": results,
        "sources": [s.__dict__ for s in statuses.values()],
        "deferred": deferred,
        "took_ms": round((time.monotonic() - started) * 1000),
    }


# ------------------------------------------------------------------ suggestions
MOOD_PROMPTS = [
    "мрачный фонк с тяжёлым басом", "ночной Токио, дождь, одиночество", "музыка, будто я главный злодей аниме",
    "музыка для размышлений в три часа ночи", "космос и бесконечность", "дарк эмбиент для фокуса",
    "энергичный драм-н-бейс для тренировки", "спокойное пианино без слов", "синтвейв для ночной поездки",
    "эпичная оркестровая музыка", "меланхоличный лоуфай под дождь", "агрессивный индастриал",
    "загадочная атмосферная электроника", "мечтательный пост-рок", "джаз поздно ночью",
    "уверенный трэп с тяжёлым басом", "медленная и грустная музыка", "что-нибудь похожее на этот трек, но атмосфернее",
    "зимний эмбиент", "киберпанк город ночью", "гипнотичное техно 130 bpm", "музыка для сна",
]


async def suggest(session: AsyncSession, user: User, q: str) -> dict[str, Any]:
    raw = " ".join(q.split())[:100]
    cq = clean_words(raw)
    out: dict[str, Any] = {"history": [], "tracks": [], "artists": [], "moods": []}
    if not cq:
        rows = await session.execute(
            select(SearchHistory.query)
            .where(SearchHistory.user_id == user.id)
            .order_by(SearchHistory.created_at.desc())
            .limit(30)
        )
        seen: list[str] = []
        for (query,) in rows:
            if query not in seen:
                seen.append(query)
        out["history"] = seen[:8]
        out["moods"] = MOOD_PROMPTS[:6]
        return out
    hist = await session.execute(
        select(SearchHistory.query)
        .where(SearchHistory.user_id == user.id)
        .order_by(SearchHistory.created_at.desc())
        .limit(200)
    )
    seen_h: list[str] = []
    for (query,) in hist:
        if cq in clean_words(query) and query not in seen_h:
            seen_h.append(query)
    out["history"] = seen_h[:4]
    rows = await session.execute(
        select(Track)
        .where(Track.norm_key.contains(cq), (Track.owner_id.is_(None)) | (Track.owner_id == user.id))
        .order_by(Track.popularity.desc())
        .limit(40)
    )
    tracks = list(rows.scalars())
    seen_t: set[str] = set()
    artists: dict[str, str] = {}
    picked: list[Track] = []
    for t in tracks:
        if t.norm_key in seen_t:
            continue
        seen_t.add(t.norm_key)
        if cq in clean_words(t.artist) and t.artist_key not in artists:
            artists[t.artist_key] = t.artist
        if len(picked) < 5 and (cq in clean_words(t.title) or cq in clean_words(t.artist)):
            picked.append(t)
    liked = await liked_ids(session, user.id, [t.id for t in picked])
    out["tracks"] = [track_out(t, liked=t.id in liked) for t in picked]
    out["artists"] = [{"key": k, "name": v} for k, v in list(artists.items())[:4]]
    out["moods"] = [m for m in MOOD_PROMPTS if cq in clean_words(m)][:4]
    spec = interpret(raw)
    if spec.descriptive and raw not in out["moods"]:
        out["interpretation"] = [c.__dict__ for c in spec.chips()][:5]
    return out


def tag_catalog() -> list[dict[str, Any]]:
    return [{"key": t.key, "label": t.ru, "group": t.group} for t in BY_KEY.values()]
