"""Natural-language mood query interpreter.

Local, rule-based and transparent: a stemmed RU/EN lexicon maps words and phrases
onto canonical tags, tempo, vocal preference and a target point in mood space.
If an OpenAI-compatible model is configured (LLM_BASE_URL/LLM_MODEL — e.g. a local
Ollama), its structured answer is merged in; any failure silently falls back to
the rules. The user always sees which parameters were recognised.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any

import httpx
import snowballstemmer

from ..config import get_settings
from ..music.normalize import fold
from ..music.taxonomy import BY_KEY, cosine, label, mood_distance, mood_point
from .lexicon import NEGATORS, PHRASES, STOPWORDS, WORDS

log = logging.getLogger("sword.interpreter")

_RU = snowballstemmer.stemmer("russian")
_EN = snowballstemmer.stemmer("english")
_CYR = re.compile(r"[а-я]")
_TOKEN = re.compile(r"[\w&]+(?:-[\w]+)*", re.UNICODE)
_BPM = re.compile(r"(\d{2,3})\s*(?:bpm|бпм|уд)", re.IGNORECASE)
_DEEP_NIGHT = re.compile(
    r"(\b[1-5]\s*(?:час\w*)?\s*ноч|\b(?:два|три|четыре|пять)\s+час\w*\s+ноч|\b[1-5]\s*am\b|глубок\w*\s+ноч|deep night|late at night)"
)
_EN_COMPARATIVES = {"darker", "faster", "slower", "heavier", "calmer", "happier", "sadder", "softer", "harder", "deeper", "brighter", "lighter", "louder", "weirder"}


def stem(word: str) -> str:
    w = fold(word).strip("-")
    if not w:
        return w
    return _RU.stemWord(w) if _CYR.search(w) else _EN.stemWord(w)


def _build() -> tuple[dict[str, dict[str, Any]], list[tuple[list[str], dict[str, Any]]]]:
    words: dict[str, dict[str, Any]] = {}
    for forms, eff in WORDS:
        for f in forms:
            s = stem(f)
            if s:
                words.setdefault(s, eff)
            words.setdefault(fold(f), eff)
    phrases = [([stem(w) for w in seq], eff) for seq, eff in PHRASES]
    phrases.sort(key=lambda p: -len(p[0]))
    return words, phrases


LEX, PHR = _build()
_PREFIX_KEYS = sorted((k for k in LEX if len(k) >= 5), key=len, reverse=True)


def _lookup(token_stem: str, raw: str) -> dict[str, Any] | None:
    if token_stem in LEX:
        return LEX[token_stem]
    if raw in LEX:
        return LEX[raw]
    if len(token_stem) >= 5:
        for k in _PREFIX_KEYS:
            if token_stem.startswith(k):
                return LEX[k]
    return None


@dataclass
class Chip:
    label: str
    kind: str  # genre | mood | scene | texture | vocal | tempo | similar | avoid | keyword | llm


@dataclass
class MoodSpec:
    query: str
    tags: dict[str, float] = field(default_factory=dict)
    avoid: dict[str, float] = field(default_factory=dict)
    d_energy: float = 0.0
    d_valence: float = 0.0
    d_atmo: float = 0.0
    bpm_min: float | None = None
    bpm_max: float | None = None
    vocal: str | None = None
    keywords: list[str] = field(default_factory=list)
    similar: bool = False
    comparative: bool = False
    hits: int = 0
    source: str = "rules"
    context_title: str | None = None
    target: tuple[float, float, float] | None = None

    # ------------------------------------------------------------ derived
    @property
    def confidence(self) -> float:
        base = min(1.0, self.hits * 0.34 + (0.2 if self.similar else 0.0))
        if self.keywords and self.hits == 0:
            return 0.0
        penalty = 0.12 * max(0, len(self.keywords) - self.hits)
        return round(max(0.0, base - penalty), 2)

    @property
    def descriptive(self) -> bool:
        return bool(self.tags or self.similar or self.vocal or self.bpm_min or self.bpm_max) and self.confidence >= 0.3

    def finalize(self) -> MoodSpec:
        base = mood_point(self.tags) if self.tags else None
        if base is None and not (self.d_energy or self.d_valence or self.d_atmo):
            self.target = self.target
            return self
        v, e, a = self.target or base or (0.0, 0.5, 0.5)
        clamp = lambda x, lo, hi: max(lo, min(hi, x))  # noqa: E731
        self.target = (
            round(clamp(v + self.d_valence, -1, 1), 3),
            round(clamp(e + self.d_energy, 0, 1), 3),
            round(clamp(a + self.d_atmo, 0, 1), 3),
        )
        return self

    @property
    def energy(self) -> float | None:
        return self.target[1] if self.target else None

    def chips(self) -> list[Chip]:
        out: list[Chip] = []
        if self.similar:
            out.append(Chip(f"похоже на «{self.context_title}»" if self.context_title else "похоже на текущий трек", "similar"))
        for key, _w in sorted(self.tags.items(), key=lambda kv: -kv[1])[:6]:
            tag = BY_KEY.get(key)
            if tag:
                text = "атмосфернее" if (self.comparative and key == "atmospheric") else tag.ru
                out.append(Chip(text, tag.group))
        for key in list(self.avoid)[:3]:
            out.append(Chip(f"без: {label(key)}", "avoid"))
        if self.bpm_min and self.bpm_max:
            out.append(Chip(f"{int(self.bpm_min)}–{int(self.bpm_max)} BPM", "tempo"))
        elif self.bpm_min:
            out.append(Chip("быстрый темп", "tempo"))
        elif self.bpm_max:
            out.append(Chip("медленный темп", "tempo"))
        if self.vocal == "instrumental":
            out.append(Chip("без вокала", "vocal"))
        elif self.vocal == "vocal":
            out.append(Chip("с вокалом", "vocal"))
        for kw in self.keywords[:3]:
            out.append(Chip(kw, "keyword"))
        return out

    def fit(
        self,
        canonical: dict[str, float],
        point: tuple[float, float, float] | None,
        bpm: float | None = None,
        vocal: str | None = None,
    ) -> float:
        pos = cosine(self.tags, canonical) if self.tags else 0.0
        neg = cosine(self.avoid, canonical) if self.avoid else 0.0
        md = 1.0 - mood_distance(self.target, point) if self.target else 0.5
        if (self.bpm_min or self.bpm_max) and bpm:
            lo = self.bpm_min or 0
            hi = self.bpm_max or 999
            # half/double-time tolerance: 70 BPM phonk can be felt as 140
            candidates = [bpm, bpm * 2, bpm / 2]
            bpm_fit = 1.0 if any(lo <= c <= hi for c in candidates) else max(
                0.0, 1 - min(abs(c - (lo if c < lo else hi)) for c in candidates) / 40
            )
        else:
            bpm_fit = 0.5
        vocal_fit = 0.5
        if self.vocal and vocal in ("vocal", "instrumental"):
            vocal_fit = 1.0 if vocal == self.vocal else 0.0
        score = 0.56 * pos + 0.3 * md + 0.08 * bpm_fit + 0.06 * vocal_fit - 0.7 * neg
        return round(max(0.0, min(1.0, score)), 4)

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "descriptive": self.descriptive,
            "confidence": self.confidence,
            "tags": {k: round(v, 2) for k, v in sorted(self.tags.items(), key=lambda kv: -kv[1])},
            "avoid": sorted(self.avoid),
            "target": self.target,
            "bpm": [self.bpm_min, self.bpm_max],
            "vocal": self.vocal,
            "similar": self.similar,
            "keywords": self.keywords,
            "chips": [c.__dict__ for c in self.chips()],
            "source": self.source,
        }


def _apply(spec: MoodSpec, eff: dict[str, Any], *, negate: bool = False, boost: float = 1.0) -> None:
    for k, v in eff.items():
        if k == "_energy":
            spec.d_energy += (-v if negate else v) * boost
        elif k == "_valence":
            spec.d_valence += (-v if negate else v) * boost
        elif k == "_atmo":
            spec.d_atmo += (-v if negate else v) * boost
        elif k == "_tempo":
            fast = (v == "fast") != negate
            if fast:
                spec.bpm_min = spec.bpm_min or 118.0
            else:
                spec.bpm_max = spec.bpm_max or 100.0
        elif k == "_vocal":
            if negate:
                spec.vocal = "instrumental" if v == "vocal" else "vocal"
            else:
                spec.vocal = v
        elif k == "_similar":
            spec.similar = spec.similar or (not negate)
        elif k in BY_KEY:
            if negate:
                spec.avoid[k] = max(spec.avoid.get(k, 0.0), float(v))
            else:
                spec.tags[k] = round(spec.tags.get(k, 0.0) + float(v) * boost, 3)


def interpret(query: str) -> MoodSpec:
    spec = MoodSpec(query=query.strip())
    text = fold(query)
    m = _BPM.search(text)
    if m:
        bpm = float(m.group(1))
        if 40 <= bpm <= 220:
            spec.bpm_min, spec.bpm_max = bpm - 6, bpm + 6
            spec.hits += 1
    if _DEEP_NIGHT.search(text):
        _apply(spec, {"night": 1.0, "lonely": 0.35, "calm": 0.35, "atmospheric": 0.3, "_energy": -0.2})
        spec.hits += 1
        text = _DEEP_NIGHT.sub(" ", text)

    raw_tokens = [t.strip("-") for t in _TOKEN.findall(text)]
    raw_tokens = [t for t in raw_tokens if t]
    stems = [stem(t) for t in raw_tokens]
    used = [False] * len(raw_tokens)

    # phrases first (longest first)
    for seq, eff in PHR:
        n = len(seq)
        for i in range(0, len(stems) - n + 1):
            if any(used[i : i + n]):
                continue
            if stems[i : i + n] == seq:
                _apply(spec, eff)
                spec.hits += 1
                for j in range(i, i + n):
                    used[j] = True

    negate_left = 0
    boost_next = 1.0
    for i, (raw, st) in enumerate(zip(raw_tokens, stems)):
        if used[i]:
            negate_left = max(0, negate_left - 1)
            continue
        if raw in NEGATORS:
            negate_left = 2
            continue
        if raw in ("более", "more", "поострее", "побольше"):
            boost_next = 1.3
            spec.comparative = True
            continue
        eff = _lookup(st, raw)
        if eff is not None:
            comparative = (len(raw) >= 6 and raw.endswith(("ее", "ей")) and _CYR.search(raw) is not None) or raw in _EN_COMPARATIVES
            if comparative:
                spec.comparative = True
            boost = 1.3 if comparative else boost_next
            _apply(spec, eff, negate=negate_left > 0, boost=boost)
            spec.hits += 1
            boost_next = 1.0
        elif raw not in STOPWORDS and st not in STOPWORDS and len(raw) >= 2 and not raw.isdigit():
            spec.keywords.append(raw)
        negate_left = max(0, negate_left - 1)

    # comparatives such as "атмосфернее" shift the target point further
    if spec.comparative and "atmospheric" in spec.tags:
        spec.d_atmo += 0.15
        spec.d_energy -= 0.05
    return spec.finalize()


def apply_context(
    spec: MoodSpec,
    *,
    title: str,
    canonical: dict[str, float],
    bpm: float | None,
    speed: str | None,
) -> MoodSpec:
    """'Что-нибудь похожее на этот трек, но …' — blend the current track into the spec."""
    spec.context_title = title
    explicit = dict(spec.tags)
    merged = {k: round(w * 0.85, 3) for k, w in canonical.items()}
    for k, w in explicit.items():
        merged[k] = round(merged.get(k, 0.0) + w, 3)
    spec.tags = merged
    base = mood_point(canonical, bpm, speed)
    if base is not None:
        spec.target = base
    if bpm and not (spec.bpm_min or spec.bpm_max):
        spec.bpm_min, spec.bpm_max = bpm - 12, bpm + 12
    spec.hits = max(spec.hits, 2)
    return spec.finalize()


# ---------------------------------------------------------------- optional LLM
_LLM_SYSTEM = (
    "You convert music mood requests (Russian or English) into JSON for a music search engine. "
    "Use ONLY these tag keys: {keys}. Answer with a single JSON object: "
    '{{"tags": {{"<key>": weight 0..1.2}}, "avoid": ["<key>"], "energy": 0..1 or null, '
    '"bpm_min": number or null, "bpm_max": number or null, "vocal": "instrumental"|"vocal"|null, '
    '"keywords": ["english search words"]}}. No prose.'
)


async def llm_refine(spec: MoodSpec, client: httpx.AsyncClient) -> MoodSpec:
    s = get_settings()
    if not s.llm_configured:
        return spec
    keys = ", ".join(BY_KEY.keys())
    headers = {"Content-Type": "application/json"}
    if s.llm_api_key:
        headers["Authorization"] = f"Bearer {s.llm_api_key}"
    body = {
        "model": s.llm_model,
        "temperature": 0.1,
        "messages": [
            {"role": "system", "content": _LLM_SYSTEM.format(keys=keys)},
            {"role": "user", "content": spec.query[:300]},
        ],
    }
    try:
        resp = await client.post(
            s.llm_base_url.rstrip("/") + "/chat/completions", json=body, headers=headers, timeout=s.llm_timeout
        )
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"]
        start, end = content.find("{"), content.rfind("}")
        data = json.loads(content[start : end + 1])
    except Exception as exc:  # noqa: BLE001 — the LLM is optional; fall back silently
        log.info("LLM refine skipped: %s", exc.__class__.__name__)
        return spec
    try:
        added = 0
        for k, w in (data.get("tags") or {}).items():
            if k in BY_KEY:
                w = max(0.0, min(1.2, float(w)))
                spec.tags[k] = round(max(spec.tags.get(k, 0.0), w * 0.9), 3)
                added += 1
        for k in data.get("avoid") or []:
            if k in BY_KEY:
                spec.avoid[k] = 1.0
                spec.tags.pop(k, None)
        if data.get("vocal") in ("instrumental", "vocal") and not spec.vocal:
            spec.vocal = data["vocal"]
        for key in ("bpm_min", "bpm_max"):
            val = data.get(key)
            if isinstance(val, (int, float)) and 40 <= val <= 220 and getattr(spec, key) is None:
                setattr(spec, key, float(val))
        for kw in data.get("keywords") or []:
            if isinstance(kw, str) and kw.strip() and len(spec.keywords) < 6:
                spec.keywords.append(kw.strip()[:40])
        if added:
            spec.hits = max(spec.hits, 2)
            spec.source = "rules+llm"
            spec.target = None
            spec.finalize()
            energy = data.get("energy")
            if isinstance(energy, (int, float)) and spec.target:
                spec.target = (spec.target[0], round(max(0.0, min(1.0, float(energy))), 3), spec.target[2])
    except (TypeError, ValueError) as exc:
        log.info("LLM answer ignored: %s", exc)
    return spec
