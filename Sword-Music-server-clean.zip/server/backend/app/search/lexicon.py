"""Russian / English lexicon for natural-language mood search.

Entries are written as ordinary word forms; they are stemmed at import time with
the same Snowball stemmer used for queries, so "мрачная", "мрачное", "мрачнее"
all hit the "мрачный" entry. Effects reference canonical taxonomy keys plus a few
control keys:

  _energy / _valence / _atmo   — shift of the target point in mood space
  _tempo                       — "fast" | "slow"
  _vocal                       — "instrumental" | "vocal"
  _similar                     — the user refers to the current track
"""
from __future__ import annotations

from typing import Any

Effect = dict[str, Any]

WORDS: list[tuple[list[str], Effect]] = [
    # ------------------------------------------------------------ moods
    (["мрачный", "мрачно", "мрак", "мрачняк", "тёмный", "темная", "тьма", "тьмы", "дарк", "dark", "darker", "gloomy", "grim", "noir", "нуар"], {"dark": 1.0, "_valence": -0.3}),
    (["грустный", "грусть", "грустно", "печальный", "печаль", "тоска", "тоскливый", "sad", "sadness", "sorrow"], {"sad": 1.0, "melancholic": 0.5, "_valence": -0.35, "_energy": -0.1}),
    (["меланхолия", "меланхоличный", "меланхолично", "melancholic", "melancholy", "wistful"], {"melancholic": 1.0, "_valence": -0.25}),
    (["одиночество", "одинокий", "одиноко", "lonely", "loneliness", "alone", "solitude"], {"lonely": 1.0, "melancholic": 0.4, "_valence": -0.2}),
    (["спокойный", "спокойно", "тихий", "тихо", "расслабляющий", "расслабиться", "расслабон", "чилл", "чил", "calm", "chill", "relax", "relaxing", "peaceful", "mellow"], {"calm": 1.0, "_energy": -0.25}),
    (["мечтательный", "мечта", "сонный", "воздушный", "dreamy", "ethereal", "hazy"], {"dreamy": 1.0, "atmospheric": 0.3}),
    (["атмосферный", "атмосфера", "атмосферно", "погружение", "погружающий", "atmospheric", "atmosphere", "immersive"], {"atmospheric": 1.0, "_atmo": 0.25}),
    (["загадочный", "таинственный", "мистический", "мистика", "тайна", "mysterious", "mystic", "mystery"], {"mysterious": 1.0}),
    (["жуткий", "страшный", "хоррор", "ужас", "ужасы", "зловещий", "creepy", "horror", "scary", "eerie", "haunting", "ominous"], {"creepy": 1.0, "dark": 0.5}),
    (["напряжённый", "напряжение", "тревожный", "тревога", "саспенс", "tense", "suspense", "anxious", "thriller", "триллер"], {"tense": 1.0}),
    (["эпичный", "эпик", "эпично", "величественный", "мощный", "героический", "epic", "heroic", "majestic", "powerful"], {"epic": 1.0, "cinematic": 0.35, "_energy": 0.15}),
    (["драматичный", "драма", "драматично", "dramatic", "drama"], {"dramatic": 1.0}),
    (["агрессивный", "агрессия", "злой", "злость", "ярость", "яростный", "жёсткий", "жесткий", "aggressive", "angry", "rage", "furious", "brutal"], {"aggressive": 1.0, "_energy": 0.25}),
    (["энергичный", "энергия", "бодрый", "бодро", "драйв", "драйвовый", "заряжающий", "energetic", "energy", "upbeat", "hype", "pumped"], {"energetic": 1.0, "_energy": 0.25}),
    (["уверенный", "уверенность", "дерзкий", "пафосный", "крутой", "confident", "swagger", "bold", "badass", "cool"], {"confident": 1.0}),
    (["гипнотичный", "гипноз", "гипнотический", "психоделический", "психоделика", "hypnotic", "psychedelic", "trippy"], {"hypnotic": 1.0}),
    (["ностальгия", "ностальгический", "ностальгично", "nostalgic", "nostalgia"], {"nostalgic": 1.0}),
    (["романтичный", "романтика", "любовь", "нежный", "нежно", "romantic", "love", "tender", "sensual"], {"romantic": 1.0}),
    (["весёлый", "веселый", "радостный", "радость", "счастливый", "счастье", "позитивный", "happy", "joyful", "cheerful", "fun"], {"happy": 1.0, "_valence": 0.35}),
    (["вдохновляющий", "вдохновение", "мотивирующий", "мотивация", "надежда", "uplifting", "inspiring", "motivational", "hopeful"], {"uplifting": 1.0, "_valence": 0.25}),
    (["эйфория", "эйфоричный", "euphoric", "euphoria"], {"euphoric": 1.0, "_energy": 0.2}),
    # ------------------------------------------------------------ genres
    (["фонк", "phonk", "фонковый"], {"phonk": 1.2, "_energy": 0.15}),
    (["дрифт", "drift", "дрифтовый"], {"phonk": 0.6, "drive": 0.8, "_energy": 0.15}),
    (["мемфис", "memphis"], {"phonk": 0.8, "hiphop": 0.4}),
    (["трэп", "трап", "trap"], {"trap": 1.1}),
    (["рэп", "хип-хоп", "хипхоп", "хип", "rap", "hip-hop", "hiphop"], {"hiphop": 1.1}),
    (["лоуфай", "лофай", "лоу-фай", "lofi", "lo-fi"], {"lofi": 1.2, "calm": 0.3}),
    (["эмбиент", "амбиент", "ambient"], {"ambient": 1.2, "_atmo": 0.2, "_energy": -0.2}),
    (["дроун", "дрон", "drone"], {"drone": 1.1, "ambient": 0.4}),
    (["синтвейв", "синтвэйв", "ретровейв", "synthwave", "retrowave", "outrun"], {"synthwave": 1.2}),
    (["дарксинт", "darksynth"], {"darksynth": 1.2, "dark": 0.4}),
    (["киберпанк", "cyberpunk"], {"darksynth": 0.9, "city": 0.5, "night": 0.3, "dark": 0.3}),
    (["электроника", "электронный", "электронная", "electronic", "electronica", "edm"], {"electronic": 1.0}),
    (["техно", "techno"], {"techno": 1.2}),
    (["хаус", "house"], {"house": 1.1}),
    (["драмнбейс", "dnb", "джангл", "jungle"], {"dnb": 1.2}),
    (["дабстеп", "dubstep", "riddim"], {"dubstep": 1.2}),
    (["транс", "trance", "psytrance"], {"trance": 1.1}),
    (["индастриал", "industrial", "ebm"], {"industrial": 1.1, "dark": 0.3}),
    (["витч-хаус", "witchhouse"], {"witchhouse": 1.2, "dark": 0.4}),
    (["вейпорвейв", "vaporwave"], {"vaporwave": 1.2}),
    (["даунтемпо", "трипхоп", "трип-хоп", "downtempo", "trip-hop", "triphop"], {"downtempo": 1.1}),
    (["метал", "металл", "metal"], {"metal": 1.2, "heavy": 0.4}),
    (["рок", "rock", "гранж", "панк", "punk", "grunge"], {"rock": 1.1}),
    (["пост-рок", "построк", "post-rock", "postrock", "шугейз", "shoegaze"], {"postrock": 1.2, "atmospheric": 0.3}),
    (["инди", "indie"], {"indie": 1.1}),
    (["поп", "pop", "попса"], {"pop": 1.0}),
    (["джаз", "jazz", "джазовый"], {"jazz": 1.2}),
    (["блюз", "blues"], {"blues": 1.2}),
    (["соул", "soul", "rnb", "r&b"], {"rnb": 1.1}),
    (["фанк", "диско", "funk", "disco"], {"funk": 1.1}),
    (["классика", "классический", "classical", "барокко", "baroque", "ноктюрн", "nocturne", "соната", "sonata", "симфония", "symphony"], {"classical": 1.2}),
    (["оркестр", "оркестровый", "оркестровая", "симфонический", "orchestral", "orchestra", "symphonic"], {"orchestral": 1.2, "cinematic": 0.3}),
    (["саундтрек", "кино", "фильм", "кинематографичный", "кинематографично", "soundtrack", "cinematic", "film", "ost"], {"cinematic": 1.2, "_atmo": 0.15}),
    (["фолк", "акустика", "акустический", "folk", "acoustic"], {"folk": 1.1}),
    (["чиптюн", "8-бит", "8бит", "chiptune", "8bit", "8-bit"], {"chiptune": 1.2}),
    (["этника", "этнический", "world", "ethnic"], {"world": 1.0}),
    (["экспериментальный", "эксперимент", "авангард", "experimental", "avant-garde"], {"experimental": 1.1}),
    (["idm", "глитч", "glitch"], {"idm": 1.1}),
    # ------------------------------------------------------------ textures
    (["бас", "басы", "басс", "басовый", "bass", "808"], {"bass_heavy": 1.0}),
    (["тяжёлый", "тяжелый", "тяжело", "heavy"], {"heavy": 0.8, "_energy": 0.2}),
    (["пианино", "фортепиано", "рояль", "piano"], {"piano": 1.1}),
    (["гитара", "гитарный", "guitar"], {"guitar": 1.0}),
    (["синтезатор", "синтезаторы", "синты", "synth", "synths", "synthesizer"], {"synth": 1.0}),
    (["скрипка", "виолончель", "струнные", "violin", "cello", "strings"], {"strings": 1.0}),
    (["хор", "хоровой", "choir", "choral"], {"choir": 1.1}),
    (["барабаны", "ударные", "drums", "percussion"], {"drums": 0.9}),
    (["инструментал", "инструментальный", "инструментальная", "instrumental"], {"_vocal": "instrumental", "instrumental": 0.5}),
    (["вокал", "вокальный", "голос", "vocal", "vocals"], {"_vocal": "vocal", "vocal": 0.5}),
    # ------------------------------------------------------------ scenes & imagery
    (["ночь", "ночной", "ночная", "ночью", "полночь", "night", "nocturnal", "midnight"], {"night": 1.0, "_valence": -0.1, "_atmo": 0.1}),
    (["дождь", "дождливый", "ливень", "гроза", "rain", "rainy", "storm"], {"rain": 1.0, "melancholic": 0.3, "_energy": -0.1}),
    (["город", "городской", "улица", "улицы", "мегаполис", "неон", "неоновый", "city", "urban", "street", "neon"], {"city": 1.0}),
    (["токио", "tokyo", "киото", "осака"], {"japan": 0.9, "city": 0.6}),
    (["япония", "японский", "японская", "japan", "japanese"], {"japan": 1.0}),
    (["аниме", "anime", "манга", "отаку"], {"anime": 1.0, "japan": 0.3}),
    (["злодей", "злодея", "злодеи", "злодейский", "антагонист", "villain", "antagonist", "evil"], {"villain": 1.1, "dark": 0.6, "epic": 0.4, "_valence": -0.3}),
    (["демон", "демонический", "ад", "адский", "demon", "demonic", "hell"], {"villain": 0.6, "dark": 0.8, "creepy": 0.3}),
    (["космос", "космический", "космическая", "звёзды", "звезды", "галактика", "вселенная", "space", "cosmic", "galaxy", "stars", "universe", "interstellar"], {"space": 1.2, "ambient": 0.4, "atmospheric": 0.5, "_atmo": 0.25}),
    (["бесконечность", "бесконечный", "бесконечная", "вечность", "вечный", "infinite", "infinity", "endless", "eternal", "eternity"], {"atmospheric": 0.7, "ambient": 0.5, "drone": 0.3, "space": 0.3, "_atmo": 0.2}),
    (["дорога", "трасса", "машина", "авто", "поездка", "гонка", "гонки", "drive", "driving", "road", "racing", "car"], {"drive": 1.0, "_energy": 0.1}),
    (["тренировка", "тренировки", "спортзал", "зал", "качалка", "бег", "пробежка", "workout", "gym", "training", "running"], {"workout": 1.0, "energetic": 0.5, "_energy": 0.3}),
    (["учёба", "учеба", "работа", "работы", "фокус", "концентрация", "сосредоточиться", "кодинг", "study", "focus", "concentration", "coding", "work"], {"study": 1.0, "calm": 0.3, "_energy": -0.15}),
    (["сон", "сна", "засыпать", "засыпания", "уснуть", "колыбельная", "бессонница", "sleep", "sleeping", "lullaby", "insomnia"], {"sleep": 1.0, "calm": 0.5, "_energy": -0.35}),
    (["размышления", "размышлений", "размышлять", "подумать", "задуматься", "мысли", "философский", "медитация", "медитировать", "thinking", "contemplation", "reflective", "meditation", "meditative"], {"atmospheric": 0.6, "calm": 0.5, "ambient": 0.5, "piano": 0.3, "_energy": -0.2}),
    (["природа", "лес", "океан", "море", "волны", "nature", "forest", "ocean", "sea", "waves"], {"nature": 1.0, "calm": 0.3}),
    (["зима", "зимний", "снег", "холод", "холодный", "мороз", "winter", "snow", "cold", "frozen"], {"winter": 1.0, "atmospheric": 0.3}),
    (["ретро", "винтаж", "80-х", "80х", "восьмидесятые", "retro", "vintage", "80s"], {"retro": 1.0, "synthwave": 0.5}),
    (["битва", "бой", "сражение", "война", "самурай", "меч", "battle", "fight", "war", "samurai", "sword"], {"battle": 1.0, "epic": 0.5, "_energy": 0.25}),
    (["вечеринка", "клуб", "танцы", "танцевальный", "рейв", "party", "club", "dance", "rave"], {"party": 1.0, "energetic": 0.5, "_energy": 0.25}),
    # ------------------------------------------------------------ tempo & control
    (["быстрый", "быстро", "быстрее", "быстрая", "fast", "faster", "quick"], {"_tempo": "fast", "_energy": 0.25}),
    (["медленный", "медленно", "медленнее", "медленная", "неспешный", "slow", "slower"], {"_tempo": "slow", "_energy": -0.25}),
    (["похожее", "похожий", "похожая", "похожие", "похож", "similar", "alike"], {"_similar": True}),
]

# Multi-word expressions (matched on stems, in order).
PHRASES: list[tuple[list[str], Effect]] = [
    (["тяжёлый", "бас"], {"bass_heavy": 1.3, "heavy": 0.3}),
    (["тяжелый", "бас"], {"bass_heavy": 1.3, "heavy": 0.3}),
    (["heavy", "bass"], {"bass_heavy": 1.3, "heavy": 0.3}),
    (["без", "слов"], {"_vocal": "instrumental", "instrumental": 0.6}),
    (["без", "вокала"], {"_vocal": "instrumental", "instrumental": 0.6}),
    (["no", "vocals"], {"_vocal": "instrumental", "instrumental": 0.6}),
    (["женский", "вокал"], {"female_vocal": 1.0, "_vocal": "vocal"}),
    (["мужской", "вокал"], {"male_vocal": 1.0, "_vocal": "vocal"}),
    (["female", "vocals"], {"female_vocal": 1.0, "_vocal": "vocal"}),
    (["male", "vocals"], {"male_vocal": 1.0, "_vocal": "vocal"}),
    (["драм", "энд", "бейс"], {"dnb": 1.2}),
    (["драм", "н", "бейс"], {"dnb": 1.2}),
    (["drum", "and", "bass"], {"dnb": 1.2}),
    (["drum", "n", "bass"], {"dnb": 1.2}),
    (["dark", "ambient"], {"dark_ambient": 1.3}),
    (["дарк", "эмбиент"], {"dark_ambient": 1.3}),
    (["мрачный", "эмбиент"], {"dark_ambient": 1.1}),
    (["главный", "злодей"], {"villain": 1.2, "dark": 0.6, "epic": 0.5, "confident": 0.5, "_valence": -0.3}),
    (["ночной", "город"], {"city": 0.6, "night": 0.6, "synthwave": 0.3}),
    (["night", "drive"], {"drive": 0.6, "night": 0.6, "synthwave": 0.4}),
    (["ночная", "поездка"], {"drive": 0.6, "night": 0.6, "synthwave": 0.4}),
    (["like", "this"], {"_similar": True}),
    (["как", "этот"], {"_similar": True}),
    (["как", "эта"], {"_similar": True}),
    (["в", "духе"], {"_similar": True}),
    (["в", "стиле"], {"_similar": True}),
    (["конец", "света"], {"dark": 0.6, "epic": 0.5, "cinematic": 0.4}),
    (["в", "дождь"], {"rain": 0.5}),
]

STOPWORDS = {
    "музыка", "музыку", "музыки", "музыкой", "песня", "песни", "песню", "песен", "трек", "треки", "трека",
    "треков", "что-нибудь", "что-то", "чтонибудь", "хочу", "хочется", "найди", "найти", "поставь", "включи",
    "дай", "для", "чтобы", "будто", "словно", "как", "типа", "я", "мне", "меня", "мой", "моя", "и", "в", "во",
    "на", "с", "со", "под", "про", "это", "этот", "эту", "эта", "такое", "такой", "немного", "очень", "чуть",
    "какой-нибудь", "но", "а", "или", "из", "к", "по", "о", "об", "от", "у", "же", "ещё", "еще", "более",
    "менее", "самый", "самая", "часа", "часов", "час", "music", "songs", "song", "track", "tracks",
    "something", "some", "for", "the", "a", "an", "to", "of", "in", "with", "me", "i", "my", "vibe", "vibes",
    "feel", "feeling", "mood", "more", "less", "but", "and", "or", "that", "this", "it", "is", "be", "am",
    "playlist", "плейлист", "звучание", "звук", "звучит", "ощущение", "ощущением", "чувство", "настроение",
    "сам", "себя", "всё", "все", "весь", "главный", "bpm", "бпм", "ударов", "минуту",
}

NEGATORS = {"не", "без", "no", "not", "without", "никакого", "никакой", "никаких", "кроме"}
