from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core import ratelimit as rl
from ..core.deps import current_user
from ..core.errors import too_many
from ..db import get_session
from ..models import SearchHistory, User
from ..music.registry import get_registry
from ..music.taxonomy import public_catalog
from .interpreter import interpret
from .service import run_search, suggest

router = APIRouter(prefix="/api/search", tags=["search"])


@router.get("")
async def search(
    q: str = Query(..., min_length=1, max_length=200),
    mode: str = Query("auto", pattern="^(auto|text|mood)$"),
    context: str | None = Query(None, max_length=200),
    record: bool = False,
    limit: int = Query(40, ge=1, le=80),
    sources: str | None = Query(None, max_length=200),
    deep: bool = True,
    version: str = Query("all", pattern="^(all|original|sped|slowed|reverb|nightcore)$"),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    wait = rl.limiter.check(f"search:{user.id}", rl.SEARCH_USER)
    if wait:
        raise too_many(wait)
    provider_filter = {s.strip() for s in sources.split(",") if s.strip()} if sources else None
    return await run_search(
        session,
        get_registry(),
        user,
        q,
        mode=mode,
        context_track_id=context,
        limit=limit,
        record=record,
        provider_filter=provider_filter,
        deep=deep,
        version=version,
    )


@router.get("/suggest")
async def search_suggest(
    q: str = Query("", max_length=100),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    return await suggest(session, user, q)


@router.get("/interpret")
async def search_interpret(q: str = Query(..., min_length=1, max_length=200), _user: User = Depends(current_user)):
    return interpret(q).to_dict()


@router.get("/history")
async def history(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    rows = await session.execute(
        select(SearchHistory)
        .where(SearchHistory.user_id == user.id)
        .order_by(SearchHistory.created_at.desc())
        .limit(100)
    )
    return {
        "items": [
            {"id": h.id, "query": h.query, "kind": h.kind, "results": h.results, "created_at": h.created_at.isoformat()}
            for h in rows.scalars()
        ]
    }


@router.delete("/history")
async def clear_history(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    await session.execute(delete(SearchHistory).where(SearchHistory.user_id == user.id))
    await session.commit()
    return {"ok": True}


@router.delete("/history/{item_id}")
async def delete_history_item(item_id: int, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    await session.execute(delete(SearchHistory).where(SearchHistory.id == item_id, SearchHistory.user_id == user.id))
    await session.commit()
    return {"ok": True}


@router.get("/tags")
async def tags(_user: User = Depends(current_user)):
    return {"tags": public_catalog()}
