"""Listening rooms: REST management + WebSocket sync channel."""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.deps import current_user, websocket_user
from ..core.errors import ApiError, forbidden, not_found
from ..core.security import new_room_code
from ..db import get_session, get_sessionmaker, utcnow
from ..models import Room, RoomMember, Track, User
from ..music.store import track_out
from .manager import RoomError, hub

router = APIRouter(tags=["rooms"])
log = logging.getLogger("sword.rooms")


class RoomIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    allow_member_queue: bool = False
    allow_suggestions: bool = True


class RoomPatch(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=80)
    allow_member_queue: bool | None = None
    allow_suggestions: bool | None = None


async def _room(session: AsyncSession, code: str) -> Room:
    room = (await session.execute(select(Room).where(Room.code == code.upper()))).scalar_one_or_none()
    if room is None or room.closed_at is not None:
        raise not_found("Комната не найдена или закрыта.")
    return room


async def _member(session: AsyncSession, room: Room, user: User) -> RoomMember | None:
    return await session.get(RoomMember, (room.id, user.id))


@router.get("/api/rooms")
async def my_rooms(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    rows = await session.execute(
        select(Room, RoomMember.role)
        .join(RoomMember, RoomMember.room_id == Room.id)
        .where(RoomMember.user_id == user.id, Room.closed_at.is_(None))
        .order_by(Room.created_at.desc())
    )
    out = []
    for room, role in rows.all():
        members = (await session.execute(select(func.count()).select_from(RoomMember).where(RoomMember.room_id == room.id))).scalar_one()
        now_track = None
        if (room.state or {}).get("track_id"):
            t = await session.get(Track, room.state["track_id"])
            now_track = track_out(t) if t else None
        out.append(
            {
                "code": room.code,
                "name": room.name,
                "role": role,
                "members": members,
                "online": len(hub.online_ids(room.id)),
                "now": now_track,
                "playing": bool((room.state or {}).get("playing")),
            }
        )
    return {"rooms": out}


@router.post("/api/rooms")
async def create_room(body: RoomIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    owned = (await session.execute(select(func.count()).select_from(Room).where(Room.owner_id == user.id, Room.closed_at.is_(None)))).scalar_one()
    if owned >= 20:
        raise ApiError(400, "limit", "У вас уже 20 открытых комнат — закройте ненужные.")
    for _ in range(10):
        code = new_room_code()
        if (await session.execute(select(Room.id).where(Room.code == code))).scalar_one_or_none() is None:
            break
    room = Room(code=code, name=body.name.strip(), owner_id=user.id, allow_member_queue=body.allow_member_queue, allow_suggestions=body.allow_suggestions, state={})
    session.add(room)
    await session.flush()
    session.add(RoomMember(room_id=room.id, user_id=user.id, role="owner"))
    await session.commit()
    return {"code": room.code, "name": room.name, "path": f"/room/?code={room.code}"}


@router.post("/api/rooms/{code}/join")
async def join(code: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    room = await _room(session, code)
    if await _member(session, room, user) is None:
        session.add(RoomMember(room_id=room.id, user_id=user.id, role="member"))
        await session.commit()
        await hub.push_state(room.id)
    return {"code": room.code, "name": room.name}


@router.get("/api/rooms/{code}")
async def room_info(code: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    room = await _room(session, code)
    member = await _member(session, room, user)
    if member is None:
        return {"joined": False, "room": {"code": room.code, "name": room.name}}
    snap = await hub.snapshot(session, room)
    return {"joined": True, **snap}


@router.patch("/api/rooms/{code}")
async def update_room(code: str, body: RoomPatch, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    room = await _room(session, code)
    if room.owner_id != user.id:
        raise forbidden("Настройки комнаты меняет только владелец.")
    if body.name is not None:
        room.name = body.name.strip()
    if body.allow_member_queue is not None:
        room.allow_member_queue = body.allow_member_queue
    if body.allow_suggestions is not None:
        room.allow_suggestions = body.allow_suggestions
    await session.commit()
    await hub.push_state(room.id)
    return {"ok": True}


@router.post("/api/rooms/{code}/leave")
async def leave(code: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    room = await _room(session, code)
    if room.owner_id == user.id:
        raise ApiError(400, "owner_leave", "Владелец не может выйти — закройте комнату.")
    await session.execute(delete(RoomMember).where(RoomMember.room_id == room.id, RoomMember.user_id == user.id))
    await session.commit()
    await hub.push_state(room.id)
    return {"ok": True}


@router.delete("/api/rooms/{code}/members/{user_id}")
async def kick(code: str, user_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    room = await _room(session, code)
    if room.owner_id != user.id or user_id == user.id:
        raise forbidden("Удалять участников может только владелец.")
    await session.execute(delete(RoomMember).where(RoomMember.room_id == room.id, RoomMember.user_id == user_id))
    await session.commit()
    for ws, uid in list(hub.connections.get(room.id, {}).items()):
        if uid == user_id:
            try:
                await ws.send_json({"t": "kicked"})
                await ws.close(code=4003)
            except Exception:  # noqa: BLE001
                pass
            await hub.disconnect(room.id, ws)
    await hub.push_state(room.id)
    return {"ok": True}


@router.delete("/api/rooms/{code}")
async def close_room(code: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    room = await _room(session, code)
    if room.owner_id != user.id:
        raise forbidden("Закрыть комнату может только владелец.")
    room.closed_at = utcnow()
    await session.commit()
    await hub.close_room(room.id)
    return {"ok": True}


@router.websocket("/api/rooms/{code}/ws")
async def room_socket(ws: WebSocket, code: str):
    user = await websocket_user(ws)
    if user is None:
        await ws.close(code=4401)
        return
    async with get_sessionmaker()() as session:
        room = (await session.execute(select(Room).where(Room.code == code.upper()))).scalar_one_or_none()
        if room is None or room.closed_at is not None:
            await ws.close(code=4404)
            return
        if await session.get(RoomMember, (room.id, user.id)) is None:
            await ws.close(code=4403)
            return
        room_id = room.id
    await ws.accept()
    await hub.connect(room_id, ws, user.id)
    await hub.push_state(room_id)
    try:
        while True:
            raw = await ws.receive_text()
            if len(raw) > 4000:
                continue
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if not isinstance(msg, dict):
                continue
            try:
                reply = await hub.handle(room_id, user.id, msg)
            except RoomError as exc:
                reply = {"t": "error", "message": exc.message}
            except Exception:  # noqa: BLE001
                log.exception("room message failed")
                reply = {"t": "error", "message": "Ошибка обработки команды."}
            if reply is not None:
                await ws.send_json(reply)
    except WebSocketDisconnect:
        pass
    finally:
        await hub.disconnect(room_id, ws)
        try:
            await hub.push_state(room_id)
        except Exception:  # noqa: BLE001
            pass
