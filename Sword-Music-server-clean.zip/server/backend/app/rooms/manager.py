"""In-process room hub: WebSocket connections, authoritative playback clock, queue logic.

Single-process by design (fits a group of friends). For several server workers
put a pub/sub (e.g. Redis) behind `broadcast` — the rest stays the same.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from typing import Any

from fastapi import WebSocket
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.storage import media_url
from ..db import get_sessionmaker
from ..models import Room, RoomMember, RoomQueueItem, Track, User
from ..music.store import track_out

log = logging.getLogger("sword.rooms")


def now_ms() -> int:
    return int(time.time() * 1000)


class RoomError(Exception):
    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class RoomHub:
    def __init__(self) -> None:
        self.connections: dict[str, dict[WebSocket, str]] = defaultdict(dict)  # room_id -> ws -> user_id
        self.locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self.timers: dict[str, asyncio.Task[None]] = {}

    # ------------------------------------------------------------------ presence
    def online_ids(self, room_id: str) -> set[str]:
        return set(self.connections.get(room_id, {}).values())

    async def connect(self, room_id: str, ws: WebSocket, user_id: str) -> None:
        self.connections[room_id][ws] = user_id

    async def disconnect(self, room_id: str, ws: WebSocket) -> None:
        self.connections.get(room_id, {}).pop(ws, None)
        if not self.connections.get(room_id):
            self.connections.pop(room_id, None)

    async def broadcast(self, room_id: str, message: dict[str, Any]) -> None:
        dead = []
        for ws in list(self.connections.get(room_id, {}).keys()):
            try:
                await ws.send_json(message)
            except Exception:  # noqa: BLE001 — a closed socket must not break the room
                dead.append(ws)
        for ws in dead:
            await self.disconnect(room_id, ws)

    # ------------------------------------------------------------------ state
    @staticmethod
    def position(state: dict[str, Any]) -> int:
        pos = int(state.get("position_ms") or 0)
        if state.get("playing"):
            pos += max(0, now_ms() - int(state.get("server_ts") or now_ms()))
        return pos

    async def snapshot(self, session: AsyncSession, room: Room) -> dict[str, Any]:
        members = (
            await session.execute(
                select(RoomMember, User).join(User, User.id == RoomMember.user_id).where(RoomMember.room_id == room.id)
            )
        ).all()
        online = self.online_ids(room.id)
        items = (
            await session.execute(
                select(RoomQueueItem, Track)
                .join(Track, Track.id == RoomQueueItem.track_id)
                .where(RoomQueueItem.room_id == room.id, RoomQueueItem.status.in_(("queued", "suggested")))
                .order_by(RoomQueueItem.position, RoomQueueItem.id)
            )
        ).all()
        names = {u.id: u.display_name for _, u in members}
        queue, suggestions = [], []
        for it, t in items:
            entry = {"item_id": it.id, "track": track_out(t), "added_by": names.get(it.added_by or "", "?"), "added_by_id": it.added_by}
            (queue if it.status == "queued" else suggestions).append(entry)
        state = dict(room.state or {})
        now_track = None
        if state.get("track_id"):
            t = await session.get(Track, state["track_id"])
            now_track = track_out(t) if t else None
        return {
            "t": "state",
            "room": {
                "id": room.id,
                "code": room.code,
                "name": room.name,
                "owner_id": room.owner_id,
                "allow_member_queue": room.allow_member_queue,
                "allow_suggestions": room.allow_suggestions,
                "closed": room.closed_at is not None,
            },
            "members": [
                {
                    "id": u.id,
                    "name": u.display_name,
                    "avatar": media_url(u.avatar_path),
                    "role": m.role,
                    "online": u.id in online,
                }
                for m, u in sorted(members, key=lambda mu: (mu[0].role != "owner", mu[1].display_name.lower()))
            ],
            "now": {
                "item_id": state.get("item_id"),
                "track": now_track,
                "playing": bool(state.get("playing")) and now_track is not None,
                "position_ms": self.position(state) if now_track else 0,
                "server_ts": now_ms(),
            },
            "queue": queue,
            "suggestions": suggestions,
        }

    async def push_state(self, room_id: str) -> None:
        async with get_sessionmaker()() as session:
            room = await session.get(Room, room_id)
            if room is None:
                return
            snap = await self.snapshot(session, room)
        await self.broadcast(room_id, snap)

    # ------------------------------------------------------------------ playback
    def _schedule_advance(self, room_id: str, state: dict[str, Any], duration: float | None) -> None:
        old = self.timers.pop(room_id, None)
        if old:
            old.cancel()
        if not state.get("playing") or not duration:
            return
        remaining = duration * 1000 - self.position(state)
        item_id = state.get("item_id")

        async def _later() -> None:
            try:
                await asyncio.sleep(max(0.5, remaining / 1000 + 1.5))
                await self.advance(room_id, expected_item=item_id)
            except asyncio.CancelledError:
                pass
            except Exception:  # noqa: BLE001
                log.exception("room auto-advance failed")

        self.timers[room_id] = asyncio.create_task(_later())

    async def _save_state(self, session: AsyncSession, room: Room, state: dict[str, Any]) -> None:
        room.state = state
        await session.commit()
        duration = None
        if state.get("track_id"):
            t = await session.get(Track, state["track_id"])
            duration = t.duration if t else None
        self._schedule_advance(room.id, state, duration)

    async def advance(self, room_id: str, expected_item: int | None = None) -> None:
        async with self.locks[room_id]:
            async with get_sessionmaker()() as session:
                room = await session.get(Room, room_id)
                if room is None or room.closed_at:
                    return
                state = dict(room.state or {})
                if expected_item is not None and state.get("item_id") != expected_item:
                    return
                if state.get("item_id"):
                    cur = await session.get(RoomQueueItem, state["item_id"])
                    if cur is not None:
                        cur.status = "played"
                nxt = (
                    await session.execute(
                        select(RoomQueueItem)
                        .where(RoomQueueItem.room_id == room.id, RoomQueueItem.status == "queued", RoomQueueItem.id != (state.get("item_id") or -1))
                        .order_by(RoomQueueItem.position, RoomQueueItem.id)
                        .limit(1)
                    )
                ).scalar_one_or_none()
                if nxt is None:
                    new_state = {"item_id": None, "track_id": None, "playing": False, "position_ms": 0, "server_ts": now_ms()}
                else:
                    new_state = {"item_id": nxt.id, "track_id": nxt.track_id, "playing": True, "position_ms": 0, "server_ts": now_ms()}
                await self._save_state(session, room, new_state)
        await self.push_state(room_id)

    async def handle(self, room_id: str, user_id: str, msg: dict[str, Any]) -> dict[str, Any] | None:
        kind = msg.get("t")
        if kind == "ping":
            return {"t": "pong", "c": msg.get("c"), "s": now_ms()}
        advance_from: int | None = None
        async with self.locks[room_id]:
            async with get_sessionmaker()() as session:
                room = await session.get(Room, room_id)
                if room is None or room.closed_at:
                    raise RoomError("Комната закрыта.")
                is_owner = room.owner_id == user_id
                state = dict(room.state or {})
                changed = True
                if kind in ("play", "pause", "seek"):
                    if not is_owner:
                        raise RoomError("Управлять воспроизведением может только владелец комнаты.")
                    if not state.get("track_id"):
                        changed = False
                    else:
                        pos = msg.get("pos")
                        cur = self.position(state)
                        if kind == "seek" and isinstance(pos, (int, float)):
                            cur = max(0, int(pos))
                        if kind == "pause" and isinstance(pos, (int, float)):
                            cur = max(0, int(pos))
                        state.update(position_ms=cur, server_ts=now_ms(), playing=(kind == "play") or (kind == "seek" and state.get("playing", False)))
                        await self._save_state(session, room, state)
                elif kind in ("next", "ended"):
                    if not is_owner:
                        raise RoomError("Переключать треки может только владелец.")
                    changed = False
                    if not (kind == "ended" and msg.get("item_id") not in (None, state.get("item_id"))):
                        advance_from = state.get("item_id") or -1
                elif kind in ("queue_add", "suggest"):
                    tid = str(msg.get("track_id") or "")
                    t = await session.get(Track, tid)
                    if t is None or t.owner_id is not None:
                        raise RoomError("Этот трек нельзя добавить в комнату (личные файлы не транслируются).")
                    if t.stream_kind == "embed":
                        raise RoomError("Треки YouTube пока нельзя слушать в комнате вместе: их плеер не синхронизируется.")
                    if t.stream_kind != "full" or t.unavailable_reason:
                        raise RoomError("В комнату можно добавлять только полностью доступные треки.")
                    direct = kind == "queue_add" and (is_owner or room.allow_member_queue)
                    if not direct and not room.allow_suggestions and not is_owner:
                        raise RoomError("Владелец отключил предложения треков.")
                    maxpos = (
                        await session.execute(select(func.coalesce(func.max(RoomQueueItem.position), 0)).where(RoomQueueItem.room_id == room.id))
                    ).scalar_one()
                    item = RoomQueueItem(room_id=room.id, track_id=t.id, added_by=user_id, status="queued" if direct else "suggested", position=float(maxpos) + 1)
                    session.add(item)
                    await session.commit()
                    if direct and not state.get("track_id"):
                        state = {"item_id": item.id, "track_id": t.id, "playing": True, "position_ms": 0, "server_ts": now_ms()}
                        await self._save_state(session, room, state)
                elif kind in ("accept", "reject"):
                    if not is_owner:
                        raise RoomError("Принимать предложения может только владелец.")
                    item = await session.get(RoomQueueItem, int(msg.get("item_id") or 0))
                    if item is None or item.room_id != room.id or item.status != "suggested":
                        raise RoomError("Предложение не найдено.")
                    item.status = "queued" if kind == "accept" else "rejected"
                    await session.commit()
                    if kind == "accept" and not state.get("track_id"):
                        state = {"item_id": item.id, "track_id": item.track_id, "playing": True, "position_ms": 0, "server_ts": now_ms()}
                        await self._save_state(session, room, state)
                elif kind == "remove":
                    item = await session.get(RoomQueueItem, int(msg.get("item_id") or 0))
                    if item is None or item.room_id != room.id:
                        raise RoomError("Элемент не найден.")
                    if not is_owner and item.added_by != user_id:
                        raise RoomError("Можно удалять только свои треки.")
                    item.status = "rejected"
                    await session.commit()
                elif kind == "move":
                    if not is_owner:
                        raise RoomError("Менять порядок может только владелец.")
                    rows = list(
                        (
                            await session.execute(
                                select(RoomQueueItem).where(RoomQueueItem.room_id == room.id, RoomQueueItem.status == "queued").order_by(RoomQueueItem.position, RoomQueueItem.id)
                            )
                        ).scalars()
                    )
                    iid = int(msg.get("item_id") or 0)
                    to = max(0, min(len(rows) - 1, int(msg.get("to") or 0)))
                    moving = next((r for r in rows if r.id == iid), None)
                    if moving is None:
                        raise RoomError("Элемент не найден.")
                    rows.remove(moving)
                    rows.insert(to, moving)
                    for i, r in enumerate(rows):
                        r.position = float(i + 1)
                    await session.commit()
                elif kind == "play_item":
                    if not is_owner:
                        raise RoomError("Только владелец может выбрать трек.")
                    item = await session.get(RoomQueueItem, int(msg.get("item_id") or 0))
                    if item is None or item.room_id != room.id or item.status != "queued":
                        raise RoomError("Элемент не найден.")
                    if state.get("item_id"):
                        cur = await session.get(RoomQueueItem, state["item_id"])
                        if cur is not None and cur.id != item.id:
                            cur.status = "played"
                    state = {"item_id": item.id, "track_id": item.track_id, "playing": True, "position_ms": 0, "server_ts": now_ms()}
                    await self._save_state(session, room, state)
                else:
                    changed = False
        if advance_from is not None:
            await self.advance(room_id, expected_item=advance_from if advance_from != -1 else None)
        elif changed:
            await self.push_state(room_id)
        return None

    async def close_room(self, room_id: str) -> None:
        timer = self.timers.pop(room_id, None)
        if timer:
            timer.cancel()
        await self.broadcast(room_id, {"t": "closed"})
        for ws in list(self.connections.get(room_id, {}).keys()):
            try:
                await ws.close(code=4000)
            except Exception:  # noqa: BLE001
                pass
        self.connections.pop(room_id, None)

    async def shutdown(self) -> None:
        for task in self.timers.values():
            task.cancel()
        self.timers.clear()


hub = RoomHub()


async def restore_rooms() -> None:
    """After a restart rooms resume paused at their last position."""
    async with get_sessionmaker()() as session:
        rows = await session.execute(select(Room).where(Room.closed_at.is_(None)))
        for room in rows.scalars():
            st = dict(room.state or {})
            if st.get("playing"):
                st["position_ms"] = RoomHub.position(st)
                st["playing"] = False
                st["server_ts"] = now_ms()
                room.state = st
        await session.commit()

