"""Registration (invite-only), login/logout, password recovery and session management."""
from __future__ import annotations

import hmac
import logging
from datetime import timedelta

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..core import ratelimit as rl
from ..core.deps import SESSION_COOKIE, client_ip, current_user, optional_user
from ..core.errors import ApiError, too_many
from ..core.mailer import send_mail
from ..core.security import (
    DUMMY_HASH,
    hash_password,
    needs_rehash,
    new_token,
    password_problem,
    token_hash,
    verify_password,
)
from ..db import get_session, utcnow
from ..models import Invite, PasswordReset, User, UserSession
from ..users.schemas import user_out

router = APIRouter(prefix="/api/auth", tags=["auth"])
log = logging.getLogger("sword.auth")


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=200)
    display_name: str = Field(min_length=1, max_length=40)
    invite_code: str | None = Field(default=None, max_length=40)
    setup_code: str | None = Field(default=None, max_length=40)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=200)


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)
    password: str = Field(min_length=1, max_length=200)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=200)
    new_password: str = Field(min_length=1, max_length=200)


def _norm_email(email: str) -> str:
    return email.strip().lower()


def set_session_cookie(response: Response, token: str) -> None:
    s = get_settings()
    response.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=s.session_days * 86400,
        httponly=True,
        secure=s.secure_cookies,
        samesite="lax",
        path="/",
    )


async def create_session(session: AsyncSession, user: User, request: Request) -> str:
    token = new_token()
    now = utcnow()
    session.add(
        UserSession(
            user_id=user.id,
            token_hash=token_hash(token),
            user_agent=(request.headers.get("user-agent") or "")[:255],
            ip=client_ip(request),
            created_at=now,
            last_used_at=now,
            expires_at=now + timedelta(days=get_settings().session_days),
        )
    )
    return token


async def invite_state(session: AsyncSession, code: str) -> tuple[Invite | None, str | None]:
    code = code.strip().upper()
    inv = (await session.execute(select(Invite).where(Invite.code == code))).scalar_one_or_none()
    if inv is None:
        return None, "Приглашение не найдено."
    if inv.revoked_at is not None:
        return inv, "Приглашение отозвано."
    if inv.expires_at is not None and inv.expires_at <= utcnow():
        return inv, "Срок действия приглашения истёк."
    if inv.uses >= inv.max_uses:
        return inv, "Приглашение уже использовано."
    return inv, None


@router.get("/status")
async def status(session: AsyncSession = Depends(get_session), user: User | None = Depends(optional_user)):
    s = get_settings()
    users = (await session.execute(select(func.count()).select_from(User))).scalar_one()
    return {
        "setup_required": users == 0,
        "registration_mode": s.registration_mode,
        "email_enabled": s.smtp_configured,
        "authenticated": user is not None,
        "version": "1.0.0",
    }


@router.get("/invite/{code}")
async def check_invite(code: str, request: Request, session: AsyncSession = Depends(get_session)):
    wait = rl.limiter.check(f"invite:{client_ip(request)}", rl.INVITE_CHECK)
    if wait:
        raise too_many(wait)
    _inv, problem = await invite_state(session, code)
    return {"valid": problem is None, "reason": problem}


@router.post("/register")
async def register(
    body: RegisterIn,
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_session),
):
    s = get_settings()
    wait = rl.limiter.check(f"register:{client_ip(request)}", rl.REGISTER_IP)
    if wait:
        raise too_many(wait)

    email = _norm_email(body.email)
    problem = password_problem(body.password, email)
    if problem:
        raise ApiError(400, "weak_password", problem)
    display_name = " ".join(body.display_name.split())[:40]
    if not display_name:
        raise ApiError(400, "bad_name", "Укажите имя.")

    users_count = (await session.execute(select(func.count()).select_from(User))).scalar_one()
    is_first = users_count == 0
    invite: Invite | None = None

    if is_first:
        supplied = (body.setup_code or "").strip().upper()
        if not supplied or not hmac.compare_digest(supplied, s.setup_code):
            raise ApiError(
                403,
                "setup_code_required",
                "Для создания первого (администраторского) аккаунта нужен код настройки из консоли сервера.",
            )
    else:
        if s.registration_mode == "closed":
            raise ApiError(403, "registration_closed", "Регистрация закрыта администратором.")
        if not body.invite_code:
            raise ApiError(403, "invite_required", "Регистрация доступна только по приглашению.")
        invite, inv_problem = await invite_state(session, body.invite_code)
        if inv_problem:
            raise ApiError(403, "invite_invalid", inv_problem)

    exists = (await session.execute(select(User.id).where(User.email == email))).scalar_one_or_none()
    if exists:
        raise ApiError(409, "email_taken", "Этот e-mail уже зарегистрирован.")

    if invite is not None:
        # Atomic consumption — protects against two people racing for the last use.
        res = await session.execute(
            update(Invite)
            .where(Invite.id == invite.id, Invite.uses < Invite.max_uses, Invite.revoked_at.is_(None))
            .values(uses=Invite.uses + 1)
        )
        if res.rowcount != 1:
            raise ApiError(403, "invite_invalid", "Приглашение уже использовано.")

    user = User(
        email=email,
        password_hash=hash_password(body.password),
        display_name=display_name,
        is_admin=is_first,
        invited_by=invite.created_by if invite else None,
        settings={},
    )
    session.add(user)
    await session.flush()
    token = await create_session(session, user, request)
    await session.commit()
    set_session_cookie(response, token)
    log.info("User registered (admin=%s)", is_first)
    return {"user": user_out(user)}


@router.post("/login")
async def login(
    body: LoginIn,
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_session),
):
    ip = client_ip(request)
    email = _norm_email(body.email)
    wait = rl.limiter.check(f"login-ip:{ip}", rl.LOGIN_IP)
    if wait:
        raise too_many(wait, "Слишком много попыток входа. Попробуйте позже.")
    fail_key = f"login-fail:{email}"
    wait = rl.limiter.check(fail_key, rl.LOGIN_FAIL_EMAIL, consume=False)
    if wait:
        raise too_many(wait, "Слишком много неудачных попыток для этого аккаунта. Подождите немного.")

    user = (await session.execute(select(User).where(User.email == email))).scalar_one_or_none()
    ok = verify_password(user.password_hash if user else DUMMY_HASH, body.password)
    if not user or not ok or not user.is_active:
        rl.limiter.hit(fail_key)
        if user and ok and not user.is_active:
            raise ApiError(403, "disabled", "Аккаунт отключён администратором.")
        raise ApiError(401, "invalid_credentials", "Неверный e-mail или пароль.")

    rl.limiter.reset(fail_key)
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    token = await create_session(session, user, request)
    await session.commit()
    set_session_cookie(response, token)
    out = {"user": user_out(user)}
    if request.query_params.get("token") == "1":
        out["token"] = token
    return out


@router.post("/logout")
async def logout(request: Request, response: Response, session: AsyncSession = Depends(get_session), user: User | None = Depends(optional_user)):
    sid = getattr(request.state, "session_id", None)
    if user is not None and sid:
        await session.execute(delete(UserSession).where(UserSession.id == sid))
        await session.commit()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@router.get("/me")
async def me(user: User = Depends(current_user)):
    return {"user": user_out(user)}


async def issue_reset_token(session: AsyncSession, user: User) -> str:
    token = new_token()
    session.add(
        PasswordReset(
            user_id=user.id,
            token_hash=token_hash(token),
            expires_at=utcnow() + timedelta(hours=2),
        )
    )
    return token


def reset_link(token: str) -> str:
    return f"{get_settings().public_url.rstrip('/')}/reset/?token={token}"


@router.post("/password/forgot")
async def forgot(body: ForgotIn, request: Request, session: AsyncSession = Depends(get_session)):
    s = get_settings()
    email = _norm_email(body.email)
    wait = rl.limiter.check(f"forgot:{client_ip(request)}:{email}", rl.FORGOT)
    if wait:
        raise too_many(wait)
    user = (await session.execute(select(User).where(User.email == email))).scalar_one_or_none()
    if user and user.is_active and s.smtp_configured:
        token = await issue_reset_token(session, user)
        await session.commit()
        await send_mail(
            user.email,
            "Sword Music — восстановление доступа",
            "Чтобы задать новый пароль, откройте ссылку (действует 2 часа):\n\n"
            f"{reset_link(token)}\n\nЕсли вы не запрашивали сброс, просто проигнорируйте письмо.",
        )
    return {"ok": True, "email_enabled": s.smtp_configured}


@router.post("/password/reset")
async def reset_password(body: ResetIn, session: AsyncSession = Depends(get_session)):
    row = (
        await session.execute(select(PasswordReset).where(PasswordReset.token_hash == token_hash(body.token)))
    ).scalar_one_or_none()
    if row is None or row.used_at is not None or row.expires_at <= utcnow():
        raise ApiError(400, "reset_invalid", "Ссылка для сброса недействительна или устарела.")
    user = await session.get(User, row.user_id)
    if user is None or not user.is_active:
        raise ApiError(400, "reset_invalid", "Ссылка для сброса недействительна или устарела.")
    problem = password_problem(body.password, user.email)
    if problem:
        raise ApiError(400, "weak_password", problem)
    user.password_hash = hash_password(body.password)
    row.used_at = utcnow()
    await session.execute(delete(UserSession).where(UserSession.user_id == user.id))
    await session.commit()
    rl.limiter.reset(f"login-fail:{user.email}")
    return {"ok": True}


@router.post("/password/change")
async def change_password(
    body: ChangePasswordIn,
    request: Request,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    if not verify_password(user.password_hash, body.current_password):
        raise ApiError(400, "wrong_password", "Текущий пароль указан неверно.")
    problem = password_problem(body.new_password, user.email)
    if problem:
        raise ApiError(400, "weak_password", problem)
    db_user = await session.get(User, user.id)
    assert db_user is not None
    db_user.password_hash = hash_password(body.new_password)
    sid = getattr(request.state, "session_id", None)
    # Log out every other device.
    await session.execute(delete(UserSession).where(UserSession.user_id == user.id, UserSession.id != sid))
    await session.commit()
    return {"ok": True}


@router.get("/sessions")
async def list_sessions(request: Request, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    rows = (
        await session.execute(
            select(UserSession).where(UserSession.user_id == user.id).order_by(UserSession.last_used_at.desc())
        )
    ).scalars()
    sid = getattr(request.state, "session_id", None)
    return {
        "sessions": [
            {
                "id": r.id,
                "user_agent": r.user_agent,
                "ip": r.ip,
                "created_at": r.created_at.isoformat(),
                "last_used_at": r.last_used_at.isoformat(),
                "current": r.id == sid,
            }
            for r in rows
        ]
    }


@router.delete("/sessions/{session_id}")
async def revoke_session(session_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    await session.execute(delete(UserSession).where(UserSession.id == session_id, UserSession.user_id == user.id))
    await session.commit()
    return {"ok": True}
