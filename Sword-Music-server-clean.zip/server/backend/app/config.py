"""Application settings.

All configuration comes from environment variables (or a `.env` file).
See `.env.example` in the repository root for documentation of every value.
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(str(ROOT_DIR / ".env"), ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- core -------------------------------------------------------------
    env: str = Field("development", alias="SWORD_ENV")  # development | production | test
    secret_key: str = Field("", alias="SECRET_KEY")
    # empty = SQLite file in DATA_DIR (resolved below, independent of the current folder)
    database_url: str = Field("", alias="DATABASE_URL")
    data_dir: Path = Field(ROOT_DIR / "data", alias="DATA_DIR")
    frontend_dist: Path = Field(ROOT_DIR / "frontend" / "out", alias="FRONTEND_DIST")
    public_url: str = Field("http://localhost:8000", alias="PUBLIC_URL")
    cors_origins: str = Field("", alias="CORS_ORIGINS")  # comma separated, only for dev setups
    trust_proxy: bool = Field(False, alias="TRUST_PROXY")
    cookie_secure: bool | None = Field(None, alias="COOKIE_SECURE")
    session_days: int = Field(30, alias="SESSION_DAYS")
    log_level: str = Field("INFO", alias="LOG_LEVEL")

    # --- registration -----------------------------------------------------
    registration_mode: str = Field("invite", alias="REGISTRATION_MODE")  # invite | closed

    # --- music providers --------------------------------------------------
    providers_enabled: str = Field(
        "itunes,musicbrainz,youtube_link,soundcloud,spotify_link,audius,jamendo,archive,wikimedia,youtube,uploads", alias="PROVIDERS_ENABLED"
    )
    genius_access_token: str = Field("", alias="GENIUS_ACCESS_TOKEN")
    lyrics_enabled: bool = Field(True, alias="LYRICS_ENABLED")
    youtube_api_key: str = Field("", alias="YOUTUBE_API_KEY")
    youtube_daily_searches: int = Field(95, alias="YOUTUBE_DAILY_SEARCHES")
    app_contact: str = Field("", alias="APP_CONTACT")  # e-mail or URL for User-Agent headers
    audius_app_name: str = Field("SwordMusic", alias="AUDIUS_APP_NAME")
    audius_api_key: str = Field("", alias="AUDIUS_API_KEY")
    audius_base_url: str = Field("https://api.audius.co", alias="AUDIUS_BASE_URL")
    jamendo_client_id: str = Field("", alias="JAMENDO_CLIENT_ID")
    deezer_enabled: bool = Field(False, alias="DEEZER_ENABLED")
    provider_timeout: float = Field(8.0, alias="PROVIDER_TIMEOUT")

    # --- uploads ----------------------------------------------------------
    upload_max_mb: int = Field(60, alias="UPLOAD_MAX_MB")
    upload_quota_mb: int = Field(2048, alias="UPLOAD_QUOTA_MB")

    # --- optional language model for mood search ---------------------------
    llm_base_url: str = Field("", alias="LLM_BASE_URL")
    llm_api_key: str = Field("", alias="LLM_API_KEY")
    llm_model: str = Field("", alias="LLM_MODEL")
    llm_timeout: float = Field(8.0, alias="LLM_TIMEOUT")

    # --- optional e-mail --------------------------------------------------
    smtp_host: str = Field("", alias="SMTP_HOST")
    smtp_port: int = Field(587, alias="SMTP_PORT")
    smtp_user: str = Field("", alias="SMTP_USER")
    smtp_password: str = Field("", alias="SMTP_PASSWORD")
    smtp_from: str = Field("", alias="SMTP_FROM")
    smtp_tls: bool = Field(True, alias="SMTP_TLS")

    @field_validator("data_dir", "frontend_dist", mode="before")
    @classmethod
    def _expand(cls, v):  # noqa: N805
        return Path(v).expanduser() if v else v

    @model_validator(mode="after")
    def _resolve_database(self):
        """Default to DATA_DIR/sword.db; relative SQLite paths are taken from the project root, not the current folder."""
        url = self.database_url.strip()
        if not url:
            url = f"sqlite+aiosqlite:///{(self.data_dir / 'sword.db').as_posix()}"
        elif url.startswith("sqlite") and ":///" in url:
            prefix, raw = url.split(":///", 1)
            if raw and raw != ":memory:" and not Path(raw).is_absolute() and not raw.startswith("/"):
                url = f"{prefix}:///{(ROOT_DIR / raw).resolve().as_posix()}"
        self.database_url = url
        return self

    @property
    def sqlite_file(self) -> Path | None:
        if not self.database_url.startswith("sqlite") or ":///" not in self.database_url:
            return None
        raw = self.database_url.split(":///", 1)[1].split("?", 1)[0]
        return None if not raw or raw == ":memory:" else Path(raw)

    # ------------------------------------------------------------------
    @property
    def is_test(self) -> bool:
        return self.env == "test"

    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def effective_secret(self) -> str:
        """Secret used for HMAC derivations.

        In production SECRET_KEY is mandatory (checked at startup). In development
        a key is generated once and stored in the data directory so that sessions
        and the setup code survive restarts.
        """
        if self.secret_key:
            return self.secret_key
        key_file = self.data_dir / ".secret_key"
        try:
            if key_file.exists():
                return key_file.read_text().strip()
            self.data_dir.mkdir(parents=True, exist_ok=True)
            key = secrets.token_urlsafe(48)
            key_file.write_text(key)
            return key
        except OSError:
            # Read-only file system: fall back to a per-process key.
            if not hasattr(self, "_ephemeral_secret"):
                object.__setattr__(self, "_ephemeral_secret", secrets.token_urlsafe(48))
            return object.__getattribute__(self, "_ephemeral_secret")

    @property
    def secure_cookies(self) -> bool:
        if self.cookie_secure is not None:
            return self.cookie_secure
        return self.public_url.startswith("https://")

    @property
    def enabled_provider_ids(self) -> list[str]:
        ids = [p.strip().lower() for p in self.providers_enabled.split(",") if p.strip()]
        if self.deezer_enabled and "deezer" not in ids:
            ids.append("deezer")
        if self.is_test and "fixture" not in ids:
            ids.append("fixture")
        return ids

    @property
    def user_agent(self) -> str:
        contact = self.app_contact or self.public_url
        return f"SwordMusic/1.0 (+{contact}; personal non-commercial music player)"

    @property
    def smtp_configured(self) -> bool:
        return bool(self.smtp_host and self.smtp_from)

    @property
    def llm_configured(self) -> bool:
        return bool(self.llm_base_url and self.llm_model)

    def derive(self, purpose: str) -> str:
        return hmac.new(
            self.effective_secret.encode(), purpose.encode(), hashlib.sha256
        ).hexdigest()

    @property
    def setup_code(self) -> str:
        """Deterministic one-time code that allows creating the first (admin) account."""
        raw = self.derive("first-admin-setup")
        return f"{raw[:4]}-{raw[4:8]}-{raw[8:12]}".upper()


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
