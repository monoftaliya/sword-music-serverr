"""User taste profile built from real listening signals stored in the database.

Signals and their meaning (kept deliberately separate):
  * like / favourite            strong positive
  * "больше такого" (more)      positive + explicit tag boost
  * completed / long listens    mild positive, repeats count more
  * early skip                  *soft*, short-lived negative — a skip is not a dislike
  * dislike                     strong negative for the track (and its sound, weaker)
  * "меньше такого" (less)      explicit tag penalty
  * exclude artist              hard filter
Exposure (how much of a tag the user has heard) is tracked separately from
rejection, so "never heard" is never confused with "doesn't like".
"""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import utcnow
from ..models import ArtistExclusion, Favorite, Feedback, PlayEvent, TagBias, Track, User
from ..music.store import load_tracks, track_point
from ..music.taxonomy import BY_KEY, mood_point
from ..users.schemas import merged_settings

PLAY_HALF_LIFE = 45.0
FEEDBACK_HALF_LIFE = 150.0
FAVORITE_HALF_LIFE = 400.0
SKIP_MEMORY_DAYS = 10
NEG_SCALE = 3.0


def _decay(at: datetime, now: datetime, half_life: float) -> float:
    age = max(0.0, (now - at).total_seconds() / 86400)
    return 0.5 ** (age / half_life)


def _norm(vec: dict[str, float]) -> dict[str, float]:
    if not vec:
        return {}
    top = max(vec.values())
    if top <= 0:
        return {}
    return {k: round(v / top, 4) for k, v in vec.items() if v / top > 0.02}


@dataclass
class TasteProfile:
    user_id: str
    pos: dict[str, float] = field(default_factory=dict)
    neg: dict[str, float] = field(default_factory=dict)
    exposure: dict[str, float] = field(default_factory=dict)
    artist_aff: dict[str, float] = field(default_factory=dict)
    artist_names: dict[str, str] = field(default_factory=dict)
    artist_refs: dict[str, tuple[str, str]] = field(default_factory=dict)  # artist_key -> (provider, ref)
    heard: dict[str, int] = field(default_factory=dict)
    liked: set[str] = field(default_factory=set)
    disliked: set[str] = field(default_factory=set)
    recent_skips: set[str] = field(default_factory=set)
    excluded_artists: set[str] = field(default_factory=set)
    tag_bias: dict[str, float] = field(default_factory=dict)
    centroid: tuple[float, float, float] | None = None
    bpm_mean: float | None = None
    bpm_std: float | None = None
    signals: int = 0
    seed_tags: list[str] = field(default_factory=list)

    @property
    def cold(self) -> bool:
        return self.signals < 3 and not self.seed_tags

    def top(self, n: int = 5, groups: set[str] | None = None) -> list[str]:
        items = [(k, w) for k, w in self.pos.items() if groups is None or (k in BY_KEY and BY_KEY[k].group in groups)]
        items.sort(key=lambda kv: -kv[1])
        return [k for k, _ in items[:n]]

    def top_artists(self, n: int = 5) -> list[str]:
        return [k for k, w in sorted(self.artist_aff.items(), key=lambda kv: -kv[1]) if w > 0][:n]

    def exposure_of(self, tag: str) -> float:
        return self.exposure.get(tag, 0.0)

    def neg_overlap(self, canonical: dict[str, float]) -> float:
        """Magnitude-aware rejection score of a track (0 = nothing rejected, 1 = fully rejected sound)."""
        if not self.neg or not canonical:
            return 0.0
        total = sum(canonical.values())
        return min(1.0, sum(self.neg.get(k, 0.0) * w for k, w in canonical.items()) / total) if total else 0.0


async def build_profile(session: AsyncSession, user: User, *, since_days: int | None = None) -> TasteProfile:
    now = utcnow()
    prof = TasteProfile(user_id=user.id)
    settings = merged_settings(user)
    prof.seed_tags = [t for t in settings.get("seed_tags") or [] if t in BY_KEY][:12]
    since = now - timedelta(days=since_days) if since_days else now - timedelta(days=730)
    reset_at = settings.get("rec_reset_at")
    if reset_at:
        try:
            since = max(since, datetime.fromisoformat(reset_at))
        except ValueError:
            pass

    plays = list(
        (
            await session.execute(
                select(PlayEvent)
                .where(PlayEvent.user_id == user.id, PlayEvent.started_at >= since)
                .order_by(PlayEvent.started_at.desc())
                .limit(4000)
            )
        ).scalars()
    )
    feedback = list(
        (
            await session.execute(
                select(Feedback)
                .where(Feedback.user_id == user.id, Feedback.created_at >= since)
                .order_by(Feedback.created_at.desc())
                .limit(3000)
            )
        ).scalars()
    )
    favs = list((await session.execute(select(Favorite).where(Favorite.user_id == user.id, Favorite.created_at >= since))).scalars())
    biases = list((await session.execute(select(TagBias).where(TagBias.user_id == user.id))).scalars())
    excl = list((await session.execute(select(ArtistExclusion).where(ArtistExclusion.user_id == user.id))).scalars())

    ids = {p.track_id for p in plays} | {f.track_id for f in feedback} | {f.track_id for f in favs}
    tracks = await load_tracks(session, ids)

    weights: dict[str, float] = defaultdict(float)  # per-track signed weight
    soft_neg: dict[str, float] = defaultdict(float)
    play_counts: dict[str, int] = defaultdict(int)
    for p in plays:
        d = _decay(p.started_at, now, PLAY_HALF_LIFE)
        if p.skipped:
            soft_neg[p.track_id] += 0.35 * d
            if (now - p.started_at).days < SKIP_MEMORY_DAYS:
                prof.recent_skips.add(p.track_id)
            continue
        play_counts[p.track_id] += 1
        if p.completed:
            weights[p.track_id] += 1.0 * d
        elif p.duration_ms and p.played_ms >= p.duration_ms * 0.5:
            weights[p.track_id] += 0.5 * d
        else:
            weights[p.track_id] += 0.15 * d
    for tid, n in play_counts.items():
        if n >= 2:
            weights[tid] += 0.6 * math.log1p(n - 1)  # repeats are a strong implicit signal
    prof.heard = dict(play_counts)

    for f in favs:
        weights[f.track_id] += 3.0 * _decay(f.created_at, now, FAVORITE_HALF_LIFE)
        prof.liked.add(f.track_id)
    for fb in feedback:
        d = _decay(fb.created_at, now, FEEDBACK_HALF_LIFE)
        if fb.kind == "like" and fb.track_id not in prof.liked:
            weights[fb.track_id] += 2.5 * d
            prof.liked.add(fb.track_id)
        elif fb.kind == "more":
            weights[fb.track_id] += 2.0 * d
        elif fb.kind == "dislike":
            weights[fb.track_id] -= 3.0 * d
            prof.disliked.add(fb.track_id)
        elif fb.kind == "less":
            weights[fb.track_id] -= 1.2 * d

    pos: dict[str, float] = defaultdict(float)
    neg: dict[str, float] = defaultdict(float)
    exposure: dict[str, float] = defaultdict(float)
    artist: dict[str, float] = defaultdict(float)
    pts: list[tuple[tuple[float, float, float], float]] = []
    bpms: list[tuple[float, float]] = []

    for tid, w in weights.items():
        t = tracks.get(tid)
        if t is None:
            continue
        canon = t.canonical or {}
        if t.artist_key:
            artist[t.artist_key] += w
            prof.artist_names.setdefault(t.artist_key, t.artist)
            if t.artist_ref and t.provider not in ("upload",):
                prof.artist_refs.setdefault(t.artist_key, (t.provider, t.artist_ref))
        for k, tw in canon.items():
            if w > 0:
                pos[k] += w * tw
            elif w < 0:
                neg[k] += -w * tw * (1.0 if tid in prof.disliked else 0.7)
        if w > 0:
            p = track_point(t)
            if p is not None:
                pts.append((p, w))
            if t.bpm:
                bpms.append((t.bpm, w))
    for tid, sw in soft_neg.items():
        t = tracks.get(tid)
        if t is None or tid in prof.liked:
            continue
        for k, tw in (t.canonical or {}).items():
            neg[k] += sw * tw * 0.4
        if t.artist_key:
            artist[t.artist_key] -= sw * 0.3
    for tid in set(play_counts) | set(soft_neg):
        t = tracks.get(tid)
        if t is None:
            continue
        for k, tw in (t.canonical or {}).items():
            exposure[k] += tw * (1 + math.log1p(play_counts.get(tid, 0)))

    # explicit tag biases ("больше такого" / "меньше такого")
    for b in biases:
        prof.tag_bias[b.tag] = b.weight
        if b.weight > 0:
            pos[b.tag] += b.weight
        elif b.weight < 0:
            neg[b.tag] += -b.weight
    # onboarding seeds fade as real data accumulates
    signals = len(weights) + len(feedback)
    seed_w = 2.0 / (1 + signals / 15)
    for tag in prof.seed_tags:
        pos[tag] += seed_w

    # a tag can't be both strongly liked and disliked: net them out softly
    for k in list(neg.keys()):
        if k in pos:
            overlap = min(pos[k], neg[k]) * 0.5
            pos[k] -= overlap
            neg[k] -= overlap

    prof.pos = _norm(dict(pos))
    # Negatives keep an ABSOLUTE scale: one explicit dislike ≈ 1.0, a single early skip ≈ 0.05.
    # (Normalising by the max would turn one skip into a "hated genre".)
    prof.neg = {k: round(min(1.0, v / NEG_SCALE), 4) for k, v in neg.items() if v / NEG_SCALE > 0.02}
    prof.exposure = _norm(dict(exposure))
    prof.artist_aff = {k: round(math.tanh(v / 3), 3) for k, v in artist.items()}
    prof.excluded_artists = {e.artist_key for e in excl}
    for e in excl:
        prof.artist_names.setdefault(e.artist_key, e.artist_name)
    prof.signals = signals

    if pts:
        tw = sum(w for _, w in pts)
        prof.centroid = tuple(round(sum(p[i] * w for p, w in pts) / tw, 3) for i in range(3))  # type: ignore[assignment]
    elif prof.pos:
        prof.centroid = mood_point(prof.pos)
    if bpms:
        tw = sum(w for _, w in bpms)
        mean = sum(b * w for b, w in bpms) / tw
        var = sum(w * (b - mean) ** 2 for b, w in bpms) / tw
        prof.bpm_mean, prof.bpm_std = round(mean, 1), round(math.sqrt(var), 1)
    return prof


def tag_cooccurrence(tracks: list[Track]) -> dict[str, dict[str, float]]:
    """How often canonical tags appear together in the known catalogue."""
    co: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for t in tracks:
        tags = [(k, w) for k, w in (t.canonical or {}).items() if w >= 0.3]
        for i, (a, wa) in enumerate(tags):
            for b, wb in tags[i + 1 :]:
                co[a][b] += wa * wb
                co[b][a] += wa * wb
    return {k: dict(v) for k, v in co.items()}


def shadow_vector(prof: TasteProfile, co: dict[str, dict[str, float]], size: int = 8) -> dict[str, float]:
    """Tags adjacent to the user's taste that they have *not explored* (and never rejected)."""
    from ..music.taxonomy import TAGS, mood_distance

    top = prof.top(6)
    if not top and prof.centroid is None:
        return {}
    cand: dict[str, float] = defaultdict(float)
    for t in top:
        for other, c in co.get(t, {}).items():
            cand[other] += c * prof.pos.get(t, 0)
    if cand:
        mx = max(cand.values())
        cand = defaultdict(float, {k: v / mx for k, v in cand.items()})
    center = prof.centroid or mood_point(prof.pos)
    for tag in TAGS:
        if tag.group in ("vocal",):
            continue
        d = mood_distance(center, (tag.v, tag.e, tag.a))
        if d < 0.42:
            cand[tag.key] += (0.42 - d) * 1.6
    out: dict[str, float] = {}
    for k, v in cand.items():
        if k in top[:3] or prof.neg.get(k, 0) > 0.25:
            continue  # skip core taste and anything explicitly rejected
        unexplored = 1.0 - min(1.0, prof.exposure_of(k))
        score = v * (0.35 + 0.65 * unexplored)
        if score > 0.05:
            out[k] = score
    best = sorted(out.items(), key=lambda kv: -kv[1])[:size]
    if not best:
        return {}
    mx = best[0][1]
    return {k: round(v / mx, 3) for k, v in best}
