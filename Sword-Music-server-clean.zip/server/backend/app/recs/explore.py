"""MUSIC DNA, ECHO SELF and INFINITE DESCENT — built on the same catalogue, taxonomy and profile."""
from __future__ import annotations

import asyncio
import math
from collections import Counter, defaultdict
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.deps import current_user
from ..core.errors import ApiError, not_found
from ..db import get_session, utcnow
from ..models import Favorite, Impression, PlayEvent, Track, User
from ..music.providers.base import DiscoverSpec, ProviderError
from ..music.registry import NAMES, get_registry
from ..music.store import liked_ids, load_tracks, save_results, track_out, track_point
from ..music.taxonomy import BY_KEY, SPEED_ENERGY, TAGS, cosine, label, mood_distance, mood_point, similarity
from ..search.interpreter import MoodSpec
from .engine import Scored, _discover_all, discover_results, load_catalog, select_mmr
from .modes import AFTER_DARK
from .profile import TasteProfile, build_profile, tag_cooccurrence

router = APIRouter(tags=["explore"])

SPEED_RU = {"verylow": "очень медленный", "low": "медленный", "medium": "средний", "high": "быстрый", "veryhigh": "очень быстрый"}
RHYTHM_TAGS = {"drums", "bass_heavy", "heavy", "dnb", "trap", "techno", "house", "dubstep", "phonk", "hiphop", "trance", "breakbeat"}


async def _visible(session: AsyncSession, track_id: str, user: User) -> Track:
    t = await session.get(Track, track_id)
    if t is None or (t.owner_id and t.owner_id != user.id):
        raise not_found("Трек не найден.")
    return t


# =================================================================== MUSIC DNA
def dna_params(t: Track) -> list[dict[str, Any]]:
    src = NAMES.get(t.provider, t.provider)
    extra = t.extra or {}
    params: list[dict[str, Any]] = []
    if t.bpm:
        measured = extra.get("bpm_source") == "audius-analysis"
        params.append({"key": "bpm", "label": "Темп", "value": f"{round(t.bpm)} BPM",
                       "source": f"{src} — анализ аудио источником" if measured else f"{src} — указан автором/каталогом",
                       "kind": "measured" if measured else "metadata"})
    elif t.speed in SPEED_RU:
        params.append({"key": "speed", "label": "Темп", "value": SPEED_RU[t.speed], "source": f"{src} — категория каталога", "kind": "metadata"})
    if t.musical_key:
        measured = extra.get("key_source") == "audius-analysis"
        params.append({"key": "key", "label": "Тональность", "value": t.musical_key,
                       "source": f"{src} — анализ аудио источником" if measured else f"{src} — указана автором",
                       "kind": "measured" if measured else "metadata"})
    if t.genres:
        params.append({"key": "genre", "label": "Жанр", "value": ", ".join(t.genres[:4]), "source": f"{src} — метаданные", "kind": "metadata"})
    if t.moods:
        params.append({"key": "mood", "label": "Настроение", "value": ", ".join(t.moods[:5]), "source": f"{src} — метаданные", "kind": "metadata"})
    if t.vocal in ("vocal", "instrumental"):
        val = "инструментал" if t.vocal == "instrumental" else "с вокалом"
        if extra.get("gender") in ("male", "female") and t.vocal == "vocal":
            val += ", " + ("мужской" if extra["gender"] == "male" else "женский")
        params.append({"key": "vocal", "label": "Вокал", "value": val, "source": f"{src} — метаданные", "kind": "metadata"})
    if t.instruments:
        params.append({"key": "instruments", "label": "Инструменты", "value": ", ".join(t.instruments[:6]), "source": f"{src} — метаданные", "kind": "metadata"})
    if extra.get("acousticelectric"):
        val = {"acoustic": "акустическое", "electric": "электронное/электрическое"}.get(extra["acousticelectric"], extra["acousticelectric"])
        params.append({"key": "texture", "label": "Звучание", "value": val, "source": f"{src} — метаданные", "kind": "metadata"})
    if t.tags:
        params.append({"key": "tags", "label": "Теги", "value": ", ".join(t.tags[:8]), "source": f"{src} — теги автора/каталога", "kind": "metadata"})
    if t.duration:
        m, s = divmod(int(round(t.duration)), 60)
        params.append({"key": "duration", "label": "Длительность", "value": f"{m}:{s:02d}", "source": src, "kind": "metadata"})
    if t.release_date:
        params.append({"key": "year", "label": "Год", "value": t.release_date[:4], "source": src, "kind": "metadata"})
    if t.license:
        params.append({"key": "license", "label": "Лицензия", "value": t.license, "source": src, "kind": "metadata", "url": t.license_url})
    return params


def dna_out(t: Track) -> dict[str, Any]:
    pt = track_point(t)
    canon = t.canonical or {}
    return {
        "params": dna_params(t),
        "tags": [{"key": k, "label": label(k), "group": BY_KEY[k].group, "weight": w} for k, w in sorted(canon.items(), key=lambda kv: -kv[1]) if k in BY_KEY],
        "mood": None if (pt is None or not canon) else {
            "valence": pt[0], "energy": pt[1], "atmosphere": pt[2],
            "note": "Оценка по тегам и темпу из метаданных — это не анализ аудиосигнала.",
        },
        "waveform": (t.extra or {}).get("waveform"),
        "waveform_source": f"{NAMES.get(t.provider, t.provider)} — пики громкости из аудио" if (t.extra or {}).get("waveform") else None,
        "completeness": min(1.0, round(len(dna_params(t)) / 9, 2)),
    }


@router.get("/api/dna/track/{track_id}")
async def dna(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await _visible(session, track_id, user)
    liked = await liked_ids(session, user.id, [t.id])
    return {"track": track_out(t, liked=t.id in liked), **dna_out(t)}


class BlendIn(BaseModel):
    a: str = Field(max_length=200)
    b: str = Field(max_length=200)
    atmosphere: str = Field("a", pattern="^(a|b|both)$")
    rhythm: str = Field("b", pattern="^(a|b|both)$")
    genre: str = Field("a", pattern="^(a|b|both|none)$")
    count: int = Field(12, ge=4, le=30)


def _pick(which: str, a: Track, b: Track) -> list[Track]:
    return [a] if which == "a" else [b] if which == "b" else [a, b]


def _blend_spec(body: BlendIn, a: Track, b: Track) -> tuple[MoodSpec, list[str]]:
    spec = MoodSpec(query="dna-blend")
    notes: list[str] = []
    atm_tags: dict[str, float] = defaultdict(float)
    atm_pts = []
    for t in _pick(body.atmosphere, a, b):
        for k, w in (t.canonical or {}).items():
            if k in BY_KEY and BY_KEY[k].group in ("mood", "scene"):
                atm_tags[k] += w
        p = track_point(t)
        if p:
            atm_pts.append(p)
    if atm_tags:
        notes.append("атмосфера: " + ", ".join(label(k) for k, _ in sorted(atm_tags.items(), key=lambda kv: -kv[1])[:3]))
    for k, w in atm_tags.items():
        spec.tags[k] = spec.tags.get(k, 0) + w
    if body.genre != "none":
        gen: dict[str, float] = defaultdict(float)
        for t in _pick(body.genre, a, b):
            for k, w in (t.canonical or {}).items():
                if k in BY_KEY and BY_KEY[k].group == "genre":
                    gen[k] += w
        for k, w in gen.items():
            spec.tags[k] = spec.tags.get(k, 0) + w * 0.9
        if gen:
            notes.append("жанр: " + ", ".join(label(k) for k, _ in sorted(gen.items(), key=lambda kv: -kv[1])[:2]))
    rhythm_src = _pick(body.rhythm, a, b)
    bpms = [t.bpm for t in rhythm_src if t.bpm]
    energies = []
    for t in rhythm_src:
        p = track_point(t)
        if p:
            energies.append(p[1])
        for k, w in (t.canonical or {}).items():
            if k in RHYTHM_TAGS:
                spec.tags[k] = spec.tags.get(k, 0) + w * 0.5
    if bpms:
        mid = sum(bpms) / len(bpms)
        spec.bpm_min, spec.bpm_max = mid - 10, mid + 10
        notes.append(f"ритм: ~{round(mid)} BPM")
    else:
        speeds = [t.speed for t in rhythm_src if t.speed in SPEED_ENERGY]
        if speeds:
            energies.append(sum(SPEED_ENERGY[s] for s in speeds) / len(speeds))
            notes.append("ритм: " + SPEED_RU.get(speeds[0], speeds[0]) + " темп")
        elif energies:
            notes.append("ритм: по оценке энергии (без BPM в метаданных)")
    v = sum(p[0] for p in atm_pts) / len(atm_pts) if atm_pts else 0.0
    at = sum(p[2] for p in atm_pts) / len(atm_pts) if atm_pts else 0.6
    e = sum(energies) / len(energies) if energies else 0.5
    spec.target = (round(v, 3), round(e, 3), round(at, 3))
    spec.hits = 3
    return spec, notes


@router.post("/api/dna/blend")
async def dna_blend(body: BlendIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    a = await _visible(session, body.a, user)
    b = await _visible(session, body.b, user)
    spec, notes = _blend_spec(body, a, b)
    if not spec.tags and spec.target is None:
        raise ApiError(422, "no_data", "У выбранных треков слишком мало метаданных для смешивания.")
    return await _dna_find(session, user, spec, body.count, exclude={a.id, b.id}, notes=notes)


@router.get("/api/dna/search")
async def dna_search(
    tags: str = Query("", max_length=400),
    bpm_min: float | None = Query(None, ge=40, le=240),
    bpm_max: float | None = Query(None, ge=40, le=240),
    vocal: str | None = Query(None, pattern="^(vocal|instrumental)$"),
    energy: float | None = Query(None, ge=0, le=1),
    count: int = Query(20, ge=4, le=40),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    keys = [k for k in tags.split(",") if k in BY_KEY]
    if not keys and not (bpm_min or bpm_max or vocal or energy is not None):
        raise ApiError(400, "empty", "Выберите хотя бы одну характеристику.")
    spec = MoodSpec(query="dna-search", tags={k: 1.0 for k in keys}, bpm_min=bpm_min, bpm_max=bpm_max, vocal=vocal, hits=2)
    spec.finalize()
    if energy is not None:
        base = spec.target or (0.0, 0.5, 0.6)
        spec.target = (base[0], energy, base[2])
    return await _dna_find(session, user, spec, count, exclude=set(), notes=[])


async def _dna_find(session: AsyncSession, user: User, spec: MoodSpec, count: int, *, exclude: set[str], notes: list[str]) -> dict[str, Any]:
    registry = get_registry()
    statuses: dict[str, dict[str, Any]] = {}
    dspec = DiscoverSpec(
        tags={k: v for k, v in sorted(spec.tags.items(), key=lambda kv: -kv[1])[:5]},
        bpm_min=spec.bpm_min, bpm_max=spec.bpm_max, vocal=spec.vocal,
        energy=spec.target[1] if spec.target else None, limit=30,
    )
    found = await _discover_all(session, registry, [dspec], statuses)
    pool = {t.id: t for t in [*found, *await load_catalog(session, user, 1500)]}
    scored = []
    for t in pool.values():
        if t.id in exclude or t.stream_kind != "full" or t.unavailable_reason:
            continue
        f = spec.fit(t.canonical or {}, track_point(t), t.bpm, t.vocal)
        scored.append(Scored(track=t, score=f + 0.05 * (t.popularity or 0), point=track_point(t)))
    prof = TasteProfile(user_id=user.id)
    picked = select_mmr(scored, count, 0.8, 2, 0, prof)
    liked = await liked_ids(session, user.id, [s.track.id for s in picked])
    items = []
    for s in picked:
        d = track_out(s.track, liked=s.track.id in liked)
        d["match"] = round(s.score, 3)
        items.append(d)
    return {"items": items, "notes": notes, "spec": spec.to_dict(), "sources": list(statuses.values())}


# =================================================================== ECHO SELF
PERIODS = {"7d": 7, "30d": 30, "90d": 90, "365d": 365, "all": None}


def _nearest_mode(point: tuple[float, float, float] | None, tags: dict[str, float]) -> dict[str, Any] | None:
    if point is None and not tags:
        return None
    best, best_s = None, -1.0
    for m in AFTER_DARK.values():
        s = similarity(m.prior, tags, m.target, point)
        if s > best_s:
            best, best_s = m, s
    return {"id": best.id, "name": best.name, "affinity": round(best_s, 3)} if best else None


async def echo_snapshot(session: AsyncSession, user: User, start, end) -> dict[str, Any]:  # noqa: ANN001
    q = select(PlayEvent).where(PlayEvent.user_id == user.id, PlayEvent.started_at < end)
    if start is not None:
        q = q.where(PlayEvent.started_at >= start)
    plays = list((await session.execute(q.limit(5000))).scalars())
    fq = select(Favorite).where(Favorite.user_id == user.id, Favorite.created_at < end)
    if start is not None:
        fq = fq.where(Favorite.created_at >= start)
    favs = list((await session.execute(fq)).scalars())
    tracks = await load_tracks(session, {p.track_id for p in plays} | {f.track_id for f in favs})
    weights: dict[str, float] = defaultdict(float)
    for p in plays:
        if p.skipped:
            continue
        weights[p.track_id] += 1.0 if p.completed else 0.5
    for f in favs:
        weights[f.track_id] += 2.0
    tag_w: dict[str, float] = defaultdict(float)
    artists: Counter[str] = Counter()
    names: dict[str, str] = {}
    pts, bpms = [], []
    for tid, w in weights.items():
        t = tracks.get(tid)
        if t is None:
            continue
        for k, tw in (t.canonical or {}).items():
            tag_w[k] += w * tw
        artists[t.artist_key] += w
        names[t.artist_key] = t.artist
        p = track_point(t)
        if p:
            pts.append((p, w))
        if t.bpm:
            bpms.append((t.bpm, w))
    total = sum(tag_w.values())
    lobes = []
    if total > 0:
        for k, w in sorted(tag_w.items(), key=lambda kv: -kv[1])[:9]:
            tag = BY_KEY.get(k)
            if not tag:
                continue
            lobes.append({"key": k, "label": tag.ru, "group": tag.group, "weight": round(w / total, 4), "v": tag.v, "e": tag.e, "a": tag.a})
    probs = [w / total for w in tag_w.values()] if total else []
    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    diversity = round(entropy / math.log(len(probs)), 3) if len(probs) > 1 else 0.0
    centroid = None
    if pts:
        tw = sum(w for _, w in pts)
        centroid = tuple(round(sum(p[i] * w for p, w in pts) / tw, 3) for i in range(3))
    first_seen: dict[str, Any] = {}
    if start is not None and artists:
        rows = await session.execute(select(PlayEvent.track_id, PlayEvent.started_at).where(PlayEvent.user_id == user.id, PlayEvent.started_at < start).limit(20000))
        before_tracks = await load_tracks(session, {tid for tid, _ in rows.all()})
        before_artists = {t.artist_key for t in before_tracks.values()}
        new = [a for a in artists if a not in before_artists]
        first_seen = {"new_artists": len(new), "share": round(len(new) / len(artists), 3)}
    norm_tags = {k: w / max(tag_w.values()) for k, w in tag_w.items()} if tag_w else {}
    return {
        "plays": sum(1 for p in plays if not p.skipped),
        "skips": sum(1 for p in plays if p.skipped),
        "likes": len(favs),
        "lobes": lobes,
        "centroid": centroid,
        "bpm": round(sum(b * w for b, w in bpms) / sum(w for _, w in bpms), 1) if bpms else None,
        "diversity": diversity,
        "novelty": first_seen or None,
        "top_artists": [{"key": k, "name": names.get(k, k)} for k, _ in artists.most_common(4)],
        "nearest_mode": _nearest_mode(centroid, norm_tags),
    }


@router.get("/api/echo")
async def echo(
    period: str = Query("30d", pattern="^(7d|30d|90d|365d|all)$"),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    end = utcnow()
    days = PERIODS[period]
    start = end - timedelta(days=days) if days else None
    snap = await echo_snapshot(session, user, start, end)
    snap["period"] = period
    snap["disclaimer"] = "Echo Self — художественная визуализация ваших прослушиваний и лайков. Это не психологический анализ."
    return snap


@router.get("/api/echo/timeline")
async def echo_timeline(
    months: int = Query(6, ge=1, le=24), session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    end = utcnow()
    frames = []
    for i in range(months, 0, -1):
        f_end = end - timedelta(days=30 * (i - 1))
        f_start = f_end - timedelta(days=30)
        snap = await echo_snapshot(session, user, f_start, f_end)
        frames.append({"from": f_start.date().isoformat(), "to": f_end.date().isoformat(), **{k: snap[k] for k in ("plays", "likes", "lobes", "centroid", "diversity", "bpm", "nearest_mode")}})
    return {"frames": frames}


# =================================================================== INFINITE DESCENT
def _relation(center: Track, t: Track, c_pt, t_pt) -> tuple[str, str]:  # noqa: ANN001
    if center.artist_key == t.artist_key:
        return "artist", "тот же исполнитель"
    shared = [k for k, w in sorted((center.canonical or {}).items(), key=lambda kv: -kv[1]) if (t.canonical or {}).get(k, 0) > 0.25 and w > 0.25]
    genres = [k for k in shared if BY_KEY.get(k) and BY_KEY[k].group == "genre"]
    if genres:
        return "genre", f"общий жанр: {label(genres[0])}"
    if shared:
        return "mood", f"общее: {label(shared[0])}"
    if c_pt and t_pt and mood_distance(c_pt, t_pt) < 0.18:
        return "mood", "близкое настроение"
    if center.bpm and t.bpm and abs(center.bpm - t.bpm) <= 6:
        return "tempo", f"похожий темп, {round(t.bpm)} BPM"
    return "drift", "дальняя связь"


def _drift_tags(center: Track, co: dict[str, dict[str, float]], depth: int, visited_tags: Counter[str]) -> dict[str, float]:
    """Move away from the centre's dominant tags towards adjacent, less-visited ones."""
    canon = center.canonical or {}
    ranked = [k for k, _ in sorted(canon.items(), key=lambda kv: -kv[1])]
    keep = ranked[1:3] if len(ranked) > 1 else ranked
    out = {k: 0.6 for k in keep}
    neighbours: dict[str, float] = defaultdict(float)
    for k in ranked[:3]:
        for other, c in co.get(k, {}).items():
            if other not in canon:
                neighbours[other] += c
    pt = mood_point(canon) if canon else None
    for tag in TAGS:
        if tag.key in canon or tag.group == "vocal":
            continue
        d = mood_distance(pt, (tag.v, tag.e, tag.a)) if pt else 0.6
        neighbours[tag.key] += max(0.0, 0.45 - d)
    for k in list(neighbours):
        neighbours[k] /= 1 + visited_tags.get(k, 0)
    for k, _ in sorted(neighbours.items(), key=lambda kv: -kv[1])[: 2 + min(depth, 2)]:
        out[k] = 1.0
    return out


@router.get("/api/descent")
async def descent(
    center: str = Query(..., max_length=200),
    mode: str = Query("explore", pattern="^(explore|descend)$"),
    depth: int = Query(0, ge=0, le=200),
    visited: str = Query("", max_length=12000),
    count: int = Query(10, ge=4, le=16),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    c = await _visible(session, center, user)
    visited_ids = {x for x in visited.split(",") if x}
    visited_ids.add(c.id)
    registry = get_registry()
    catalog = await load_catalog(session, user, 2000)
    co = tag_cooccurrence(catalog)
    visited_tracks = await load_tracks(session, list(visited_ids)[:300])
    visited_tags: Counter[str] = Counter()
    for vt in visited_tracks.values():
        for k, w in (vt.canonical or {}).items():
            if w > 0.4:
                visited_tags[k] += 1
    visited_norm = {vt.norm_key for vt in visited_tracks.values() if vt.norm_key}
    prof = await build_profile(session, user)

    canon = c.canonical or {}
    statuses: dict[str, dict[str, Any]] = {}
    specs = []
    if mode == "explore" or depth == 0:
        if canon:
            specs.append(DiscoverSpec(tags=dict(sorted(canon.items(), key=lambda kv: -kv[1])[:4]), limit=25,
                                      bpm_min=c.bpm - 12 if c.bpm else None, bpm_max=c.bpm + 12 if c.bpm else None))
    if mode == "descend":
        specs.append(DiscoverSpec(tags=_drift_tags(c, co, depth, visited_tags), limit=25, popular=depth < 3))
    if not specs:
        specs.append(DiscoverSpec(keywords=[c.artist], limit=20))
    jobs = [discover_results(registry, specs, statuses)]
    if c.artist_ref and registry.usable(c.provider):
        p = registry.get(c.provider)

        async def artist_job() -> list:
            try:
                return await registry.run(p, "artist", lambda: p.artist_tracks(c.artist_ref or "", 12), cache_key=c.artist_ref, ttl=3600)
            except ProviderError:
                return []

        jobs.append(artist_job())
    found_lists = await asyncio.gather(*jobs)
    stored = await save_results(session, [r for lst in found_lists for r in lst])
    pool: dict[str, Track] = {t.id: t for t in catalog}
    pool.update(stored)

    c_pt = track_point(c)
    hi = max(0.32, 0.9 - 0.07 * depth) if mode == "descend" else 1.01
    lo = max(0.1, hi - 0.32) if mode == "descend" else 0.0
    scored: list[Scored] = []
    for t in pool.values():
        if t.id in visited_ids or t.norm_key in visited_norm or t.stream_kind != "full" or t.unavailable_reason:
            continue
        if t.artist_key in prof.excluded_artists or t.id in prof.disliked:
            continue
        t_pt = track_point(t)
        sim = similarity(canon, t.canonical or {}, c_pt, t_pt) + (0.12 if t.artist_key == c.artist_key else 0.0)
        if mode == "explore":
            s = sim + 0.05 * (t.popularity or 0)
        else:
            in_band = lo <= sim <= hi
            dist = 0.0 if in_band else min(abs(sim - lo), abs(sim - hi))
            novelty = 1.0 if t.artist_key not in prof.artist_aff else 0.3
            same_artist_pen = 0.25 if (t.artist_key == c.artist_key and depth > 0) else 0.0
            s = 0.6 - dist * 1.5 + 0.2 * novelty + 0.1 * (t.popularity or 0) - same_artist_pen
        scored.append(Scored(track=t, score=s, point=t_pt, parts={"sim": round(sim, 3)}))
    picked = select_mmr(scored, count, 0.72 if mode == "explore" else 0.55, 2 if mode == "explore" else 1, 0, prof)
    if picked:
        now = utcnow()
        for s in picked:
            session.add(Impression(user_id=user.id, track_id=s.track.id, surface="descent", served_at=now))
        await session.commit()
    liked = await liked_ids(session, user.id, [c.id, *[s.track.id for s in picked]])
    nodes = []
    for s in picked:
        kind, text = _relation(c, s.track, c_pt, s.point)
        nodes.append({"track": track_out(s.track, liked=s.track.id in liked), "relation": kind, "label": text, "similarity": s.parts.get("sim")})
    return {
        "center": track_out(c, liked=c.id in liked),
        "mode": mode,
        "depth": depth,
        "nodes": nodes,
        "band": [round(lo, 2), round(min(hi, 1.0), 2)] if mode == "descend" else None,
        "sources": list(statuses.values()),
        "note": None if canon else "У центрального трека мало метаданных — связи построены по исполнителю и доступным данным.",
    }
