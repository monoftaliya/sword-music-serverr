"""Recommendation engine shared by My Wave, AFTER DARK, SHADOW and Infinite Descent.

Pipeline: profile → discovery specs → candidates (providers + known catalogue)
→ filters (exclusions, dislikes, recent skips, recent impressions) → mode-specific
scoring → MMR diversification → ordering → impressions + reasons.
"""
from __future__ import annotations

import asyncio
import math
from collections import Counter
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import utcnow
from ..models import Favorite, Impression, Track, User
from ..music.providers.base import DiscoverSpec, ProviderError, TrackResult
from ..music.registry import NAMES, Registry
from ..music.store import liked_ids, load_tracks, save_results, track_out, track_point
from ..music.taxonomy import BY_KEY, cosine, label, mood_distance, similarity
from .modes import ModeDef
from .profile import TasteProfile, build_profile, shadow_vector, tag_cooccurrence

STARTER_SPECS = [
    {"electronic": 1.0, "synthwave": 0.6},
    {"hiphop": 1.0, "phonk": 0.6},
    {"ambient": 1.0, "atmospheric": 0.6},
    {"rock": 1.0, "indie": 0.6},
]
SEED_SUGGESTIONS = [
    "phonk", "dark", "synthwave", "lofi", "ambient", "dark_ambient", "trap", "hiphop", "techno", "dnb",
    "rock", "metal", "postrock", "cinematic", "orchestral", "piano", "jazz", "pop", "indie", "night",
    "melancholic", "energetic", "calm", "space", "anime", "drive",
]


@dataclass
class Scored:
    track: Track
    score: float
    parts: dict[str, float] = field(default_factory=dict)
    reason: str = ""
    point: tuple[float, float, float] | None = None


@dataclass
class RecRequest:
    mode: ModeDef
    surface: str
    count: int = 10
    lens: str = "main"  # main | shadow
    current_id: str | None = None
    exclude: set[str] = field(default_factory=set)
    record: bool = True


async def load_catalog(session: AsyncSession, user: User, limit: int = 2500) -> list[Track]:
    rows = await session.execute(
        select(Track)
        .where(
            Track.unavailable_reason.is_(None),
            Track.stream_kind == "full",
            (Track.owner_id.is_(None)) | (Track.owner_id == user.id),
        )
        .order_by(Track.updated_at.desc())
        .limit(limit)
    )
    return list(rows.scalars())


async def discover_results(
    registry: Registry, specs: list[DiscoverSpec], statuses: dict[str, dict[str, Any]]
) -> list[TrackResult]:
    """Run discovery specs on every usable provider concurrently (no DB access here)."""
    jobs = []
    for spec in specs:
        for p in registry.active():
            jobs.append(
                (p.id, registry.run(p, "discover", lambda p=p, s=spec: p.discover(s), cache_key=spec.cache_key(), ttl=1800))
            )
    results: list[TrackResult] = []
    outs = await asyncio.gather(*(j[1] for j in jobs), return_exceptions=True)
    for (pid, _), res in zip(jobs, outs):
        st = statuses.setdefault(pid, {"id": pid, "name": NAMES.get(pid, pid), "status": "ok", "count": 0})
        if isinstance(res, ProviderError):
            if st["count"] == 0:
                st.update(status="error", message=res.message)
            continue
        if isinstance(res, BaseException):
            continue
        if res or st["status"] != "error":
            st.update(status="ok", count=st["count"] + len(res))
            st.pop("message", None)
        results.extend(res)
    for pid in registry.providers:
        if not registry.usable(pid) and pid not in statuses:
            statuses[pid] = {"id": pid, "name": NAMES.get(pid, pid), "status": "skipped", "count": 0, "message": registry.state_of(pid)}
    return results


async def _discover_all(
    session: AsyncSession, registry: Registry, specs: list[DiscoverSpec], statuses: dict[str, dict[str, Any]]
) -> list[Track]:
    results = await discover_results(registry, specs, statuses)
    stored = await save_results(session, results)
    return list(stored.values())


async def artist_results(registry: Registry, prof: TasteProfile, n: int = 2) -> list[TrackResult]:
    jobs = []
    for key in prof.top_artists(6):
        ref = prof.artist_refs.get(key)
        if not ref or not registry.usable(ref[0]):
            continue
        p = registry.get(ref[0])
        if p is None:
            continue
        jobs.append(registry.run(p, "artist", lambda p=p, r=ref[1]: p.artist_tracks(r, 15), cache_key=ref[1], ttl=3600))
        if len(jobs) >= n:
            break
    results: list[TrackResult] = []
    for res in await asyncio.gather(*jobs, return_exceptions=True):
        if isinstance(res, list):
            results.extend(res)
    return results


def _spec(tags: dict[str, float], *, popular: bool = True, energy: float | None = None, bpm: tuple | None = None, limit: int = 30) -> DiscoverSpec:
    top = dict(sorted(tags.items(), key=lambda kv: -kv[1])[:5])
    return DiscoverSpec(
        tags=top,
        popular=popular,
        energy=energy,
        bpm_min=(bpm or (None, None))[0],
        bpm_max=(bpm or (None, None))[1],
        limit=limit,
    )


def build_specs(req: RecRequest, prof: TasteProfile, taste: dict[str, float], shadow: dict[str, float]) -> list[DiscoverSpec]:
    mode = req.mode
    specs: list[DiscoverSpec] = []
    taste_top = dict(sorted(taste.items(), key=lambda kv: -kv[1])[:4])
    if mode.id == "chaos":
        source = shadow or taste
        keys = [k for k, _ in sorted(source.items(), key=lambda kv: -kv[1])]
        # three different unexplored directions instead of one blended query
        for k in keys[:3]:
            specs.append(_spec({k: 1.0}, popular=False, limit=25))
        if not specs:
            specs = [_spec(s, popular=False) for s in STARTER_SPECS[:3]]
        return specs
    if mode.prior:
        prior_top = dict(sorted(mode.prior.items(), key=lambda kv: -kv[1])[:4])
        specs.append(_spec(prior_top, energy=mode.target[1] if mode.target else None, bpm=mode.bpm))
        if taste_top:
            blend = {k: v * 0.6 for k, v in prior_top.items()}
            for k, v in list(taste_top.items())[:2]:
                blend[k] = blend.get(k, 0) + v
            specs.append(_spec(blend, energy=mode.target[1] if mode.target else None, bpm=mode.bpm))
        return specs
    # FLOW
    if taste_top:
        specs.append(_spec(taste_top))
        if len(taste_top) > 2:
            keys = list(taste_top)
            specs.append(_spec({keys[0]: 1.0, keys[2]: 0.8}, popular=False))
    else:
        specs = [_spec(s) for s in STARTER_SPECS]
    return specs


def _reason(req: RecRequest, t: Track, prof: TasteProfile, taste: dict[str, float], parts: dict[str, float], shadow: dict[str, float]) -> str:
    canon = t.canonical or {}
    mode = req.mode
    approx = "" if canon else " (приблизительно: мало метаданных)"
    if req.lens == "shadow" and shadow:
        common = [k for k in sorted(shadow, key=lambda k: -shadow[k]) if canon.get(k, 0) > 0.2]
        liked_top = prof.top(1)
        if common:
            near = f" — рядом с «{label(liked_top[0])}»" if liked_top else ""
            return f"Тень: {label(common[0])}{near}, вы почти не слушали это{approx}"
        return f"Тень: новое направление рядом с вашим вкусом{approx}"
    if mode.id == "chaos":
        new_artist = t.artist_key not in prof.artist_aff
        top = [k for k, w in sorted(canon.items(), key=lambda kv: -kv[1]) if prof.exposure.get(k, 0) < 0.3]
        if new_artist and top:
            return f"Новый исполнитель, неизведанное: {label(top[0])}"
        if new_artist:
            return f"Новый для вас исполнитель{approx}"
        return f"Неожиданный поворот: {label(top[0])}" if top else "Новое направление"
    if mode.prior:
        matched = [k for k, _ in sorted(mode.prior.items(), key=lambda kv: -kv[1]) if canon.get(k, 0) > 0.2][:3]
        if matched:
            return f"{mode.name}: " + ", ".join(label(k) for k in matched)
        return f"{mode.name}: близко по настроению{approx}"
    # FLOW
    aff = prof.artist_aff.get(t.artist_key, 0)
    if t.id in prof.liked:
        return "Из ваших любимых"
    if aff > 0.35:
        return f"Вы часто слушаете {t.artist}"
    common = [k for k, _ in sorted(taste.items(), key=lambda kv: -kv[1]) if canon.get(k, 0) > 0.2][:3]
    if common:
        return "Похоже на то, что вам нравится: " + ", ".join(label(k) for k in common)
    if parts.get("cont", 0) > 0.75:
        return "Продолжает настроение текущего трека"
    return f"Новое рядом с вашим вкусом{approx}"


def score_candidates(
    req: RecRequest,
    cands: list[Track],
    prof: TasteProfile,
    taste: dict[str, float],
    shadow: dict[str, float],
    current: Track | None,
) -> list[Scored]:
    mode = req.mode
    cur_point = track_point(current) if current else None
    taste_center = prof.centroid
    out: list[Scored] = []
    for t in cands:
        if t.artist_key in prof.excluded_artists or t.id in prof.disliked or t.id in req.exclude:
            continue
        if t.stream_kind != "full" or t.unavailable_reason:
            continue
        if current is not None and (t.id == current.id or (t.norm_key and t.norm_key == current.norm_key)):
            continue
        heard = prof.heard.get(t.id, 0)
        if heard and mode.allow_heard == 0:
            continue
        canon = t.canonical or {}
        pt = track_point(t)
        rel = similarity(taste, canon, taste_center, pt) if taste else 0.35
        neg = prof.neg_overlap(canon)
        mode_fit = 0.0
        if mode.prior:
            mode_fit = similarity(mode.prior, canon, mode.target, pt) - 0.8 * cosine(mode.avoid, canon)
            lo, hi = mode.bpm
            if t.bpm and (lo or hi):
                ok = (lo is None or t.bpm >= lo or t.bpm * 2 >= lo) and (hi is None or t.bpm <= hi or t.bpm / 2 <= hi)
                mode_fit += 0.08 if ok else -0.12
        artist_aff = prof.artist_aff.get(t.artist_key, 0.0)
        new_artist = t.artist_key not in prof.artist_aff
        weight_sum = sum(canon.values()) or 1.0
        tag_exposure = sum(prof.exposure.get(k, 0) * w for k, w in canon.items()) / weight_sum
        novelty = 0.6 * (1.0 if new_artist else 0.0) + 0.4 * (1.0 - min(1.0, tag_exposure))
        cont = 1.0 - mood_distance(cur_point, pt) if cur_point else 0.5
        pop = t.popularity or 0.0
        s = (
            mode.w_mode * mode_fit
            + mode.w_rel * rel
            + mode.w_novel * novelty
            + mode.w_pop * pop
            + mode.w_cont * cont
            + mode.w_artist * max(0.0, artist_aff)
            - 0.55 * neg
        )
        if mode.id == "chaos":
            adj = 1.0 - mood_distance(taste_center, pt) if taste_center else 0.5
            if taste and rel < 0.08 and adj < 0.45:
                continue  # not a discovery — just random
            s += 0.22 * adj
        if req.lens == "shadow" and shadow:
            s += 0.25 * cosine(shadow, canon)
        if t.id in prof.liked and mode.id == "flow":
            s += 0.04
        if t.id in prof.recent_skips:
            s -= 0.35
        if heard:
            s -= 0.05 * min(heard, 4)
        sc = Scored(track=t, score=s, point=pt, parts={"rel": round(rel, 3), "mode": round(mode_fit, 3), "novel": round(novelty, 3), "pop": round(pop, 3), "cont": round(cont, 3), "neg": round(neg, 3)})
        out.append(sc)
    return out


def _pair_sim(a: Scored, b: Scored) -> float:
    if a.track.norm_key and a.track.norm_key == b.track.norm_key:
        return 1.5
    s = similarity(a.track.canonical or {}, b.track.canonical or {}, a.point, b.point) * 0.8
    if a.track.artist_key == b.track.artist_key:
        s += 0.4
    return s


def select_mmr(items: list[Scored], k: int, lam: float, max_per_artist: int, allow_heard: int, prof: TasteProfile) -> list[Scored]:
    pool = sorted(items, key=lambda s: -s.score)[:250]
    chosen: list[Scored] = []
    per_artist: Counter[str] = Counter()
    heard_used = 0
    while len(chosen) < k and pool:
        best_i, best_val = -1, -math.inf
        for i, cand in enumerate(pool):
            if per_artist[cand.track.artist_key] >= max_per_artist:
                continue
            if prof.heard.get(cand.track.id) and heard_used >= allow_heard:
                continue
            sim = max((_pair_sim(cand, c) for c in chosen), default=0.0)
            val = lam * cand.score - (1 - lam) * sim
            if val > best_val:
                best_i, best_val = i, val
        if best_i < 0:
            break
        pick = pool.pop(best_i)
        chosen.append(pick)
        per_artist[pick.track.artist_key] += 1
        if prof.heard.get(pick.track.id):
            heard_used += 1
    return chosen


async def recent_impressions(session: AsyncSession, user_id: str, surface_prefix: str, hours: float = 4) -> set[str]:
    since = utcnow() - timedelta(hours=hours)
    rows = await session.execute(
        select(Impression.track_id).where(
            Impression.user_id == user_id, Impression.served_at >= since, Impression.surface.startswith(surface_prefix)
        )
    )
    return set(rows.scalars())


def profile_summary(prof: TasteProfile, shadow: dict[str, float] | None = None) -> dict[str, Any]:
    return {
        "signals": prof.signals,
        "cold": prof.cold,
        "top_tags": [{"key": k, "label": label(k), "weight": prof.pos[k]} for k in prof.top(8)],
        "avoided": [{"key": k, "label": label(k)} for k, w in sorted(prof.neg.items(), key=lambda kv: -kv[1])[:5] if w > 0.3],
        "top_artists": [{"key": k, "name": prof.artist_names.get(k, k)} for k in prof.top_artists(6)],
        "excluded_artists": [{"key": k, "name": prof.artist_names.get(k, k)} for k in sorted(prof.excluded_artists)],
        "centroid": prof.centroid,
        "bpm": prof.bpm_mean,
        "seed_tags": prof.seed_tags,
        "shadow_tags": [{"key": k, "label": label(k), "weight": w} for k, w in (shadow or {}).items()],
    }


async def recommend(session: AsyncSession, registry: Registry, user: User, req: RecRequest) -> dict[str, Any]:
    prof = await build_profile(session, user)
    catalog = await load_catalog(session, user)
    co = tag_cooccurrence(catalog)
    shadow = shadow_vector(prof, co) if (req.lens == "shadow" or req.mode.id == "chaos") else {}
    if req.lens == "shadow" and shadow:
        taste = {k: v * 0.85 for k, v in shadow.items()}
        for k, v in prof.pos.items():
            taste[k] = taste.get(k, 0) + v * 0.2
    else:
        taste = dict(prof.pos)

    current = await session.get(Track, req.current_id) if req.current_id else None
    statuses: dict[str, dict[str, Any]] = {}
    specs = build_specs(req, prof, taste, shadow)
    want_artists = req.mode.id == "flow" and req.lens == "main"
    found, by_artist = await asyncio.gather(
        discover_results(registry, specs, statuses),
        artist_results(registry, prof) if want_artists else asyncio.sleep(0, []),
    )
    stored = await save_results(session, [*found, *(by_artist or [])])  # one session, sequential writes
    pool: dict[str, Track] = {t.id: t for t in catalog}
    pool.update(stored)
    if req.mode.id == "flow" and prof.liked:
        fav = await load_tracks(session, list(prof.liked)[:300])
        pool.update(fav)

    served = await recent_impressions(session, user.id, req.surface.split(":")[0] + ":" + req.surface.split(":")[1] if ":" in req.surface else req.surface)
    fresh = [t for t in pool.values() if t.id not in served]
    candidates = fresh if len(fresh) >= req.count * 2 else list(pool.values())

    scored = score_candidates(req, candidates, prof, taste, shadow, current)
    allow_heard = int(round(req.mode.allow_heard * req.count))
    picked = select_mmr(scored, req.count, req.mode.mmr_lambda, req.mode.max_per_artist, allow_heard, prof)
    if req.mode.order == "rising":
        picked.sort(key=lambda s: (s.point[1] if s.point else 0.5))

    for s in picked:
        s.reason = _reason(req, s.track, prof, taste, s.parts, shadow)
    if req.record and picked:
        now = utcnow()
        for s in picked:
            session.add(Impression(user_id=user.id, track_id=s.track.id, surface=req.surface, served_at=now))
        await session.commit()

    liked = await liked_ids(session, user.id, [s.track.id for s in picked])
    items = []
    for s in picked:
        d = track_out(s.track, liked=s.track.id in liked, reason=s.reason)
        d["score"] = round(s.score, 3)
        d["parts"] = s.parts
        d["point"] = s.point
        items.append(d)
    return {
        "mode": req.mode.id,
        "lens": req.lens,
        "items": items,
        "cold_start": prof.cold,
        "seed_suggestions": [{"key": k, "label": label(k), "group": BY_KEY[k].group} for k in SEED_SUGGESTIONS] if prof.cold else [],
        "profile": profile_summary(prof, shadow),
        "sources": list(statuses.values()),
        "pool_size": len(pool),
    }


async def favorites_tracks(session: AsyncSession, user_id: str, limit: int = 500) -> list[Track]:
    rows = await session.execute(
        select(Track).join(Favorite, Favorite.track_id == Track.id).where(Favorite.user_id == user_id).limit(limit)
    )
    return list(rows.scalars())
