"""My Wave (FLOW / VOID / CHAOS × MAIN / SHADOW), AFTER DARK modes and feedback."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import delete
from sqlalchemy.ext.asyncio import AsyncSession

from ..core import ratelimit as rl
from ..core.deps import current_user
from ..core.errors import ApiError, not_found, too_many
from ..db import get_session, utcnow
from ..models import (
    ArtistExclusion,
    Favorite,
    Feedback,
    Impression,
    PlayEvent,
    TagBias,
    Track,
    User,
)
from ..music.registry import get_registry
from ..music.taxonomy import BY_KEY, label, top_tags
from .engine import RecRequest, load_catalog, profile_summary, recommend
from .modes import AFTER_DARK, WAVE_MODES
from .profile import build_profile, shadow_vector, tag_cooccurrence

router = APIRouter(tags=["recommendations"])


def _ids(raw: str | None) -> set[str]:
    return {x for x in (raw or "").split(",") if x and len(x) <= 200}


@router.get("/api/wave/next")
async def wave_next(
    mode: str = Query("flow", pattern="^(flow|void|chaos)$"),
    lens: str | None = Query(None, pattern="^(main|shadow)$"),
    count: int = Query(10, ge=1, le=30),
    current: str | None = Query(None, max_length=200),
    exclude: str | None = Query(None, max_length=8000),
    peek: bool = False,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    wait = rl.limiter.check(f"wave:{user.id}", rl.WAVE_USER)
    if wait:
        raise too_many(wait)
    lens = lens or (user.settings or {}).get("wave_lens", "main")
    req = RecRequest(
        mode=WAVE_MODES[mode],
        surface=f"wave:{mode}:{lens}",
        count=count,
        lens=lens,
        current_id=current,
        exclude=_ids(exclude),
        record=not peek,
    )
    return await recommend(session, get_registry(), user, req)


@router.get("/api/modes")
async def modes(_user: User = Depends(current_user)):
    return {"modes": [m.public() for m in AFTER_DARK.values()], "wave": [m.public() for m in WAVE_MODES.values()]}


@router.get("/api/modes/{mode_id}/next")
async def mode_next(
    mode_id: str,
    count: int = Query(10, ge=1, le=30),
    current: str | None = Query(None, max_length=200),
    exclude: str | None = Query(None, max_length=8000),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    mode = AFTER_DARK.get(mode_id)
    if mode is None:
        raise not_found("Режим не найден.")
    wait = rl.limiter.check(f"wave:{user.id}", rl.WAVE_USER)
    if wait:
        raise too_many(wait)
    req = RecRequest(mode=mode, surface=f"mode:{mode_id}", count=count, current_id=current, exclude=_ids(exclude))
    return await recommend(session, get_registry(), user, req)


class FeedbackIn(BaseModel):
    track_id: str = Field(max_length=200)
    kind: str = Field(pattern="^(like|unlike|dislike|more|less|exclude_artist|unexclude_artist)$")
    context: str = Field("", max_length=80)


async def _bias(session: AsyncSession, user_id: str, tags: list[str], delta: float) -> None:
    for tag in tags:
        row = await session.get(TagBias, (user_id, tag))
        if row is None:
            session.add(TagBias(user_id=user_id, tag=tag, weight=max(-3.0, min(3.0, delta))))
        else:
            row.weight = max(-3.0, min(3.0, row.weight + delta))


@router.post("/api/wave/feedback")
async def feedback(body: FeedbackIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await session.get(Track, body.track_id)
    if t is None or (t.owner_id and t.owner_id != user.id):
        raise not_found("Трек не найден.")
    result: dict[str, object] = {"ok": True, "kind": body.kind}
    if body.kind == "like":
        if await session.get(Favorite, (user.id, t.id)) is None:
            session.add(Favorite(user_id=user.id, track_id=t.id))
        session.add(Feedback(user_id=user.id, track_id=t.id, kind="like", context=body.context))
        await session.execute(delete(Feedback).where(Feedback.user_id == user.id, Feedback.track_id == t.id, Feedback.kind == "dislike"))
        result["liked"] = True
    elif body.kind == "unlike":
        await session.execute(delete(Favorite).where(Favorite.user_id == user.id, Favorite.track_id == t.id))
        await session.execute(delete(Feedback).where(Feedback.user_id == user.id, Feedback.track_id == t.id, Feedback.kind == "like"))
        result["liked"] = False
    elif body.kind == "dislike":
        await session.execute(delete(Favorite).where(Favorite.user_id == user.id, Favorite.track_id == t.id))
        await session.execute(delete(Feedback).where(Feedback.user_id == user.id, Feedback.track_id == t.id, Feedback.kind == "like"))
        session.add(Feedback(user_id=user.id, track_id=t.id, kind="dislike", context=body.context))
        result["liked"] = False
    elif body.kind in ("more", "less"):
        tags = top_tags(t.canonical or {}, 3)
        session.add(Feedback(user_id=user.id, track_id=t.id, kind=body.kind, context=body.context))
        await _bias(session, user.id, tags, 0.5 if body.kind == "more" else -0.5)
        result["tags"] = [label(x) for x in tags]
        if not tags:
            result["note"] = "У трека мало метаданных — учтём исполнителя и сам трек."
    elif body.kind == "exclude_artist":
        if await session.get(ArtistExclusion, (user.id, t.artist_key)) is None:
            session.add(ArtistExclusion(user_id=user.id, artist_key=t.artist_key, artist_name=t.artist))
        result["artist"] = t.artist
    elif body.kind == "unexclude_artist":
        await session.execute(delete(ArtistExclusion).where(ArtistExclusion.user_id == user.id, ArtistExclusion.artist_key == t.artist_key))
    await session.commit()
    return result


@router.delete("/api/wave/exclusions/{artist_key}")
async def remove_exclusion(artist_key: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    await session.execute(delete(ArtistExclusion).where(ArtistExclusion.user_id == user.id, ArtistExclusion.artist_key == artist_key))
    await session.commit()
    return {"ok": True}


@router.get("/api/wave/profile")
async def wave_profile(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    prof = await build_profile(session, user)
    catalog = await load_catalog(session, user, 1500)
    shadow = shadow_vector(prof, tag_cooccurrence(catalog))
    return profile_summary(prof, shadow)


class SeedsIn(BaseModel):
    tags: list[str] = Field(default_factory=list, max_length=12)


@router.put("/api/wave/seeds")
async def set_seeds(body: SeedsIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    tags = [t for t in body.tags if t in BY_KEY][:12]
    db_user = await session.get(User, user.id)
    assert db_user is not None
    settings = dict(db_user.settings or {})
    settings["seed_tags"] = tags
    db_user.settings = settings
    await session.commit()
    return {"seed_tags": tags}


class ResetIn(BaseModel):
    clear_history: bool = False
    clear_exclusions: bool = False
    confirm: bool = False


@router.post("/api/wave/reset")
async def reset(body: ResetIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    if not body.confirm:
        raise ApiError(400, "confirm_required", "Подтвердите сброс рекомендаций.")
    db_user = await session.get(User, user.id)
    assert db_user is not None
    settings = dict(db_user.settings or {})
    settings["rec_reset_at"] = utcnow().isoformat()
    settings["seed_tags"] = []
    db_user.settings = settings
    for model in (Feedback, TagBias, Impression):
        await session.execute(delete(model).where(model.user_id == user.id))
    if body.clear_history:
        await session.execute(delete(PlayEvent).where(PlayEvent.user_id == user.id))
    if body.clear_exclusions:
        await session.execute(delete(ArtistExclusion).where(ArtistExclusion.user_id == user.id))
    await session.commit()
    return {"ok": True, "reset_at": settings["rec_reset_at"]}
