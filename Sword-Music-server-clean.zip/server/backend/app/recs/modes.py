"""Mode definitions for My Wave (FLOW / VOID / CHAOS) and AFTER DARK.

Each mode is a *selection rule*, not a fixed playlist: a prior over canonical
tags, a region of mood space, things to avoid, and how much weight goes to the
user's own taste, novelty and diversity. Tag priors are matched against catalogue
metadata (genres, moods, tags); when metadata is thin, the match is approximate
and the UI says so.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..music.taxonomy import label


@dataclass(frozen=True)
class ModeDef:
    id: str
    name: str
    tagline: str
    description: str
    prior: dict[str, float] = field(default_factory=dict)
    avoid: dict[str, float] = field(default_factory=dict)
    target: tuple[float, float, float] | None = None
    bpm: tuple[float | None, float | None] = (None, None)
    # scoring weights
    w_mode: float = 0.0
    w_rel: float = 0.5
    w_novel: float = 0.1
    w_pop: float = 0.1
    w_cont: float = 0.1
    w_artist: float = 0.1
    mmr_lambda: float = 0.75
    max_per_artist: int = 2
    allow_heard: float = 0.2  # share of already-heard tracks allowed in a batch
    order: str = "score"  # score | rising | falling
    colors: tuple[str, str, str] = ("#8B5CFF", "#5C8DFF", "#141722")

    def public(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "tagline": self.tagline,
            "description": self.description,
            "tags": [{"key": k, "label": label(k)} for k, _ in sorted(self.prior.items(), key=lambda kv: -kv[1])[:6]],
            "avoid": [label(k) for k in list(self.avoid)[:4]],
            "colors": list(self.colors),
            "target": self.target,
        }


WAVE_MODES: dict[str, ModeDef] = {
    "flow": ModeDef(
        id="flow",
        name="FLOW",
        tagline="Ваш личный поток",
        description="Подбор по вашей истории, лайкам, повторам и любимым исполнителям с небольшой долей нового.",
        w_mode=0.0, w_rel=0.52, w_novel=0.08, w_pop=0.1, w_cont=0.14, w_artist=0.16,
        mmr_lambda=0.78, max_per_artist=2, allow_heard=0.25,
        colors=("#8B5CFF", "#5C8DFF", "#121426"),
    ),
    "void": ModeDef(
        id="void",
        name="VOID",
        tagline="Атмосферное погружение",
        description="Мрачное, атмосферное и пространственное звучание — с учётом того, что вы уже любите.",
        prior={"dark": 1.0, "atmospheric": 1.0, "dark_ambient": 0.9, "ambient": 0.7, "melancholic": 0.7,
               "space": 0.6, "cinematic": 0.5, "drone": 0.5, "night": 0.5, "mysterious": 0.5,
               "lonely": 0.4, "darksynth": 0.4, "postrock": 0.35, "phonk": 0.2},
        avoid={"happy": 1.0, "party": 0.8, "euphoric": 0.8, "funk": 0.5, "pop": 0.4, "workout": 0.5},
        target=(-0.55, 0.32, 0.9),
        w_mode=0.46, w_rel=0.28, w_novel=0.1, w_pop=0.08, w_cont=0.08, w_artist=0.0,
        mmr_lambda=0.72, max_per_artist=2, allow_heard=0.15,
        colors=("#4B3B8F", "#1D2B4F", "#06070B"),
    ),
    "chaos": ModeDef(
        id="chaos",
        name="CHAOS",
        tagline="Открытия на грани вкуса",
        description="Неожиданные жанры и новые исполнители — но рядом с вашим вкусом, а не случайные треки.",
        w_mode=0.0, w_rel=0.16, w_novel=0.38, w_pop=0.16, w_cont=0.0, w_artist=0.0,
        mmr_lambda=0.42, max_per_artist=1, allow_heard=0.0,
        colors=("#FF5C8A", "#FFB547", "#160C14"),
    ),
}

AFTER_DARK: dict[str, ModeDef] = {
    "void": ModeDef(
        id="void", name="VOID", tagline="Пространство и тишина",
        description="Атмосферная, пространственная музыка: эмбиент, дроун, кинематографичная темнота.",
        prior=WAVE_MODES["void"].prior, avoid=WAVE_MODES["void"].avoid, target=(-0.5, 0.25, 0.95),
        w_mode=0.56, w_rel=0.24, w_novel=0.1, w_pop=0.1, w_cont=0.0, mmr_lambda=0.7,
        colors=("#4B3B8F", "#1D2B4F", "#06070B"),
    ),
    "rage": ModeDef(
        id="rage", name="RAGE", tagline="Энергия на пределе",
        description="Интенсивное звучание: агрессивный фонк, индастриал, метал, драм-н-бейс, тяжёлый бас.",
        prior={"aggressive": 1.0, "energetic": 0.8, "phonk": 0.7, "metal": 0.7, "bass_heavy": 0.7, "heavy": 0.7,
               "industrial": 0.6, "dnb": 0.6, "dubstep": 0.6, "trap": 0.5, "battle": 0.5, "workout": 0.4, "darksynth": 0.4},
        avoid={"calm": 1.0, "sleep": 1.0, "ambient": 0.6, "romantic": 0.5, "dreamy": 0.5},
        target=(-0.35, 0.92, 0.35), bpm=(125, None),
        w_mode=0.56, w_rel=0.24, w_novel=0.1, w_pop=0.1, mmr_lambda=0.72,
        colors=("#FF3B3B", "#FF8A3D", "#140707"),
    ),
    "ego": ModeDef(
        id="ego", name="EGO", tagline="Уверенность и масштаб",
        description="Уверенная, выразительная, масштабная музыка: трэп, эпик, кинематографичный размах.",
        prior={"confident": 1.0, "epic": 0.8, "trap": 0.6, "hiphop": 0.6, "villain": 0.5, "phonk": 0.5,
               "cinematic": 0.45, "bass_heavy": 0.4, "orchestral": 0.3, "dramatic": 0.3},
        avoid={"sad": 0.8, "lonely": 0.6, "sleep": 0.8, "calm": 0.4},
        target=(0.3, 0.75, 0.55),
        w_mode=0.55, w_rel=0.25, w_novel=0.1, w_pop=0.1, mmr_lambda=0.72,
        colors=("#F5C451", "#8B5CFF", "#120E06"),
    ),
    "oblivion": ModeDef(
        id="oblivion", name="OBLIVION", tagline="Раствориться",
        description="Спокойные и погружающие композиции: эмбиент, лоуфай, фортепиано, дроун.",
        prior={"calm": 1.0, "ambient": 0.9, "dreamy": 0.8, "atmospheric": 0.8, "drone": 0.6, "sleep": 0.6,
               "lofi": 0.5, "piano": 0.5, "nature": 0.4, "downtempo": 0.4},
        avoid={"aggressive": 1.0, "energetic": 0.8, "metal": 0.8, "party": 0.7, "heavy": 0.7},
        target=(0.1, 0.12, 0.9), bpm=(None, 100),
        w_mode=0.58, w_rel=0.22, w_novel=0.1, w_pop=0.1, mmr_lambda=0.75,
        colors=("#5CC8FF", "#5C8DFF", "#060A10"),
    ),
    "ascension": ModeDef(
        id="ascension", name="ASCENSION", tagline="Движение вверх",
        description="Эпичная музыка с ощущением развития: оркестр, пост-рок, транс. Энергия растёт от трека к треку.",
        prior={"epic": 1.0, "uplifting": 0.8, "orchestral": 0.8, "cinematic": 0.8, "postrock": 0.7, "trance": 0.5,
               "choir": 0.5, "strings": 0.4, "euphoric": 0.4},
        avoid={"sad": 0.5, "creepy": 0.6, "lonely": 0.4},
        target=(0.45, 0.7, 0.85),
        w_mode=0.55, w_rel=0.25, w_novel=0.1, w_pop=0.1, mmr_lambda=0.75, order="rising",
        colors=("#FFD27A", "#5C8DFF", "#0B0C16"),
    ),
    "afterdark": ModeDef(
        id="afterdark", name="AFTER DARK", tagline="Ночь и меланхолия",
        description="Ночная, меланхоличная атмосфера: лоуфай, синтвейв, R&B, город после полуночи.",
        prior={"night": 1.0, "melancholic": 0.9, "lonely": 0.6, "city": 0.5, "rain": 0.5, "lofi": 0.5,
               "synthwave": 0.5, "downtempo": 0.5, "dreamy": 0.4, "rnb": 0.4, "jazz": 0.3},
        avoid={"happy": 0.7, "party": 0.6, "workout": 0.6},
        target=(-0.35, 0.35, 0.8),
        w_mode=0.55, w_rel=0.25, w_novel=0.1, w_pop=0.1, mmr_lambda=0.74,
        colors=("#8B5CFF", "#FF5C8A", "#08070E"),
    ),
}
