"""Local file storage for avatars, playlist covers, artwork and uploaded audio."""
from __future__ import annotations

import io
import uuid
from pathlib import Path

from fastapi import UploadFile
from PIL import Image, ImageOps, UnidentifiedImageError

from ..config import get_settings
from .errors import ApiError

MAX_IMAGE_BYTES = 8 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 40_000_000  # decompression-bomb guard


def media_root() -> Path:
    root = get_settings().data_dir / "media"
    root.mkdir(parents=True, exist_ok=True)
    return root


def media_url(rel: str | None) -> str | None:
    return f"/media/{rel}" if rel else None


def _safe_path(rel: str) -> Path:
    root = media_root().resolve()
    p = (root / rel).resolve()
    if root not in p.parents:
        raise ApiError(400, "bad_path", "Некорректный путь к файлу.")
    return p


def delete_media(rel: str | None) -> None:
    if not rel:
        return
    try:
        _safe_path(rel).unlink(missing_ok=True)
    except (OSError, ApiError):
        pass


def process_image_bytes(data: bytes, size: int) -> bytes:
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ApiError(415, "bad_image", "Файл не похож на изображение.") from exc
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA" if "A" in img.getbands() else "RGB")
    img = ImageOps.fit(img, (size, size), Image.Resampling.LANCZOS, centering=(0.5, 0.5))
    out = io.BytesIO()
    img.save(out, format="WEBP", quality=86, method=5)
    return out.getvalue()


async def save_image(upload: UploadFile, folder: str, size: int = 512) -> str:
    data = await upload.read(MAX_IMAGE_BYTES + 1)
    if len(data) > MAX_IMAGE_BYTES:
        raise ApiError(413, "too_large", "Изображение больше 8 МБ.")
    return save_image_bytes(data, folder, size)


def save_image_bytes(data: bytes, folder: str, size: int = 512) -> str:
    processed = process_image_bytes(data, size)
    rel = f"{folder}/{uuid.uuid4().hex}.webp"
    path = _safe_path(rel)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(processed)
    return rel


def uploads_dir(user_id: str) -> Path:
    d = get_settings().data_dir / "uploads" / user_id
    d.mkdir(parents=True, exist_ok=True)
    return d
