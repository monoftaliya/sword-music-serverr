"""Optional e-mail delivery (password reset). Works only when SMTP_* is configured."""
from __future__ import annotations

import asyncio
import logging
import smtplib
import ssl
from email.message import EmailMessage

from ..config import get_settings

log = logging.getLogger("sword.mail")


def _send_sync(to: str, subject: str, text: str) -> None:
    s = get_settings()
    msg = EmailMessage()
    msg["From"] = s.smtp_from
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(text)
    if s.smtp_port == 465:
        with smtplib.SMTP_SSL(s.smtp_host, s.smtp_port, context=ssl.create_default_context(), timeout=15) as smtp:
            if s.smtp_user:
                smtp.login(s.smtp_user, s.smtp_password)
            smtp.send_message(msg)
        return
    with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=15) as smtp:
        if s.smtp_tls:
            smtp.starttls(context=ssl.create_default_context())
        if s.smtp_user:
            smtp.login(s.smtp_user, s.smtp_password)
        smtp.send_message(msg)


async def send_mail(to: str, subject: str, text: str) -> bool:
    if not get_settings().smtp_configured:
        return False
    try:
        await asyncio.to_thread(_send_sync, to, subject, text)
        return True
    except Exception as exc:  # noqa: BLE001 — never leak SMTP details to the client
        log.warning("Mail delivery failed: %s", exc.__class__.__name__)
        return False
