"""Password hashing and opaque token helpers."""
from __future__ import annotations

import hashlib
import secrets
import string

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

_hasher = PasswordHasher(time_cost=3, memory_cost=64 * 1024, parallelism=2)

# A tiny deny-list; length + uniqueness checks below do most of the work.
_COMMON = {
    "password", "password1", "12345678", "123456789", "1234567890", "qwerty123",
    "qwertyuiop", "11111111", "iloveyou", "admin123", "letmein1", "йцукенгш",
    "пароль123", "00000000", "abc12345", "sword123", "swordai1",
}


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def needs_rehash(password_hash: str) -> bool:
    try:
        return _hasher.check_needs_rehash(password_hash)
    except InvalidHashError:
        return True


# A pre-computed hash used to equalise timing when the e-mail does not exist.
DUMMY_HASH = _hasher.hash(secrets.token_urlsafe(16))


def password_problem(password: str, email: str | None = None) -> str | None:
    """Return a human readable (Russian) problem description, or None if acceptable."""
    if len(password) < 8:
        return "Пароль должен содержать минимум 8 символов."
    if len(password) > 128:
        return "Пароль слишком длинный (максимум 128 символов)."
    if password.lower() in _COMMON:
        return "Этот пароль слишком распространён — выберите другой."
    if len(set(password)) < 4:
        return "Пароль слишком однообразный."
    if email and password.lower() == email.lower():
        return "Пароль не должен совпадать с e-mail."
    return None


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


_INVITE_ALPHABET = "".join(c for c in string.ascii_uppercase + string.digits if c not in "O0I1L")


def new_invite_code() -> str:
    raw = "".join(secrets.choice(_INVITE_ALPHABET) for _ in range(8))
    return f"SWRD-{raw[:4]}-{raw[4:]}"


def new_room_code() -> str:
    return "".join(secrets.choice(_INVITE_ALPHABET) for _ in range(6))
