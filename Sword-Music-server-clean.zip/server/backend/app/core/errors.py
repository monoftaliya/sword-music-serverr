"""Uniform API errors: {"error": {"code": str, "message": str, ...}}."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

log = logging.getLogger("sword.errors")


class ApiError(Exception):
    def __init__(
        self,
        status: int,
        code: str,
        message: str,
        *,
        extra: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.extra = extra or {}
        self.headers = headers


def not_found(message: str = "Не найдено.") -> ApiError:
    return ApiError(404, "not_found", message)


def forbidden(message: str = "Недостаточно прав.") -> ApiError:
    return ApiError(403, "forbidden", message)


def bad_request(message: str, code: str = "bad_request", **extra: Any) -> ApiError:
    return ApiError(400, code, message, extra=extra)


def too_many(retry_after: float, message: str = "Слишком много запросов. Попробуйте позже.") -> ApiError:
    secs = max(1, int(retry_after + 0.999))
    return ApiError(
        429, "rate_limited", message, extra={"retry_after": secs}, headers={"Retry-After": str(secs)}
    )


_STATUS_CODES = {
    400: "bad_request",
    401: "unauthorized",
    403: "forbidden",
    404: "not_found",
    405: "method_not_allowed",
    409: "conflict",
    413: "too_large",
    415: "unsupported_media",
    422: "validation_error",
    429: "rate_limited",
}

_FIELD_NAMES = {
    "email": "e-mail",
    "password": "пароль",
    "display_name": "имя",
    "name": "название",
}


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(ApiError)
    async def _api_error(_req: Request, exc: ApiError):  # noqa: ANN202
        body = {"error": {"code": exc.code, "message": exc.message, **exc.extra}}
        return JSONResponse(body, status_code=exc.status, headers=exc.headers)

    @app.exception_handler(RequestValidationError)
    async def _validation(_req: Request, exc: RequestValidationError):  # noqa: ANN202
        fields = []
        for err in exc.errors():
            loc = [str(x) for x in err.get("loc", []) if x not in ("body", "query", "path")]
            fields.append({"field": ".".join(loc), "message": err.get("msg", "")})
        first = fields[0]["field"] if fields else ""
        human = _FIELD_NAMES.get(first.split(".")[-1], first)
        msg = f"Проверьте поле «{human}»." if human else "Некорректный запрос."
        return JSONResponse(
            {"error": {"code": "validation_error", "message": msg, "fields": fields}},
            status_code=422,
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_req: Request, exc: StarletteHTTPException):  # noqa: ANN202
        code = _STATUS_CODES.get(exc.status_code, "error")
        message = exc.detail if isinstance(exc.detail, str) else "Ошибка запроса."
        return JSONResponse(
            {"error": {"code": code, "message": message}},
            status_code=exc.status_code,
            headers=getattr(exc, "headers", None),
        )

    @app.exception_handler(Exception)
    async def _unhandled(_req: Request, exc: Exception):  # noqa: ANN202
        log.exception("Unhandled error: %s", exc.__class__.__name__)
        return JSONResponse(
            {"error": {"code": "internal", "message": "Внутренняя ошибка сервера."}},
            status_code=500,
        )
