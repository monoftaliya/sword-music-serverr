"""Small in-memory sliding-window rate limiter.

Good enough for a single-process deployment used by a group of friends. For a
multi-worker setup put a shared store (e.g. Redis) behind the same interface.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass
from threading import Lock


@dataclass
class Limit:
    count: int
    window: float  # seconds


class RateLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()
        self._last_sweep = time.monotonic()

    def _sweep(self, now: float) -> None:
        if now - self._last_sweep < 300:
            return
        self._last_sweep = now
        for key in list(self._hits.keys()):
            dq = self._hits[key]
            while dq and now - dq[0] > 3600 * 6:
                dq.popleft()
            if not dq:
                del self._hits[key]

    def check(self, key: str, limit: Limit, *, consume: bool = True) -> float:
        """Return 0 if allowed, otherwise seconds until the next attempt is allowed."""
        now = time.monotonic()
        with self._lock:
            self._sweep(now)
            dq = self._hits[key]
            while dq and now - dq[0] > limit.window:
                dq.popleft()
            if len(dq) >= limit.count:
                return max(0.5, limit.window - (now - dq[0]))
            if consume:
                dq.append(now)
            return 0.0

    def hit(self, key: str) -> None:
        with self._lock:
            self._hits[key].append(time.monotonic())

    def reset(self, key: str) -> None:
        with self._lock:
            self._hits.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()

LOGIN_IP = Limit(20, 15 * 60)
LOGIN_FAIL_EMAIL = Limit(6, 15 * 60)
REGISTER_IP = Limit(8, 60 * 60)
FORGOT = Limit(4, 60 * 60)
INVITE_CHECK = Limit(30, 60 * 60)
SEARCH_USER = Limit(90, 60)
WAVE_USER = Limit(60, 60)
UPLOAD_USER = Limit(60, 60 * 60)
