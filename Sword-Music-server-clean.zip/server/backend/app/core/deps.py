"""Request dependencies: authentication, client IP, CSRF guard."""
from __future__ import annotations

import json
from datetime import timedelta

from fastapi import Depends, Request, WebSocket
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.types import ASGIApp, Receive, Scope, Send

from ..config import get_settings
from ..db import get_session, get_sessionmaker, utcnow
from ..models import User, UserSession
from .errors import ApiError
from .security import token_hash

SESSION_COOKIE = "sword_session"
CSRF_HEADER = "x-sword-client"


def client_ip(request: Request | WebSocket) -> str:
    if get_settings().trust_proxy:
        xff = request.headers.get("x-forwarded-for")
        if xff:
            return xff.split(",")[0].strip()[:64]
        real = request.headers.get("x-real-ip")
        if real:
            return real.strip()[:64]
    return (request.client.host if request.client else "unknown")[:64]


def _extract_token(conn: Request | WebSocket) -> str | None:
    auth = conn.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip() or None
    return conn.cookies.get(SESSION_COOKIE)


async def resolve_user(session: AsyncSession, token: str | None) -> tuple[User, UserSession] | None:
    if not token or len(token) > 200:
        return None
    row = (
        await session.execute(
            select(UserSession, User)
            .join(User, User.id == UserSession.user_id)
            .where(UserSession.token_hash == token_hash(token))
        )
    ).first()
    if row is None:
        return None
    sess, user = row
    now = utcnow()
    if sess.expires_at <= now or not user.is_active:
        return None
    # Sliding expiration, written at most once per hour to keep requests cheap.
    if now - sess.last_used_at > timedelta(hours=1):
        sess.last_used_at = now
        days = get_settings().session_days
        if sess.expires_at - now < timedelta(days=days / 2):
            sess.expires_at = now + timedelta(days=days)
        await session.commit()
    return user, sess


async def optional_user(
    request: Request, session: AsyncSession = Depends(get_session)
) -> User | None:
    resolved = await resolve_user(session, _extract_token(request))
    if resolved is None:
        return None
    user, sess = resolved
    request.state.session_id = sess.id
    return user


async def current_user(user: User | None = Depends(optional_user)) -> User:
    if user is None:
        raise ApiError(401, "unauthorized", "Требуется вход в аккаунт.")
    return user


async def admin_user(user: User = Depends(current_user)) -> User:
    if not user.is_admin:
        raise ApiError(403, "forbidden", "Доступно только администратору.")
    return user


async def websocket_user(ws: WebSocket) -> User | None:
    async with get_sessionmaker()() as session:
        resolved = await resolve_user(session, _extract_token(ws) or ws.query_params.get("token"))
        return resolved[0] if resolved else None


class CSRFGuard:
    """Reject state-changing cookie-authenticated API requests without our custom header.

    Browsers cannot attach custom headers to cross-site requests without a CORS
    pre-flight (which we do not allow), so this blocks CSRF in combination with
    SameSite=Lax cookies. Bearer-token clients are not affected.
    """

    SAFE = {"GET", "HEAD", "OPTIONS"}

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http" and scope["method"] not in self.SAFE:
            path: str = scope.get("path", "")
            if path.startswith("/api/"):
                headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
                has_bearer = headers.get("authorization", "").lower().startswith("bearer ")
                if not has_bearer and CSRF_HEADER not in headers:
                    body = json.dumps(
                        {"error": {"code": "csrf", "message": "Запрос отклонён (CSRF)."}},
                        ensure_ascii=False,
                    ).encode()
                    await send(
                        {
                            "type": "http.response.start",
                            "status": 403,
                            "headers": [(b"content-type", b"application/json")],
                        }
                    )
                    await send({"type": "http.response.body", "body": body})
                    return
        await self.app(scope, receive, send)
