"""User audio uploads — private to the uploader, streamed with HTTP Range support."""
from __future__ import annotations

import asyncio
import base64
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..core import ratelimit as rl
from ..core.deps import current_user
from ..core.errors import ApiError, not_found, too_many
from ..core.storage import delete_media, media_url, save_image_bytes, uploads_dir
from ..db import get_session, utcnow
from ..models import Track, User
from ..music.normalize import artist_key, norm_key
from ..music.store import track_out
from ..music.taxonomy import canonicalize

router = APIRouter(tags=["uploads"])

ALLOWED = {
    ".mp3": "audio/mpeg",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".ogg": "audio/ogg",
    ".oga": "audio/ogg",
    ".opus": "audio/ogg",
    ".flac": "audio/flac",
    ".wav": "audio/wav",
    ".webm": "audio/webm",
}


def _first(tags: Any, key: str) -> str | None:
    try:
        val = tags.get(key) if tags else None
    except (KeyError, ValueError, TypeError):
        return None
    if isinstance(val, list):
        val = val[0] if val else None
    return str(val).strip()[:300] if val else None


def _read_audio(path: Path) -> dict[str, Any]:
    import mutagen

    try:
        audio = mutagen.File(str(path))
        easy = mutagen.File(str(path), easy=True)
    except Exception:  # noqa: BLE001 — mutagen raises many types on bad files
        audio = None
        easy = None
    if audio is None or not getattr(audio, "info", None):
        return {}
    info: dict[str, Any] = {"duration": float(getattr(audio.info, "length", 0) or 0)}
    tags = getattr(easy, "tags", None) if easy is not None else None
    info["title"] = _first(tags, "title")
    info["artist"] = _first(tags, "artist")
    info["album"] = _first(tags, "album")
    info["genre"] = _first(tags, "genre")
    info["date"] = _first(tags, "date")
    pic: bytes | None = None
    try:
        t = audio.tags
        if t is not None:
            if hasattr(t, "getall"):  # ID3
                frames = t.getall("APIC")
                if frames:
                    pic = frames[0].data
            elif "covr" in t:  # MP4
                pic = bytes(t["covr"][0])
            elif "metadata_block_picture" in t:  # Ogg
                from mutagen.flac import Picture

                pic = Picture(base64.b64decode(t["metadata_block_picture"][0])).data
        if pic is None and getattr(audio, "pictures", None):  # FLAC
            pic = audio.pictures[0].data
    except Exception:  # noqa: BLE001
        pic = None
    info["picture"] = pic
    return info


async def _quota_used(session: AsyncSession, user_id: str) -> int:
    rows = await session.execute(select(Track.extra).where(Track.provider == "upload", Track.owner_id == user_id))
    return sum(int((e or {}).get("size") or 0) for e in rows.scalars())


@router.get("/api/library/uploads")
async def list_uploads(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    rows = await session.execute(
        select(Track).where(Track.provider == "upload", Track.owner_id == user.id).order_by(Track.created_at.desc())
    )
    tracks = list(rows.scalars())
    used = sum(int((t.extra or {}).get("size") or 0) for t in tracks)
    from ..music.store import tracks_out

    return {
        "items": await tracks_out(session, user.id, tracks),
        "used_bytes": used,
        "quota_bytes": get_settings().upload_quota_mb * 1024 * 1024,
    }


@router.post("/api/uploads")
async def upload(file: UploadFile = File(...), session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    s = get_settings()
    if "uploads" not in s.enabled_provider_ids:
        raise ApiError(403, "uploads_disabled", "Загрузка файлов отключена администратором.")
    wait = rl.limiter.check(f"upload:{user.id}", rl.UPLOAD_USER)
    if wait:
        raise too_many(wait)
    name = (file.filename or "audio").strip()
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED:
        raise ApiError(415, "bad_format", "Поддерживаются MP3, M4A/AAC, OGG/Opus, FLAC, WAV и WebM.")
    max_bytes = s.upload_max_mb * 1024 * 1024
    quota = s.upload_quota_mb * 1024 * 1024
    used = await _quota_used(session, user.id)
    file_id = uuid.uuid4().hex
    dest = uploads_dir(user.id) / f"{file_id}{ext}"
    size = 0
    try:
        with dest.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > max_bytes:
                    raise ApiError(413, "too_large", f"Файл больше {s.upload_max_mb} МБ.")
                if used + size > quota:
                    raise ApiError(413, "quota", "Недостаточно места: превышена квота загрузок.")
                out.write(chunk)
        meta = await asyncio.to_thread(_read_audio, dest)
        if not meta or meta.get("duration", 0) <= 0:
            raise ApiError(415, "not_audio", "Не удалось распознать аудиофайл.")
    except BaseException:
        dest.unlink(missing_ok=True)
        raise
    art_rel = None
    if meta.get("picture"):
        try:
            art_rel = save_image_bytes(meta["picture"], "art", 600)
        except ApiError:
            art_rel = None
    title = meta.get("title") or Path(name).stem.replace("_", " ")[:300]
    artist = meta.get("artist") or "Неизвестный исполнитель"
    genres = [meta["genre"]] if meta.get("genre") else []
    track = Track(
        id=f"upload:{file_id}",
        provider="upload",
        provider_track_id=file_id,
        title=title,
        artist=artist,
        album=meta.get("album"),
        duration=round(meta["duration"], 2),
        artwork_url=media_url(art_rel),
        artwork_small=media_url(art_rel),
        stream_kind="full",
        license="Личный файл",
        genres=genres,
        canonical=canonicalize(genres=genres),
        release_date=meta.get("date"),
        norm_key=norm_key(title, artist),
        artist_key=artist_key(artist),
        owner_id=user.id,
        extra={
            "path": str(dest.relative_to(s.data_dir)),
            "mime": ALLOWED[ext],
            "size": size,
            "original_name": name[:200],
            "art": art_rel,
        },
    )
    session.add(track)
    await session.commit()
    return track_out(track)


async def _own_upload(session: AsyncSession, track_id: str, user: User) -> Track:
    t = await session.get(Track, track_id)
    if t is None or t.provider != "upload" or t.owner_id != user.id:
        raise not_found("Файл не найден.")
    return t


@router.get("/api/uploads/{track_id}/file")
async def upload_file(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await _own_upload(session, track_id, user)
    s = get_settings()
    path = (s.data_dir / (t.extra or {}).get("path", "")).resolve()
    if s.data_dir.resolve() not in path.parents or not path.exists():
        raise not_found("Файл отсутствует на сервере.")
    return FileResponse(path, media_type=(t.extra or {}).get("mime") or "application/octet-stream")


class UploadPatch(BaseModel):
    title: str | None = Field(None, min_length=1, max_length=300)
    artist: str | None = Field(None, min_length=1, max_length=300)
    album: str | None = Field(None, max_length=300)


@router.patch("/api/uploads/{track_id}")
async def edit_upload(
    track_id: str, body: UploadPatch, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    t = await _own_upload(session, track_id, user)
    if body.title is not None:
        t.title = body.title.strip()
    if body.artist is not None:
        t.artist = body.artist.strip()
    if body.album is not None:
        t.album = body.album.strip() or None
    t.norm_key = norm_key(t.title, t.artist)
    t.artist_key = artist_key(t.artist)
    t.updated_at = utcnow()
    await session.commit()
    return track_out(t)


@router.delete("/api/uploads/{track_id}")
async def delete_upload(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await _own_upload(session, track_id, user)
    s = get_settings()
    extra = t.extra or {}
    await session.delete(t)
    await session.commit()
    path = (s.data_dir / extra.get("path", "")).resolve()
    if s.data_dir.resolve() in path.parents:
        path.unlink(missing_ok=True)
    delete_media(extra.get("art"))
    return {"ok": True}
