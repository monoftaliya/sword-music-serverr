"""Playlists: CRUD, ordering, covers and share links."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, File, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.deps import current_user
from ..core.errors import ApiError, not_found
from ..core.security import new_token
from ..core.storage import delete_media, media_url, save_image
from ..db import get_session, utcnow
from ..models import Playlist, PlaylistTrack, Track, User
from ..music.store import liked_ids, track_out

router = APIRouter(tags=["playlists"])
MAX_TRACKS = 5000


class PlaylistIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field("", max_length=600)


class PlaylistPatch(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=120)
    description: str | None = Field(None, max_length=600)


class AddTracksIn(BaseModel):
    track_ids: list[str] = Field(min_length=1, max_length=500)
    allow_duplicates: bool = False


class OrderIn(BaseModel):
    item_ids: list[int] = Field(max_length=MAX_TRACKS)


async def _own_playlist(session: AsyncSession, playlist_id: str, user: User) -> Playlist:
    pl = await session.get(Playlist, playlist_id)
    if pl is None or pl.owner_id != user.id:
        raise not_found("Плейлист не найден.")
    return pl


async def playlist_summaries(session: AsyncSession, playlists: list[Playlist]) -> list[dict[str, Any]]:
    if not playlists:
        return []
    ids = [p.id for p in playlists]
    stats = await session.execute(
        select(PlaylistTrack.playlist_id, func.count(PlaylistTrack.id), func.coalesce(func.sum(Track.duration), 0))
        .join(Track, Track.id == PlaylistTrack.track_id)
        .where(PlaylistTrack.playlist_id.in_(ids))
        .group_by(PlaylistTrack.playlist_id)
    )
    by_id = {pid: (cnt, dur) for pid, cnt, dur in stats}
    covers: dict[str, list[str]] = {pid: [] for pid in ids}
    rows = await session.execute(
        select(PlaylistTrack.playlist_id, Track.artwork_small, Track.artwork_url)
        .join(Track, Track.id == PlaylistTrack.track_id)
        .where(PlaylistTrack.playlist_id.in_(ids))
        .order_by(PlaylistTrack.playlist_id, PlaylistTrack.position)
    )
    for pid, small, big in rows:
        art = small or big
        if art and len(covers[pid]) < 4 and art not in covers[pid]:
            covers[pid].append(art)
    out = []
    for p in playlists:
        cnt, dur = by_id.get(p.id, (0, 0))
        out.append(
            {
                "id": p.id,
                "name": p.name,
                "description": p.description,
                "cover": media_url(p.cover_path),
                "mosaic": covers[p.id],
                "track_count": int(cnt or 0),
                "duration": float(dur or 0),
                "shared": bool(p.share_token),
                "updated_at": p.updated_at.isoformat(),
                "created_at": p.created_at.isoformat(),
            }
        )
    return out


async def playlist_detail(session: AsyncSession, pl: Playlist, viewer: User, *, owner_view: bool) -> dict[str, Any]:
    rows = await session.execute(
        select(PlaylistTrack, Track)
        .join(Track, Track.id == PlaylistTrack.track_id)
        .where(PlaylistTrack.playlist_id == pl.id)
        .order_by(PlaylistTrack.position, PlaylistTrack.id)
    )
    pairs = list(rows.all())
    liked = await liked_ids(session, viewer.id, [t.id for _, t in pairs])
    items = []
    for it, t in pairs:
        data = track_out(t, liked=t.id in liked)
        if t.owner_id and t.owner_id != viewer.id:
            data["playable"] = False
            data["unavailable"] = "Личный файл владельца плейлиста — доступен только ему."
        items.append({"item_id": it.id, "added_at": it.added_at.isoformat(), "track": data})
    summary = (await playlist_summaries(session, [pl]))[0]
    owner = await session.get(User, pl.owner_id)
    summary.update(
        {
            "items": items,
            "owner": {"id": pl.owner_id, "display_name": owner.display_name if owner else "?"},
            "is_owner": owner_view,
            "share_token": pl.share_token if owner_view else None,
        }
    )
    return summary


async def _renumber(session: AsyncSession, playlist_id: str) -> None:
    rows = await session.execute(
        select(PlaylistTrack).where(PlaylistTrack.playlist_id == playlist_id).order_by(PlaylistTrack.position, PlaylistTrack.id)
    )
    for i, it in enumerate(rows.scalars()):
        it.position = i


@router.get("/api/playlists")
async def list_playlists(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    rows = await session.execute(select(Playlist).where(Playlist.owner_id == user.id).order_by(Playlist.updated_at.desc()))
    return {"playlists": await playlist_summaries(session, list(rows.scalars()))}


@router.post("/api/playlists")
async def create_playlist(body: PlaylistIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    count = (await session.execute(select(func.count()).select_from(Playlist).where(Playlist.owner_id == user.id))).scalar_one()
    if count >= 500:
        raise ApiError(400, "limit", "Достигнут лимит плейлистов (500).")
    pl = Playlist(owner_id=user.id, name=body.name.strip(), description=body.description.strip())
    session.add(pl)
    await session.commit()
    return (await playlist_summaries(session, [pl]))[0]


@router.get("/api/playlists/{playlist_id}")
async def get_playlist(playlist_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _own_playlist(session, playlist_id, user)
    return await playlist_detail(session, pl, user, owner_view=True)


@router.patch("/api/playlists/{playlist_id}")
async def update_playlist(
    playlist_id: str, body: PlaylistPatch, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    pl = await _own_playlist(session, playlist_id, user)
    if body.name is not None:
        pl.name = body.name.strip()
    if body.description is not None:
        pl.description = body.description.strip()
    pl.updated_at = utcnow()
    await session.commit()
    return (await playlist_summaries(session, [pl]))[0]


@router.delete("/api/playlists/{playlist_id}")
async def delete_playlist(playlist_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _own_playlist(session, playlist_id, user)
    cover = pl.cover_path
    await session.delete(pl)
    await session.commit()
    delete_media(cover)
    return {"ok": True}


@router.post("/api/playlists/{playlist_id}/tracks")
async def add_tracks(
    playlist_id: str, body: AddTracksIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    pl = await _own_playlist(session, playlist_id, user)
    existing_rows = await session.execute(select(PlaylistTrack.track_id).where(PlaylistTrack.playlist_id == pl.id))
    existing = set(existing_rows.scalars())
    if len(existing) + len(body.track_ids) > MAX_TRACKS:
        raise ApiError(400, "limit", f"В плейлисте может быть не больше {MAX_TRACKS} треков.")
    found = await session.execute(select(Track).where(Track.id.in_(body.track_ids)))
    tracks = {t.id: t for t in found.scalars()}
    max_pos = (
        await session.execute(select(func.coalesce(func.max(PlaylistTrack.position), -1)).where(PlaylistTrack.playlist_id == pl.id))
    ).scalar_one()
    added, skipped = 0, 0
    for tid in body.track_ids:
        t = tracks.get(tid)
        if t is None or (t.owner_id and t.owner_id != user.id):
            skipped += 1
            continue
        if tid in existing and not body.allow_duplicates:
            skipped += 1
            continue
        max_pos += 1
        session.add(PlaylistTrack(playlist_id=pl.id, track_id=tid, position=max_pos, added_by=user.id))
        existing.add(tid)
        added += 1
    pl.updated_at = utcnow()
    await session.commit()
    return {"added": added, "skipped": skipped}


@router.delete("/api/playlists/{playlist_id}/tracks/{item_id}")
async def remove_track(
    playlist_id: str, item_id: int, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    pl = await _own_playlist(session, playlist_id, user)
    await session.execute(delete(PlaylistTrack).where(PlaylistTrack.id == item_id, PlaylistTrack.playlist_id == pl.id))
    await _renumber(session, pl.id)
    pl.updated_at = utcnow()
    await session.commit()
    return {"ok": True}


@router.put("/api/playlists/{playlist_id}/order")
async def reorder(playlist_id: str, body: OrderIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _own_playlist(session, playlist_id, user)
    rows = await session.execute(select(PlaylistTrack).where(PlaylistTrack.playlist_id == pl.id))
    items = {it.id: it for it in rows.scalars()}
    if set(body.item_ids) != set(items.keys()):
        raise ApiError(409, "stale_order", "Плейлист изменился — обновите страницу и повторите.")
    for pos, iid in enumerate(body.item_ids):
        items[iid].position = pos
    pl.updated_at = utcnow()
    await session.commit()
    return {"ok": True}


@router.post("/api/playlists/{playlist_id}/cover")
async def set_cover(
    playlist_id: str,
    file: UploadFile = File(...),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    pl = await _own_playlist(session, playlist_id, user)
    rel = await save_image(file, "covers", 640)
    old = pl.cover_path
    pl.cover_path = rel
    pl.updated_at = utcnow()
    await session.commit()
    delete_media(old)
    return {"cover": media_url(rel)}


@router.delete("/api/playlists/{playlist_id}/cover")
async def remove_cover(playlist_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _own_playlist(session, playlist_id, user)
    old = pl.cover_path
    pl.cover_path = None
    await session.commit()
    delete_media(old)
    return {"ok": True}


@router.post("/api/playlists/{playlist_id}/share")
async def share(playlist_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _own_playlist(session, playlist_id, user)
    if not pl.share_token:
        pl.share_token = new_token(18)
        await session.commit()
    return {"token": pl.share_token, "path": f"/shared/?token={pl.share_token}"}


@router.delete("/api/playlists/{playlist_id}/share")
async def unshare(playlist_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _own_playlist(session, playlist_id, user)
    pl.share_token = None
    await session.commit()
    return {"ok": True}


async def _shared(session: AsyncSession, token: str) -> Playlist:
    if not token or len(token) > 80:
        raise not_found("Ссылка недействительна.")
    pl = (await session.execute(select(Playlist).where(Playlist.share_token == token))).scalar_one_or_none()
    if pl is None:
        raise not_found("Ссылка недействительна или доступ к плейлисту закрыт.")
    return pl


@router.get("/api/shared/{token}")
async def shared_playlist(token: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pl = await _shared(session, token)
    return await playlist_detail(session, pl, user, owner_view=pl.owner_id == user.id)


@router.post("/api/shared/{token}/save")
async def save_shared(token: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    src = await _shared(session, token)
    owner = await session.get(User, src.owner_id)
    copy = Playlist(
        owner_id=user.id,
        name=src.name[:120],
        description=(src.description or f"Копия плейлиста {owner.display_name if owner else ''}".strip())[:600],
        copied_from=src.id,
    )
    session.add(copy)
    await session.flush()
    rows = await session.execute(
        select(PlaylistTrack, Track)
        .join(Track, Track.id == PlaylistTrack.track_id)
        .where(PlaylistTrack.playlist_id == src.id)
        .order_by(PlaylistTrack.position)
    )
    pos = 0
    for _it, t in rows.all():
        if t.owner_id and t.owner_id != user.id:
            continue  # private uploads of the owner are not copied
        session.add(PlaylistTrack(playlist_id=copy.id, track_id=t.id, position=pos, added_by=user.id))
        pos += 1
    await session.commit()
    return (await playlist_summaries(session, [copy]))[0]
