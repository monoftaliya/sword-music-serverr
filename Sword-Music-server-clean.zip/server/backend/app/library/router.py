"""Library: favourites, recents, artists, albums, listening events, player state, home feed."""
from __future__ import annotations

import math
from collections import defaultdict
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.deps import current_user
from ..core.errors import not_found
from ..db import get_session, utcnow
from ..models import Favorite, Feedback, PlayEvent, Playlist, PlaylistTrack, Track, User
from ..music.normalize import clean_words
from ..music.providers.base import ProviderError
from ..music.registry import NAMES, get_registry
from ..music.store import liked_ids, load_tracks, save_results, track_out, tracks_out
from ..search.service import run_search
from ..users.schemas import merged_settings
from .playlists import playlist_summaries

router = APIRouter(tags=["library"])


# ------------------------------------------------------------------ favourites
@router.get("/api/library/favorites")
async def favorites(
    offset: int = Query(0, ge=0),
    limit: int = Query(60, ge=1, le=200),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    total = (await session.execute(select(func.count()).select_from(Favorite).where(Favorite.user_id == user.id))).scalar_one()
    rows = await session.execute(
        select(Track)
        .join(Favorite, Favorite.track_id == Track.id)
        .where(Favorite.user_id == user.id)
        .order_by(Favorite.created_at.desc())
        .offset(offset)
        .limit(limit)
    )
    items = [track_out(t, liked=True) for t in rows.scalars()]
    return {"items": items, "total": total, "offset": offset}


@router.put("/api/library/favorites/{track_id}")
async def add_favorite(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await session.get(Track, track_id)
    if t is None or (t.owner_id and t.owner_id != user.id):
        raise not_found("Трек не найден.")
    exists = await session.get(Favorite, (user.id, track_id))
    if exists is None:
        session.add(Favorite(user_id=user.id, track_id=track_id))
        session.add(Feedback(user_id=user.id, track_id=track_id, kind="like", context="favorite"))
        await session.commit()
    return {"liked": True}


@router.delete("/api/library/favorites/{track_id}")
async def remove_favorite(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    await session.execute(delete(Favorite).where(Favorite.user_id == user.id, Favorite.track_id == track_id))
    # an un-like is a withdrawal of the positive signal, not a dislike
    await session.execute(
        delete(Feedback).where(Feedback.user_id == user.id, Feedback.track_id == track_id, Feedback.kind == "like")
    )
    await session.commit()
    return {"liked": False}


# ------------------------------------------------------------------ recents
async def recent_tracks(session: AsyncSession, user_id: str, limit: int = 30) -> list[tuple[Track, Any]]:
    sub = (
        select(PlayEvent.track_id, func.max(PlayEvent.started_at).label("last"))
        .where(PlayEvent.user_id == user_id)
        .group_by(PlayEvent.track_id)
        .subquery()
    )
    rows = await session.execute(
        select(Track, sub.c.last).join(sub, sub.c.track_id == Track.id).order_by(sub.c.last.desc()).limit(limit)
    )
    return [(t, last) for t, last in rows.all()]


@router.get("/api/library/recent")
async def recent(limit: int = Query(40, ge=1, le=200), session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pairs = await recent_tracks(session, user.id, limit)
    liked = await liked_ids(session, user.id, [t.id for t, _ in pairs])
    return {"items": [{**track_out(t, liked=t.id in liked), "played_at": last.isoformat() if last else None} for t, last in pairs]}


# ------------------------------------------------------------------ artists & albums
async def _library_tracks(session: AsyncSession, user_id: str) -> dict[str, tuple[Track, float]]:
    """Tracks the user interacted with, weighted (likes > repeated plays > playlist membership)."""
    weights: dict[str, float] = defaultdict(float)
    for (tid,) in (await session.execute(select(Favorite.track_id).where(Favorite.user_id == user_id))).all():
        weights[tid] += 3.0
    since = utcnow() - timedelta(days=365)
    plays = await session.execute(
        select(PlayEvent.track_id, func.count(PlayEvent.id))
        .where(PlayEvent.user_id == user_id, PlayEvent.started_at >= since, PlayEvent.skipped.is_(False))
        .group_by(PlayEvent.track_id)
    )
    for tid, cnt in plays.all():
        weights[tid] += 1.0 + math.log1p(cnt)
    pl = await session.execute(
        select(PlaylistTrack.track_id).join(Playlist, Playlist.id == PlaylistTrack.playlist_id).where(Playlist.owner_id == user_id)
    )
    for (tid,) in pl.all():
        weights[tid] += 0.8
    tracks = await load_tracks(session, weights.keys())
    return {tid: (tracks[tid], w) for tid, w in weights.items() if tid in tracks}


@router.get("/api/library/artists")
async def artists(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    lib = await _library_tracks(session, user.id)
    agg: dict[str, dict[str, Any]] = {}
    for t, w in lib.values():
        a = agg.setdefault(
            t.artist_key,
            {"key": t.artist_key, "name": t.artist, "score": 0.0, "tracks": 0, "artwork": None, "provider": t.provider, "ref": t.artist_ref},
        )
        a["score"] += w
        a["tracks"] += 1
        if not a["artwork"] and t.artwork_small:
            a["artwork"] = t.artwork_small
    items = sorted(agg.values(), key=lambda a: -a["score"])
    for a in items:
        a["score"] = round(a["score"], 2)
    return {"items": items[:200]}


@router.get("/api/library/albums")
async def albums(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    lib = await _library_tracks(session, user.id)
    agg: dict[str, dict[str, Any]] = {}
    for t, w in lib.values():
        if not t.album:
            continue
        key = f"{t.provider}:{t.album_ref}" if t.album_ref else f"name:{clean_words(t.artist)}|{clean_words(t.album)}"
        a = agg.setdefault(
            key,
            {"key": key, "name": t.album, "artist": t.artist, "provider": t.provider, "ref": t.album_ref, "artwork": t.artwork_url, "score": 0.0, "tracks": 0},
        )
        a["score"] += w
        a["tracks"] += 1
    items = sorted(agg.values(), key=lambda a: -a["score"])
    return {"items": items[:200]}


@router.get("/api/artists/{artist_key}")
async def artist_page(
    artist_key: str,
    name: str = Query("", max_length=300),
    provider: str | None = Query(None, max_length=32),
    ref: str | None = Query(None, max_length=160),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    lib_rows = await session.execute(
        select(Track).where(Track.artist_key == artist_key, (Track.owner_id.is_(None)) | (Track.owner_id == user.id)).limit(200)
    )
    known = list(lib_rows.scalars())
    display = name or (known[0].artist if known else artist_key.removeprefix("a:"))
    registry = get_registry()
    top: list[Track] = []
    sources: list[dict[str, Any]] = []
    if provider and ref and registry.usable(provider):
        p = registry.get(provider)
        assert p is not None
        try:
            res = await registry.run(p, "artist", lambda: p.artist_tracks(ref, 100), cache_key=ref, ttl=3600)
            stored = await save_results(session, res)
            top = [stored[r.id] for r in res if r.id in stored]
            sources.append({"id": provider, "name": NAMES.get(provider, provider), "status": "ok", "count": len(top)})
        except ProviderError as exc:
            sources.append({"id": provider, "name": NAMES.get(provider, provider), "status": "error", "message": exc.message})
    if not top and display:
        res = await run_search(session, registry, user, display, mode="text", limit=40)
        ids = [r["id"] for r in res["results"] if r["artist_key"] == artist_key]
        loaded = await load_tracks(session, ids)
        top = [loaded[i] for i in ids if i in loaded]
        sources.extend(res["sources"])
    lib_ids = set()
    lib = await _library_tracks(session, user.id)
    in_library = [t for t, _w in sorted(lib.values(), key=lambda x: -x[1]) if t.artist_key == artist_key]
    lib_ids = {t.id for t in in_library}
    top = [t for t in top if t.id not in lib_ids]
    artwork = next((t.artwork_url for t in [*in_library, *top, *known] if t.artwork_url), None)
    return {
        "key": artist_key,
        "name": display,
        "artwork": artwork,
        "library": await tracks_out(session, user.id, in_library[:50]),
        "top": await tracks_out(session, user.id, top[:100]),
        "sources": sources,
    }


@router.get("/api/albums/view")
async def album_page(
    key: str = Query(..., max_length=400),
    session: AsyncSession = Depends(get_session),
    user: User = Depends(current_user),
):
    provider, _, ref = key.partition(":")
    registry = get_registry()
    tracks: list[Track] = []
    if provider in registry.providers and ref and registry.usable(provider):
        p = registry.get(provider)
        assert p is not None
        try:
            res = await registry.run(p, "album", lambda: p.album_tracks(ref, 100), cache_key=ref, ttl=3600)
            stored = await save_results(session, res)
            tracks = [stored[r.id] for r in res if r.id in stored]
        except ProviderError:
            tracks = []
    if not tracks:
        q = select(Track).where((Track.owner_id.is_(None)) | (Track.owner_id == user.id))
        if provider != "name" and ref:
            q = q.where(Track.provider == provider, Track.album_ref == ref)
        else:
            artist_part, _, album_part = ref.partition("|")
            q = q.where(Track.album.is_not(None))
            rows = [t for t in (await session.execute(q.limit(2000))).scalars() if clean_words(t.album or "") == album_part and clean_words(t.artist) == artist_part]
            tracks = rows
        if not tracks:
            tracks = list((await session.execute(q.limit(200))).scalars())
    if not tracks:
        raise not_found("Альбом не найден.")
    head = tracks[0]
    return {
        "key": key,
        "name": head.album or "Альбом",
        "artist": head.artist,
        "artwork": next((t.artwork_url for t in tracks if t.artwork_url), None),
        "items": await tracks_out(session, user.id, tracks),
    }


# ------------------------------------------------------------------ listening events
class PlayEventIn(BaseModel):
    track_id: str = Field(max_length=200)
    played_ms: int = Field(ge=0, le=24 * 3600 * 1000)
    duration_ms: int = Field(0, ge=0, le=24 * 3600 * 1000)
    end_reason: str = Field("ended", pattern="^(ended|skip|prev|stop|error|switch)$")
    context: str = Field("", max_length=80)
    mode: str | None = Field(None, max_length=24)


@router.post("/api/events/play")
async def play_event(body: PlayEventIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    if not merged_settings(user).get("history_enabled", True):
        return {"recorded": False, "reason": "history_disabled"}
    t = await session.get(Track, body.track_id)
    if t is None or (t.owner_id and t.owner_id != user.id):
        return {"recorded": False}
    duration = body.duration_ms or int((t.duration or 0) * 1000)
    completed = body.end_reason == "ended" or (duration > 0 and body.played_ms >= duration * 0.85)
    early = body.played_ms < (min(30000, duration * 0.35) if duration else 30000)
    skipped = body.end_reason in ("skip", "switch") and early
    if body.end_reason == "error" or (body.played_ms < 4000 and not skipped):
        return {"recorded": False}
    session.add(
        PlayEvent(
            user_id=user.id,
            track_id=t.id,
            started_at=utcnow() - timedelta(milliseconds=body.played_ms),
            played_ms=body.played_ms,
            duration_ms=duration,
            end_reason=body.end_reason,
            completed=completed,
            skipped=skipped,
            context=body.context,
            mode=body.mode,
        )
    )
    await session.commit()
    return {"recorded": True, "completed": completed, "skipped": skipped}


# ------------------------------------------------------------------ player state (cross-device)
class PlayerStateIn(BaseModel):
    queue: list[str] = Field(default_factory=list, max_length=500)
    index: int = Field(0, ge=0)
    position_ms: int = Field(0, ge=0)
    shuffle: bool = False
    repeat: str = Field("off", pattern="^(off|all|one)$")
    context: str = Field("", max_length=120)
    device: str = Field("", max_length=80)


@router.put("/api/me/player-state")
async def save_player_state(body: PlayerStateIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    db_user = await session.get(User, user.id)
    assert db_user is not None
    data = body.model_dump()
    data["index"] = min(body.index, max(0, len(body.queue) - 1))
    data["updated_at"] = utcnow().isoformat()
    db_user.player_state = data
    await session.commit()
    return {"ok": True, "updated_at": data["updated_at"]}


@router.get("/api/me/player-state")
async def get_player_state(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    st = user.player_state or None
    if not st or not st.get("queue"):
        return {"state": None}
    tracks = await load_tracks(session, st["queue"])
    visible = [tracks[i] for i in st["queue"] if i in tracks and (not tracks[i].owner_id or tracks[i].owner_id == user.id)]
    if not visible:
        return {"state": None}
    current_id = st["queue"][min(st.get("index", 0), len(st["queue"]) - 1)]
    index = next((i for i, t in enumerate(visible) if t.id == current_id), 0)
    return {
        "state": {
            **{k: st.get(k) for k in ("position_ms", "shuffle", "repeat", "context", "updated_at", "device")},
            "index": index,
            "queue": await tracks_out(session, user.id, visible),
        }
    }


# ------------------------------------------------------------------ home
@router.get("/api/home")
async def home(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    pairs = await recent_tracks(session, user.id, 12)
    recent_list = [t for t, _ in pairs]
    lib = await _library_tracks(session, user.id)
    agg: dict[str, dict[str, Any]] = {}
    for t, w in lib.values():
        a = agg.setdefault(t.artist_key, {"key": t.artist_key, "name": t.artist, "score": 0.0, "artwork": None, "provider": t.provider, "ref": t.artist_ref})
        a["score"] += w
        if not a["artwork"] and t.artwork_small:
            a["artwork"] = t.artwork_small
    top_artists = sorted(agg.values(), key=lambda a: -a["score"])[:10]
    pls = await session.execute(select(Playlist).where(Playlist.owner_id == user.id).order_by(Playlist.updated_at.desc()).limit(8))
    fav_count = (await session.execute(select(func.count()).select_from(Favorite).where(Favorite.user_id == user.id))).scalar_one()
    plays_count = (await session.execute(select(func.count()).select_from(PlayEvent).where(PlayEvent.user_id == user.id))).scalar_one()
    cont = None
    st = user.player_state or {}
    if st.get("queue"):
        idx = min(st.get("index", 0), len(st["queue"]) - 1)
        t = await session.get(Track, st["queue"][idx])
        if t is not None and (not t.owner_id or t.owner_id == user.id):
            liked = await liked_ids(session, user.id, [t.id])
            cont = {"track": track_out(t, liked=t.id in liked), "position_ms": st.get("position_ms", 0), "queue_length": len(st["queue"])}
    return {
        "user": {"display_name": user.display_name},
        "continue": cont,
        "recent": await tracks_out(session, user.id, recent_list),
        "artists": [{**a, "score": round(a["score"], 2)} for a in top_artists],
        "playlists": await playlist_summaries(session, list(pls.scalars())),
        "stats": {"favorites": fav_count, "plays": plays_count},
    }
