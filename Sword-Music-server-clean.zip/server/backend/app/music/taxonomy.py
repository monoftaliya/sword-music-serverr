"""Canonical music tag taxonomy.

Every provider describes music differently (Audius genres/moods + free tags,
Jamendo genres/vartags/instruments, Internet Archive subjects...). All of them are
mapped onto this shared vocabulary so that search, recommendations, Music DNA,
Echo Self and Infinite Descent work on the same representation.

Each tag also has an *approximate* position in a small "mood space":
  v — valence   (-1 gloomy … +1 bright)
  e — energy    ( 0 still  …  1 intense)
  a — atmosphere/depth (0 dry/direct … 1 spacious/immersive)
These coordinates are hand-tuned heuristics used for ranking and visualisation.
They are NOT derived from audio analysis, and the UI says so.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Tag:
    key: str
    group: str  # genre | mood | texture | scene | vocal
    ru: str
    v: float
    e: float
    a: float
    aliases: tuple[str, ...] = field(default_factory=tuple)


def _t(key: str, group: str, ru: str, v: float, e: float, a: float, *aliases: str) -> Tag:
    return Tag(key, group, ru, v, e, a, tuple(aliases))


TAGS: tuple[Tag, ...] = (
    # ---------------------------------------------------------------- moods
    _t("dark", "mood", "мрачное", -0.7, 0.45, 0.75, "dark", "darkness", "gloomy", "sinister", "ominous", "brooding", "grim", "gritty", "noir", "darkwave"),
    _t("melancholic", "mood", "меланхоличное", -0.55, 0.25, 0.7, "melancholy", "melancholic", "sentimental", "yearning", "wistful", "bittersweet"),
    _t("sad", "mood", "грустное", -0.8, 0.2, 0.55, "sad", "sadness", "depressing", "depressive", "heartbreak", "sorrow", "tearful", "emotional", "emo"),
    _t("lonely", "mood", "одиночество", -0.6, 0.2, 0.8, "lonely", "loneliness", "solitude", "isolation", "isolationism", "alone"),
    _t("calm", "mood", "спокойное", 0.25, 0.15, 0.6, "calm", "peaceful", "relaxing", "relaxed", "relax", "chill", "chillout", "easygoing", "tender", "soothing", "mellow", "gentle", "serene", "lounge"),
    _t("dreamy", "mood", "мечтательное", 0.2, 0.25, 0.85, "dreamy", "dream", "ethereal", "floating", "dreampop", "dream pop", "hazy"),
    _t("atmospheric", "mood", "атмосферное", -0.1, 0.3, 0.95, "atmospheric", "atmosphere", "soundscape", "soundscapes", "spacious", "immersive", "textural"),
    _t("mysterious", "mood", "загадочное", -0.3, 0.35, 0.85, "mysterious", "mystery", "enigmatic", "mystical", "occult", "esoteric"),
    _t("creepy", "mood", "жуткое", -0.85, 0.4, 0.85, "creepy", "horror", "scary", "eerie", "haunting", "spooky", "terror", "macabre"),
    _t("tense", "mood", "напряжённое", -0.5, 0.7, 0.6, "tense", "suspense", "tension", "thriller", "serious", "anxious", "nervous"),
    _t("epic", "mood", "эпичное", 0.15, 0.82, 0.78, "epic", "heroic", "stirring", "majestic", "grandiose", "triumphant", "powerful", "anthemic"),
    _t("dramatic", "mood", "драматичное", -0.25, 0.68, 0.75, "dramatic", "drama", "intense"),
    _t("aggressive", "mood", "агрессивное", -0.45, 0.95, 0.3, "aggressive", "angry", "rage", "fiery", "rowdy", "defiant", "brutal", "furious", "hard"),
    _t("energetic", "mood", "энергичное", 0.4, 0.9, 0.3, "energetic", "energizing", "energy", "upbeat", "excited", "exciting", "driving", "dynamic", "bouncy", "hype"),
    _t("confident", "mood", "уверенное", 0.5, 0.75, 0.4, "confident", "cool", "swagger", "bold", "boss", "sophisticated", "badass"),
    _t("hypnotic", "mood", "гипнотичное", 0.0, 0.5, 0.82, "hypnotic", "mesmerizing", "trance-like", "repetitive", "trippy", "psychedelic"),
    _t("nostalgic", "mood", "ностальгия", 0.1, 0.35, 0.72, "nostalgic", "nostalgia", "memories", "throwback"),
    _t("romantic", "mood", "романтичное", 0.5, 0.35, 0.55, "romantic", "love", "sensual", "sexy", "intimate"),
    _t("happy", "mood", "радостное", 0.85, 0.65, 0.3, "happy", "joyful", "cheerful", "fun", "funny", "playful", "sunny", "feel good", "feelgood"),
    _t("uplifting", "mood", "вдохновляющее", 0.7, 0.6, 0.55, "uplifting", "empowering", "inspiring", "inspirational", "hopeful", "positive", "motivational"),
    _t("euphoric", "mood", "эйфория", 0.8, 0.9, 0.6, "euphoric", "euphoria", "ecstatic", "festival"),
    # ---------------------------------------------------------------- genres
    _t("phonk", "genre", "фонк", -0.4, 0.82, 0.45, "phonk", "drift phonk", "driftphonk", "drift-phonk", "memphis", "memphis rap", "cowbell", "brazilian phonk", "funk phonk", "house phonk", "phonkhouse"),
    _t("trap", "genre", "трэп", -0.1, 0.75, 0.35, "trap", "trap music", "drill", "rage beat"),
    _t("hiphop", "genre", "хип-хоп", 0.1, 0.62, 0.3, "hip-hop/rap", "hip-hop", "hiphop", "hip hop", "rap", "boom bap", "boombap", "underground rap", "instrumental hip hop", "beats"),
    _t("lofi", "genre", "лоу-фай", 0.1, 0.25, 0.62, "lo-fi", "lofi", "lo fi", "chillhop", "lofi hip hop", "lo-fi hip hop", "study beats"),
    _t("ambient", "genre", "эмбиент", 0.0, 0.1, 0.95, "ambient", "ambience", "new age", "newage", "meditation", "ambient music"),
    _t("dark_ambient", "genre", "дарк-эмбиент", -0.72, 0.15, 1.0, "dark ambient", "darkambient", "dark-ambient", "ritual ambient", "black ambient"),
    _t("drone", "genre", "дроун", -0.3, 0.1, 0.95, "drone", "drones", "drone ambient"),
    _t("synthwave", "genre", "синтвейв", 0.2, 0.65, 0.62, "synthwave", "retrowave", "outrun", "80s", "chillsynth", "chillwave", "newretrowave", "synth-pop", "synthpop"),
    _t("darksynth", "genre", "дарксинт", -0.55, 0.85, 0.55, "darksynth", "dark synth", "dark synthwave", "cyberpunk", "midnight synth"),
    _t("electronic", "genre", "электроника", 0.1, 0.6, 0.5, "electronic", "electronica", "edm", "electro", "electronic music", "bass music"),
    _t("techno", "genre", "техно", -0.1, 0.8, 0.52, "techno", "tech house", "minimal techno", "hard techno", "acid", "acid techno"),
    _t("house", "genre", "хаус", 0.5, 0.75, 0.4, "house", "deep house", "progressive house", "tropical house", "future house", "garage", "uk garage", "disco house"),
    _t("dnb", "genre", "драм-н-бейс", 0.1, 0.9, 0.45, "drum & bass", "drum and bass", "drum n bass", "dnb", "d&b", "jungle", "liquid dnb", "neurofunk"),
    _t("dubstep", "genre", "дабстеп", -0.2, 0.9, 0.35, "dubstep", "riddim", "brostep", "bass house", "wonky", "midtempo"),
    _t("trance", "genre", "транс", 0.5, 0.8, 0.7, "trance", "psytrance", "psy trance", "progressive trance", "goa"),
    _t("idm", "genre", "IDM", -0.1, 0.5, 0.7, "idm", "glitch", "glitch hop", "braindance", "intelligent dance music"),
    _t("experimental", "genre", "экспериментальное", -0.15, 0.5, 0.72, "experimental", "avant-garde", "avantgarde", "noise", "abstract", "sound art", "musique concrete"),
    _t("industrial", "genre", "индастриал", -0.6, 0.85, 0.5, "industrial", "ebm", "power electronics", "dark electro", "aggrotech"),
    _t("witchhouse", "genre", "витч-хаус", -0.8, 0.45, 0.85, "witch house", "witchhouse", "drag"),
    _t("vaporwave", "genre", "вейпорвейв", 0.1, 0.3, 0.8, "vaporwave", "future funk", "mallsoft", "slushwave"),
    _t("downtempo", "genre", "даунтемпо", 0.0, 0.3, 0.7, "downtempo", "trip hop", "trip-hop", "triphop", "chill out"),
    _t("metal", "genre", "метал", -0.5, 0.95, 0.4, "metal", "heavy metal", "metalcore", "death metal", "black metal", "doom", "doom metal", "djent", "nu metal"),
    _t("rock", "genre", "рок", 0.2, 0.75, 0.35, "rock", "alternative", "alternative rock", "punk", "grunge", "hard rock", "garage rock"),
    _t("postrock", "genre", "пост-рок", -0.1, 0.5, 0.9, "post-rock", "post rock", "postrock", "shoegaze", "math rock"),
    _t("indie", "genre", "инди", 0.3, 0.5, 0.45, "indie", "indie rock", "indie pop", "bedroom pop", "lo-fi indie"),
    _t("pop", "genre", "поп", 0.6, 0.65, 0.3, "pop", "hyperpop", "electropop", "dance pop", "k-pop", "kpop"),
    _t("jpop", "genre", "J-pop / сити-поп", 0.5, 0.6, 0.45, "j-pop", "jpop", "city pop", "citypop", "j-rock", "jrock", "anisong"),
    _t("rnb", "genre", "R&B / соул", 0.4, 0.45, 0.45, "r&b/soul", "r&b", "rnb", "soul", "neo soul", "neo-soul"),
    _t("funk", "genre", "фанк / диско", 0.75, 0.75, 0.3, "funk", "disco", "nu disco", "boogie"),
    _t("jazz", "genre", "джаз", 0.3, 0.4, 0.5, "jazz", "smooth jazz", "jazz hop", "nu jazz", "swing", "bebop"),
    _t("blues", "genre", "блюз", -0.1, 0.4, 0.4, "blues"),
    _t("classical", "genre", "классика", 0.1, 0.35, 0.7, "classical", "baroque", "romantic era", "chamber music", "sonata", "concerto", "symphony", "nocturne", "prelude", "etude", "waltz", "opera", "string quartet"),
    _t("orchestral", "genre", "оркестровое", 0.1, 0.62, 0.8, "orchestral", "orchestra", "symphonic", "epic orchestral", "neoclassical", "modern classical"),
    _t("cinematic", "genre", "кинематографичное", 0.0, 0.6, 0.85, "cinematic", "soundtrack", "score", "film score", "film", "trailer", "movie", "ost", "game music", "video game", "videogame"),
    _t("folk", "genre", "фолк / акустика", 0.3, 0.35, 0.45, "folk", "acoustic", "singer-songwriter", "country", "americana", "bluegrass"),
    _t("world", "genre", "этника", 0.3, 0.5, 0.55, "world", "ethnic", "latin", "reggae", "afrobeat", "dancehall", "celtic", "oriental", "balkan"),
    _t("chiptune", "genre", "чиптюн", 0.6, 0.75, 0.35, "chiptune", "8-bit", "8bit", "bitpop", "chipmusic"),
    # ---------------------------------------------------------------- textures / instruments
    _t("bass_heavy", "texture", "тяжёлый бас", -0.2, 0.82, 0.4, "bass", "heavy bass", "bass boosted", "bassboosted", "808", "sub bass", "subbass", "basshead", "slap"),
    _t("heavy", "texture", "тяжёлое", -0.35, 0.88, 0.35, "heavy", "distorted", "distortion", "crushing"),
    _t("piano", "texture", "фортепиано", 0.05, 0.25, 0.65, "piano", "solo piano", "keys", "grand piano", "rhodes"),
    _t("guitar", "texture", "гитара", 0.25, 0.5, 0.45, "guitar", "electric guitar", "acoustic guitar", "guitars"),
    _t("synth", "texture", "синтезаторы", 0.1, 0.55, 0.6, "synth", "synthesizer", "synthesizers", "analog synth", "modular"),
    _t("strings", "texture", "струнные", 0.05, 0.45, 0.75, "strings", "violin", "cello", "string", "viola"),
    _t("choir", "texture", "хор", -0.1, 0.5, 0.88, "choir", "choral", "chant", "chants", "gregorian"),
    _t("drums", "texture", "ударные", 0.1, 0.75, 0.35, "drums", "percussion", "breakbeat", "breaks", "drum"),
    _t("instrumental", "vocal", "инструментал", 0.0, 0.45, 0.6, "instrumental", "no vocals", "beat", "instrumentals"),
    _t("vocal", "vocal", "с вокалом", 0.2, 0.55, 0.4, "vocal", "vocals", "singing", "singer"),
    _t("female_vocal", "vocal", "женский вокал", 0.3, 0.5, 0.5, "female vocals", "female vocal", "female"),
    _t("male_vocal", "vocal", "мужской вокал", 0.1, 0.55, 0.4, "male vocals", "male vocal", "male"),
    # ---------------------------------------------------------------- scenes / imagery
    _t("night", "scene", "ночь", -0.3, 0.38, 0.8, "night", "nocturnal", "midnight", "late night", "latenight", "nighttime", "after dark", "3am"),
    _t("rain", "scene", "дождь", -0.3, 0.2, 0.82, "rain", "rainy", "storm", "thunder"),
    _t("city", "scene", "город", 0.0, 0.55, 0.6, "city", "urban", "metropolis", "street", "neon"),
    _t("space", "scene", "космос", 0.0, 0.3, 1.0, "space", "cosmic", "galaxy", "stars", "interstellar", "sci-fi", "scifi", "universe", "astral", "nebula", "spacesynth", "space ambient"),
    _t("japan", "scene", "Япония", 0.15, 0.5, 0.62, "japan", "japanese", "tokyo", "kyoto", "osaka", "nihon"),
    _t("anime", "scene", "аниме", 0.15, 0.68, 0.62, "anime", "otaku", "manga", "animecore"),
    _t("villain", "scene", "злодей", -0.75, 0.72, 0.72, "villain", "evil", "dark lord", "antagonist", "demon", "demonic", "boss battle", "boss fight", "sinister boss"),
    _t("drive", "scene", "в дороге", 0.1, 0.72, 0.6, "drive", "driving", "drift", "racing", "night drive", "road trip", "speed"),
    _t("workout", "scene", "тренировка", 0.3, 0.95, 0.2, "workout", "gym", "training", "fitness", "running", "sport"),
    _t("study", "scene", "фокус", 0.1, 0.25, 0.6, "study", "focus", "concentration", "studying", "work", "coding"),
    _t("sleep", "scene", "сон", 0.2, 0.05, 0.82, "sleep", "sleeping", "lullaby", "insomnia", "bedtime"),
    _t("nature", "scene", "природа", 0.4, 0.2, 0.75, "nature", "forest", "ocean", "sea", "water", "field recording", "field recordings", "birds"),
    _t("winter", "scene", "зима", -0.2, 0.2, 0.82, "winter", "snow", "cold", "frozen", "ice"),
    _t("retro", "scene", "ретро", 0.3, 0.5, 0.5, "retro", "vintage", "oldschool", "old school", "90s", "70s", "60s"),
    _t("battle", "scene", "битва", -0.2, 0.92, 0.6, "battle", "fight", "war", "combat", "warrior", "samurai", "sword"),
    _t("party", "scene", "вечеринка", 0.7, 0.88, 0.3, "party", "club", "dance", "dancefloor", "rave"),
)

BY_KEY: dict[str, Tag] = {t.key: t for t in TAGS}
GROUP_WEIGHT = {"genre": 1.0, "mood": 0.9, "scene": 0.6, "texture": 0.55, "vocal": 0.4}


def _norm_alias(s: str) -> str:
    s = s.lower().strip().lstrip("#")
    s = s.replace("_", " ").replace("–", "-")
    s = re.sub(r"\s+", " ", s)
    return s


ALIAS: dict[str, str] = {}
for _tag in TAGS:
    ALIAS[_norm_alias(_tag.key.replace("_", " "))] = _tag.key
    for _a in _tag.aliases:
        ALIAS.setdefault(_norm_alias(_a), _tag.key)


_GROUP_ORDER = {"genre": 0, "mood": 1, "scene": 2, "texture": 3, "vocal": 4}


def lookup_all(raw: str) -> list[str]:
    """Map one provider tag/genre/mood string onto canonical keys.

    An exact alias wins. Compound strings ("dark phonk", "ambient drone") are split
    into known words; genres come first so "dark phonk" is primarily phonk.
    """
    if not raw:
        return []
    s = _norm_alias(raw)
    if s in ALIAS:
        return [ALIAS[s]]
    compact = s.replace(" ", "").replace("-", "")
    for variant in (s.replace("-", " "), s.replace(" ", "-"), compact):
        if variant in ALIAS:
            return [ALIAS[variant]]
    words = [w for w in re.split(r"[\s/,&+]+", s) if w]
    found: list[str] = []
    # bigrams first ("heavy bass", "night drive"), then single words
    for i in range(len(words) - 1):
        k = ALIAS.get(f"{words[i]} {words[i + 1]}")
        if k and k not in found:
            found.append(k)
    for w in words:
        k = ALIAS.get(w) if len(w) > 2 else None
        if k and k not in found:
            found.append(k)
    found.sort(key=lambda k: _GROUP_ORDER.get(BY_KEY[k].group, 9))
    return found


def lookup(raw: str) -> str | None:
    found = lookup_all(raw)
    return found[0] if found else None


def canonicalize(
    *,
    genres: list[str] | None = None,
    moods: list[str] | None = None,
    tags: list[str] | None = None,
    instruments: list[str] | None = None,
    extra: dict[str, float] | None = None,
) -> dict[str, float]:
    """Combine raw provider descriptors into a normalised canonical tag vector (max = 1)."""
    acc: dict[str, float] = {}

    def add(items: list[str] | None, weight: float) -> None:
        for raw in items or []:
            for i, key in enumerate(lookup_all(raw)[:3]):
                factor = 1.0 if i == 0 else 0.7
                w = weight * factor * GROUP_WEIGHT.get(BY_KEY[key].group, 0.5)
                acc[key] = acc.get(key, 0.0) + w

    add(genres, 1.0)
    add(moods, 0.95)
    add(tags, 0.6)
    add(instruments, 0.45)
    for k, w in (extra or {}).items():
        if k in BY_KEY:
            acc[k] = acc.get(k, 0.0) + w
    if not acc:
        return {}
    top = max(acc.values())
    return {k: round(min(1.0, v / top), 3) for k, v in sorted(acc.items(), key=lambda kv: -kv[1])[:14]}


# ------------------------------------------------------------------ mood space
SPEED_ENERGY = {"verylow": 0.1, "low": 0.3, "medium": 0.5, "high": 0.75, "veryhigh": 0.92}


def mood_point(
    canonical: dict[str, float], bpm: float | None = None, speed: str | None = None
) -> tuple[float, float, float] | None:
    """Approximate (valence, energy, atmosphere) of a track from its tags and tempo hints."""
    if not canonical and bpm is None and speed is None:
        return None
    wsum = v = e = a = 0.0
    for key, w in canonical.items():
        tag = BY_KEY.get(key)
        if tag is None:
            continue
        g = GROUP_WEIGHT.get(tag.group, 0.5)
        wsum += w * g
        v += tag.v * w * g
        e += tag.e * w * g
        a += tag.a * w * g
    if wsum > 0:
        v, e, a = v / wsum, e / wsum, a / wsum
    else:
        v, e, a = 0.0, 0.5, 0.5
    if bpm and 40 <= bpm <= 220:
        e_bpm = min(1.0, max(0.0, (bpm - 60) / 110))
        e = e * 0.75 + e_bpm * 0.25
    elif speed in SPEED_ENERGY:
        e = e * 0.65 + SPEED_ENERGY[speed] * 0.35
    return (round(v, 3), round(e, 3), round(a, 3))


def cosine(a: dict[str, float], b: dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(w * b.get(k, 0.0) for k, w in a.items())
    if dot == 0:
        return 0.0
    na = math.sqrt(sum(w * w for w in a.values()))
    nb = math.sqrt(sum(w * w for w in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def mood_distance(p: tuple[float, float, float] | None, q: tuple[float, float, float] | None) -> float:
    """Distance in mood space normalised to 0..1 (1 = unknown/maximally different)."""
    if p is None or q is None:
        return 0.6
    dv = (p[0] - q[0]) / 2.0  # valence spans 2
    de = p[1] - q[1]
    da = p[2] - q[2]
    return min(1.0, math.sqrt(dv * dv * 1.2 + de * de + da * da * 0.8) / 1.5)


def similarity(
    tags_a: dict[str, float],
    tags_b: dict[str, float],
    point_a: tuple[float, float, float] | None,
    point_b: tuple[float, float, float] | None,
) -> float:
    """Blend of exact tag overlap and proximity in mood space (0..1)."""
    return 0.62 * cosine(tags_a, tags_b) + 0.38 * (1.0 - mood_distance(point_a, point_b))


def top_tags(canonical: dict[str, float], n: int = 4, groups: set[str] | None = None) -> list[str]:
    items = [
        (k, w)
        for k, w in canonical.items()
        if k in BY_KEY and (groups is None or BY_KEY[k].group in groups)
    ]
    items.sort(key=lambda kv: -kv[1])
    return [k for k, _ in items[:n]]


def label(key: str) -> str:
    tag = BY_KEY.get(key)
    return tag.ru if tag else key


def public_catalog() -> list[dict]:
    return [
        {"key": t.key, "group": t.group, "label": t.ru, "v": t.v, "e": t.e, "a": t.a}
        for t in TAGS
    ]
