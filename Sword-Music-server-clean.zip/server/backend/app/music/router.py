"""Track endpoints: details, playback resolution, availability, alternatives, palette."""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.deps import current_user
from ..core.errors import ApiError, forbidden, not_found
from ..db import get_session, utcnow
from ..models import Track, User
from ..search.service import run_search
from ..users.schemas import merged_settings
from .normalize import base_title, primary_artist
from .palette import palette_for_url
from .providers.base import ProviderError
from .registry import NAMES, get_registry
from .store import liked_ids, save_results, track_out

router = APIRouter(prefix="/api/tracks", tags=["tracks"])


async def load_visible_track(session: AsyncSession, track_id: str, user: User) -> Track:
    t = await session.get(Track, track_id)
    if t is None:
        raise not_found("Трек не найден.")
    if t.owner_id and t.owner_id != user.id:
        raise forbidden("Это личный файл другого пользователя.")
    return t


def attribution(t: Track) -> dict[str, Any]:
    return {
        "source": NAMES.get(t.provider, t.provider),
        "provider": t.provider,
        "artist": t.artist,
        "page_url": t.page_url,
        "license": t.license,
        "license_url": t.license_url,
    }


async def find_alternatives(session: AsyncSession, user: User, t: Track, limit: int = 6) -> list[dict[str, Any]]:
    """Look for other playable versions of the same song across sources."""
    query = f"{t.artist} {base_title(t.title)}".strip()
    if not query:
        return []
    res = await run_search(session, get_registry(), user, query, mode="text", limit=30)
    want_artist = primary_artist(t.artist)
    want_title = base_title(t.title)
    out = []
    for item in res["results"]:
        for cand in [item, *item.get("alternatives", [])]:
            if cand["id"] == t.id or not cand["playable"]:
                continue
            if primary_artist(cand["artist"]) == want_artist and base_title(cand["title"]) == want_title:
                out.append(cand)
    seen: set[str] = set()
    uniq = []
    for c in out:
        if c["id"] not in seen:
            seen.add(c["id"])
            uniq.append(c)
    return uniq[:limit]


async def mark_unavailable(session: AsyncSession, t: Track, reason: str) -> None:
    t.unavailable_reason = reason[:200]
    t.unavailable_at = utcnow()
    await session.commit()


@router.get("/{track_id}")
async def get_track(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await load_visible_track(session, track_id, user)
    liked = await liked_ids(session, user.id, [t.id])
    out = track_out(t, liked=t.id in liked)
    out["attribution"] = attribution(t)
    out["extra"] = {k: v for k, v in (t.extra or {}).items() if k in ("waveform", "plays", "favorites", "handle")}
    return out


@router.get("/{track_id}/play")
async def play(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await load_visible_track(session, track_id, user)
    if t.provider == "upload":
        return {"url": f"/api/uploads/{t.id}/file", "kind": "full", "mime": (t.extra or {}).get("mime"), "attribution": attribution(t)}
    if t.stream_kind == "none":
        raise ApiError(
            409,
            "not_streamable",
            "Источник не разрешает воспроизведение этого трека.",
            extra={"alternatives": await find_alternatives(session, user, t)},
        )
    registry = get_registry()
    provider = registry.get(t.provider)
    if provider is None:
        raise ApiError(503, "source_off", f"Источник «{NAMES.get(t.provider, t.provider)}» сейчас отключён.")
    try:
        info = await registry.run(
            provider,
            "resolve",
            lambda: provider.resolve(
                t.provider_track_id,
                {**(t.extra or {}), "stream_kind": t.stream_kind, "quality": merged_settings(user).get("quality", "high")},
            ),
        )
    except ProviderError as exc:
        if exc.kind in ("unavailable", "not_found"):
            await mark_unavailable(session, t, exc.message)
            raise ApiError(
                410,
                "unavailable",
                "Трек больше недоступен в источнике.",
                extra={"alternatives": await find_alternatives(session, user, t)},
            ) from exc
        raise ApiError(503, "source_error", exc.message, extra={"retryable": True}) from exc
    if t.unavailable_reason:
        t.unavailable_reason = None
        t.unavailable_at = None
        await session.commit()
    return {"url": info.url, "kind": info.kind, "mime": info.mime, "attribution": attribution(t)}


class ReportIn(BaseModel):
    error: str = Field("media", max_length=40)


@router.post("/{track_id}/report")
async def report_problem(
    track_id: str, body: ReportIn, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)
):
    """The player could not play the stream — re-check the source honestly."""
    t = await load_visible_track(session, track_id, user)
    registry = get_registry()
    provider = registry.get(t.provider)
    available: bool | None = None
    if provider is not None and t.provider != "upload":
        try:
            fresh = await registry.run(provider, "get", lambda: provider.get(t.provider_track_id, t.extra or {}))
        except ProviderError:
            fresh = None
            available = None  # unknown — source failed, do not blame the track
        else:
            if fresh is None or fresh.stream_kind == "none":
                available = False
                await mark_unavailable(session, t, "Трек удалён, скрыт или закрыт в источнике.")
            else:
                available = True
                await save_results(session, [fresh])
    alternatives = await find_alternatives(session, user, t) if available is not True else []
    return {"available": available, "alternatives": alternatives}


@router.get("/{track_id}/alternatives")
async def alternatives(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await load_visible_track(session, track_id, user)
    return {"alternatives": await find_alternatives(session, user, t)}


@router.get("/{track_id}/palette")
async def palette(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    t = await load_visible_track(session, track_id, user)
    if t.palette:
        return {"palette": t.palette}
    if not t.artwork_url:
        return {"palette": None}
    pal = await palette_for_url(get_registry().client, t.artwork_url)
    if pal:
        t.palette = pal
        await session.commit()
    return {"palette": pal}
