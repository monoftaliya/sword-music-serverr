"""Dashboard facts derived from listening events or an attributed public chart."""
from __future__ import annotations

from collections import Counter
from datetime import timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import get_settings
from ..core.deps import current_user
from ..core.errors import not_found
from ..db import get_session, utcnow
from ..models import PlayEvent, Track, User
from .metadata import song_metadata
from .normalize import clean_words
from .providers.base import ProviderError
from .registry import get_registry
from .store import load_tracks, save_results, track_out, tracks_out
from .taxonomy import BY_KEY, label

router = APIRouter(tags=["dashboard"])


@router.get("/api/dashboard")
async def dashboard(session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    registry = get_registry()
    now = utcnow()
    weekly = (await session.execute(
        select(Track.id, func.count(PlayEvent.id).label("plays"))
        .join(PlayEvent, PlayEvent.track_id == Track.id)
        .where(Track.owner_id.is_(None), Track.stream_kind != "none",
               PlayEvent.started_at >= now - timedelta(days=7), PlayEvent.skipped.is_(False),
               PlayEvent.played_ms >= 30000)
        .group_by(Track.id).order_by(func.count(PlayEvent.id).desc(), Track.id).limit(5))).all()
    chart_tracks = [await session.get(Track, tid) for tid, _ in weekly]
    chart_tracks = [track for track in chart_tracks if track is not None]
    chart_source = "Прослушивания в Sword Music за 7 дней" if weekly else "Audius · недельный чарт"
    chart_url = None if weekly else "https://audius.co/trending"
    chart_error = None
    if not chart_tracks:
        provider = registry.get("audius")
        if provider and registry.usable("audius"):
            try:
                async def public_chart():
                    return await provider.trending(time="week", limit=5)
                results = await registry.run(provider, "weekly_chart", public_chart, cache_key="week", ttl=1800)
                stored = await save_results(session, results)
                chart_tracks = [stored[r.id] for r in results if r.id in stored and stored[r.id].stream_kind != "none"][:5]
            except ProviderError as exc:
                chart_error = exc.message
        else:
            chart_error = "Источник чарта сейчас недоступен."
    chart = await tracks_out(session, user.id, chart_tracks)
    for index, item in enumerate(chart):
        item["rank"] = index + 1
        item["plays"] = dict(weekly).get(item["id"]) if weekly else None

    monthly = (await session.execute(
        select(Track.id, func.count(PlayEvent.id).label("plays"))
        .join(PlayEvent, PlayEvent.track_id == Track.id)
        .where(PlayEvent.user_id == user.id, PlayEvent.started_at >= now - timedelta(days=30),
               PlayEvent.skipped.is_(False), PlayEvent.played_ms >= 30000,
               (Track.owner_id.is_(None)) | (Track.owner_id == user.id))
        .group_by(Track.id).order_by(func.count(PlayEvent.id).desc(), Track.id))).all()
    month_tracks = await load_tracks(session, [tid for tid, _ in monthly])
    song = month_tracks.get(monthly[0][0]) if monthly else None
    albums: dict[str, dict] = {}
    for tid, plays in monthly:
        track = month_tracks.get(tid)
        if track is None or not track.album:
            continue
        key = f"{track.provider}:{track.album_ref}" if track.album_ref else f"name:{clean_words(track.artist)}|{clean_words(track.album)}"
        item = albums.setdefault(key, {"key": key, "name": track.album, "artist": track.artist,
            "artwork": track.artwork_url, "plays": 0, "track": track_out(track), "release_date": track.release_date})
        item["plays"] += plays
    genres = Counter(tag for track in chart_tracks for tag in (track.canonical or {})
                     if (track.canonical or {})[tag] >= 0.35
                     and tag in BY_KEY and BY_KEY[tag].group == "genre")
    await session.commit()
    return {"weekly": chart, "weekly_source": chart_source, "weekly_url": chart_url,
        "weekly_error": chart_error, "song_of_month": track_out(song) if song else None,
        "album_of_month": max(albums.values(), key=lambda a: a["plays"]) if albums else None,
        "monthly_basis": "Ваши прослушивания за последние 30 дней",
        "genres": [{"key": key, "name": label(key), "tracks": amount} for key, amount in genres.most_common(5)],
        "genres_basis": "Жанры недельной подборки",
        "sources": {"youtube": registry.state_of("youtube"), "genius": bool(get_settings().genius_access_token),
                    "lyrics": get_settings().lyrics_enabled, "musicbrainz": registry.state_of("musicbrainz")}}


@router.get("/api/tracks/{track_id}/lyrics")
async def lyrics(track_id: str, session: AsyncSession = Depends(get_session), user: User = Depends(current_user)):
    track = await session.get(Track, track_id)
    if track is None or (track.owner_id and track.owner_id != user.id):
        raise not_found("Трек не найден.")
    registry = get_registry()
    key = f"metadata:{track.id}:{track.updated_at}"
    cached = registry.cache.get(key)
    if cached is not None:
        return cached
    result = await song_metadata(registry.client, track.title, track.artist, track.album, track.duration)
    registry.cache.set(key, result, 3600)
    return result
