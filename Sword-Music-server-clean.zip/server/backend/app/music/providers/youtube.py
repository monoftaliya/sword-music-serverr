"""YouTube — almost any song, played through the official embedded YouTube player.

* Search uses the YouTube Data API v3 with a free key (YOUTUBE_API_KEY). The key stays on the
  server; the browser only receives video ids.
* Playback happens only in YouTube's own IFrame player, which stays visible on screen while a
  YouTube track plays (YouTube API Services policies: no audio-only/background playback, no
  hiding or modifying the player, no blocking ads, no downloading or caching media).
* Quota: by default a Google project may call search.list 100 times a day. The provider keeps
  its own daily budget (YOUTUBE_DAILY_SEARCHES), the search service only asks YouTube once the
  user has finished typing, and results are cached for hours.
Docs: https://developers.google.com/youtube/v3/docs/search/list
"""
from __future__ import annotations

import html
import math
import re
from datetime import datetime, timedelta, timezone
from typing import Any, ClassVar
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx

from ...config import get_settings
from .base import Provider, ProviderError, StreamInfo, TrackResult

API = "https://www.googleapis.com/youtube/v3"
MUSIC_CATEGORY = "10"
MIN_SECONDS, MAX_SECONDS = 50, 15 * 60
try:
    PACIFIC = ZoneInfo("America/Los_Angeles")  # YouTube quotas reset at midnight Pacific time
except ZoneInfoNotFoundError:  # Windows without the tzdata package: standard time is close enough
    PACIFIC = timezone(timedelta(hours=-8), "PST")

_DURATION = re.compile(r"^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$")
_NOISE = re.compile(
    r"\s*[\(\[\|]\s*(?:official\s*(?:hd\s*)?(?:music\s*)?(?:video|audio|lyrics?\s*video|visuali[sz]er|clip)?|"
    r"lyrics?(?:\s*video)?|audio|hd|hq|4k|mv|m/v|video\s*oficial|clip\s*officiel|visuali[sz]er|"
    r"офиц[а-яё]*\s*(?:клип|видео|аудио)?|клип|премьера[^)\]]*|lyric\s*video)\s*[\)\]]",
    re.IGNORECASE,
)
_SEPARATORS = (" - ", " – ", " — ", " | ")


def parse_duration(value: str | None) -> float | None:
    m = _DURATION.match(value or "")
    if not m:
        return None
    d, h, mi, s = (int(x or 0) for x in m.groups())
    total = d * 86400 + h * 3600 + mi * 60 + s
    return float(total) if total else None


def split_title(raw_title: str, channel: str) -> tuple[str, str]:
    """'Artist - Song (Official Video)' → ('Artist', 'Song'); '… - Topic' channels give the artist."""
    title = html.unescape(raw_title or "").strip()
    channel = html.unescape(channel or "").strip()
    title = _NOISE.sub("", title).strip(" -–—|")
    if channel.endswith(" - Topic"):
        return channel[: -len(" - Topic")].strip(), title
    for sep in _SEPARATORS:
        if sep in title:
            left, right = title.split(sep, 1)
            if left.strip() and right.strip():
                return left.strip(), _NOISE.sub("", right).strip(" -–—|")
    artist = re.sub(r"(?i)\s*(vevo|official|music|tv)$", "", channel).strip() or channel
    return artist, title


def seconds_until_quota_reset(now: datetime | None = None) -> float:
    now = now or datetime.now(PACIFIC)
    tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=5, microsecond=0)
    return max(60.0, (tomorrow - now).total_seconds())


class YouTubeProvider(Provider):
    id: ClassVar[str] = "youtube"
    name: ClassVar[str] = "YouTube"
    homepage: ClassVar[str] = "https://www.youtube.com"
    requires_key: ClassVar[bool] = True
    stream_kind: ClassVar[str] = "embed"
    quota_limited: ClassVar[bool] = True
    search_ttl: ClassVar[float] = 6 * 3600
    image_hosts: ClassVar[tuple[str, ...]] = ("i.ytimg.com",)
    terms_note: ClassVar[str] = (
        "Почти любая музыка. Играет только через официальный плеер YouTube: окошко с видео видно, пока звучит трек, "
        "реклама YouTube не скрывается, ничего не скачивается. Слушая треки YouTube, вы соглашаетесь с Условиями "
        "использования YouTube. Поиск тратит квоту YouTube Data API: по умолчанию 100 поисков в день на сервер, "
        "результаты запоминаются на несколько часов."
    )

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)
        self._day: str = ""
        self._searches = 0

    # -- configuration ------------------------------------------------------
    @property
    def key(self) -> str:
        return get_settings().youtube_api_key.strip()

    def configured(self) -> bool:
        return bool(self.key)

    def config_hint(self) -> str:
        return "Добавьте YOUTUBE_API_KEY в .env: бесплатный ключ YouTube Data API v3 из Google Cloud Console (см. README)."

    def budget_left(self) -> int:
        today = datetime.now(PACIFIC).date().isoformat()
        if today != self._day:
            self._day, self._searches = today, 0
        return max(0, get_settings().youtube_daily_searches - self._searches)

    # -- HTTP ---------------------------------------------------------------
    async def _call(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        if not self.configured():
            raise ProviderError("config", "YouTube: не задан YOUTUBE_API_KEY")
        try:
            resp = await self.client.get(f"{API}/{method}", params={**params, "key": self.key})
        except httpx.TimeoutException as exc:
            raise ProviderError("timeout", "YouTube: превышено время ожидания") from exc
        except httpx.HTTPError as exc:
            raise ProviderError("network", "YouTube: сетевая ошибка") from exc
        if resp.status_code >= 400:
            reason = ""
            try:
                errors = (resp.json().get("error") or {}).get("errors") or []
                reason = (errors[0] or {}).get("reason", "") if errors else ""
            except ValueError:
                pass
            if reason in ("quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded", "userRateLimitExceeded") or resp.status_code == 429:
                raise ProviderError("rate_limited", "YouTube: дневной лимит поиска исчерпан", seconds_until_quota_reset())
            if reason in ("keyInvalid", "keyExpired", "accessNotConfigured", "forbidden", "ipRefererBlocked") or resp.status_code in (400, 401, 403):
                raise ProviderError("config", "YouTube: ключ не подходит. Включите YouTube Data API v3 для проекта ключа.")
            if resp.status_code >= 500:
                raise ProviderError("network", f"YouTube: сервис временно недоступен ({resp.status_code})")
            raise ProviderError("bad_response", f"YouTube: ошибка запроса ({resp.status_code})")
        try:
            return resp.json()
        except ValueError as exc:
            raise ProviderError("bad_response", "YouTube: некорректный ответ") from exc

    # -- parsing ------------------------------------------------------------
    def _parse(self, item: dict[str, Any]) -> TrackResult | None:
        vid = item.get("id")
        snip = item.get("snippet") or {}
        details = item.get("contentDetails") or {}
        status = item.get("status") or {}
        if not isinstance(vid, str) or not vid:
            return None
        if status.get("embeddable") is False or status.get("privacyStatus", "public") != "public":
            return None
        if snip.get("liveBroadcastContent", "none") != "none":
            return None
        if (details.get("contentRating") or {}).get("ytRating") == "ytAgeRestricted":
            return None  # age-restricted videos do not play in embedded players
        duration = parse_duration(details.get("duration"))
        if duration is None or not MIN_SECONDS <= duration <= MAX_SECONDS:
            return None
        artist, title = split_title(snip.get("title", ""), snip.get("channelTitle", ""))
        if not title:
            return None
        thumbs = snip.get("thumbnails") or {}
        big = (thumbs.get("maxres") or thumbs.get("medium") or thumbs.get("high") or {}).get("url")
        small = (thumbs.get("medium") or thumbs.get("default") or {}).get("url")
        views = int((item.get("statistics") or {}).get("viewCount") or 0)
        tags = [t.lower() for t in (snip.get("tags") or [])[:25] if isinstance(t, str) and len(t) <= 40]
        return TrackResult(
            provider=self.id,
            provider_track_id=vid,
            title=title[:300],
            artist=(artist or "YouTube")[:200],
            artist_ref=snip.get("channelId"),
            duration=duration,
            artwork_url=big,
            artwork_small=small or big,
            stream_kind="embed",
            page_url=f"https://www.youtube.com/watch?v={vid}",
            tags=tags,
            popularity=min(1.0, math.log10(views + 1) / 9) if views else 0.0,
            release_date=(snip.get("publishedAt") or "")[:10] or None,
            extra={"channel": snip.get("channelTitle"), "views": views},
        )

    async def _videos(self, ids: list[str]) -> list[TrackResult]:
        if not ids:
            return []
        data = await self._call("videos", {"part": "snippet,contentDetails,status,statistics", "id": ",".join(ids[:50]), "maxResults": 50})
        order = {vid: i for i, vid in enumerate(ids)}
        parsed = [t for t in (self._parse(it) for it in data.get("items") or []) if t]
        return sorted(parsed, key=lambda t: order.get(t.provider_track_id, 999))

    # -- provider API -------------------------------------------------------
    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        query = " ".join(query.split())
        if len(query) < 2:
            return []
        if self.budget_left() <= 0:
            raise ProviderError("rate_limited", "YouTube: дневной запас поисков исчерпан, обновится ночью", seconds_until_quota_reset())
        self._searches += 1
        data = await self._call(
            "search",
            {
                "part": "snippet",
                "type": "video",
                "videoEmbeddable": "true",
                "q": query,
                "maxResults": max(5, min(limit + 5, 50)),
            },
        )
        ids = [((it.get("id") or {}).get("videoId")) for it in data.get("items") or []]
        return (await self._videos([i for i in ids if i]))[:limit]

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        items = await self._videos([provider_track_id])
        return items[0] if items else None

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        # The browser plays the video id in the official YouTube player; there is no stream URL.
        if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", provider_track_id):
            raise ProviderError("not_found", "YouTube: неверный идентификатор видео")
        return StreamInfo(url=provider_track_id, kind="embed")
