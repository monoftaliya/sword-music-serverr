"""Audius — open music protocol with a free public REST API.

* Read access needs only an `app_name` query parameter (an API key is optional).
* Full tracks are streamable unless the artist gated them (purchase/follow gates);
  for gated tracks only an artist-provided preview may be available.
* BPM and musical key come from Audius' own audio analysis when present.
Docs: https://docs.audius.co/api
"""
from __future__ import annotations

import math
from typing import Any
from urllib.parse import urlencode

from ...config import get_settings
from .base import DiscoverSpec, Provider, ProviderError, StreamInfo, TrackResult, first, split_tags

# canonical tag -> Audius genre names
GENRES: dict[str, list[str]] = {
    "trap": ["Trap"],
    "hiphop": ["Hip-Hop/Rap"],
    "phonk": ["Hip-Hop/Rap", "Electronic"],
    "lofi": ["Lo-Fi"],
    "ambient": ["Ambient"],
    "dark_ambient": ["Ambient", "Experimental"],
    "drone": ["Ambient", "Experimental"],
    "electronic": ["Electronic"],
    "synthwave": ["Electronic"],
    "darksynth": ["Electronic"],
    "techno": ["Techno"],
    "house": ["House", "Deep House"],
    "dnb": ["Drum & Bass", "Jungle"],
    "dubstep": ["Dubstep"],
    "trance": ["Trance"],
    "idm": ["Experimental", "Glitch Hop"],
    "experimental": ["Experimental"],
    "industrial": ["Experimental", "Electronic"],
    "witchhouse": ["Experimental", "Electronic"],
    "vaporwave": ["Vaporwave"],
    "downtempo": ["Downtempo"],
    "metal": ["Metal"],
    "rock": ["Rock", "Alternative"],
    "postrock": ["Alternative", "Rock"],
    "indie": ["Alternative"],
    "pop": ["Pop"],
    "jpop": ["Pop"],
    "rnb": ["R&B/Soul"],
    "funk": ["Funk", "Disco"],
    "jazz": ["Jazz"],
    "blues": ["Blues"],
    "classical": ["Classical"],
    "orchestral": ["Classical", "Soundtrack"],
    "cinematic": ["Soundtrack"],
    "folk": ["Folk", "Acoustic"],
    "world": ["World", "Latin"],
    "chiptune": ["Electronic"],
}
# canonical tag -> Audius mood names
MOODS: dict[str, list[str]] = {
    "dark": ["Brooding", "Gritty"],
    "melancholic": ["Melancholy", "Yearning", "Sentimental"],
    "sad": ["Melancholy", "Sentimental"],
    "lonely": ["Melancholy", "Yearning"],
    "calm": ["Peaceful", "Easygoing", "Tender"],
    "dreamy": ["Peaceful", "Yearning"],
    "atmospheric": ["Brooding", "Peaceful"],
    "mysterious": ["Brooding", "Serious"],
    "creepy": ["Brooding", "Gritty"],
    "tense": ["Serious", "Brooding"],
    "epic": ["Stirring", "Empowering"],
    "dramatic": ["Stirring", "Serious"],
    "aggressive": ["Aggressive", "Fiery", "Defiant", "Rowdy"],
    "energetic": ["Energizing", "Excited", "Upbeat"],
    "confident": ["Cool", "Sophisticated", "Defiant"],
    "romantic": ["Romantic", "Sensual"],
    "happy": ["Upbeat", "Excited"],
    "uplifting": ["Empowering", "Stirring"],
    "euphoric": ["Excited", "Energizing"],
    "nostalgic": ["Yearning", "Sentimental"],
    "hypnotic": ["Cool", "Brooding"],
}
# canonical tag -> good English search keywords
KEYWORDS: dict[str, str] = {
    "phonk": "phonk",
    "dark_ambient": "dark ambient",
    "darksynth": "darksynth",
    "synthwave": "synthwave",
    "witchhouse": "witch house",
    "lofi": "lofi",
    "dnb": "drum and bass",
    "postrock": "post rock",
    "jpop": "city pop",
    "bass_heavy": "bass",
    "villain": "villain",
    "anime": "anime",
    "space": "space",
    "night": "night",
    "rain": "rain",
    "drive": "drift",
    "japan": "japan",
    "cinematic": "cinematic",
    "orchestral": "orchestral",
    "piano": "piano",
    "choir": "choir",
}


def _popularity(plays: Any, favs: Any) -> float:
    try:
        p = float(plays or 0)
        f = float(favs or 0)
    except (TypeError, ValueError):
        return 0.0
    return round(min(1.0, (math.log10(p + 10) - 1) / 5.5 * 0.8 + math.log10(f + 1) / 4.5 * 0.2), 3)


class AudiusProvider(Provider):
    id = "audius"
    name = "Audius"
    homepage = "https://audius.co"
    terms_note = (
        "Открытый протокол. Публичный API бесплатен, требует только app_name. "
        "Треки транслируются напрямую из сети Audius; закрытые (gated) треки не воспроизводятся."
    )

    @property
    def base(self) -> str:
        return get_settings().audius_base_url.rstrip("/") + "/v1"

    def _auth(self) -> list[tuple[str, str]]:
        s = get_settings()
        params = [("app_name", s.audius_app_name or "SwordMusic")]
        if s.audius_api_key:
            params.append(("api_key", s.audius_api_key))
        return params

    # ------------------------------------------------------------------ parsing
    def parse(self, d: dict[str, Any]) -> TrackResult | None:
        if not isinstance(d, dict) or not d.get("id") or not d.get("title"):
            return None
        if d.get("is_delete") or d.get("is_unlisted"):
            return None
        user = d.get("user") or {}
        art = d.get("artwork") or {}
        access = d.get("access") or {}
        gated = bool(d.get("is_stream_gated")) or access.get("stream") is False
        available = d.get("is_available", True) is not False and d.get("is_streamable", True) is not False
        if not available:
            kind = "none"
        elif gated:
            kind = "preview" if d.get("preview_cid") else "none"
        else:
            kind = "full"
        permalink = d.get("permalink") or ""
        bpm = d.get("bpm")
        try:
            bpm = round(float(bpm), 1) if bpm else None
        except (TypeError, ValueError):
            bpm = None
        return TrackResult(
            provider=self.id,
            provider_track_id=str(d["id"]),
            title=str(d["title"]).strip()[:390],
            artist=str(first(user.get("name"), user.get("handle"), "Неизвестный исполнитель"))[:290],
            artist_ref=str(user.get("id")) if user.get("id") else None,
            duration=float(d["duration"]) if d.get("duration") else None,
            artwork_url=first(art.get("1000x1000"), art.get("480x480"), art.get("150x150")),
            artwork_small=first(art.get("480x480"), art.get("150x150")),
            stream_kind=kind,
            license=d.get("license") or None,
            page_url=f"https://audius.co{permalink}" if permalink.startswith("/") else None,
            genres=[d["genre"]] if d.get("genre") else [],
            moods=[d["mood"]] if d.get("mood") else [],
            tags=split_tags(d.get("tags")),
            bpm=bpm,
            musical_key=d.get("musical_key") or None,
            popularity=_popularity(d.get("play_count"), d.get("favorite_count")),
            release_date=(d.get("release_date") or d.get("created_at") or "")[:10] or None,
            extra={
                "handle": user.get("handle"),
                "plays": d.get("play_count"),
                "favorites": d.get("favorite_count"),
                "gated": gated,
                "bpm_source": "audius-analysis" if bpm and not d.get("is_custom_bpm") else ("artist" if bpm else None),
                "key_source": "audius-analysis" if d.get("musical_key") and not d.get("is_custom_musical_key") else ("artist" if d.get("musical_key") else None),
            },
        )

    def _parse_list(self, payload: Any) -> list[TrackResult]:
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            raise ProviderError("bad_response", "Audius: неожиданный формат ответа")
        out = []
        for item in data:
            t = self.parse(item)
            if t:
                out.append(t)
        return out

    # ------------------------------------------------------------------ API
    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        params = [("query", query[:120]), ("limit", str(min(limit, 50))), ("sort_method", "relevant"), *self._auth()]
        return self._parse_list(await self.get_json(f"{self.base}/tracks/search", params))

    async def search_filtered(
        self,
        query: str,
        *,
        genres: list[str] | None = None,
        moods: list[str] | None = None,
        bpm_min: float | None = None,
        bpm_max: float | None = None,
        sort: str = "popular",
        limit: int = 30,
    ) -> list[TrackResult]:
        params: list[tuple[str, str]] = [("query", query[:120]), ("limit", str(min(limit, 50))), ("sort_method", sort)]
        for g in genres or []:
            params.append(("genre", g))
        for m in moods or []:
            params.append(("mood", m))
        if bpm_min:
            params.append(("bpm_min", str(int(bpm_min))))
        if bpm_max:
            params.append(("bpm_max", str(int(bpm_max))))
        params.extend(self._auth())
        return self._parse_list(await self.get_json(f"{self.base}/tracks/search", params))

    async def trending(self, genre: str | None = None, time: str = "month", limit: int = 30) -> list[TrackResult]:
        params = [("time", time), ("limit", str(min(limit, 100))), *self._auth()]
        if genre:
            params.append(("genre", genre))
        return self._parse_list(await self.get_json(f"{self.base}/tracks/trending", params))

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        import asyncio

        top = spec.top(4)
        genres: list[str] = []
        moods: list[str] = []
        words: list[str] = []
        for key in top:
            for g in GENRES.get(key, []):
                if g not in genres:
                    genres.append(g)
            for m in MOODS.get(key, []):
                if m not in moods:
                    moods.append(m)
            if key in KEYWORDS and len(words) < 2:
                words.append(KEYWORDS[key])
        words.extend(w for w in spec.keywords[:2] if w not in words)
        query = " ".join(words[:3]) or (top[0].replace("_", " ") if top else "")

        calls = []
        if query:
            calls.append(self.search_filtered(query, sort="popular" if spec.popular else "relevant", limit=spec.limit))
        if genres or moods:
            calls.append(
                self.search_filtered(
                    (words[0] if words else (genres[0] if genres else query)).strip(),
                    genres=genres[:3],
                    moods=moods[:4],
                    bpm_min=spec.bpm_min,
                    bpm_max=spec.bpm_max,
                    sort="popular",
                    limit=spec.limit,
                )
            )
        if genres and spec.popular:
            calls.append(self.trending(genres[0], "month", min(spec.limit, 40)))
        results: list[TrackResult] = []
        seen: set[str] = set()
        errors: list[ProviderError] = []
        for res in await asyncio.gather(*calls, return_exceptions=True):
            if isinstance(res, ProviderError):
                errors.append(res)
                continue
            if isinstance(res, BaseException):
                errors.append(ProviderError("bad_response", str(res)))
                continue
            for t in res:
                if t.provider_track_id not in seen:
                    seen.add(t.provider_track_id)
                    results.append(t)
        if not results and errors:
            raise errors[0]
        return results

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        try:
            payload = await self.get_json(f"{self.base}/tracks/{provider_track_id}", self._auth())
        except ProviderError as exc:
            if exc.kind == "not_found":
                return None
            raise
        data = payload.get("data") if isinstance(payload, dict) else None
        return self.parse(data) if isinstance(data, dict) else None

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        params = self._auth()
        kind = "full"
        if extra.get("stream_kind") == "preview":
            params.append(("preview", "true"))
            kind = "preview"
        # The stream endpoint redirects to a healthy content node; the browser follows it.
        return StreamInfo(url=f"{self.base}/tracks/{provider_track_id}/stream?{urlencode(params)}", kind=kind)

    async def artist_tracks(self, artist_ref: str, limit: int = 20) -> list[TrackResult]:
        params = [("limit", str(min(limit, 50))), ("sort_method", "plays"), ("sort_direction", "desc"), *self._auth()]
        return self._parse_list(await self.get_json(f"{self.base}/users/{artist_ref}/tracks", params))
