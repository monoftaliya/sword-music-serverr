"""Deezer public API — metadata and official 30-second previews only. OFF by default.

The Deezer API terms (developers.deezer.com/termsofuse) allow strictly
non-commercial use, limit streaming to 30-second extracts for non-subscribers and
restrict use to a private, family scope. Enable it (DEEZER_ENABLED=true) only if
that matches how you use Sword Music. Previews are always labelled as previews;
full tracks are never offered. Preview URLs expire, so they are refreshed per play.
"""
from __future__ import annotations

import math
from typing import Any

from .base import DiscoverSpec, Provider, ProviderError, StreamInfo, TrackResult, first

API = "https://api.deezer.com"


class DeezerProvider(Provider):
    id = "deezer"
    name = "Deezer (превью)"
    homepage = "https://www.deezer.com"
    stream_kind = "preview"
    terms_note = (
        "Только метаданные и официальные 30-секундные превью. Условия API: некоммерческое, "
        "частное использование. Полные треки не воспроизводятся. Выключен по умолчанию."
    )

    def parse(self, d: dict[str, Any]) -> TrackResult | None:
        if not isinstance(d, dict) or d.get("type", "track") != "track" or not d.get("id"):
            return None
        if d.get("readable") is False:
            return None
        artist = d.get("artist") or {}
        album = d.get("album") or {}
        rank = d.get("rank") or 0
        try:
            pop = min(1.0, math.log10(float(rank) + 10) / 6.2)
        except (TypeError, ValueError):
            pop = 0.3
        bpm = d.get("bpm")
        return TrackResult(
            provider=self.id,
            provider_track_id=str(d["id"]),
            title=str(first(d.get("title"), d.get("title_short"), "?"))[:390],
            artist=str(artist.get("name") or "?")[:290],
            artist_ref=str(artist.get("id")) if artist.get("id") else None,
            album=album.get("title") or None,
            album_ref=str(album.get("id")) if album.get("id") else None,
            duration=float(d["duration"]) if d.get("duration") else None,
            artwork_url=first(album.get("cover_xl"), album.get("cover_big"), album.get("cover_medium")),
            artwork_small=first(album.get("cover_medium"), album.get("cover_small")),
            stream_kind="preview" if d.get("preview") else "none",
            license="© правообладатели (превью Deezer)",
            page_url=d.get("link") or None,
            bpm=float(bpm) if bpm and float(bpm) > 0 else None,
            popularity=round(pop, 3),
            release_date=d.get("release_date") or None,
            extra={"explicit": bool(d.get("explicit_lyrics"))},
        )

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        payload = await self.get_json(f"{API}/search", {"q": query[:120], "limit": str(min(limit, 50))})
        if isinstance(payload, dict) and payload.get("error"):
            err = payload["error"]
            kind = "rate_limited" if str(err.get("code")) == "4" else "bad_response"
            raise ProviderError(kind, f"Deezer: {err.get('message', 'ошибка')}", 5.0 if kind == "rate_limited" else None)
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            raise ProviderError("bad_response", "Deezer: неожиданный формат ответа")
        return [t for t in (self.parse(x) for x in data) if t]

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        words = [k.replace("_", " ") for k in spec.top(2)] + spec.keywords[:1]
        if not words:
            return []
        return await self.search(" ".join(words), spec.limit)

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        try:
            payload = await self.get_json(f"{API}/track/{provider_track_id}")
        except ProviderError as exc:
            if exc.kind == "not_found":
                return None
            raise
        if not isinstance(payload, dict) or payload.get("error"):
            return None
        return self.parse(payload)

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        payload = await self.get_json(f"{API}/track/{provider_track_id}")
        preview = payload.get("preview") if isinstance(payload, dict) else None
        if not preview:
            raise ProviderError("unavailable", "Deezer: превью для трека недоступно")
        return StreamInfo(url=preview, kind="preview", mime="audio/mpeg", expires_in=600)
