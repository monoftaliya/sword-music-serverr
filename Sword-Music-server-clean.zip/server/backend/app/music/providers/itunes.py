"""iTunes public search metadata. Promotional audio isn't used as an entertainment stream."""
from __future__ import annotations

import asyncio
import time

from .base import Provider, ProviderError, TrackResult


class ITunesCatalog(Provider):
    id = "itunes"
    name = "iTunes · каталог"
    homepage = "https://music.apple.com"
    stream_kind = "none"
    search_ttl = 3600
    image_hosts = ("is1-ssl.mzstatic.com", "is2-ssl.mzstatic.com", "is3-ssl.mzstatic.com", "is4-ssl.mzstatic.com", "is5-ssl.mzstatic.com")
    terms_note = "Поиск названий, исполнителей и альбомов в каталоге iTunes. Без подписки и ключа. Аудио не предоставляется; запись можно найти в другом источнике."

    def __init__(self, client):
        super().__init__(client)
        self._lock = asyncio.Lock()
        self._last = 0.0

    async def _request(self, path: str, params: dict):
        async with self._lock:
            delay = 3.1 - (time.monotonic() - self._last)
            if delay > 0:
                await asyncio.sleep(delay)
            self._last = time.monotonic()
            payload = await self.get_json("https://itunes.apple.com/" + path, params, retries=0)
        if not isinstance(payload, dict) or not isinstance(payload.get("results"), list):
            raise ProviderError("bad_response", "iTunes: неожиданный ответ каталога")
        return payload["results"]

    def parse(self, data) -> TrackResult | None:
        if not isinstance(data, dict) or data.get("kind") != "song" or not str(data.get("trackId", "")).isdigit():
            return None
        if not data.get("trackName") or not data.get("artistName"):
            return None
        duration = data.get("trackTimeMillis")
        return TrackResult(provider=self.id, provider_track_id=str(data["trackId"]),
            title=str(data["trackName"])[:390], artist=str(data["artistName"])[:290],
            artist_ref=str(data["artistId"]) if data.get("artistId") else None,
            album=data.get("collectionName"), album_ref=str(data["collectionId"]) if data.get("collectionId") else None,
            duration=duration / 1000 if isinstance(duration, (int, float)) and duration > 0 else None,
            artwork_url=data.get("artworkUrl100"), artwork_small=data.get("artworkUrl100"),
            stream_kind="none", page_url=data.get("trackViewUrl"),
            genres=[data["primaryGenreName"]] if data.get("primaryGenreName") else [],
            release_date=data.get("releaseDate"), license="Метаданные iTunes · без аудио")

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        results = await self._request("search", {"term": query[:200], "entity": "song", "media": "music", "country": "US", "explicit": "Yes", "limit": min(limit, 50)})
        return [track for data in results if (track := self.parse(data))]

    async def get(self, provider_track_id: str, extra: dict | None = None) -> TrackResult | None:
        if not provider_track_id.isdigit():
            return None
        results = await self._request("lookup", {"id": provider_track_id, "entity": "song", "country": "US"})
        return next((track for data in results if (track := self.parse(data)) and track.provider_track_id == provider_track_id), None)

    async def artist_tracks(self, artist_ref: str, limit: int = 100) -> list[TrackResult]:
        if not artist_ref.isdigit():
            return []
        results = await self._request("lookup", {"id": artist_ref, "entity": "song", "country": "US", "limit": min(limit, 100)})
        return [track for data in results if (track := self.parse(data))]

    async def album_tracks(self, album_ref: str, limit: int = 100) -> list[TrackResult]:
        return await self.artist_tracks(album_ref, limit)
