"""Public official embeds, without subscription or developer credentials.

This is URL import, not unrestricted access to any service's catalog.
"""
from __future__ import annotations

import hashlib
import html
import re
from urllib.parse import urlparse

from .base import Provider, ProviderError, StreamInfo, TrackResult


def soundcloud_url(value: str) -> str | None:
    try:
        url = urlparse(value.strip())
        parts = url.path.strip("/").split("/")
        if url.scheme not in ("http", "https") or url.username or url.password or url.port not in (None, 80, 443):
            return None
        if url.hostname not in ("soundcloud.com", "www.soundcloud.com", "m.soundcloud.com"):
            return None
        if len(parts) != 2 or any(not re.fullmatch(r"[A-Za-z0-9_-]+", p) for p in parts):
            return None
        if parts[0] in ("discover", "search", "charts", "you", "settings"):
            return None
        return "https://soundcloud.com/" + "/".join(parts)
    except ValueError:
        return None


def spotify_id(value: str) -> str | None:
    try:
        if value.startswith("spotify:track:"):
            identifier = value.removeprefix("spotify:track:")
            return identifier if re.fullmatch(r"[A-Za-z0-9]{22}", identifier) else None
        url = urlparse(value.strip())
        if url.scheme not in ("http", "https") or url.hostname != "open.spotify.com" or url.username or url.password or url.port not in (None, 80, 443):
            return None
        parts = url.path.strip("/").split("/")
        if parts and parts[0].startswith("intl-"):
            parts = parts[1:]
        return parts[1] if len(parts) == 2 and parts[0] == "track" and re.fullmatch(r"[A-Za-z0-9]{22}", parts[1]) else None
    except ValueError:
        return None


def linked_service(query: str) -> str | None:
    if soundcloud_url(query):
        return "soundcloud"
    if spotify_id(query):
        return "spotify_link"
    return None


class SoundCloudLinks(Provider):
    id = "soundcloud"
    name = "SoundCloud"
    homepage = "https://soundcloud.com"
    stream_kind = "embed"
    image_hosts = ("i1.sndcdn.com", "i2.sndcdn.com")
    terms_note = "Бесплатный официальный плеер по ссылке на публичный трек. Доступность и ограничения записи определяет SoundCloud. Поиск по всему сервису открывается на SoundCloud."

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        url = soundcloud_url(query)
        if not url:
            return []
        track = await self.get("", {"canonical_url": url})
        return [track] if track else []

    async def get(self, provider_track_id: str, extra: dict | None = None) -> TrackResult | None:
        url = soundcloud_url(str((extra or {}).get("canonical_url", "")))
        if not url:
            return None
        data = await self.get_json("https://soundcloud.com/oembed", {"url": url, "format": "json"})
        if not isinstance(data, dict) or not data.get("title"):
            raise ProviderError("bad_response", "SoundCloud: не удалось получить информацию о записи")
        artist = html.unescape(str(data.get("author_name") or ""))
        title = html.unescape(str(data["title"]))
        if artist and title.endswith(" by " + artist):
            title = title[: -len(" by " + artist)]
        identifier = hashlib.sha256(url.encode()).hexdigest()[:32]
        return TrackResult(provider=self.id, provider_track_id=identifier, title=title[:390], artist=artist[:290],
            artwork_url=data.get("thumbnail_url"), artwork_small=data.get("thumbnail_url"),
            page_url=url, stream_kind="embed", extra={"canonical_url": url})

    async def resolve(self, provider_track_id: str, extra: dict) -> StreamInfo:
        url = soundcloud_url(str(extra.get("canonical_url", "")))
        if not url:
            raise ProviderError("not_found", "Вставьте полную ссылку на отдельный трек SoundCloud.")
        return StreamInfo(url=url, kind="embed")


class SpotifyLinks(Provider):
    id = "spotify_link"
    name = "Spotify · встроенный плеер"
    homepage = "https://open.spotify.com"
    stream_kind = "embed"
    image_hosts = ("i.scdn.co", "image-cdn-ak.spotifycdn.com")
    terms_note = "Ссылка на песню и официальный встроенный плеер. Без Premium полная версия не гарантируется; доступный фрагмент определяет Spotify. Подписка в Sword Music не оформляется."

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        identifier = spotify_id(query)
        if not identifier:
            return []
        track = await self.get(identifier)
        return [track] if track else []

    async def get(self, provider_track_id: str, extra: dict | None = None) -> TrackResult | None:
        if not re.fullmatch(r"[A-Za-z0-9]{22}", provider_track_id):
            return None
        url = "https://open.spotify.com/track/" + provider_track_id
        data = await self.get_json("https://open.spotify.com/oembed", {"url": url})
        if not isinstance(data, dict) or not data.get("title"):
            raise ProviderError("bad_response", "Spotify: не удалось получить информацию о записи")
        # oEmbed doesn't promise artist/duration metadata: leave those fields unknown.
        return TrackResult(provider=self.id, provider_track_id=provider_track_id,
            title=html.unescape(str(data["title"]))[:390], artist="",
            artwork_url=data.get("thumbnail_url"), artwork_small=data.get("thumbnail_url"),
            page_url=url, stream_kind="embed", extra={"limited_embed": True})

    async def resolve(self, provider_track_id: str, extra: dict) -> StreamInfo:
        if not re.fullmatch(r"[A-Za-z0-9]{22}", provider_track_id):
            raise ProviderError("not_found", "Вставьте ссылку на отдельную песню Spotify.")
        return StreamInfo(url="spotify:track:" + provider_track_id, kind="embed")
