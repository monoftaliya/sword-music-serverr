"""Internet Archive — openly licensed audio (netlabels, Live Music Archive, community audio).

* No API key. Search via `advancedsearch.php`, track lists via `/metadata/<id>`.
* Only items from collections with clear sharing terms are used: `netlabels`
  (Creative Commons netlabel releases), `etree` (Live Music Archive — trade-friendly
  artists) and community uploads that carry an explicit CC / public-domain licence.
* Audio is streamed straight from archive.org; nothing is copied to our server.
"""
from __future__ import annotations

import asyncio
import hashlib
import math
import re
from typing import Any
from urllib.parse import quote

from .base import (
    DiscoverSpec,
    Provider,
    ProviderError,
    StreamInfo,
    TrackResult,
    as_float,
    cc_license_name,
    split_tags,
)

SEARCH = "https://archive.org/advancedsearch.php"
META = "https://archive.org/metadata/{}"
COLLECTIONS = ("netlabels", "etree", "opensource_audio")
AUDIO_FORMATS = (
    "VBR MP3", "320Kbps MP3", "256Kbps MP3", "192Kbps MP3", "160Kbps MP3", "128Kbps MP3",
    "64Kbps MP3", "MP3", "Ogg Vorbis",
)
_BAD_NAME = re.compile(r"(_sample|_preview|\.afpk|_spectrogram)", re.IGNORECASE)

SUBJECTS: dict[str, list[str]] = {
    "dark_ambient": ["dark ambient", "darkambient"],
    "ambient": ["ambient"],
    "drone": ["drone"],
    "dark": ["dark"],
    "atmospheric": ["atmospheric"],
    "melancholic": ["melancholic"],
    "experimental": ["experimental"],
    "idm": ["idm", "glitch"],
    "electronic": ["electronic", "electronica"],
    "techno": ["techno", "minimal"],
    "house": ["house", "deep house"],
    "dnb": ["drum and bass", "jungle"],
    "dubstep": ["dubstep"],
    "downtempo": ["downtempo", "trip hop"],
    "lofi": ["lo-fi", "lofi"],
    "hiphop": ["hip hop", "hiphop"],
    "industrial": ["industrial"],
    "postrock": ["post-rock", "post rock"],
    "rock": ["rock"],
    "jazz": ["jazz"],
    "classical": ["classical"],
    "piano": ["piano"],
    "folk": ["folk", "acoustic"],
    "space": ["space", "cosmic"],
    "synthwave": ["synthwave", "synth"],
    "chiptune": ["chiptune", "8bit"],
    "noise": ["noise"],
}


def _escape(q: str) -> str:
    return re.sub(r'([+\-!(){}\[\]^"~*?:\\/]|&&|\|\|)', " ", q).strip()


def _pid(identifier: str, filename: str) -> str:
    return f"{identifier}~{hashlib.sha1(filename.encode()).hexdigest()[:10]}"


class ArchiveProvider(Provider):
    id = "archive"
    name = "Internet Archive"
    homepage = "https://archive.org"
    terms_note = (
        "Без ключа. Используются только коллекции с открытыми условиями (netlabels — Creative Commons, "
        "Live Music Archive) и записи с явной CC/PD-лицензией. Воспроизведение напрямую с archive.org."
    )

    async def _search_items(self, q: str, rows: int, sort_downloads: bool) -> list[dict[str, Any]]:
        coll = " OR ".join(f"collection:{c}" for c in COLLECTIONS)
        params: list[tuple[str, str]] = [
            ("q", f"({q}) AND mediatype:audio AND ({coll})"),
            ("rows", str(rows)),
            ("page", "1"),
            ("output", "json"),
        ]
        for f in ("identifier", "title", "creator", "subject", "licenseurl", "downloads", "date", "collection"):
            params.append(("fl[]", f))
        if sort_downloads:
            params.append(("sort[]", "downloads desc"))
        payload = await self.get_json(SEARCH, params)
        docs = (payload.get("response") or {}).get("docs") if isinstance(payload, dict) else None
        if not isinstance(docs, list):
            raise ProviderError("bad_response", "Internet Archive: неожиданный формат ответа")
        out = []
        for d in docs:
            colls = d.get("collection") or []
            if isinstance(colls, str):
                colls = [colls]
            open_coll = any(c in ("netlabels", "etree") for c in colls)
            if not open_coll and not cc_license_name(d.get("licenseurl")):
                continue  # licence unclear — skip rather than assume
            out.append(d)
        return out

    async def _item_tracks(
        self, doc: dict[str, Any], *, max_tracks: int, query: str | None = None
    ) -> list[TrackResult]:
        identifier = doc["identifier"]
        try:
            meta = await self.get_json(META.format(quote(identifier)), retries=0)
        except ProviderError:
            return []
        files = meta.get("files") if isinstance(meta, dict) else None
        md = meta.get("metadata") if isinstance(meta, dict) else None
        if not isinstance(files, list) or not isinstance(md, dict):
            return []
        # choose one playable file per original recording
        by_original: dict[str, dict[str, Any]] = {}
        rank = {f: i for i, f in enumerate(AUDIO_FORMATS)}
        for f in files:
            fmt = f.get("format")
            name = f.get("name") or ""
            if fmt not in rank or _BAD_NAME.search(name):
                continue
            original = f.get("original") or name
            cur = by_original.get(original)
            if cur is None or rank[fmt] < rank[cur["format"]]:
                # keep metadata from the original file if this one is a derivative
                merged = dict(f)
                if f.get("source") == "derivative":
                    src = next((x for x in files if x.get("name") == original), {})
                    for k in ("title", "creator", "album", "track", "length", "genre"):
                        merged.setdefault(k, src.get(k))
                        if not merged.get(k) and src.get(k):
                            merged[k] = src.get(k)
                by_original[original] = merged
        if not by_original:
            return []

        def track_no(f: dict[str, Any]) -> float:
            raw = str(f.get("track") or "").split("/")[0]
            return as_float(raw) or 999.0

        chosen = sorted(by_original.values(), key=lambda f: (track_no(f), f.get("name", "")))
        if query:
            qt = [w for w in re.findall(r"\w+", query.lower()) if len(w) > 2]
            if qt:
                scored = [
                    (sum(1 for w in qt if w in (f.get("title") or f.get("name") or "").lower()), i, f)
                    for i, f in enumerate(chosen)
                ]
                if any(s for s, _, _ in scored):
                    scored.sort(key=lambda x: (-x[0], x[1]))
                    chosen = [f for _, _, f in scored]
        licence_url = md.get("licenseurl") or doc.get("licenseurl")
        subjects = split_tags(md.get("subject") or doc.get("subject"))
        creator = md.get("creator") or doc.get("creator") or "Internet Archive"
        if isinstance(creator, list):
            creator = creator[0]
        album_title = md.get("title") or identifier
        if isinstance(album_title, list):
            album_title = album_title[0]
        try:
            downloads = float(doc.get("downloads") or md.get("downloads") or 0)
        except (TypeError, ValueError):
            downloads = 0.0
        popularity = round(min(1.0, math.log10(downloads + 10) / 6.0), 3)
        colls = md.get("collection") or []
        if isinstance(colls, str):
            colls = [colls]
        licence = cc_license_name(licence_url) or (
            "Live Music Archive (некоммерческий обмен)" if "etree" in colls else None
        )
        art = f"https://archive.org/services/img/{quote(identifier)}"
        out: list[TrackResult] = []
        for f in chosen[:max_tracks]:
            name = f["name"]
            title = f.get("title") or re.sub(r"\.[a-z0-9]+$", "", name.split("/")[-1]).replace("_", " ")
            artist = f.get("creator") or creator
            if isinstance(artist, list):
                artist = artist[0]
            duration = as_float(f.get("length"))
            if duration is not None and duration < 20:
                continue
            genre = split_tags(f.get("genre"))
            out.append(
                TrackResult(
                    provider=self.id,
                    provider_track_id=_pid(identifier, name),
                    title=str(title)[:390],
                    artist=str(artist)[:290],
                    artist_ref=None,
                    album=str(f.get("album") or album_title)[:390],
                    album_ref=identifier,
                    duration=duration,
                    artwork_url=art,
                    artwork_small=art,
                    stream_kind="full",
                    license=licence,
                    license_url=licence_url,
                    page_url=f"https://archive.org/details/{quote(identifier)}",
                    genres=genre,
                    tags=subjects,
                    popularity=popularity,
                    release_date=str(md.get("date") or doc.get("date") or "")[:10] or None,
                    extra={"identifier": identifier, "file": name, "format": f.get("format")},
                )
            )
        return out

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        q = _escape(query)
        if not q:
            return []
        docs = await self._search_items(q, rows=8, sort_downloads=False)
        lists = await asyncio.gather(
            *(self._item_tracks(d, max_tracks=3, query=query) for d in docs[:6]), return_exceptions=True
        )
        out: list[TrackResult] = []
        for lst in lists:
            if isinstance(lst, list):
                out.extend(lst)
        return out[:limit]

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        terms: list[str] = []
        for key in spec.top(4):
            for s in SUBJECTS.get(key, []):
                if s not in terms:
                    terms.append(s)
        if not terms:
            terms = [k for k in spec.keywords[:2]]
        if not terms:
            return []
        q = " OR ".join(f'subject:"{_escape(t)}"' for t in terms[:5])
        docs = await self._search_items(q, rows=10, sort_downloads=spec.popular)
        lists = await asyncio.gather(
            *(self._item_tracks(d, max_tracks=2) for d in docs[:7]), return_exceptions=True
        )
        out: list[TrackResult] = []
        for lst in lists:
            if isinstance(lst, list):
                out.extend(lst)
        return out[: spec.limit]

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        identifier = (extra or {}).get("identifier") or provider_track_id.split("~")[0]
        try:
            items = await self._item_tracks({"identifier": identifier}, max_tracks=500)
        except ProviderError:
            raise
        for t in items:
            if t.provider_track_id == provider_track_id:
                return t
        return None

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        identifier = extra.get("identifier")
        name = extra.get("file")
        if not identifier or not name:
            raise ProviderError("unavailable", "Internet Archive: нет данных о файле")
        mime = "audio/ogg" if str(extra.get("format", "")).startswith("Ogg") else "audio/mpeg"
        url = f"https://archive.org/download/{quote(identifier)}/{quote(name)}"
        return StreamInfo(url=url, kind="full", mime=mime)

    async def album_tracks(self, album_ref: str, limit: int = 100) -> list[TrackResult]:
        return await self._item_tracks({"identifier": album_ref}, max_tracks=limit)
