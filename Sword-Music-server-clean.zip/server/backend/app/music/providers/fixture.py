"""Test-only catalogue (enabled exclusively when SWORD_ENV=test).

Lets automated tests exercise search, playback and recommendations without
network access. It is never registered in development or production, so the
app can never show these synthetic tracks to real users.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from ...config import get_settings
from ..taxonomy import cosine
from ..normalize import query_tokens
from .base import DiscoverSpec, Provider, ProviderError, StreamInfo, TrackResult

FIXTURE_DIR = Path(__file__).resolve().parents[3] / "tests" / "fixtures"


@lru_cache
def _catalog() -> list[dict[str, Any]]:
    path = FIXTURE_DIR / "catalog.json"
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class FixtureProvider(Provider):
    id = "fixture"
    name = "Тестовый каталог"
    homepage = ""
    terms_note = "Синтетические данные только для автоматических тестов (SWORD_ENV=test)."

    def configured(self) -> bool:
        return get_settings().is_test

    def _to_result(self, d: dict[str, Any]) -> TrackResult:
        return TrackResult(
            provider=self.id,
            provider_track_id=d["id"],
            title=d["title"],
            artist=d["artist"],
            artist_ref=d.get("artist_ref"),
            album=d.get("album"),
            duration=d.get("duration"),
            artwork_url=d.get("artwork"),
            artwork_small=d.get("artwork"),
            stream_kind=d.get("stream_kind", "full"),
            license="Test fixture",
            genres=d.get("genres", []),
            moods=d.get("moods", []),
            tags=d.get("tags", []),
            bpm=d.get("bpm"),
            musical_key=d.get("key"),
            popularity=d.get("popularity", 0.3),
            extra={"audio": d.get("audio")},
        )

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        if query.strip().lower() == "__fail__":
            raise ProviderError("network", "Тестовый каталог: имитация сбоя")
        tokens = query_tokens(query)
        out = []
        for d in _catalog():
            hay = " ".join([d["title"], d["artist"], d.get("album") or "", *d.get("tags", []), *d.get("genres", []), *d.get("moods", [])]).lower()
            if tokens and all(any(w.startswith(t) for w in query_tokens(hay)) for t in tokens):
                out.append(self._to_result(d))
        return out[:limit]

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        from ..taxonomy import canonicalize

        scored = []
        for d in _catalog():
            canon = canonicalize(genres=d.get("genres"), moods=d.get("moods"), tags=d.get("tags"))
            s = cosine(spec.tags, canon)
            if s > 0.05 or not spec.tags:
                scored.append((s, d))
        scored.sort(key=lambda x: -x[0])
        return [self._to_result(d) for _, d in scored[: spec.limit]]

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        for d in _catalog():
            if d["id"] == provider_track_id:
                return self._to_result(d)
        return None

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        audio = extra.get("audio")
        if not audio:
            raise ProviderError("unavailable", "Тестовый трек без аудио")
        if extra.get("stream_kind") == "embed":
            return StreamInfo(url=audio, kind="embed")
        return StreamInfo(url=f"/api/_test/audio/{audio}", kind="full", mime="audio/ogg")

    async def artist_tracks(self, artist_ref: str, limit: int = 20) -> list[TrackResult]:
        return [self._to_result(d) for d in _catalog() if d.get("artist_ref") == artist_ref][:limit]
