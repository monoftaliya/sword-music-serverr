"""Provider interface shared by every music source."""
from __future__ import annotations

import asyncio
import ipaddress
import json
import logging
import socket
from dataclasses import dataclass, field
from typing import Any, ClassVar
from urllib.parse import urlparse

import httpx

log = logging.getLogger("sword.providers")


class ProviderError(Exception):
    """kind: config | network | timeout | rate_limited | bad_response | not_found | unavailable"""

    def __init__(self, kind: str, message: str = "", retry_after: float | None = None) -> None:
        super().__init__(message or kind)
        self.kind = kind
        self.message = message or kind
        self.retry_after = retry_after


@dataclass
class TrackResult:
    provider: str
    provider_track_id: str
    title: str
    artist: str
    artist_ref: str | None = None
    album: str | None = None
    album_ref: str | None = None
    duration: float | None = None
    artwork_url: str | None = None
    artwork_small: str | None = None
    stream_kind: str = "full"  # full | preview | none
    license: str | None = None
    license_url: str | None = None
    page_url: str | None = None
    genres: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    moods: list[str] = field(default_factory=list)
    instruments: list[str] = field(default_factory=list)
    bpm: float | None = None
    musical_key: str | None = None
    speed: str | None = None
    vocal: str | None = None
    popularity: float = 0.0
    release_date: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def id(self) -> str:
        return f"{self.provider}:{self.provider_track_id}"


@dataclass
class DiscoverSpec:
    """Provider-agnostic description of what to look for (used by mood search & recommendations)."""

    tags: dict[str, float] = field(default_factory=dict)  # canonical tag -> weight (positive only)
    avoid: set[str] = field(default_factory=set)
    keywords: list[str] = field(default_factory=list)  # free text terms
    bpm_min: float | None = None
    bpm_max: float | None = None
    energy: float | None = None  # 0..1 target
    vocal: str | None = None  # instrumental | vocal
    popular: bool = True
    limit: int = 30

    def top(self, n: int = 3) -> list[str]:
        return [k for k, _ in sorted(self.tags.items(), key=lambda kv: -kv[1])[:n]]

    def cache_key(self) -> str:
        return json.dumps(
            {
                "t": sorted((k, round(v, 2)) for k, v in self.tags.items()),
                "a": sorted(self.avoid),
                "k": self.keywords,
                "b": [self.bpm_min, self.bpm_max],
                "e": None if self.energy is None else round(self.energy, 1),
                "v": self.vocal,
                "p": self.popular,
                "l": self.limit,
            },
            ensure_ascii=False,
        )


@dataclass
class StreamInfo:
    url: str
    kind: str = "full"  # full | preview
    mime: str | None = None
    expires_in: int | None = None


class Provider:
    id: ClassVar[str] = ""
    name: ClassVar[str] = ""
    homepage: ClassVar[str] = ""
    requires_key: ClassVar[bool] = False
    stream_kind: ClassVar[str] = "full"
    terms_note: ClassVar[str] = ""
    # Hosts this provider is known to serve artwork from (palette extraction guard).
    image_hosts: ClassVar[tuple[str, ...]] = ()

    def __init__(self, client: httpx.AsyncClient) -> None:
        self.client = client

    # -- capabilities -----------------------------------------------------
    def configured(self) -> bool:
        return True

    def config_hint(self) -> str:
        return ""

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        raise NotImplementedError

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        return []

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        return None

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        raise ProviderError("unavailable", "Источник не поддерживает воспроизведение.")

    async def artist_tracks(self, artist_ref: str, limit: int = 20) -> list[TrackResult]:
        return []

    async def album_tracks(self, album_ref: str, limit: int = 100) -> list[TrackResult]:
        return []

    # -- HTTP helper -------------------------------------------------------
    async def get_json(
        self,
        url: str,
        params: Any = None,
        *,
        headers: dict[str, str] | None = None,
        retries: int = 1,
    ) -> Any:
        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                resp = await self.client.get(url, params=params, headers=headers)
            except httpx.TimeoutException as exc:
                last_exc = ProviderError("timeout", f"{self.name}: превышено время ожидания")
                log.info("%s timeout (%s)", self.id, exc.__class__.__name__)
            except httpx.HTTPError as exc:
                last_exc = ProviderError("network", f"{self.name}: сетевая ошибка")
                log.info("%s network error (%s)", self.id, exc.__class__.__name__)
            else:
                if resp.status_code == 429:
                    ra = resp.headers.get("retry-after")
                    try:
                        retry_after = float(ra) if ra else 60.0
                    except ValueError:
                        retry_after = 60.0
                    raise ProviderError("rate_limited", f"{self.name}: лимит запросов", retry_after)
                if resp.status_code == 404:
                    raise ProviderError("not_found", f"{self.name}: не найдено")
                if resp.status_code >= 500:
                    last_exc = ProviderError("network", f"{self.name}: сервис временно недоступен ({resp.status_code})")
                elif resp.status_code >= 400:
                    raise ProviderError("bad_response", f"{self.name}: ошибка запроса ({resp.status_code})")
                else:
                    try:
                        return resp.json()
                    except (json.JSONDecodeError, ValueError) as exc:
                        raise ProviderError("bad_response", f"{self.name}: некорректный ответ") from exc
            if attempt < retries:
                await asyncio.sleep(0.5 * (attempt + 1))
        assert last_exc is not None
        raise last_exc


# ---------------------------------------------------------------- SSRF guard
def is_public_http_url(url: str) -> bool:
    """True if the URL is http(s) and every resolved address is publicly routable."""
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        return False
    host = parsed.hostname
    try:
        infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80))
    except (socket.gaierror, UnicodeError):
        return False
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            return False
        if not ip.is_global:
            return False
    return True


def first(*values: Any) -> Any:
    for v in values:
        if v not in (None, "", [], {}):
            return v
    return None


def as_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        if isinstance(value, str) and ":" in value:
            parts = [float(p) for p in value.split(":")]
            total = 0.0
            for p in parts:
                total = total * 60 + p
            return total
        f = float(value)
        return f if f == f else None  # NaN guard
    except (TypeError, ValueError):
        return None


def split_tags(value: Any) -> list[str]:
    if not value:
        return []
    if isinstance(value, list):
        out: list[str] = []
        for v in value:
            out.extend(split_tags(v))
        return out
    parts = [p.strip() for p in str(value).replace(";", ",").split(",")]
    return [p for p in parts if p and len(p) <= 60][:30]


def cc_license_name(url: str | None) -> str | None:
    if not url:
        return None
    u = url.lower()
    if "publicdomain/zero" in u:
        return "CC0"
    if "publicdomain" in u:
        return "Public Domain"
    if "creativecommons.org/licenses/" in u:
        try:
            part = u.split("creativecommons.org/licenses/")[1].strip("/").split("/")
            kind = part[0].upper()
            ver = part[1] if len(part) > 1 else ""
            return f"CC {kind} {ver}".strip()
        except IndexError:
            return "Creative Commons"
    return None
