"""Jamendo — Creative Commons music catalogue with a free API for non-commercial use.

* Requires a free `client_id` (https://devportal.jamendo.com). Without it the
  provider is shown as "not configured" and simply skipped.
* Terms: non-commercial use is free; apps must credit the artist and Jamendo and
  link to the track page; content must not be specifically cached for offline use.
* `musicinfo` contains genres, mood tags (vartags), instruments, speed and
  vocal/instrumental flags — real catalogue metadata used by search & Music DNA.
Docs: https://developer.jamendo.com/v3.0
"""
from __future__ import annotations

import json
import math
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from ...config import get_settings
from .base import (
    DiscoverSpec,
    Provider,
    ProviderError,
    StreamInfo,
    TrackResult,
    cc_license_name,
    first,
)

BASE = "https://api.jamendo.com/v3.0"


def with_audio_format(url: str, fmt: str) -> str:
    """Jamendo serves the same track as mp31 (96 kbps) or mp32 (VBR ~192 kbps); switch via the documented format param."""
    parts = urlsplit(url)
    query = [(k, fmt if k == "format" else v) for k, v in parse_qsl(parts.query, keep_blank_values=True)]
    if not any(k == "format" for k, _ in query):
        return url
    return urlunsplit(parts._replace(query=urlencode(query)))


# canonical tag -> Jamendo tags (used with fuzzytags = OR)
TAGS: dict[str, list[str]] = {
    "dark": ["dark"],
    "melancholic": ["melancholic", "melancholy"],
    "sad": ["sad"],
    "lonely": ["sad", "melancholic"],
    "calm": ["calm", "relaxing", "peaceful"],
    "dreamy": ["dreamy", "ethereal"],
    "atmospheric": ["atmospheric"],
    "mysterious": ["mysterious"],
    "creepy": ["horror", "dark"],
    "tense": ["suspense", "tension"],
    "epic": ["epic"],
    "dramatic": ["dramatic"],
    "aggressive": ["aggressive"],
    "energetic": ["energetic", "powerful"],
    "confident": ["groovy", "powerful"],
    "hypnotic": ["hypnotic"],
    "nostalgic": ["nostalgic"],
    "romantic": ["romantic"],
    "happy": ["happy"],
    "uplifting": ["uplifting", "hopeful"],
    "euphoric": ["euphoric"],
    "phonk": ["phonk"],
    "trap": ["trap"],
    "hiphop": ["hiphop"],
    "lofi": ["lofi", "chillhop"],
    "ambient": ["ambient"],
    "dark_ambient": ["darkambient", "dark"],
    "drone": ["drone"],
    "synthwave": ["synthwave", "retrowave"],
    "darksynth": ["darksynth", "synthwave"],
    "electronic": ["electronic"],
    "techno": ["techno"],
    "house": ["house"],
    "dnb": ["drumnbass"],
    "dubstep": ["dubstep"],
    "trance": ["trance"],
    "idm": ["idm"],
    "experimental": ["experimental"],
    "industrial": ["industrial"],
    "vaporwave": ["vaporwave"],
    "downtempo": ["downtempo", "triphop"],
    "metal": ["metal"],
    "rock": ["rock"],
    "postrock": ["postrock"],
    "indie": ["indie"],
    "pop": ["pop"],
    "rnb": ["rnb", "soul"],
    "funk": ["funk"],
    "jazz": ["jazz"],
    "blues": ["blues"],
    "classical": ["classical"],
    "orchestral": ["orchestral", "symphonic"],
    "cinematic": ["soundtrack", "cinematic", "film"],
    "folk": ["folk", "acoustic"],
    "world": ["world"],
    "chiptune": ["chiptune", "8bit"],
    "piano": ["piano"],
    "guitar": ["guitar"],
    "synth": ["synthesizer"],
    "strings": ["strings"],
    "choir": ["choir"],
    "space": ["space"],
    "night": ["night"],
    "rain": ["rain"],
    "sleep": ["sleep"],
    "nature": ["nature"],
    "workout": ["sport"],
    "study": ["concentration"],
    "drive": ["driving"],
    "japan": ["japan", "japanese"],
    "anime": ["anime"],
    "villain": ["dark", "epic"],
}


def _speed_from_energy(energy: float | None, bpm_min: float | None, bpm_max: float | None) -> list[str]:
    if bpm_min or bpm_max:
        lo = bpm_min or 40
        hi = bpm_max or 220
        speeds = []
        for name, (a, b) in {
            "verylow": (0, 75), "low": (70, 95), "medium": (90, 125), "high": (120, 150), "veryhigh": (145, 260),
        }.items():
            if a <= hi and b >= lo:
                speeds.append(name)
        return speeds
    if energy is None:
        return []
    if energy < 0.25:
        return ["verylow", "low"]
    if energy < 0.45:
        return ["low", "medium"]
    if energy < 0.7:
        return ["medium", "high"]
    return ["high", "veryhigh"]


def _waveform(raw: Any, points: int = 96) -> list[float] | None:
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
        peaks = data.get("peaks") if isinstance(data, dict) else None
        if not peaks:
            return None
        vals = [abs(float(p)) for p in peaks]
        if not vals:
            return None
        step = max(1, len(vals) // points)
        buckets = [max(vals[i : i + step]) for i in range(0, len(vals), step)][:points]
        top = max(buckets) or 1.0
        return [round(v / top, 3) for v in buckets]
    except (ValueError, TypeError, AttributeError):
        return None


class JamendoProvider(Provider):
    id = "jamendo"
    name = "Jamendo"
    homepage = "https://www.jamendo.com"
    requires_key = True
    terms_note = (
        "Бесплатно для некоммерческого использования при наличии client_id. Требуется указывать "
        "исполнителя, Jamendo как источник и ссылку на страницу трека. Кэширование для офлайн-доступа запрещено."
    )

    def configured(self) -> bool:
        return bool(get_settings().jamendo_client_id)

    def config_hint(self) -> str:
        return "Получите бесплатный client_id на devportal.jamendo.com и укажите JAMENDO_CLIENT_ID."

    def _base_params(self, limit: int) -> list[tuple[str, str]]:
        return [
            ("client_id", get_settings().jamendo_client_id),
            ("format", "json"),
            ("limit", str(max(1, min(limit, 100)))),
            ("include", "musicinfo stats licenses"),
            ("audioformat", "mp32"),
            ("imagesize", "600"),
        ]

    def parse(self, d: dict[str, Any]) -> TrackResult | None:
        if not isinstance(d, dict) or not d.get("id") or not d.get("name"):
            return None
        mi = d.get("musicinfo") or {}
        tags = mi.get("tags") or {}
        stats = d.get("stats") or {}
        audio = d.get("audio") or ""
        listened = stats.get("rate_listened_total") or stats.get("listened") or 0
        try:
            pop = min(1.0, math.log10(float(listened) + 10) / 6.5) if listened else 0.25
        except (TypeError, ValueError):
            pop = 0.25
        vocal = mi.get("vocalinstrumental") or None
        instruments = list(tags.get("instruments") or [])
        extra_tags: list[str] = []
        if mi.get("acousticelectric"):
            extra_tags.append(mi["acousticelectric"])
        gender = mi.get("gender")
        if gender in ("male", "female") and vocal != "instrumental":
            extra_tags.append(f"{gender} vocals")
        image = first(d.get("album_image"), d.get("image"))
        pid = str(d["id"])
        return TrackResult(
            provider=self.id,
            provider_track_id=pid,
            title=str(d["name"]).strip()[:390],
            artist=str(d.get("artist_name") or "Неизвестный исполнитель")[:290],
            artist_ref=str(d["artist_id"]) if d.get("artist_id") else None,
            album=d.get("album_name") or None,
            album_ref=str(d["album_id"]) if d.get("album_id") else None,
            duration=float(d["duration"]) if d.get("duration") else None,
            artwork_url=image,
            artwork_small=image.replace("width=600", "width=200") if isinstance(image, str) else None,
            stream_kind="full" if audio else "none",
            license=cc_license_name(d.get("license_ccurl")),
            license_url=d.get("license_ccurl") or None,
            page_url=d.get("shareurl") or f"https://www.jamendo.com/track/{pid}",
            genres=list(tags.get("genres") or []),
            moods=list(tags.get("vartags") or []),
            tags=extra_tags + ([vocal] if vocal else []),
            instruments=instruments,
            speed=mi.get("speed") or None,
            vocal=vocal,
            popularity=round(pop, 3),
            release_date=d.get("releasedate") or None,
            extra={
                "audio": audio,
                "download_allowed": bool(d.get("audiodownload_allowed")),
                "waveform": _waveform(d.get("waveform")),
                "gender": gender if gender in ("male", "female") else None,
                "acousticelectric": mi.get("acousticelectric") or None,
                "lang": mi.get("lang") or None,
                "position": d.get("position"),
            },
        )

    def _parse_list(self, payload: Any) -> list[TrackResult]:
        if not isinstance(payload, dict):
            raise ProviderError("bad_response", "Jamendo: неожиданный формат ответа")
        headers = payload.get("headers") or {}
        if headers.get("status") not in (None, "success"):
            msg = headers.get("error_message") or "ошибка API"
            kind = "config" if "client" in str(msg).lower() else "bad_response"
            raise ProviderError(kind, f"Jamendo: {msg}")
        return [t for t in (self.parse(x) for x in payload.get("results") or []) if t]

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        if not self.configured():
            raise ProviderError("config", "Jamendo: не задан JAMENDO_CLIENT_ID")
        params = self._base_params(limit) + [("search", query[:120]), ("boost", "popularity_total")]
        return self._parse_list(await self.get_json(f"{BASE}/tracks/", params))

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        if not self.configured():
            raise ProviderError("config", "Jamendo: не задан JAMENDO_CLIENT_ID")
        jtags: list[str] = []
        for key in spec.top(5):
            for t in TAGS.get(key, [key])[:2]:
                if t not in jtags:
                    jtags.append(t)
        params = self._base_params(spec.limit)
        if jtags:
            params.append(("fuzzytags", " ".join(jtags[:8])))  # space == "+" after URL decoding
        elif spec.keywords:
            params.append(("search", " ".join(spec.keywords[:3])))
        speeds = _speed_from_energy(spec.energy, spec.bpm_min, spec.bpm_max)
        if speeds:
            params.append(("speed", " ".join(speeds)))
        if spec.vocal in ("vocal", "instrumental"):
            params.append(("vocalinstrumental", spec.vocal))
        params.append(("boost", "popularity_month" if spec.popular else "buzzrate"))
        return self._parse_list(await self.get_json(f"{BASE}/tracks/", params))

    async def get(self, provider_track_id: str, extra: dict[str, Any] | None = None) -> TrackResult | None:
        if not self.configured():
            raise ProviderError("config", "Jamendo: не задан JAMENDO_CLIENT_ID")
        params = self._base_params(1) + [("id", provider_track_id)]
        items = self._parse_list(await self.get_json(f"{BASE}/tracks/", params))
        return items[0] if items else None

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        url = extra.get("audio")
        if not url:
            fresh = await self.get(provider_track_id)
            url = fresh.extra.get("audio") if fresh else None
        if not url:
            raise ProviderError("unavailable", "Jamendo: поток для трека недоступен")
        if extra.get("quality") == "data_saver":
            url = with_audio_format(url, "mp31")
        return StreamInfo(url=url, kind="full", mime="audio/mpeg")

    async def artist_tracks(self, artist_ref: str, limit: int = 20) -> list[TrackResult]:
        if not self.configured():
            return []
        params = self._base_params(limit) + [("artist_id", artist_ref), ("order", "popularity_total")]
        return self._parse_list(await self.get_json(f"{BASE}/tracks/", params))

    async def album_tracks(self, album_ref: str, limit: int = 100) -> list[TrackResult]:
        if not self.configured():
            return []
        params = self._base_params(min(limit, 100)) + [("album_id", album_ref)]
        items = self._parse_list(await self.get_json(f"{BASE}/tracks/", params))
        items.sort(key=lambda t: int(t.extra.get("position") or 0))
        return items
