"""Open recording metadata; playback stays with the recording's licensed source."""
from __future__ import annotations

import asyncio
import re
import time
from typing import Any

from .base import Provider, ProviderError, TrackResult

API = "https://musicbrainz.org/ws/2"
MBID = re.compile(r"^[0-9a-f-]{36}$")


class MusicBrainzProvider(Provider):
    id = "musicbrainz"
    name = "MusicBrainz"
    homepage = "https://musicbrainz.org"
    stream_kind = "none"
    terms_note = "Открытый каталог исполнителей и записей. Аудио не предоставляется; полные версии ищите в подключённых источниках."
    search_ttl = 6 * 3600
    image_hosts = ("coverartarchive.org", "archive.org")

    def __init__(self, client):
        super().__init__(client)
        self._lock = asyncio.Lock()
        self._last_request = 0.0

    async def _request(self, path: str, params: dict[str, Any]) -> dict:
        # MusicBrainz permits about one request per second per source IP.
        async with self._lock:
            delay = 1.1 - (time.monotonic() - self._last_request)
            if delay > 0:
                await asyncio.sleep(delay)
            self._last_request = time.monotonic()
            payload = await self.get_json(f"{API}/{path}", {**params, "fmt": "json"}, retries=0)
        if not isinstance(payload, dict):
            raise ProviderError("bad_response", "MusicBrainz: неожиданный ответ")
        return payload

    def parse(self, recording: dict[str, Any], release: dict | None = None) -> TrackResult | None:
        if not isinstance(recording, dict) or not MBID.fullmatch(str(recording.get("id", ""))):
            return None
        credits = [c for c in recording.get("artist-credit", []) if isinstance(c, dict)]
        artist = "".join(str(c.get("name") or (c.get("artist") or {}).get("name") or "")
                         + str(c.get("joinphrase", "")) for c in credits).strip()
        if not artist or not recording.get("title"):
            return None
        release = release or next(iter(recording.get("releases") or []), {})
        length = recording.get("length")
        duration = float(length) / 1000 if isinstance(length, (int, float)) and length > 0 else None
        return TrackResult(
            provider=self.id, provider_track_id=recording["id"],
            title=str(recording["title"])[:390], artist=artist[:290],
            artist_ref=(credits[0].get("artist") or {}).get("id"),
            album=release.get("title"), album_ref=release.get("id"), duration=duration,
            stream_kind="none", page_url=f"https://musicbrainz.org/recording/{recording['id']}",
            license="MusicBrainz — открытые метаданные, без аудио",
            release_date=release.get("date") or recording.get("first-release-date"),
            tags=[t["name"] for t in recording.get("tags", []) if isinstance(t, dict) and t.get("name")],
        )

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        words = re.sub(r'[+\-!(){}\[\]^"~*?:\\/|&]', " ", query).strip()[:180]
        if not words:
            return []
        payload = await self._request("recording", {"query": words, "limit": min(100, limit)})
        return [t for t in (self.parse(r) for r in payload.get("recordings", [])) if t]

    async def get(self, provider_track_id: str, extra: dict | None = None) -> TrackResult | None:
        if not MBID.fullmatch(provider_track_id):
            return None
        data = await self._request(f"recording/{provider_track_id}", {"inc": "artists+releases+tags"})
        return self.parse(data)

    async def artist_tracks(self, artist_ref: str, limit: int = 100) -> list[TrackResult]:
        if not MBID.fullmatch(artist_ref):
            return []
        payload = await self._request("recording", {"artist": artist_ref, "inc": "artist-credits+releases", "limit": min(limit, 100)})
        return [t for t in (self.parse(r) for r in payload.get("recordings", [])) if t]

    async def album_tracks(self, album_ref: str, limit: int = 100) -> list[TrackResult]:
        if not MBID.fullmatch(album_ref):
            return []
        release = await self._request(f"release/{album_ref}", {"inc": "recordings+artist-credits"})
        tracks = []
        for medium in release.get("media", []):
            for item in medium.get("tracks", []):
                recording = {**item.get("recording", {})}
                recording.setdefault("artist-credit", item.get("artist-credit") or release.get("artist-credit", []))
                parsed = self.parse(recording, release)
                if parsed:
                    tracks.append(parsed)
        return tracks[:limit]
