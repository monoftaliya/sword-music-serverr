"""Wikimedia Commons — freely licensed / public-domain recordings (mostly classical).

* No key; a descriptive User-Agent with contact information is required by the
  Wikimedia User-Agent policy (configured via APP_CONTACT).
* Pronunciation clips and other short spoken files are filtered out.
* For browser compatibility an MP3 transcode is preferred when Commons offers one.
"""
from __future__ import annotations

import html
import re
from typing import Any

from .base import DiscoverSpec, Provider, ProviderError, StreamInfo, TrackResult, as_float

API = "https://commons.wikimedia.org/w/api.php"
_TAGS_RE = re.compile(r"<[^>]+>")
_SPOKEN_WORDS = re.compile(
    r"(pronunciation|pronounce|произношение|spoken|speech|interview|lecture|podcast|audiobook|"
    r"аудиокнига|интервью|лекция|wikipedia)",
    re.IGNORECASE,
)
# Lingua Libre / language-prefixed pronunciation files: "LL-Q7737 (rus)-…", "En-us-word.ogg", "Ru-слово.ogg"
_PRONUNCIATION_FILE = re.compile(r"^(LL-Q\d+|[A-Za-z]{2,3}(-[A-Za-z]{2,4})?-\S+\.(ogg|oga|wav|mp3|flac|opus)$)")


def _is_spoken(title: str) -> bool:
    bare = re.sub(r"^File:", "", title)
    return bool(_SPOKEN_WORDS.search(bare) or _PRONUNCIATION_FILE.search(bare))


CLASSICAL_HINTS = {
    "nocturne": ["classical", "piano", "night"],
    "sonata": ["classical"],
    "symphony": ["classical", "orchestral"],
    "symphonie": ["classical", "orchestral"],
    "concerto": ["classical", "orchestral"],
    "prelude": ["classical"],
    "étude": ["classical", "piano"],
    "etude": ["classical", "piano"],
    "waltz": ["classical"],
    "requiem": ["classical", "choir", "dark"],
    "fugue": ["classical"],
    "piano": ["piano"],
    "violin": ["strings"],
    "cello": ["strings"],
    "choir": ["choir"],
    "mass": ["choir"],
    "opera": ["classical"],
    "overture": ["classical", "orchestral"],
    "march": ["classical"],
    "lullaby": ["sleep", "calm"],
    "adagio": ["classical", "melancholic"],
    "lacrimosa": ["classical", "choir", "dark"],
    "moonlight": ["classical", "piano", "night"],
    "funeral": ["classical", "dark", "sad"],
}
DISCOVER_QUERIES: dict[str, str] = {
    "classical": "classical music",
    "orchestral": "symphony orchestra",
    "piano": "piano",
    "strings": "string quartet",
    "choir": "choir",
    "dark": "requiem",
    "sad": "adagio",
    "melancholic": "nocturne",
    "night": "nocturne",
    "sleep": "lullaby",
    "calm": "piano prelude",
    "epic": "symphony",
}


def _clean(raw: Any) -> str:
    if not raw:
        return ""
    return html.unescape(_TAGS_RE.sub("", str(raw))).strip()


class WikimediaProvider(Provider):
    id = "wikimedia"
    name = "Wikimedia Commons"
    homepage = "https://commons.wikimedia.org"
    terms_note = (
        "Без ключа. Свободные лицензии и общественное достояние; обязательна указанная лицензия и автор. "
        "Запросы помечаются User-Agent с контактом (политика Wikimedia)."
    )

    def _parse_page(self, page: dict[str, Any]) -> TrackResult | None:
        info_list = page.get("videoinfo") or page.get("imageinfo") or []
        if not info_list:
            return None
        info = info_list[0]
        mime = info.get("mime") or ""
        if not (mime.startswith("audio/") or mime == "application/ogg"):
            return None
        title_raw = str(page.get("title") or "")
        if _is_spoken(title_raw):
            return None
        duration = as_float(info.get("duration"))
        if duration is not None and duration < 45:
            return None
        meta = info.get("extmetadata") or {}
        name = _clean((meta.get("ObjectName") or {}).get("value")) or re.sub(
            r"^File:|\.[A-Za-z0-9]+$", "", title_raw
        ).replace("_", " ")
        artist = _clean((meta.get("Artist") or {}).get("value")) or "Wikimedia Commons"
        artist = re.sub(r"\s+", " ", artist)[:200]
        lic = _clean((meta.get("LicenseShortName") or {}).get("value")) or None
        lic_url = _clean((meta.get("LicenseUrl") or {}).get("value")) or None
        url = info.get("url")
        mp3 = None
        for der in info.get("derivatives") or []:
            if (der.get("type") or "").startswith("audio/mpeg"):
                mp3 = der.get("src")
                break
        stream = mp3 or url
        if not stream:
            return None
        low = name.lower()
        hints: list[str] = []
        for word, tags in CLASSICAL_HINTS.items():
            if word in low:
                hints.extend(tags)
        page_id = str(page.get("pageid") or "")
        if not page_id:
            return None
        return TrackResult(
            provider=self.id,
            provider_track_id=page_id,
            title=name[:390],
            artist=artist[:290],
            duration=duration,
            stream_kind="full",
            license=lic,
            license_url=lic_url,
            page_url=info.get("descriptionurl") or None,
            genres=sorted(set(h for h in hints if h in ("classical", "orchestral"))),
            tags=sorted(set(hints)),
            popularity=0.2,
            extra={"url": stream, "mime": "audio/mpeg" if mp3 else mime},
        )

    async def _query(self, text: str, limit: int) -> list[TrackResult]:
        params = {
            "action": "query",
            "format": "json",
            "formatversion": "2",
            "generator": "search",
            "gsrsearch": f"filetype:audio {text}"[:200],
            "gsrnamespace": "6",
            "gsrlimit": str(min(limit * 2, 40)),
            "prop": "videoinfo",
            "viprop": "url|mime|size|derivatives|extmetadata",
            "viextmetadatafilter": "Artist|LicenseShortName|LicenseUrl|ObjectName",
        }
        payload = await self.get_json(API, params)
        if not isinstance(payload, dict):
            raise ProviderError("bad_response", "Wikimedia: неожиданный формат ответа")
        if "error" in payload:
            raise ProviderError("bad_response", "Wikimedia: ошибка API")
        pages = (payload.get("query") or {}).get("pages") or []
        if isinstance(pages, dict):
            pages = list(pages.values())
        pages.sort(key=lambda p: p.get("index", 0))
        out = [t for t in (self._parse_page(p) for p in pages) if t]
        return out[:limit]

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        return await self._query(query, limit)

    async def discover(self, spec: DiscoverSpec) -> list[TrackResult]:
        queries = [DISCOVER_QUERIES[k] for k in spec.top(4) if k in DISCOVER_QUERIES]
        relevant = {"classical", "orchestral", "piano", "strings", "choir"}
        if not queries or not (relevant & set(spec.tags)):
            return []
        return await self._query(queries[0], min(spec.limit, 15))

    async def resolve(self, provider_track_id: str, extra: dict[str, Any]) -> StreamInfo:
        url = extra.get("url")
        if not url:
            raise ProviderError("unavailable", "Wikimedia: нет ссылки на файл")
        return StreamInfo(url=url, kind="full", mime=extra.get("mime"))
