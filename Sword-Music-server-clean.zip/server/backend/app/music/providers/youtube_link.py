"""Explicit YouTube links work through official oEmbed and IFrame APIs without a search key."""
from __future__ import annotations

import re
from urllib.parse import parse_qs, urlparse

from .base import Provider, ProviderError, StreamInfo, TrackResult
from .youtube import split_title


def video_id(value: str) -> str | None:
    try:
        url = urlparse(value.strip())
        if url.scheme not in ("http", "https") or url.username or url.password:
            return None
        host = (url.hostname or "").lower()
        if host in ("youtu.be", "www.youtu.be"):
            result = url.path.strip("/")
        elif host in ("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"):
            parts = url.path.strip("/").split("/")
            result = (parse_qs(url.query).get("v") or [""])[0] if parts[0] == "watch" else parts[1] if len(parts) == 2 and parts[0] in ("shorts", "embed", "live") else ""
        else:
            return None
        return result if re.fullmatch(r"[A-Za-z0-9_-]{11}", result) else None
    except ValueError:
        return None


class YouTubeLinkProvider(Provider):
    id = "youtube_link"
    name = "YouTube · по ссылке"
    homepage = "https://www.youtube.com"
    stream_kind = "embed"
    image_hosts = ("i.ytimg.com",)
    terms_note = "Вставьте ссылку YouTube в поиск. Без ключа поиска. Воспроизведение через видимый официальный плеер YouTube, с ограничениями автора и региона."

    async def search(self, query: str, limit: int = 20) -> list[TrackResult]:
        identifier = video_id(query)
        if identifier is None:
            return []
        track = await self.get(identifier)
        return [track] if track else []

    async def get(self, provider_track_id: str, extra: dict | None = None) -> TrackResult | None:
        if not re.fullmatch(r"[A-Za-z0-9_-]{11}", provider_track_id):
            return None
        url = f"https://www.youtube.com/watch?v={provider_track_id}"
        payload = await self.get_json("https://www.youtube.com/oembed", {"url": url, "format": "json"})
        if not isinstance(payload, dict) or not payload.get("title"):
            raise ProviderError("bad_response", "YouTube: не удалось получить информацию о видео")
        artist, title = split_title(payload["title"], payload.get("author_name", "YouTube"))
        return TrackResult(provider=self.id, provider_track_id=provider_track_id, title=title[:390],
            artist=artist[:290], stream_kind="embed", page_url=url,
            artwork_url=payload.get("thumbnail_url"), artwork_small=payload.get("thumbnail_url"))

    async def resolve(self, provider_track_id: str, extra: dict) -> StreamInfo:
        if not re.fullmatch(r"[A-Za-z0-9_-]{11}", provider_track_id):
            raise ProviderError("not_found", "YouTube: неверная ссылка")
        return StreamInfo(url=provider_track_id, kind="embed")
