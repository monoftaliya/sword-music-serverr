"""Text normalisation used for de-duplication and artist identity."""
from __future__ import annotations

import re
import unicodedata

# Bracketed noise that does not change what the recording is.
_NOISE = re.compile(
    r"[\(\[\{]\s*(official( music)?( video| audio| visualizer| lyric video)?|lyrics?( video)?|audio|hq|hd|4k|"
    r"free (download|dl)|out now|premiere|visuali[sz]er|explicit|clean|prod\.?[^\)\]\}]*|"
    r"produced by[^\)\]\}]*|copyright free|no copyright|ncs release|royalty free)\s*[\)\]\}]",
    re.IGNORECASE,
)
# Markers that DO describe a different version of a song — kept in the key.
VERSION_MARKERS = (
    "remix", "mix", "edit", "live", "acoustic", "instrumental", "slowed", "reverb", "sped up",
    "speed up", "nightcore", "extended", "cover", "remaster", "remastered", "demo", "version",
    "vip", "bootleg", "rework", "flip", "mashup", "orchestral", "piano version", "8d", "bass boosted",
    "radio edit", "club mix", "a cappella", "acapella", "karaoke", "unplugged",
)
_FEAT = re.compile(r"\s*[\(\[]?\s*(feat\.?|ft\.?|featuring|при уч\.?)\s+[^\)\]]*[\)\]]?", re.IGNORECASE)
_ARTIST_SPLIT = re.compile(r"\s*(?:,|&|\bx\b|\band\b|\bи\b|/|;|\bvs\.?\b)\s*", re.IGNORECASE)


_KEEP = {"й": "\ue000", "Й": "\ue000"}


def fold(text: str) -> str:
    """Lower-case, ё→е, strip Latin diacritics — but keep Cyrillic «й» intact."""
    text = text.lower().replace("ё", "е")
    for ch, ph in _KEEP.items():
        text = text.replace(ch, ph)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return text.replace("\ue000", "й")


def clean_words(text: str) -> str:
    text = fold(text)
    text = re.sub(r"[^\w\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def version_markers(title: str) -> list[str]:
    low = fold(title)
    found = []
    for expression, marker in (
        (r"\b(?:замедлен\w*|слоу\w*|slowed|slow\s*(?:down|version))\b", "slowed"),
        (r"\b(?:ускорен\w*|спидап\w*|sped\s*up|speed\s*up|speedup)\b", "spedup"),
        (r"\b(?:найткор\w*|nightcore)\b", "nightcore"),
        (r"\b(?:реверб\w*|reverb)\b", "reverb"),
    ):
        if re.search(expression, low):
            found.append(marker)
    for m in VERSION_MARKERS:
        if re.search(rf"(?<![a-z]){re.escape(m)}(?![a-z])", low):
            marker = m.replace(" ", "")
            found.append("spedup" if marker == "speedup" else marker)
    # "mix" is contained in "remix" — keep only the most specific
    if "remix" in found and "mix" in found:
        found.remove("mix")
    return sorted(set(found))


def matches_version(title: str, version: str) -> bool:
    markers = set(version_markers(title))
    if version == "original":
        return not markers
    if version == "sped":
        return bool(markers & {"spedup", "speedup"})
    if version == "slowed":
        return "slowed" in markers
    if version == "reverb":
        return {"slowed", "reverb"} <= markers
    if version == "nightcore":
        return "nightcore" in markers
    return True


def base_title(title: str) -> str:
    t = _NOISE.sub(" ", title)
    t = _FEAT.sub(" ", t)
    # drop bracketed/dashed version descriptors from the base (they go into markers)
    t = re.sub(r"[\(\[][^\)\]]*[\)\]]", " ", t)
    return clean_words(t)


def primary_artist(artist: str) -> str:
    a = _FEAT.sub(" ", artist or "")
    parts = [p for p in _ARTIST_SPLIT.split(a) if p and p.strip()]
    return clean_words(parts[0]) if parts else clean_words(a)


def artist_key(artist: str) -> str:
    return "a:" + (primary_artist(artist) or "unknown")[:180]


def norm_key(title: str, artist: str) -> str:
    """Key for 'same recording' detection. Different versions get different keys."""
    markers = version_markers(title)
    key = f"{primary_artist(artist)}|{base_title(title)}"
    if markers:
        key += "|" + "+".join(markers)
    return key[:290]


def durations_compatible(a: float | None, b: float | None) -> bool:
    if not a or not b:
        return True
    return abs(a - b) <= max(4.0, 0.03 * max(a, b))


def query_tokens(text: str) -> list[str]:
    return [w for w in clean_words(text).split(" ") if w]


def text_relevance(query: str, title: str, artist: str, album: str | None = None) -> float:
    """Cheap lexical relevance 0..1 used to order merged text-search results."""
    q = query_tokens(query)
    if not q:
        return 0.0
    t = set(query_tokens(title))
    a = set(query_tokens(artist))
    al = set(query_tokens(album or ""))
    hits = 0.0
    for tok in q:
        if tok in t:
            hits += 1.0
        elif tok in a:
            hits += 0.9
        elif tok in al:
            hits += 0.5
        elif any(w.startswith(tok) for w in t | a) and len(tok) >= 3:
            hits += 0.6
    score = hits / len(q)
    full = clean_words(query)
    if full and full == clean_words(title):
        score += 0.35
    if full and full in f"{clean_words(artist)} {clean_words(title)}":
        score += 0.15
    return min(1.0, score)
