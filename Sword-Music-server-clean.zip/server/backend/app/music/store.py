"""Persisting provider results as stable Track rows and serialising them for the API."""
from __future__ import annotations

from collections.abc import Iterable, Sequence
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import upsert, utcnow
from ..models import Favorite, Track
from .normalize import artist_key, norm_key
from .providers.base import TrackResult
from .registry import NAMES
from .taxonomy import canonicalize, label, mood_point, top_tags

UPDATE_COLS = [
    "title", "artist", "artist_ref", "album", "album_ref", "duration", "artwork_url", "artwork_small",
    "stream_kind", "license", "license_url", "page_url", "genres", "tags", "moods", "instruments",
    "canonical", "bpm", "musical_key", "speed", "vocal", "popularity", "release_date", "norm_key",
    "artist_key", "extra", "unavailable_reason", "unavailable_at", "updated_at",
]


def canonical_for(r: TrackResult) -> dict[str, float]:
    extra_tags: dict[str, float] = {}
    if r.vocal == "instrumental":
        extra_tags["instrumental"] = 0.4
    return canonicalize(
        genres=r.genres, moods=r.moods, tags=r.tags, instruments=r.instruments, extra=extra_tags
    )


def result_to_row(r: TrackResult) -> dict[str, Any]:
    now = utcnow()
    return {
        "id": r.id[:200],
        "provider": r.provider,
        "provider_track_id": r.provider_track_id[:160],
        "title": (r.title or "Без названия")[:400],
        "artist": (r.artist or "")[:300],
        "artist_ref": r.artist_ref,
        "album": r.album[:400] if r.album else None,
        "album_ref": r.album_ref,
        "duration": r.duration,
        "artwork_url": r.artwork_url,
        "artwork_small": r.artwork_small,
        "stream_kind": r.stream_kind,
        "license": r.license[:120] if r.license else None,
        "license_url": r.license_url,
        "page_url": r.page_url,
        "genres": r.genres[:12],
        "tags": r.tags[:30],
        "moods": r.moods[:12],
        "instruments": r.instruments[:12],
        "canonical": canonical_for(r),
        "bpm": r.bpm,
        "musical_key": r.musical_key,
        "speed": r.speed,
        "vocal": r.vocal,
        "popularity": r.popularity,
        "release_date": r.release_date,
        "norm_key": norm_key(r.title, r.artist),
        "artist_key": artist_key(r.artist),
        "extra": r.extra,
        "unavailable_reason": None,
        "unavailable_at": None,
        "created_at": now,
        "updated_at": now,
    }


async def save_results(session: AsyncSession, results: Sequence[TrackResult]) -> dict[str, Track]:
    """Upsert provider results; returns ORM rows keyed by track id."""
    rows: dict[str, dict[str, Any]] = {}
    for r in results:
        row = result_to_row(r)
        rows.setdefault(row["id"], row)  # Postgres forbids touching a row twice per statement
    if not rows:
        return {}
    ids = list(rows.keys())
    for i in range(0, len(ids), 200):
        chunk = [rows[x] for x in ids[i : i + 200]]
        await upsert(session, Track, chunk, ["id"], UPDATE_COLS)
    await session.commit()
    return await load_tracks(session, ids)


async def load_tracks(session: AsyncSession, ids: Iterable[str]) -> dict[str, Track]:
    ids = list(dict.fromkeys(ids))
    out: dict[str, Track] = {}
    for i in range(0, len(ids), 500):
        chunk = ids[i : i + 500]
        res = await session.execute(select(Track).where(Track.id.in_(chunk)))
        for t in res.scalars():
            out[t.id] = t
    return out


async def liked_ids(session: AsyncSession, user_id: str, track_ids: Iterable[str]) -> set[str]:
    ids = list(track_ids)
    if not ids:
        return set()
    res = await session.execute(
        select(Favorite.track_id).where(Favorite.user_id == user_id, Favorite.track_id.in_(ids))
    )
    return set(res.scalars())


def track_out(t: Track, *, liked: bool = False, reason: str | None = None) -> dict[str, Any]:
    playable = t.stream_kind != "none" and t.unavailable_reason is None
    data: dict[str, Any] = {
        "id": t.id,
        "title": t.title,
        "artist": t.artist,
        "artist_key": t.artist_key,
        "artist_ref": t.artist_ref,
        "album": t.album,
        "album_ref": t.album_ref,
        "duration": t.duration,
        "artwork": t.artwork_url,
        "artwork_small": t.artwork_small or t.artwork_url,
        "provider": t.provider,
        "source": NAMES.get(t.provider, t.provider),
        "stream": t.stream_kind,
        "playable": playable,
        "unavailable": t.unavailable_reason,
        "license": t.license,
        "license_url": t.license_url,
        "page_url": t.page_url,
        "tags": [{"key": k, "label": label(k)} for k in top_tags(t.canonical or {}, 4)],
        "bpm": t.bpm,
        "key": t.musical_key,
        "liked": liked,
        "palette": t.palette,
    }
    if reason:
        data["reason"] = reason
    return data


async def tracks_out(
    session: AsyncSession, user_id: str, tracks: Sequence[Track], reasons: dict[str, str] | None = None
) -> list[dict[str, Any]]:
    liked = await liked_ids(session, user_id, [t.id for t in tracks])
    return [track_out(t, liked=t.id in liked, reason=(reasons or {}).get(t.id)) for t in tracks]


def track_point(t: Track) -> tuple[float, float, float] | None:
    return mood_point(t.canonical or {}, t.bpm, t.speed)
