"""Cover-art palette extraction (server side, so it works regardless of image CORS)."""
from __future__ import annotations

import asyncio
import colorsys
import io
import logging
from pathlib import Path
from typing import Any

import httpx
from PIL import Image, UnidentifiedImageError

from ..core.storage import media_root
from .providers.base import is_public_http_url

log = logging.getLogger("sword.palette")
MAX_BYTES = 6 * 1024 * 1024


def _hex(rgb: tuple[float, float, float]) -> str:
    return "#{:02x}{:02x}{:02x}".format(*(max(0, min(255, int(round(c * 255)))) for c in rgb))


def _hls(rgb: tuple[int, int, int]) -> tuple[float, float, float]:
    return colorsys.rgb_to_hls(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255)


def palette_from_bytes(data: bytes) -> dict[str, Any] | None:
    try:
        img = Image.open(io.BytesIO(data))
        img.draft("RGB", (128, 128))
        img = img.convert("RGB")
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        return None
    img.thumbnail((72, 72))
    q = img.quantize(colors=8, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette() or []
    counts = sorted(q.getcolors() or [], reverse=True)
    colors: list[tuple[int, tuple[int, int, int]]] = []
    for count, idx in counts:
        rgb = tuple(pal[idx * 3 : idx * 3 + 3])
        if len(rgb) == 3:
            colors.append((count, rgb))  # type: ignore[arg-type]
    if not colors:
        return None
    total = sum(c for c, _ in colors)
    dominant = colors[0][1]

    def vividness(item: tuple[int, tuple[int, int, int]]) -> float:
        count, rgb = item
        h, l, s = _hls(rgb)
        share = count / total
        mid = 1 - abs(l - 0.5) * 1.6
        return s * 0.65 + mid * 0.25 + min(share * 3, 1) * 0.1

    ranked = sorted(colors, key=vividness, reverse=True)
    accent_rgb = ranked[0][1]
    glow_rgb = ranked[1][1] if len(ranked) > 1 else accent_rgb

    def tune(rgb: tuple[int, int, int], lightness: float, min_sat: float, max_sat: float = 0.9) -> str:
        h, l, s = _hls(rgb)
        s = max(min_sat, min(max_sat, s))
        return _hex(colorsys.hls_to_rgb(h, lightness, s))

    h, l, s = _hls(dominant)
    mono = max(_hls(c)[2] for _, c in colors) < 0.12
    return {
        "base": tune(dominant, 0.075, 0.18 if not mono else 0.0, 0.55),
        "surface": tune(dominant, 0.13, 0.12 if not mono else 0.0, 0.45),
        "accent": tune(accent_rgb, 0.66, 0.45 if not mono else 0.0),
        "glow": tune(glow_rgb, 0.55, 0.4 if not mono else 0.0),
        "dominant": _hex(tuple(c / 255 for c in dominant)),  # type: ignore[arg-type]
        "mono": mono,
        "light": l > 0.62,
    }


async def palette_for_url(client: httpx.AsyncClient, url: str) -> dict[str, Any] | None:
    if url.startswith("/api/_test/art/"):
        from ..config import get_settings

        if not get_settings().is_test:
            return None
        art = Path(__file__).resolve().parents[2] / "tests" / "fixtures" / "art" / Path(url).name
        return await asyncio.to_thread(palette_from_bytes, art.read_bytes()) if art.exists() else None
    if url.startswith("/media/"):
        path = (media_root() / url[len("/media/") :]).resolve()
        if media_root().resolve() not in path.parents or not path.exists():
            return None
        return await asyncio.to_thread(palette_from_bytes, Path(path).read_bytes())
    if not await asyncio.to_thread(is_public_http_url, url):
        return None
    try:
        async with client.stream("GET", url, timeout=8.0, headers={"Accept": "image/*"}) as resp:
            if resp.status_code != 200 or not resp.headers.get("content-type", "").startswith("image/"):
                return None
            buf = bytearray()
            async for chunk in resp.aiter_bytes():
                buf.extend(chunk)
                if len(buf) > MAX_BYTES:
                    return None
    except httpx.HTTPError as exc:
        log.info("Palette fetch failed: %s", exc.__class__.__name__)
        return None
    return await asyncio.to_thread(palette_from_bytes, bytes(buf))
