"""Provider registry: enable/disable, health tracking, circuit breaker and response cache."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import OrderedDict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, TypeVar

import httpx

from ..config import get_settings
from .providers.archive import ArchiveProvider
from .providers.audius import AudiusProvider
from .providers.base import Provider, ProviderError
from .providers.deezer import DeezerProvider
from .providers.fixture import FixtureProvider
from .providers.jamendo import JamendoProvider
from .providers.wikimedia import WikimediaProvider
from .providers.youtube import YouTubeProvider
from .providers.musicbrainz import MusicBrainzProvider
from .providers.youtube_link import YouTubeLinkProvider
from .providers.service_links import SoundCloudLinks, SpotifyLinks
from .providers.itunes import ITunesCatalog

log = logging.getLogger("sword.registry")
T = TypeVar("T")

PROVIDER_CLASSES: dict[str, type[Provider]] = {
    "itunes": ITunesCatalog,
    "musicbrainz": MusicBrainzProvider,
    "youtube_link": YouTubeLinkProvider,
    "soundcloud": SoundCloudLinks,
    "spotify_link": SpotifyLinks,
    "audius": AudiusProvider,
    "jamendo": JamendoProvider,
    "archive": ArchiveProvider,
    "wikimedia": WikimediaProvider,
    "youtube": YouTubeProvider,
    "deezer": DeezerProvider,
    "fixture": FixtureProvider,
}
# Order used when the same recording exists in several sources.
PRIORITY = ["upload", "audius", "jamendo", "archive", "wikimedia", "youtube", "fixture", "deezer"]
NAMES = {
    "itunes": "iTunes · каталог",
    "musicbrainz": "MusicBrainz · каталог",
    "youtube_link": "YouTube · по ссылке",
    "soundcloud": "SoundCloud",
    "spotify_link": "Spotify · встроенный плеер",
    "audius": "Audius",
    "jamendo": "Jamendo",
    "archive": "Internet Archive",
    "wikimedia": "Wikimedia Commons",
    "youtube": "YouTube",
    "deezer": "Deezer",
    "upload": "Мои файлы",
    "fixture": "Тестовый каталог",
}
BREAKER_THRESHOLD = 3


class TTLCache:
    def __init__(self, maxsize: int = 800) -> None:
        self.maxsize = maxsize
        self._data: OrderedDict[str, tuple[float, Any]] = OrderedDict()

    def get(self, key: str) -> Any:
        item = self._data.get(key)
        if item is None:
            return None
        expires, value = item
        if expires < time.monotonic():
            self._data.pop(key, None)
            return None
        self._data.move_to_end(key)
        return value

    def set(self, key: str, value: Any, ttl: float) -> None:
        self._data[key] = (time.monotonic() + ttl, value)
        self._data.move_to_end(key)
        while len(self._data) > self.maxsize:
            self._data.popitem(last=False)

    def clear(self) -> None:
        self._data.clear()


@dataclass
class Health:
    failures: int = 0
    open_until: float = 0.0
    last_error: str | None = None
    last_error_kind: str | None = None
    last_error_at: float | None = None
    last_ok_at: float | None = None
    calls: int = 0
    errors: int = 0
    total_ms: float = 0.0


class Registry:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self.client = client
        enabled = get_settings().enabled_provider_ids
        self.providers: dict[str, Provider] = {
            pid: cls(client) for pid, cls in PROVIDER_CLASSES.items() if pid in enabled
        }
        self.admin_disabled: set[str] = set()
        self.health: dict[str, Health] = {pid: Health() for pid in self.providers}
        self.cache = TTLCache()
        self.uploads_enabled = "uploads" in enabled

    # ------------------------------------------------------------------ state
    def get(self, pid: str) -> Provider | None:
        return self.providers.get(pid)

    def usable(self, pid: str) -> bool:
        p = self.providers.get(pid)
        if p is None or pid in self.admin_disabled or not p.configured():
            return False
        return self.health[pid].open_until <= time.monotonic()

    def active(self) -> list[Provider]:
        return [p for pid, p in self.providers.items() if self.usable(pid)]

    def set_admin_disabled(self, pid: str, disabled: bool) -> None:
        if disabled:
            self.admin_disabled.add(pid)
        else:
            self.admin_disabled.discard(pid)
            h = self.health.get(pid)
            if h:
                h.failures = 0
                h.open_until = 0.0

    def state_of(self, pid: str) -> str:
        p = self.providers.get(pid)
        if p is None:
            return "off"
        if pid in self.admin_disabled:
            return "disabled"
        if not p.configured():
            return "not_configured"
        h = self.health[pid]
        if h.open_until > time.monotonic():
            return "rate_limited" if h.last_error_kind == "rate_limited" else "degraded"
        return "ok"

    def status(self) -> list[dict[str, Any]]:
        out = []
        now = time.monotonic()
        wall = time.time()
        for pid in [*PROVIDER_CLASSES.keys()]:
            p = self.providers.get(pid)
            if pid == "fixture" and p is None:
                continue
            h = self.health.get(pid, Health())
            out.append(
                {
                    "id": pid,
                    "name": NAMES.get(pid, pid),
                    "state": self.state_of(pid) if p else "off",
                    "enabled_in_env": p is not None,
                    "requires_key": PROVIDER_CLASSES[pid].requires_key,
                    "configured": bool(p and p.configured()),
                    "config_hint": p.config_hint() if p else "",
                    "stream": PROVIDER_CLASSES[pid].stream_kind,
                    "terms": PROVIDER_CLASSES[pid].terms_note,
                    "homepage": PROVIDER_CLASSES[pid].homepage,
                    "calls": h.calls,
                    "errors": h.errors,
                    "avg_ms": round(h.total_ms / h.calls) if h.calls else None,
                    "last_error": h.last_error,
                    "last_error_ago_s": round(now - h.last_error_at) if h.last_error_at else None,
                    "retry_in_s": max(0, round(h.open_until - now)) if h.open_until > now else 0,
                    "checked_at": wall,
                }
            )
        out.append(
            {
                "id": "uploads",
                "name": NAMES["upload"],
                "state": "ok" if self.uploads_enabled else "off",
                "enabled_in_env": self.uploads_enabled,
                "requires_key": False,
                "configured": True,
                "config_hint": "",
                "stream": "full",
                "terms": "Ваши собственные файлы. Доступны только вам и не передаются другим пользователям.",
                "homepage": "",
                "calls": 0,
                "errors": 0,
                "avg_ms": None,
                "last_error": None,
                "last_error_ago_s": None,
                "retry_in_s": 0,
                "checked_at": wall,
            }
        )
        return out

    # ------------------------------------------------------------------ calls
    async def run(
        self,
        provider: Provider,
        op: str,
        factory: Callable[[], Awaitable[T]],
        *,
        cache_key: str | None = None,
        ttl: float = 900.0,
        timeout: float | None = None,
    ) -> T:
        pid = provider.id
        key = f"{pid}:{op}:{cache_key}" if cache_key is not None else None
        if key is not None:
            cached = self.cache.get(key)
            if cached is not None:
                return cached  # type: ignore[no-any-return]
        if not self.usable(pid):
            raise ProviderError("unavailable", f"{NAMES.get(pid, pid)}: источник временно отключён")
        h = self.health[pid]
        started = time.monotonic()
        h.calls += 1
        try:
            result = await asyncio.wait_for(factory(), timeout or get_settings().provider_timeout + 4)
        except asyncio.TimeoutError:
            err = ProviderError("timeout", f"{NAMES.get(pid, pid)}: превышено время ожидания")
            self._fail(pid, err)
            raise err from None
        except ProviderError as err:
            if err.kind not in ("not_found", "config", "unavailable"):
                self._fail(pid, err)
            raise
        except Exception as exc:  # noqa: BLE001 — a broken adapter must not break search
            log.exception("Provider %s crashed in %s", pid, op)
            err = ProviderError("bad_response", f"{NAMES.get(pid, pid)}: внутренняя ошибка адаптера")
            self._fail(pid, err)
            raise err from exc
        h.total_ms += (time.monotonic() - started) * 1000
        h.failures = 0
        h.last_ok_at = time.monotonic()
        if key is not None:
            self.cache.set(key, result, ttl)
        return result

    def _fail(self, pid: str, err: ProviderError) -> None:
        h = self.health[pid]
        h.errors += 1
        h.failures += 1
        h.last_error = err.message
        h.last_error_kind = err.kind
        h.last_error_at = time.monotonic()
        if err.kind == "rate_limited":
            h.open_until = time.monotonic() + min(600.0, err.retry_after or 60.0)
        elif h.failures >= BREAKER_THRESHOLD:
            h.open_until = time.monotonic() + min(600.0, 30.0 * 2 ** (h.failures - BREAKER_THRESHOLD))
        log.warning("Provider %s error (%s): %s", pid, err.kind, err.message)


_registry: Registry | None = None


def set_registry(reg: Registry | None) -> None:
    global _registry
    _registry = reg


def get_registry() -> Registry:
    if _registry is None:
        raise RuntimeError("Provider registry is not initialised")
    return _registry


def make_http_client() -> httpx.AsyncClient:
    s = get_settings()
    return httpx.AsyncClient(
        timeout=httpx.Timeout(s.provider_timeout, connect=5.0),
        headers={"User-Agent": s.user_agent, "Accept": "application/json"},
        follow_redirects=True,
        limits=httpx.Limits(max_connections=40, max_keepalive_connections=20),
    )
