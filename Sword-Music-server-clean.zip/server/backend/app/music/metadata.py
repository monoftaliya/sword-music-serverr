"""Independent metadata adapters. No lyrics-page scraping or client-side secrets."""
from __future__ import annotations

import asyncio
import re
from difflib import SequenceMatcher
from urllib.parse import urlencode, urlparse

import httpx

from ..config import get_settings
from .normalize import clean_words

LRC_TIME = re.compile(r"\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]")


def parse_lrc(raw: str) -> list[dict]:
    lines = []
    for row in raw.splitlines()[:5000]:
        stamps = list(LRC_TIME.finditer(row))
        text = LRC_TIME.sub("", row).strip()[:1500]
        if not text:
            continue
        for stamp in stamps[:20]:
            minutes, seconds, fraction = stamp.groups()
            if int(seconds) >= 60:
                continue
            moment = int(minutes) * 60 + int(seconds) + float("0." + (fraction or "0"))
            lines.append({"time": round(moment, 3), "text": text})
    return sorted(lines, key=lambda line: line["time"])[:4000]


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, clean_words(a), clean_words(b)).ratio()


class GeniusMetadata:
    def __init__(self, client: httpx.AsyncClient):
        self.client = client

    async def find(self, title: str, artist: str) -> dict:
        token = get_settings().genius_access_token.strip()
        fallback = "https://genius.com/search?" + urlencode({"q": f"{artist} {title}"})
        empty = {"configured": bool(token), "matched": False, "url": fallback, "source": "Genius"}
        if not token:
            return empty
        try:
            response = await self.client.get("https://api.genius.com/search",
                params={"q": f"{artist} {title}"[:300]}, headers={"Authorization": f"Bearer {token}"})
            response.raise_for_status()
            hits = response.json().get("response", {}).get("hits", [])
            candidates = [hit.get("result", {}) for hit in hits if isinstance(hit, dict)]
            # A title match alone is insufficient: cover recordings must not inherit another artist's metadata.
            matches = [r for r in candidates if similarity(title, r.get("title", "")) >= 0.72
                       and similarity(artist, (r.get("primary_artist") or {}).get("name", "")) >= 0.55]
            if not matches:
                return empty
            song = max(matches, key=lambda r: similarity(title, r.get("title", "")))
            if isinstance(song.get("id"), int):
                detail = await self.client.get(f"https://api.genius.com/songs/{song['id']}",
                    headers={"Authorization": f"Bearer {token}"}, params={"text_format": "plain"})
                if detail.is_success:
                    song = detail.json().get("response", {}).get("song") or song
            url = song.get("url", "")
            if urlparse(url).hostname not in ("genius.com", "www.genius.com"):
                return empty
            return {**empty, "matched": True, "url": url, "title": song.get("title"),
                    "artist": (song.get("primary_artist") or {}).get("name"),
                    "album": (song.get("album") or {}).get("name"),
                    "release_date": song.get("release_date_for_display"),
                    "artwork": song.get("song_art_image_url")}
        except (httpx.HTTPError, ValueError, TypeError, AttributeError):
            return {**empty, "unavailable": True}


class LrclibLyrics:
    def __init__(self, client: httpx.AsyncClient):
        self.client = client

    async def find(self, title: str, artist: str, album: str | None, duration: float | None) -> dict:
        empty = {"source": "LRCLIB", "lines": [], "plain": None, "synced": False, "instrumental": False}
        if not get_settings().lyrics_enabled:
            return empty
        params: dict = {"track_name": title, "artist_name": artist}
        if album:
            params["album_name"] = album
        if duration:
            params["duration"] = round(duration)
        try:
            response = await self.client.get("https://lrclib.net/api/get", params=params)
            if response.status_code == 404:
                return empty
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict) or similarity(title, data.get("trackName", "")) < 0.75 \
                    or similarity(artist, data.get("artistName", "")) < 0.6:
                return empty
            if duration and isinstance(data.get("duration"), (float, int)) \
                    and abs(data["duration"] - duration) > 5:
                return empty
            lines = parse_lrc(str(data.get("syncedLyrics") or "")[:200000])
            return {**empty, "lines": lines, "plain": str(data.get("plainLyrics") or "")[:100000] or None,
                    "synced": bool(lines), "instrumental": data.get("instrumental") is True,
                    "url": "https://lrclib.net"}
        except (httpx.HTTPError, ValueError, TypeError, AttributeError):
            return {**empty, "unavailable": True}


async def song_metadata(client: httpx.AsyncClient, title: str, artist: str,
                        album: str | None, duration: float | None) -> dict:
    genius, lyrics = await asyncio.gather(GeniusMetadata(client).find(title, artist),
        LrclibLyrics(client).find(title, artist, album, duration))
    return {"genius": genius, "lyrics": lyrics}
