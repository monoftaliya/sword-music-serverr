from __future__ import annotations

import httpx
import pytest
import respx

from app.music.normalize import matches_version, norm_key
from app.music.providers.base import ProviderError
from app.music.providers.itunes import ITunesCatalog
from app.music.providers.service_links import SoundCloudLinks, SpotifyLinks, soundcloud_url, spotify_id


def test_spotify_sdk_compatibility_policy_is_scoped_to_the_player_page(client):
    normal = client.get("/login/").headers["content-security-policy"]
    bridge = client.get("/players/spotify.html").headers["content-security-policy"]
    assert "unsafe-eval" not in normal and "embed-cdn.spotifycdn.com" not in normal
    assert "'unsafe-eval'" in bridge and "connect-src 'none'" in bridge
    assert "frame-ancestors 'self'" in bridge
    assert client.get("/players/spotify.html").headers["x-frame-options"] == "SAMEORIGIN"


@pytest.mark.parametrize("value", ["https://soundcloud.com.evil.test/a/b", "https://soundcloud.com@127.0.0.1/a/b", "https://user@soundcloud.com/a/b", "file:///a/b", "https://soundcloud.com:8000/a/b", "https://soundcloud.com/artist/sets/album", "https://soundcloud.com/search/sounds", "https://soundcloud.com/a/%2e%2e"])
def test_soundcloud_accepts_only_public_track_urls(value):
    assert soundcloud_url(value) is None


def test_canonical_links_and_locale():
    assert soundcloud_url("https://m.soundcloud.com/Forss/flickermood?si=tracking") == "https://soundcloud.com/Forss/flickermood"
    assert spotify_id("https://open.spotify.com/intl-ru/track/4cOdK2wGLETKBW3PvgPWqT?si=tracking") == "4cOdK2wGLETKBW3PvgPWqT"
    assert spotify_id("spotify:track:4cOdK2wGLETKBW3PvgPWqT") == "4cOdK2wGLETKBW3PvgPWqT"
    assert spotify_id("https://open.spotify.com/playlist/4cOdK2wGLETKBW3PvgPWqT") is None
    assert spotify_id("https://open.spotify.com:999/track/4cOdK2wGLETKBW3PvgPWqT") is None


@pytest.mark.asyncio
async def test_official_soundcloud_metadata_and_embed_only():
    async with httpx.AsyncClient() as client:
        provider = SoundCloudLinks(client)
        with respx.mock() as mock:
            route = mock.get("https://soundcloud.com/oembed").mock(return_value=httpx.Response(200, json={"title": "Song (Slowed) by Artist", "author_name": "Artist", "thumbnail_url": "https://i1.sndcdn.com/art.jpg", "html": "<script>untrusted</script>"}))
            track = (await provider.search("https://soundcloud.com/artist/song-slowed?x=tracking"))[0]
            assert track.title == "Song (Slowed)" and track.artist == "Artist"
            assert track.stream_kind == "embed" and track.duration is None
            assert route.calls[0].request.url.params["url"] == track.page_url
            assert "html" not in track.extra
            stream = await provider.resolve(track.provider_track_id, track.extra)
            assert stream.kind == "embed" and stream.url == "https://soundcloud.com/artist/song-slowed"
            with pytest.raises(ProviderError):
                await provider.resolve(track.provider_track_id, {"canonical_url": "http://127.0.0.1/secrets"})


@pytest.mark.asyncio
async def test_spotify_does_not_invent_artist_duration_or_full_stream():
    async with httpx.AsyncClient() as client:
        provider = SpotifyLinks(client)
        with respx.mock() as mock:
            mock.get("https://open.spotify.com/oembed").mock(return_value=httpx.Response(200, json={"title": "A recording", "thumbnail_url": "https://i.scdn.co/image/a"}))
            track = (await provider.search("https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT"))[0]
            assert track.artist == "" and track.duration is None
            assert track.extra["limited_embed"] and track.stream_kind == "embed"
            stream = await provider.resolve(track.provider_track_id, track.extra)
            assert stream.kind == "embed" and stream.url == "spotify:track:4cOdK2wGLETKBW3PvgPWqT"


@pytest.mark.asyncio
async def test_itunes_search_uses_real_metadata_without_playable_promo_audio():
    async with httpx.AsyncClient() as client:
        provider = ITunesCatalog(client)
        with respx.mock() as mock:
            route = mock.get("https://itunes.apple.com/search").mock(return_value=httpx.Response(200, json={"results": [{"kind": "song", "trackId": 123, "trackName": "Название", "artistName": "Исполнитель", "trackTimeMillis": 123000, "previewUrl": "https://audio.example/promo.m4a"}, {"kind": "music-video", "trackId": 456}]}))
            tracks = await provider.search("русский рэп", 20)
            assert len(tracks) == 1 and tracks[0].title == "Название"
            assert tracks[0].duration == 123 and tracks[0].stream_kind == "none"
            assert not tracks[0].extra
            assert route.calls[0].request.url.params["term"] == "русский рэп"


@pytest.mark.parametrize("title,version", [("Песня (замедленная)", "slowed"), ("Song speed up", "sped"), ("Song (Sped Up)", "sped"), ("Песня ускоренная", "sped"), ("Song Slowed + Reverb", "reverb"), ("Song Nightcore", "nightcore"), ("Song (Official Audio)", "original")])
def test_version_filters_match_russian_and_english(title, version):
    assert matches_version(title, version)
    if version != "original":
        assert not matches_version(title, "original")
        assert norm_key(title, "Artist") != norm_key("Song", "Artist")


def test_filter_and_embed_import_through_api(make_user):
    from app.music.registry import Health, get_registry
    registry = get_registry()
    registry.providers["soundcloud"] = SoundCloudLinks(registry.client)
    registry.health["soundcloud"] = Health()
    user = make_user("FreeSources")
    try:
        originals = user.get("/api/search", params={"q": "Night Engine", "mode": "text", "version": "original"}).json()["results"]
        assert originals and all(matches_version(track["title"], "original") for track in originals)
        with respx.mock(assert_all_called=False) as mock:
            mock.route(host="testserver").pass_through()
            route = mock.get("https://soundcloud.com/oembed").mock(return_value=httpx.Response(200, json={"title": "An imported song by Artist", "author_name": "Artist"}))
            result = user.get("/api/search", params={"q": "https://soundcloud.com/artist/song-name", "version": "original", "mode": "mood"}).json()
            assert [s["id"] for s in result["sources"]] == ["soundcloud"]
            assert len(result["results"]) == 1 and result["results"][0]["playable"]
            track = result["results"][0]
            play = user.get(f"/api/tracks/{track['id']}/play").json()
            assert play["kind"] == "embed" and play["attribution"]["provider"] == "soundcloud"
            assert play["url"] == "https://soundcloud.com/artist/song-name"
            user.get("/api/search", params={"q": "https://soundcloud.com/artist/song_name"})
            assert route.call_count == 2, "distinct URLs must not collide in the search cache"
    finally:
        registry.providers.pop("soundcloud", None)
        registry.health.pop("soundcloud", None)
        registry.cache.clear()
