from __future__ import annotations

from app.music.normalize import norm_key, version_markers
from app.music.taxonomy import canonicalize, lookup_all
from app.search.interpreter import interpret
from conftest import search_ids


def test_taxonomy_mapping():
    assert lookup_all("dark phonk")[0] == "phonk"
    assert lookup_all("Hip-Hop/Rap") == ["hiphop"]
    canon = canonicalize(genres=["Lo-Fi"], moods=["Melancholy"], tags=["rain", "study beats"])
    assert {"lofi", "melancholic", "rain"} <= set(canon)


def test_version_aware_dedupe_keys():
    assert norm_key("Night Engine (Official Audio)", "Ashen Wheel feat. X") == norm_key("Night Engine", "Ashen Wheel")
    assert norm_key("Night Engine (Live)", "Ashen Wheel") != norm_key("Night Engine", "Ashen Wheel")
    assert norm_key("Night Engine - Slowed + Reverb", "Ashen Wheel") != norm_key("Night Engine", "Ashen Wheel")
    assert "remix" in version_markers("Song (VIP Remix)")


def test_interpreter_examples_from_brief():
    cases = {
        "Музыка, будто я главный злодей аниме": {"villain", "anime", "dark"},
        "Ночной Токио, дождь, одиночество": {"night", "japan", "rain", "lonely"},
        "Мрачный фонк с тяжёлым басом": {"phonk", "dark", "bass_heavy"},
        "Музыка для размышлений в три часа ночи": {"night", "calm", "atmospheric"},
        "Музыка с ощущением космоса и бесконечности": {"space", "atmospheric", "ambient"},
    }
    for q, expected in cases.items():
        spec = interpret(q)
        assert spec.descriptive, q
        assert expected <= set(spec.tags), (q, spec.tags)
    similar = interpret("Что-нибудь похожее на этот трек, но атмосфернее")
    assert similar.similar and similar.comparative and "atmospheric" in similar.tags


def test_interpreter_negation_tempo_vocal():
    spec = interpret("спокойное, не грустное, без слов, 85 bpm")
    assert "calm" in spec.tags and "sad" in spec.avoid and spec.vocal == "instrumental"
    assert spec.bpm_min == 79 and spec.bpm_max == 91
    plain = interpret("Linkin Park Numb")
    assert not plain.descriptive and plain.keywords == ["linkin", "park", "numb"]


def test_text_search_dedupes_but_keeps_versions(make_user):
    u = make_user("Searcher")
    r = u.get("/api/search", params={"q": "Night Engine", "mode": "text"})
    assert r.status_code == 200
    data = r.json()
    titles = [x["title"] for x in data["results"]]
    assert titles[0] == "Night Engine"
    assert titles.count("Night Engine") == 1, "exact duplicates must be merged"
    assert "Night Engine (Live)" in titles, "a live version is a different recording"
    assert data["results"][0]["alternatives"], "the merged duplicate is offered as an alternative"
    assert any(s["id"] == "fixture" and s["status"] == "ok" for s in data["sources"])


def test_mood_search_ranks_by_meaning(make_user):
    u = make_user("Mood")
    r = u.get("/api/search", params={"q": "мрачный фонк с тяжёлым басом"}).json()
    assert r["interpretation"]["descriptive"] is True
    chips = [c["label"] for c in r["interpretation"]["chips"]]
    assert "фонк" in chips and "мрачное" in chips
    top = r["results"][:5]
    assert all(t["artist"] in {"Kurogane", "Ashen Wheel", "Nox Rider", "Crown District", "Velvet Threat"} for t in top), [t["artist"] for t in top]
    assert all(t.get("reason") for t in top)
    calm = u.get("/api/search", params={"q": "спокойное пианино для сна"}).json()
    assert calm["results"][0]["artist"] in {"Quiet Keys", "Lumen Hall", "Paper Lanterns", "Slow Tram"}


def test_empty_results_and_failing_source(make_user):
    u = make_user("Empty")
    r = u.get("/api/search", params={"q": "zzzqqqxxx", "mode": "text"})
    assert r.status_code == 200 and r.json()["results"] == []
    r = u.get("/api/search", params={"q": "__fail__", "mode": "text"})
    assert r.status_code == 200
    src = {s["id"]: s for s in r.json()["sources"]}
    assert src["fixture"]["status"] == "error" and "сбоя" in src["fixture"]["message"]


def test_history_and_suggestions(make_user):
    u = make_user("History")
    search_ids(u, "Obsidian", record="true")
    hist = u.get("/api/search/history").json()["items"]
    assert hist and hist[0]["query"] == "Obsidian"
    sug = u.get("/api/search/suggest", params={"q": "obsid"}).json()
    assert sug["history"] == ["Obsidian"]
    assert any("Obsidian" in t["title"] for t in sug["tracks"])
    assert u.delete("/api/search/history").status_code == 200
    assert u.get("/api/search/history").json()["items"] == []


def test_play_resolution_and_preview_label(make_user):
    u = make_user("Player")
    res = u.get("/api/search", params={"q": "Preview Only", "mode": "text"}).json()["results"]
    prev = next(x for x in res if x["title"] == "Preview Only Track")
    assert prev["stream"] == "preview"
    full = u.get("/api/search", params={"q": "Night Engine", "mode": "text"}).json()["results"][0]
    play = u.get(f"/api/tracks/{full['id']}/play").json()
    assert play["kind"] == "full" and play["url"].startswith("/api/_test/audio/")
    audio = u.c.get(play["url"], headers={"Range": "bytes=0-99"})
    assert audio.status_code == 206 and len(audio.content) == 100
    pal = u.get(f"/api/tracks/{full['id']}/palette").json()["palette"]
    assert pal and pal["accent"].startswith("#")
