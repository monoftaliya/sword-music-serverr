"""Test setup: isolated data dir, SQLite by default or PostgreSQL via TEST_DATABASE_URL.

Only the synthetic fixture provider is enabled (no network access is needed).
"""
from __future__ import annotations

import asyncio
import os
import tempfile
import uuid
from typing import Any

TMP = tempfile.mkdtemp(prefix="sword-test-")
os.environ["SWORD_ENV"] = "test"
os.environ["DATA_DIR"] = TMP
os.environ["DATABASE_URL"] = os.environ.get("TEST_DATABASE_URL") or f"sqlite+aiosqlite:///{TMP}/test.db"
os.environ["FRONTEND_DIST"] = f"{TMP}/no-frontend"
os.environ["PROVIDERS_ENABLED"] = "uploads"
os.environ["SECRET_KEY"] = "test-secret-key"
os.environ["LOG_LEVEL"] = "WARNING"

import pytest  # noqa: E402
from starlette.testclient import TestClient  # noqa: E402

PASSWORD = "Correct-Horse-42"


async def _reset_postgres(url: str) -> None:
    import asyncpg

    dsn = url.replace("postgresql+asyncpg://", "postgresql://")
    conn = await asyncpg.connect(dsn)
    try:
        await conn.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    finally:
        await conn.close()


@pytest.fixture(scope="session")
def client():
    url = os.environ["DATABASE_URL"]
    if url.startswith("postgresql"):
        asyncio.run(_reset_postgres(url))
    from app.main import create_app

    app = create_app()
    with TestClient(app) as c:
        yield c


@pytest.fixture(autouse=True)
def _reset_limits():
    from app.core.ratelimit import limiter

    limiter.clear()
    yield


class Api:
    """A logged-in user talking to the API with a bearer token."""

    def __init__(self, client: TestClient, token: str, user: dict[str, Any]) -> None:
        self.c = client
        self.token = token
        self.user = user

    def _h(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        h = {"Authorization": f"Bearer {self.token}"}
        h.update(extra or {})
        return h

    def get(self, url: str, **kw: Any):
        return self.c.get(url, headers=self._h(kw.pop("headers", None)), **kw)

    def post(self, url: str, **kw: Any):
        return self.c.post(url, headers=self._h(kw.pop("headers", None)), **kw)

    def put(self, url: str, **kw: Any):
        return self.c.put(url, headers=self._h(kw.pop("headers", None)), **kw)

    def patch(self, url: str, **kw: Any):
        return self.c.patch(url, headers=self._h(kw.pop("headers", None)), **kw)

    def delete(self, url: str, **kw: Any):
        return self.c.delete(url, headers=self._h(kw.pop("headers", None)), **kw)


CSRF = {"X-Sword-Client": "1"}


def login(client: TestClient, email: str, password: str = PASSWORD) -> Api:
    r = client.post("/api/auth/login?token=1", json={"email": email, "password": password}, headers=CSRF)
    assert r.status_code == 200, r.text
    data = r.json()
    client.cookies.clear()
    return Api(client, data["token"], data["user"])


@pytest.fixture(scope="session")
def admin(client: TestClient) -> Api:
    from app.config import get_settings

    r = client.post(
        "/api/auth/register",
        json={"email": "admin@example.com", "password": PASSWORD, "display_name": "Admin", "setup_code": get_settings().setup_code},
        headers=CSRF,
    )
    assert r.status_code == 200, r.text
    assert r.json()["user"]["is_admin"] is True
    return login(client, "admin@example.com")


@pytest.fixture
def make_user(client: TestClient, admin: Api):
    def _make(name: str = "Friend") -> Api:
        inv = admin.post("/api/admin/invites", json={"max_uses": 1, "note": name}).json()
        email = f"{name.lower()}-{uuid.uuid4().hex[:8]}@example.com"
        r = client.post(
            "/api/auth/register",
            json={"email": email, "password": PASSWORD, "display_name": name, "invite_code": inv["code"]},
            headers=CSRF,
        )
        assert r.status_code == 200, r.text
        client.cookies.clear()
        return login(client, email)

    return _make


def search_ids(api: Api, q: str, **params: Any) -> list[str]:
    r = api.get("/api/search", params={"q": q, **params})
    assert r.status_code == 200, r.text
    return [x["id"] for x in r.json()["results"]]
