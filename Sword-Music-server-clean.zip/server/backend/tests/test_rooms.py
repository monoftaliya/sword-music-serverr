from __future__ import annotations

import time

from conftest import search_ids


def _recv_until(ws, kind, predicate=lambda m: True, limit=12):
    for _ in range(limit):
        msg = ws.receive_json()
        if msg.get("t") == kind and predicate(msg):
            return msg
    raise AssertionError(f"no {kind} message")


def test_room_lifecycle_and_sync(client, make_user):
    owner = make_user("RoomOwner")
    guest = make_user("Guest")
    ids = search_ids(owner, "Orbit", mode="text")[:3]
    room = owner.post("/api/rooms", json={"name": "Пятница", "allow_member_queue": False, "allow_suggestions": True}).json()
    code = room["code"]
    assert guest.get(f"/api/rooms/{code}").json()["joined"] is False
    guest.post(f"/api/rooms/{code}/join")
    rooms = guest.get("/api/rooms").json()["rooms"]
    assert rooms[0]["code"] == code and rooms[0]["role"] == "member"

    with client.websocket_connect(f"/api/rooms/{code}/ws?token={owner.token}") as ows, client.websocket_connect(
        f"/api/rooms/{code}/ws?token={guest.token}"
    ) as gws:
        _recv_until(ows, "state")
        _recv_until(gws, "state")
        # clock sync
        gws.send_json({"t": "ping", "c": 123})
        pong = _recv_until(gws, "pong")
        assert pong["c"] == 123 and abs(pong["s"] - time.time() * 1000) < 5000
        # owner queues -> starts playing for everyone
        ows.send_json({"t": "queue_add", "track_id": ids[0]})
        st = _recv_until(gws, "state", lambda m: m["now"]["track"] is not None)
        assert st["now"]["playing"] and st["now"]["track"]["id"] == ids[0]
        assert {m["name"] for m in st["members"] if m["online"]} == {"RoomOwner", "Guest"}
        # members cannot control playback
        gws.send_json({"t": "pause", "pos": 1000})
        err = _recv_until(gws, "error")
        assert "владелец" in err["message"]
        # members' adds become suggestions when direct queueing is off
        gws.send_json({"t": "queue_add", "track_id": ids[1]})
        st = _recv_until(ows, "state", lambda m: len(m["suggestions"]) == 1)
        sug = st["suggestions"][0]
        assert sug["added_by"] == "Guest"
        ows.send_json({"t": "accept", "item_id": sug["item_id"]})
        st = _recv_until(gws, "state", lambda m: len(m["queue"]) >= 2 and not m["suggestions"])
        # owner pause/seek propagates position
        ows.send_json({"t": "seek", "pos": 15000})
        st = _recv_until(gws, "state", lambda m: m["now"]["position_ms"] >= 15000)
        ows.send_json({"t": "pause", "pos": 16000})
        st = _recv_until(gws, "state", lambda m: not m["now"]["playing"])
        assert 16000 <= st["now"]["position_ms"] < 17000
        # next -> second item
        ows.send_json({"t": "next"})
        st = _recv_until(gws, "state", lambda m: m["now"]["track"] and m["now"]["track"]["id"] == ids[1])
        assert st["now"]["position_ms"] < 2000
    # private uploads / unknown tracks are refused
    with client.websocket_connect(f"/api/rooms/{code}/ws?token={owner.token}") as ows:
        _recv_until(ows, "state")
        ows.send_json({"t": "queue_add", "track_id": "upload:nope"})
        assert "нельзя" in _recv_until(ows, "error")["message"]
    assert guest.delete(f"/api/rooms/{code}").status_code == 403
    assert owner.delete(f"/api/rooms/{code}").status_code == 200
    assert guest.get(f"/api/rooms/{code}").status_code == 404


def test_websocket_requires_membership(client, make_user):
    owner = make_user("Locked")
    stranger = make_user("Stranger")
    code = owner.post("/api/rooms", json={"name": "Private"}).json()["code"]
    import pytest
    from starlette.websockets import WebSocketDisconnect

    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect(f"/api/rooms/{code}/ws?token={stranger.token}") as ws:
            ws.receive_json()
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect(f"/api/rooms/{code}/ws") as ws:
            ws.receive_json()
