from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import socket
from threading import Thread

from check_server import main, server_state


@contextmanager
def endpoint(payload, code=200):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            assert self.path == "/api/health"
            body = json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_port
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_already_running_sword_is_reused_without_another_server(capsys):
    with endpoint({"ok": True, "providers": {"uploads": "ok", "audius": "ok", "youtube": "off"}}) as port:
        assert server_state(port) == "ready"
        assert main(["--port", str(port)]) == 0
        assert "уже работает" in capsys.readouterr().out


def test_other_service_is_never_mistaken_for_sword_or_stopped(capsys):
    with endpoint({"ok": True, "name": "another service"}) as port:
        assert server_state(port) == "busy"
        assert main(["--port", str(port)]) == 2
        assert "занят" in capsys.readouterr().out
        assert server_state(port) == "busy"


def test_broken_health_response_is_a_busy_port():
    with endpoint(["not a health object"]) as port:
        assert server_state(port) == "busy"


def test_unused_port_can_start_a_new_server():
    with socket.socket() as connection:
        connection.bind(("127.0.0.1", 0))
        port = connection.getsockname()[1]
    assert server_state(port) == "free"
    assert main(["--port", str(port)]) == 1
