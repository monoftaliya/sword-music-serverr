"""YouTube source: parsing, quota protection, search gating and embed playback."""
from __future__ import annotations

import httpx
import pytest
import respx

from app.music.providers.base import ProviderError
from app.music.providers.youtube import API, YouTubeProvider, parse_duration, split_title


def video(vid: str, title: str, channel: str, duration: str = "PT3M30S", **kw) -> dict:
    return {
        "id": vid,
        "snippet": {
            "title": title,
            "channelTitle": channel,
            "channelId": "UC" + vid,
            "publishedAt": "2021-05-01T00:00:00Z",
            "liveBroadcastContent": kw.get("live", "none"),
            "tags": ["phonk", "drift phonk", "dark"],
            "thumbnails": {"medium": {"url": f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"}, "maxres": {"url": f"https://i.ytimg.com/vi/{vid}/maxresdefault.jpg"}},
        },
        "contentDetails": {"duration": duration},
        "status": {"embeddable": kw.get("embeddable", True), "privacyStatus": "public"},
        "statistics": {"viewCount": "1200000"},
    }


SEARCH = {"items": [{"id": {"videoId": v}} for v in ("aaaaaaaaaa1", "bbbbbbbbbb2", "ccccccccccc", "ddddddddddd", "eeeeeeeeeee")]}
VIDEOS = {
    "items": [
        video("aaaaaaaaaa1", "Kordhell - Murder In My Mind (Official Video)", "Kordhell"),
        video("bbbbbbbbbb2", "Murder In My Mind", "Kordhell - Topic"),
        video("ccccccccccc", "Phonk mix 2 hours", "Mixes", duration="PT2H"),
        video("ddddddddddd", "Live now", "Radio", live="live"),
        video("eeeeeeeeeee", "Blocked &amp; hidden", "Label", embeddable=False),
    ]
}


@pytest.fixture
def yt_key(monkeypatch):
    from app.config import get_settings

    monkeypatch.setenv("YOUTUBE_API_KEY", "test-key")
    monkeypatch.setenv("YOUTUBE_DAILY_SEARCHES", "3")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def test_title_and_duration_parsing():
    assert parse_duration("PT3M30S") == 210 and parse_duration("PT1H2M") == 3720 and parse_duration("P0D") is None
    assert split_title("Kordhell - Murder In My Mind (Official Video)", "Kordhell") == ("Kordhell", "Murder In My Mind")
    assert split_title("Murder In My Mind", "Kordhell - Topic") == ("Kordhell", "Murder In My Mind")
    assert split_title("Кино — Группа крови [Официальный клип]", "Кино") == ("Кино", "Группа крови")
    assert split_title("Numb", "LinkinParkVEVO") == ("LinkinPark", "Numb")
    assert split_title("Artist - Song (Official Video) (4K Remaster)", "Artist") == ("Artist", "Song (4K Remaster)")


@pytest.mark.asyncio
async def test_search_filters_and_budget(yt_key):
    async with httpx.AsyncClient() as client:
        p = YouTubeProvider(client)
        with respx.mock(assert_all_called=False) as mock:
            s = mock.get(f"{API}/search").mock(return_value=httpx.Response(200, json=SEARCH))
            mock.get(f"{API}/videos").mock(return_value=httpx.Response(200, json=VIDEOS))
            res = await p.search("murder in my mind")
            assert [t.provider_track_id for t in res] == ["aaaaaaaaaa1", "bbbbbbbbbb2"], "mixes, live streams and non-embeddable videos are dropped"
            t = res[0]
            assert (t.artist, t.title, t.stream_kind, t.duration) == ("Kordhell", "Murder In My Mind", "embed", 210.0)
            assert t.page_url == "https://www.youtube.com/watch?v=aaaaaaaaaa1" and "phonk" in t.tags
            assert "key=test-key" in str(s.calls[0].request.url)
            assert "videoEmbeddable=true" in str(s.calls[0].request.url)
            assert "videoCategoryId" not in s.calls[0].request.url.params, "artist uploads outside the music category remain searchable"
            await p.search("two")
            await p.search("three")
            with pytest.raises(ProviderError) as e:
                await p.search("four")
            assert e.value.kind == "rate_limited" and s.call_count == 3, "the daily budget is never exceeded"
        info = await p.resolve("aaaaaaaaaa1", {})
        assert (info.url, info.kind) == ("aaaaaaaaaa1", "embed")


@pytest.mark.asyncio
async def test_quota_and_key_errors(yt_key):
    async with httpx.AsyncClient() as client:
        p = YouTubeProvider(client)
        with respx.mock() as mock:
            mock.get(f"{API}/search").mock(
                return_value=httpx.Response(403, json={"error": {"errors": [{"reason": "quotaExceeded"}]}})
            )
            with pytest.raises(ProviderError) as e:
                await p.search("anything")
            assert e.value.kind == "rate_limited" and e.value.retry_after >= 60
        with respx.mock() as mock:
            mock.get(f"{API}/search").mock(return_value=httpx.Response(400, json={"error": {"errors": [{"reason": "keyInvalid"}]}}))
            with pytest.raises(ProviderError) as e:
                await p.search("anything else")
            assert e.value.kind == "config"


def test_without_key_youtube_is_not_configured():
    p = YouTubeProvider(httpx.AsyncClient())
    assert p.configured() is False and "YOUTUBE_API_KEY" in p.config_hint()


def test_search_asks_youtube_only_when_typing_is_done(make_user, yt_key):
    from app.music.registry import Health, get_registry

    reg = get_registry()
    reg.providers["youtube"] = YouTubeProvider(reg.client)
    reg.health["youtube"] = Health()
    u = make_user("Tuber")
    try:
        with respx.mock(assert_all_called=False) as mock:
            s = mock.get(f"{API}/search").mock(return_value=httpx.Response(200, json=SEARCH))
            mock.get(f"{API}/videos").mock(return_value=httpx.Response(200, json=VIDEOS))
            mock.route(host="127.0.0.1").pass_through()
            mock.route(host="testserver").pass_through()

            typing = u.get("/api/search", params={"q": "murder in my mind", "mode": "text", "deep": "false"}).json()
            assert s.call_count == 0 and all(x["id"] != "youtube" for x in typing["sources"])

            done = u.get("/api/search", params={"q": "murder in my mind", "mode": "text"}).json()
            yt = [x for x in done["results"] if x["provider"] == "youtube"]
            assert yt and yt[0]["stream"] == "embed" and yt[0]["playable"] is True and yt[0]["source"] == "YouTube"
            u.get("/api/search", params={"q": "Murder in my mind", "mode": "text"})
            assert s.call_count == 1, "repeated searches are answered from the cache"

            play = u.get(f"/api/tracks/{yt[0]['id']}/play").json()
            assert play["kind"] == "embed" and play["url"] == yt[0]["id"].split(":", 1)[1]
    finally:
        reg.providers.pop("youtube", None)
        reg.cache.clear()
