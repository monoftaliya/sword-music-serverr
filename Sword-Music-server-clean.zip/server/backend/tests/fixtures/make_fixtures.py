"""Generate the synthetic test catalogue (tracks, short audio tones, abstract covers).

Used ONLY by automated tests (SWORD_ENV=test). Run:  python tests/fixtures/make_fixtures.py
"""
from __future__ import annotations

import json
import random
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

HERE = Path(__file__).resolve().parent
AUDIO = HERE / "audio"
ART = HERE / "art"

CLUSTERS = [
    # (name, genres, moods, tags, bpm range, colours, artists)
    ("phonk", ["Hip-Hop/Rap"], ["Brooding", "Fiery"], ["phonk", "dark", "drift", "cowbell", "bass"], (128, 150), ("#2a0f3d", "#c2185b"), ["Kurogane", "Ashen Wheel", "Nox Rider"]),
    ("void", ["Ambient"], ["Brooding"], ["dark ambient", "space", "drone", "atmospheric"], (60, 80), ("#05070f", "#3949ab"), ["Hollow Orbit", "Sable Static"]),
    ("synth", ["Electronic"], ["Cool", "Yearning"], ["synthwave", "night drive", "retro", "neon"], (100, 118), ("#1a0b3b", "#ff4f9a"), ["Neon Vesper", "Grid Runner"]),
    ("lofi", ["Lo-Fi"], ["Peaceful", "Melancholy"], ["lofi", "rain", "chill", "study"], (70, 90), ("#1b2a33", "#7fb3a6"), ["Paper Lanterns", "Slow Tram"]),
    ("epic", ["Soundtrack"], ["Stirring", "Empowering"], ["epic", "orchestral", "cinematic", "choir"], (90, 130), ("#1c1406", "#f5c451"), ["Aurelian Score", "Titan Choir"]),
    ("metal", ["Metal"], ["Aggressive"], ["metal", "aggressive", "heavy", "distorted"], (150, 180), ("#140404", "#ff3b3b"), ["Iron Verdict", "Rust Cathedral"]),
    ("dnb", ["Drum & Bass"], ["Energizing"], ["dnb", "energetic", "liquid", "breakbeat"], (170, 176), ("#04141a", "#2ee6d6"), ["Signal Fault", "Rapid Glass"]),
    ("piano", ["Classical"], ["Tender"], ["piano", "calm", "sleep", "minimal"], (58, 72), ("#0d1116", "#a8c7ff"), ["Quiet Keys", "Lumen Hall"]),
    ("trap", ["Trap"], ["Cool", "Defiant"], ["trap", "808", "confident", "dark"], (136, 146), ("#0e0e10", "#b388ff"), ["Crown District", "Velvet Threat"]),
    ("house", ["House"], ["Upbeat"], ["happy", "summer", "party", "dance"], (120, 126), ("#2b1300", "#ffb547"), ["Sunday Club", "Bright Static"]),
    ("jazz", ["Jazz"], ["Sophisticated"], ["jazz", "night", "smooth", "late night"], (84, 96), ("#120c08", "#d4a373"), ["Blue Corner Trio"]),
]
WORDS_A = ["Obsidian", "Silent", "Neon", "Hollow", "Crimson", "Velvet", "Static", "Lunar", "Glass", "Iron", "Paper", "Midnight", "Golden", "Frozen", "Electric", "Distant"]
WORDS_B = ["Drift", "Orbit", "Rain", "Cathedral", "Signal", "Mirage", "Tide", "Engine", "Garden", "Horizon", "Echo", "Pulse", "Ritual", "Avenue", "Bloom", "Requiem"]
KEYS = ["A minor", "C minor", "D minor", "E minor", "F major", "G major", "B flat minor", "D flat minor"]


def make_audio() -> list[str]:
    AUDIO.mkdir(parents=True, exist_ok=True)
    names = []
    for i, freq in enumerate([196, 220, 247, 262, 294, 330, 349, 392]):
        name = f"tone{i}.ogg"
        out = AUDIO / name
        if not out.exists():
            subprocess.run(
                [
                    "ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi",
                    "-i", f"sine=frequency={freq}:duration=40",
                    "-f", "lavfi", "-i", f"sine=frequency={freq * 1.5}:duration=40",
                    "-filter_complex", "[0][1]amix=inputs=2:weights=1 0.35,volume=0.25,afade=t=in:d=1,afade=t=out:st=38:d=2",
                    "-c:a", "libvorbis", "-q:a", "1", str(out),
                ],
                check=True,
            )
        names.append(name)
    return names


def make_cover(path: Path, c1: str, c2: str, seed: int) -> None:
    rnd = random.Random(seed)
    img = Image.new("RGB", (320, 320), c1)
    draw = ImageDraw.Draw(img)
    for _ in range(5):
        r = rnd.randint(60, 170)
        x, y = rnd.randint(-40, 360), rnd.randint(-40, 360)
        draw.ellipse([x - r, y - r, x + r, y + r], fill=c2 if rnd.random() > 0.4 else c1)
    img = img.filter(ImageFilter.GaussianBlur(28))
    img.save(path, "PNG", optimize=True)


def main() -> None:
    audio = make_audio()
    if ART.exists():
        shutil.rmtree(ART)
    ART.mkdir(parents=True)
    rnd = random.Random(42)
    catalog = []
    n = 0
    for cname, genres, moods, tags, (lo, hi), (c1, c2), artists in CLUSTERS:
        per = 6 if cname in ("phonk", "void") else 4
        for i in range(per):
            artist = artists[i % len(artists)]
            title = f"{rnd.choice(WORDS_A)} {rnd.choice(WORDS_B)}"
            if i == 1 and cname == "phonk":
                title = "Night Engine"
            n += 1
            art = f"cover{n:02d}.png"
            make_cover(ART / art, c1, c2, n)
            catalog.append(
                {
                    "id": f"{cname}-{i}",
                    "title": title,
                    "artist": artist,
                    "artist_ref": artist.lower().replace(" ", "-"),
                    "album": f"{artist} — Sessions",
                    "duration": 40.0,
                    "genres": genres,
                    "moods": [moods[i % len(moods)]],
                    "tags": tags[: 2 + (i % 3)],
                    "bpm": float(rnd.randint(lo, hi)),
                    "key": rnd.choice(KEYS),
                    "popularity": round(rnd.uniform(0.2, 0.9), 2),
                    "audio": audio[n % len(audio)],
                    "artwork": f"/api/_test/art/{art}",
                    "stream_kind": "full",
                }
            )
    # a duplicate recording from the "same" source to exercise de-duplication,
    # a live version (must NOT be merged) and a preview-only track
    dup = dict(catalog[1])
    dup["id"] = "phonk-1-dup"
    catalog.append(dup)
    live = dict(catalog[1])
    live["id"] = "phonk-1-live"
    live["title"] = catalog[1]["title"] + " (Live)"
    catalog.append(live)
    prev = dict(catalog[2])
    prev["id"] = "phonk-preview"
    prev["title"] = "Preview Only Track"
    prev["stream_kind"] = "preview"
    catalog.append(prev)
    # a YouTube-style track: played by the embedded YouTube player (the test stubs the IFrame API)
    catalog.append({"id": "tube-0", "title": "Tube Signal", "artist": "Video Artist", "artist_ref": "video-artist", "album": None,
                    "duration": 212.0, "genres": ["Electronic"], "moods": [], "tags": ["synthwave"], "bpm": None, "key": None,
                    "popularity": 0.5, "audio": "M7lc1UVf-VE", "artwork": "/api/_test/art/cover03.png", "stream_kind": "embed"})
    (HERE / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(catalog)} tracks, {len(audio)} audio files")


if __name__ == "__main__":
    main()
