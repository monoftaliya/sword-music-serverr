from __future__ import annotations

import io
import shutil
import subprocess
from pathlib import Path

import pytest
from PIL import Image

from conftest import search_ids


def _tracks(u, q="Orbit", n=4):
    ids = search_ids(u, q, mode="text")
    assert len(ids) >= n, ids
    return ids[:n]


def test_favorites_roundtrip(make_user):
    u = make_user("Fav")
    tid = _tracks(u, n=1)[0]
    assert u.put(f"/api/library/favorites/{tid}").json()["liked"] is True
    favs = u.get("/api/library/favorites").json()
    assert favs["total"] == 1 and favs["items"][0]["liked"] is True
    # search results reflect the like
    res = u.get("/api/search", params={"q": favs["items"][0]["title"], "mode": "text"}).json()["results"]
    assert any(r["id"] == tid and r["liked"] for r in res)
    u.delete(f"/api/library/favorites/{tid}")
    assert u.get("/api/library/favorites").json()["total"] == 0


def test_playlist_crud_order_share_copy(make_user):
    owner = make_user("Owner")
    friend = make_user("Friend")
    ids = _tracks(owner, n=4)
    pl = owner.post("/api/playlists", json={"name": "Ночь", "description": "для поездок"}).json()
    r = owner.post(f"/api/playlists/{pl['id']}/tracks", json={"track_ids": ids + [ids[0]]}).json()
    assert r == {"added": 4, "skipped": 1}  # no accidental duplicates
    detail = owner.get(f"/api/playlists/{pl['id']}").json()
    items = [it["item_id"] for it in detail["items"]]
    assert [it["track"]["id"] for it in detail["items"]] == ids
    reordered = list(reversed(items))
    assert owner.put(f"/api/playlists/{pl['id']}/order", json={"item_ids": reordered}).status_code == 200
    detail = owner.get(f"/api/playlists/{pl['id']}").json()
    assert [it["track"]["id"] for it in detail["items"]] == list(reversed(ids))
    assert owner.put(f"/api/playlists/{pl['id']}/order", json={"item_ids": reordered[:2]}).status_code == 409
    owner.delete(f"/api/playlists/{pl['id']}/tracks/{reordered[0]}")
    owner.patch(f"/api/playlists/{pl['id']}", json={"name": "Ночь 2"})
    detail = owner.get(f"/api/playlists/{pl['id']}").json()
    assert detail["name"] == "Ночь 2" and detail["track_count"] == 3
    # friends cannot open it directly...
    assert friend.get(f"/api/playlists/{pl['id']}").status_code == 404
    # ...but can through a share link and save a copy
    share = owner.post(f"/api/playlists/{pl['id']}/share").json()
    view = friend.get(f"/api/shared/{share['token']}").json()
    assert view["name"] == "Ночь 2" and view["is_owner"] is False and len(view["items"]) == 3
    copy = friend.post(f"/api/shared/{share['token']}/save").json()
    assert copy["track_count"] == 3
    owner.delete(f"/api/playlists/{pl['id']}/share")
    assert friend.get(f"/api/shared/{share['token']}").status_code == 404


def test_playlist_cover_upload(make_user):
    u = make_user("Cover")
    pl = u.post("/api/playlists", json={"name": "C"}).json()
    buf = io.BytesIO()
    Image.new("RGB", (800, 500), "#8B5CFF").save(buf, "PNG")
    r = u.post(f"/api/playlists/{pl['id']}/cover", files={"file": ("c.png", buf.getvalue(), "image/png")})
    assert r.status_code == 200 and r.json()["cover"].endswith(".webp")
    img = u.c.get(r.json()["cover"])
    assert img.status_code == 200
    bad = u.post(f"/api/playlists/{pl['id']}/cover", files={"file": ("c.png", b"not an image", "image/png")})
    assert bad.status_code == 415


@pytest.mark.skipif(shutil.which("ffmpeg") is None, reason="ffmpeg required to build a tagged mp3")
def test_uploads_are_private_and_seekable(make_user, tmp_path: Path):
    u = make_user("Uploader")
    other = make_user("Other")
    src = tmp_path / "song.mp3"
    cover = tmp_path / "cover.png"
    Image.new("RGB", (64, 64), "#5C8DFF").save(cover)
    subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=frequency=440:duration=6", "-i", str(cover),
         "-map", "0", "-map", "1", "-c:a", "libmp3lame", "-q:a", "6", "-id3v2_version", "3",
         "-metadata", "title=Моя песня", "-metadata", "artist=Я сам", "-metadata", "album=Демо", str(src)],
        check=True,
    )
    r = u.post("/api/uploads", files={"file": ("song.mp3", src.read_bytes(), "audio/mpeg")})
    assert r.status_code == 200, r.text
    t = r.json()
    assert t["title"] == "Моя песня" and t["artist"] == "Я сам" and t["album"] == "Демо"
    assert t["artwork"] and t["provider"] == "upload" and 5 < t["duration"] < 7
    play = u.get(f"/api/tracks/{t['id']}/play").json()
    part = u.c.get(play["url"], headers={"Range": "bytes=10-209", "Authorization": f"Bearer {u.token}"})
    assert part.status_code == 206 and len(part.content) == 200
    # strangers can't see or stream it
    assert other.get(f"/api/tracks/{t['id']}").status_code == 403
    assert other.c.get(play["url"], headers={"Authorization": f"Bearer {other.token}"}).status_code == 404
    lst = u.get("/api/library/uploads").json()
    assert lst["items"][0]["id"] == t["id"] and lst["used_bytes"] > 0
    assert u.post("/api/uploads", files={"file": ("x.txt", b"hello", "text/plain")}).status_code == 415
    assert u.post("/api/uploads", files={"file": ("fake.mp3", b"\x00" * 2000, "audio/mpeg")}).status_code == 415
    assert u.delete(f"/api/uploads/{t['id']}").status_code == 200
    assert u.get("/api/library/uploads").json()["items"] == []


def test_events_recents_artists_and_player_state(make_user):
    u = make_user("Listener")
    ids = _tracks(u, "Drift", n=3)
    for tid in ids:
        r = u.post("/api/events/play", json={"track_id": tid, "played_ms": 38000, "duration_ms": 40000, "end_reason": "ended", "context": "search"})
        assert r.json()["recorded"] and r.json()["completed"]
    skip = u.post("/api/events/play", json={"track_id": ids[0], "played_ms": 5000, "duration_ms": 40000, "end_reason": "skip"}).json()
    assert skip["skipped"] is True and skip["completed"] is False
    recent = u.get("/api/library/recent").json()["items"]
    assert {r["id"] for r in recent} == set(ids)
    artists = u.get("/api/library/artists").json()["items"]
    assert artists and artists[0]["tracks"] >= 1
    state = {"queue": ids, "index": 1, "position_ms": 12345, "shuffle": False, "repeat": "all", "context": "search:drift"}
    assert u.put("/api/me/player-state", json=state).status_code == 200
    got = u.get("/api/me/player-state").json()["state"]
    assert [t["id"] for t in got["queue"]] == ids and got["index"] == 1 and got["position_ms"] == 12345
    home = u.get("/api/home").json()
    assert home["continue"]["track"]["id"] == ids[1] and home["recent"]
    # privacy: disabling history stops recording
    u.patch("/api/me/settings", json={"history_enabled": False})
    assert u.post("/api/events/play", json={"track_id": ids[0], "played_ms": 30000, "end_reason": "ended"}).json()["recorded"] is False
    u.delete("/api/me/history")
    assert u.get("/api/library/recent").json()["items"] == []


def test_artist_and_album_pages(make_user):
    u = make_user("Browse")
    res = u.get("/api/search", params={"q": "Kurogane", "mode": "text"}).json()["results"]
    t = res[0]
    page = u.get(f"/api/artists/{t['artist_key']}", params={"name": t["artist"], "provider": t["provider"], "ref": t["artist_ref"]}).json()
    assert page["name"] == "Kurogane" and all(x["artist"] == "Kurogane" for x in page["top"])
    alb = u.get("/api/albums/view", params={"key": f"name:kurogane|{t['album'].lower().replace(' — ', ' ')}"})
    assert alb.status_code in (200, 404)


def test_export_and_account_deletion(make_user, client):
    u = make_user("Leaver")
    tid = _tracks(u, n=1)[0]
    u.put(f"/api/library/favorites/{tid}")
    data = u.get("/api/me/export").json()
    assert data["favorites"] and data["profile"]["email"]
    assert u.post("/api/me/delete", json={"password": "wrong"}).status_code == 400
    assert u.post("/api/me/delete", json={"password": "Correct-Horse-42"}).status_code == 200
    assert u.get("/api/auth/me").status_code == 401
