"""Recommendation behaviour: real signals, distinct modes, honest semantics."""
from __future__ import annotations

from statistics import mean

from conftest import search_ids


def _seed_catalog(u):
    # bring the whole fixture catalogue into the database via searches
    for q in ("Kurogane", "Ashen", "Nox", "Hollow", "Sable", "Neon", "Grid", "Paper", "Slow", "Aurelian", "Titan", "Iron", "Rust",
              "Signal", "Rapid", "Quiet", "Lumen", "Crown", "Velvet", "Sunday", "Bright", "Blue"):
        search_ids(u, q, mode="text")


def _play(u, tid, *, completed=True, skip=False):
    body = {"track_id": tid, "played_ms": 4500 if skip else 39000, "duration_ms": 40000, "end_reason": "skip" if skip else "ended", "context": "test"}
    return u.post("/api/events/play", json=body).json()


def _artist_tracks(u, artist):
    return [r for r in u.get("/api/search", params={"q": artist, "mode": "text"}).json()["results"] if r["artist"] == artist]


def _energy(items):
    pts = [i["point"][1] for i in items if i.get("point")]
    return mean(pts) if pts else 0


def test_cold_start_offers_seeds(make_user):
    u = make_user("Cold")
    _seed_catalog(u)
    r = u.get("/api/wave/next", params={"mode": "flow", "count": 8}).json()
    assert r["cold_start"] is True and r["seed_suggestions"]
    assert len(r["items"]) == 8, "even cold start returns real tracks"
    u.put("/api/wave/seeds", json={"tags": ["phonk", "dark", "nonexistent"]})
    prof = u.get("/api/wave/profile").json()
    assert prof["seed_tags"] == ["phonk", "dark"] and prof["cold"] is False


def test_flow_follows_taste_and_modes_differ(make_user):
    u = make_user("Taste")
    _seed_catalog(u)
    phonk = _artist_tracks(u, "Kurogane") + _artist_tracks(u, "Nox Rider")
    for t in phonk[:4]:
        _play(u, t["id"])
    u.post("/api/wave/feedback", json={"track_id": phonk[0]["id"], "kind": "like"})
    flow = u.get("/api/wave/next", params={"mode": "flow", "count": 10}).json()
    void = u.get("/api/wave/next", params={"mode": "void", "count": 10}).json()
    chaos = u.get("/api/wave/next", params={"mode": "chaos", "count": 10}).json()
    flow_tags = [tag["key"] for i in flow["items"][:5] for tag in i["tags"]]
    assert "phonk" in flow_tags, flow_tags
    assert any("нравится" in i["reason"] or "любим" in i["reason"].lower() or "слушаете" in i["reason"] for i in flow["items"])
    void_tags = {tag["key"] for i in void["items"] for tag in i["tags"]}
    assert void_tags & {"dark_ambient", "space", "drone", "atmospheric", "dark"}
    assert all(i["reason"].startswith("VOID") for i in void["items"])
    # CHAOS: never already-heard tracks, mostly artists the user hasn't listened to, max one per artist
    heard = {t["id"] for t in phonk[:4]}
    assert not heard & {i["id"] for i in chaos["items"]}
    artists = [i["artist"] for i in chaos["items"]]
    assert len(set(artists)) == len(artists)
    assert sum(1 for a in artists if a not in {"Kurogane", "Nox Rider"}) >= len(artists) - 1
    assert {i["id"] for i in flow["items"]} != {i["id"] for i in void["items"]} != {i["id"] for i in chaos["items"]}


def test_skip_is_not_dislike_and_exclusions(make_user):
    u = make_user("Skipper")
    _seed_catalog(u)
    metal = _artist_tracks(u, "Iron Verdict")
    _play(u, metal[0]["id"], skip=True)
    prof = u.get("/api/wave/profile").json()
    assert not any(a["key"] == "metal" for a in prof["avoided"]), "a single skip must not mark a genre as disliked"
    u.post("/api/wave/feedback", json={"track_id": metal[0]["id"], "kind": "dislike"})
    u.post("/api/wave/feedback", json={"track_id": metal[0]["id"], "kind": "exclude_artist"})
    for mode in ("flow", "void", "chaos"):
        items = u.get("/api/wave/next", params={"mode": mode, "count": 12}).json()["items"]
        assert all(i["artist"] != "Iron Verdict" for i in items), mode
    rage = u.get("/api/modes/rage/next", params={"count": 10}).json()["items"]
    assert all(i["artist"] != "Iron Verdict" for i in rage)
    assert u.get("/api/wave/profile").json()["excluded_artists"][0]["name"] == "Iron Verdict"


def test_no_immediate_repeats_and_refresh(make_user):
    u = make_user("Repeat")
    _seed_catalog(u)
    a = u.get("/api/wave/next", params={"mode": "void", "count": 8}).json()["items"]
    b = u.get("/api/wave/next", params={"mode": "void", "count": 8}).json()["items"]
    assert not {i["id"] for i in a} & {i["id"] for i in b}


def test_more_less_feedback_moves_tags(make_user):
    u = make_user("Bias")
    _seed_catalog(u)
    lofi = _artist_tracks(u, "Paper Lanterns")
    r = u.post("/api/wave/feedback", json={"track_id": lofi[0]["id"], "kind": "more"}).json()
    assert r["tags"]
    prof = u.get("/api/wave/profile").json()
    assert prof["top_tags"][0]["key"] in {"lofi", "rain", "calm", "melancholic", "study"}
    house = _artist_tracks(u, "Sunday Club")
    u.post("/api/wave/feedback", json={"track_id": house[0]["id"], "kind": "less"})
    prof = u.get("/api/wave/profile").json()
    assert {a["key"] for a in prof["avoided"]} & {"house", "happy", "party"}


def test_after_dark_modes_have_distinct_logic(make_user):
    u = make_user("AfterDark")
    _seed_catalog(u)
    modes = u.get("/api/modes").json()["modes"]
    assert [m["id"] for m in modes] == ["void", "rage", "ego", "oblivion", "ascension", "afterdark"]
    rage = u.get("/api/modes/rage/next", params={"count": 8}).json()["items"]
    obl = u.get("/api/modes/oblivion/next", params={"count": 8}).json()["items"]
    asc = u.get("/api/modes/ascension/next", params={"count": 8}).json()["items"]
    assert _energy(rage) > _energy(obl) + 0.3
    energies = [i["point"][1] for i in asc if i.get("point")]
    assert energies == sorted(energies), "ASCENSION builds energy track by track"
    assert all(i["reason"].startswith("RAGE") for i in rage)


def test_shadow_lens_explores_but_respects_rejections(make_user):
    u = make_user("Shadow")
    _seed_catalog(u)
    for t in _artist_tracks(u, "Kurogane")[:2] + _artist_tracks(u, "Hollow Orbit")[:2]:
        _play(u, t["id"])
        u.post("/api/wave/feedback", json={"track_id": t["id"], "kind": "like"})
    rust = _artist_tracks(u, "Rust Cathedral")
    u.post("/api/wave/feedback", json={"track_id": rust[0]["id"], "kind": "dislike"})
    u.post("/api/wave/feedback", json={"track_id": rust[0]["id"], "kind": "less"})
    main = u.get("/api/wave/next", params={"mode": "flow", "lens": "main", "count": 10}).json()
    shadow = u.get("/api/wave/next", params={"mode": "flow", "lens": "shadow", "count": 10}).json()
    assert shadow["profile"]["shadow_tags"]
    shadow_keys = {t["key"] for t in shadow["profile"]["shadow_tags"]}
    assert not shadow_keys & {"metal", "heavy"}, "explicitly rejected sound must not be pushed by SHADOW"
    assert all(i["reason"].startswith("Тень") for i in shadow["items"])
    assert {i["id"] for i in main["items"]} != {i["id"] for i in shadow["items"]}


def test_reset_starts_over(make_user):
    u = make_user("Reset")
    _seed_catalog(u)
    t = _artist_tracks(u, "Quiet Keys")[0]
    _play(u, t["id"])
    u.post("/api/wave/feedback", json={"track_id": t["id"], "kind": "like"})
    assert u.get("/api/wave/profile").json()["signals"] > 0
    assert u.post("/api/wave/reset", json={}).status_code == 400
    assert u.post("/api/wave/reset", json={"confirm": True}).status_code == 200
    prof = u.get("/api/wave/profile").json()
    assert prof["signals"] == 0 and prof["top_tags"] == []
    # library history survives unless requested
    assert u.get("/api/library/recent").json()["items"]


def test_music_dna_only_sourced_parameters(make_user):
    u = make_user("Dna")
    _seed_catalog(u)
    t = _artist_tracks(u, "Kurogane")[0]
    d = u.get(f"/api/dna/track/{t['id']}").json()
    keys = {p["key"] for p in d["params"]}
    assert {"bpm", "key", "genre", "mood"} <= keys
    assert all(p["source"] for p in d["params"])
    assert "не анализ" in d["mood"]["note"]
    a = _artist_tracks(u, "Hollow Orbit")[0]  # atmosphere
    b = _artist_tracks(u, "Signal Fault")[0]  # rhythm (dnb ~174 BPM)
    blend = u.post("/api/dna/blend", json={"a": a["id"], "b": b["id"], "atmosphere": "a", "rhythm": "b", "genre": "a"}).json()
    assert blend["items"] and any("ритм" in n for n in blend["notes"])
    assert a["id"] not in {i["id"] for i in blend["items"]}
    s = u.get("/api/dna/search", params={"tags": "piano,calm", "bpm_max": 80}).json()
    assert s["items"][0]["artist"] in {"Quiet Keys", "Lumen Hall", "Paper Lanterns", "Slow Tram"}


def test_echo_self_and_descent(make_user):
    u = make_user("Echo")
    _seed_catalog(u)
    for t in _artist_tracks(u, "Neon Vesper") + _artist_tracks(u, "Grid Runner"):
        _play(u, t["id"])
    echo = u.get("/api/echo", params={"period": "30d"}).json()
    assert echo["plays"] >= 3 and echo["lobes"] and "не психологический" in echo["disclaimer"]
    assert echo["lobes"][0]["key"] in {"synthwave", "electronic", "drive", "night", "retro", "city", "confident", "melancholic", "nostalgic"}
    tl = u.get("/api/echo/timeline", params={"months": 3}).json()["frames"]
    assert len(tl) == 3
    center = _artist_tracks(u, "Kurogane")[0]
    visited = [center["id"]]
    seen: set[str] = set()
    cur = center["id"]
    for depth in range(4):
        r = u.get("/api/descent", params={"center": cur, "mode": "descend", "depth": depth, "visited": ",".join(visited)}).json()
        ids = [n["track"]["id"] for n in r["nodes"]]
        assert ids and not set(ids) & set(visited), "visited tracks never come back"
        assert all(n["label"] for n in r["nodes"])
        seen |= set(ids)
        cur = ids[-1]
        visited.append(cur)
    explore = u.get("/api/descent", params={"center": center["id"], "mode": "explore"}).json()
    assert any(n["relation"] == "artist" for n in explore["nodes"])
