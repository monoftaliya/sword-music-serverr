from __future__ import annotations

import uuid

from conftest import CSRF, PASSWORD, login


def test_status_and_protected_routes(client, admin):
    r = client.get("/api/auth/status")
    assert r.status_code == 200
    assert r.json()["setup_required"] is False
    client.cookies.clear()
    for url in ("/api/home", "/api/library/favorites", "/api/search?q=x", "/api/wave/next", "/api/admin/users"):
        assert client.get(url).status_code == 401, url


def test_first_admin_requires_setup_code_only_once(client, admin):
    # setup code no longer works once an account exists — invite is required
    from app.config import get_settings

    r = client.post(
        "/api/auth/register",
        json={"email": f"x{uuid.uuid4().hex[:6]}@example.com", "password": PASSWORD, "display_name": "X", "setup_code": get_settings().setup_code},
        headers=CSRF,
    )
    assert r.status_code == 403
    assert r.json()["error"]["code"] == "invite_required"


def test_invite_flow_single_use_and_revoke(client, admin):
    inv = admin.post("/api/admin/invites", json={"max_uses": 1, "note": "Тест"}).json()
    assert inv["state"] == "active" and inv["code"].startswith("SWRD-")
    assert client.get(f"/api/auth/invite/{inv['code']}").json()["valid"] is True
    email = f"a{uuid.uuid4().hex[:6]}@example.com"
    ok = client.post("/api/auth/register", json={"email": email, "password": PASSWORD, "display_name": "A", "invite_code": inv["code"]}, headers=CSRF)
    assert ok.status_code == 200 and ok.json()["user"]["is_admin"] is False
    client.cookies.clear()
    again = client.post("/api/auth/register", json={"email": "b" + email, "password": PASSWORD, "display_name": "B", "invite_code": inv["code"]}, headers=CSRF)
    assert again.status_code == 403 and again.json()["error"]["code"] == "invite_invalid"
    inv2 = admin.post("/api/admin/invites", json={"max_uses": 3}).json()
    admin.delete(f"/api/admin/invites/{inv2['id']}")
    revoked = client.post("/api/auth/register", json={"email": "c" + email, "password": PASSWORD, "display_name": "C", "invite_code": inv2["code"]}, headers=CSRF)
    assert revoked.status_code == 403
    assert "отозвано" in revoked.json()["error"]["message"]


def test_weak_password_and_duplicate_email(client, admin):
    inv = admin.post("/api/admin/invites", json={"max_uses": 5}).json()
    r = client.post("/api/auth/register", json={"email": "weak@example.com", "password": "12345678", "display_name": "W", "invite_code": inv["code"]}, headers=CSRF)
    assert r.status_code == 400 and r.json()["error"]["code"] == "weak_password"
    r = client.post("/api/auth/register", json={"email": "admin@example.com", "password": PASSWORD, "display_name": "W", "invite_code": inv["code"]}, headers=CSRF)
    assert r.status_code == 409


def test_login_logout_and_password_storage(client, make_user):
    user = make_user("Login")
    r = user.get("/api/auth/me")
    assert r.status_code == 200
    email = r.json()["user"]["email"]
    bad = client.post("/api/auth/login", json={"email": email, "password": "wrong-password"}, headers=CSRF)
    assert bad.status_code == 401
    # passwords are hashed with argon2, never stored in clear text
    import asyncio

    from sqlalchemy import select

    from app.db import get_sessionmaker
    from app.models import User

    async def fetch():
        async with get_sessionmaker()() as s:
            return (await s.execute(select(User.password_hash).where(User.email == email))).scalar_one()

    h = client.portal.call(fetch) if hasattr(client, "portal") and client.portal else asyncio.run(fetch())
    assert h.startswith("$argon2") and PASSWORD not in h
    assert user.post("/api/auth/logout").status_code == 200
    assert user.get("/api/auth/me").status_code == 401


def test_bruteforce_is_rate_limited(client, make_user):
    user = make_user("Brute")
    email = user.get("/api/auth/me").json()["user"]["email"]
    codes = [client.post("/api/auth/login", json={"email": email, "password": f"bad-{i}-pass"}, headers=CSRF).status_code for i in range(8)]
    assert codes[:6] == [401] * 6
    assert codes[-1] == 429
    # even the right password is refused while locked
    assert client.post("/api/auth/login", json={"email": email, "password": PASSWORD}, headers=CSRF).status_code == 429


def test_csrf_header_required_for_cookie_sessions(client, make_user):
    user = make_user("Csrf")
    email = user.get("/api/auth/me").json()["user"]["email"]
    client.cookies.clear()
    r = client.post("/api/auth/login", json={"email": email, "password": PASSWORD}, headers=CSRF)
    assert r.status_code == 200 and "sword_session" in r.cookies
    no_header = client.post("/api/playlists", json={"name": "x"})
    assert no_header.status_code == 403 and no_header.json()["error"]["code"] == "csrf"
    with_header = client.post("/api/playlists", json={"name": "x"}, headers=CSRF)
    assert with_header.status_code == 200
    client.cookies.clear()


def test_admin_only_endpoints_and_reset_link(client, admin, make_user):
    user = make_user("Plain")
    assert user.get("/api/admin/users").status_code == 403
    assert user.post("/api/admin/invites", json={}).status_code == 403
    uid = user.user["id"]
    link = admin.post(f"/api/admin/users/{uid}/reset-link").json()["url"]
    token = link.split("token=")[1]
    r = client.post("/api/auth/password/reset", json={"token": token, "password": "Brand-New-Pass-7"}, headers=CSRF)
    assert r.status_code == 200
    # old sessions are revoked after a reset
    assert user.get("/api/auth/me").status_code == 401
    email = user.user["email"]
    login(client, email, "Brand-New-Pass-7")
    # token cannot be reused
    assert client.post("/api/auth/password/reset", json={"token": token, "password": "Another-Pass-8"}, headers=CSRF).status_code == 400


def test_disabled_user_cannot_login(client, admin, make_user):
    user = make_user("Disabled")
    admin.patch(f"/api/admin/users/{user.user['id']}", json={"is_active": False})
    assert user.get("/api/auth/me").status_code == 401
    r = client.post("/api/auth/login", json={"email": user.user["email"], "password": PASSWORD}, headers=CSRF)
    assert r.status_code == 403


def test_forgot_password_does_not_leak_accounts(client, admin):
    a = client.post("/api/auth/password/forgot", json={"email": "admin@example.com"}, headers=CSRF)
    b = client.post("/api/auth/password/forgot", json={"email": "nobody@example.com"}, headers=CSRF)
    assert a.status_code == b.status_code == 200
    assert a.json() == b.json()


def test_profile_settings_and_sessions(make_user):
    user = make_user("Prof")
    r = user.patch("/api/me", json={"display_name": "  Новое   Имя "})
    assert r.json()["user"]["display_name"] == "Новое Имя"
    r = user.patch("/api/me/settings", json={"theme": "oled", "crossfade": 4, "motion": "reduced"})
    assert r.status_code == 200 and r.json()["settings"]["theme"] == "oled"
    assert user.patch("/api/me/settings", json={"theme": "rainbow"}).status_code == 400
    assert user.patch("/api/me/settings", json={"unknown": 1}).status_code == 400
    sessions = user.get("/api/auth/sessions").json()["sessions"]
    assert len(sessions) >= 1
