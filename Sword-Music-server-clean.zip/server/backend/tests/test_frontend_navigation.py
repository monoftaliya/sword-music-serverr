from app.main import _frontend_response


def test_exported_route_payloads_are_flight_and_revalidated(tmp_path):
    for path in ("index.txt", "search/index.txt", "search/__next._full.txt", "search/__next.search/__PAGE__.txt"):
        target = tmp_path / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text('0:{"b":"current-build"}')
        response = _frontend_response(tmp_path, path)
        assert response is not None
        assert response.headers["content-type"].startswith("text/x-component")
        assert response.headers["cache-control"] == "no-cache"
        assert response.headers["vary"] == "RSC"


def test_route_navigation_header_never_receives_the_html_page(tmp_path):
    (tmp_path / "search").mkdir()
    (tmp_path / "search/index.html").write_text("<html>Full document</html>")
    (tmp_path / "search/index.txt").write_text('0:{"b":"current-build"}')
    for path in ("search/", "search"):
        response = _frontend_response(tmp_path, path, rsc=True)
        assert response.path == (tmp_path / "search/index.txt").resolve()
        assert response.headers["content-type"].startswith("text/x-component")
    response = _frontend_response(tmp_path, "search/")
    assert response.headers["content-type"].startswith("text/html")


def test_navigation_cannot_fall_back_to_html_or_escape_the_export(tmp_path):
    (tmp_path / "index.html").write_text("<html>Home</html>")
    assert _frontend_response(tmp_path, "", rsc=True) is None
    assert _frontend_response(tmp_path, "../../private/index.txt", rsc=True) is None
