"""Provider adapters: parsing of real-world response shapes, error handling, circuit breaker."""
from __future__ import annotations

import asyncio

import httpx
import pytest
import respx

from app.music.providers.archive import ArchiveProvider
from app.music.providers.audius import AudiusProvider
from app.music.providers.base import DiscoverSpec, ProviderError
from app.music.providers.deezer import DeezerProvider
from app.music.providers.jamendo import JamendoProvider
from app.music.providers.wikimedia import WikimediaProvider
from app.music.registry import Registry
from app.music.store import canonical_for

AUDIUS_TRACK = {
    "id": "Jx8a2",
    "title": "Dark Phonk",
    "genre": "Experimental",
    "mood": "Fiery",
    "tags": "phonk,drift,cowbell",
    "duration": 119,
    "bpm": 132.0,
    "musical_key": "D flat minor",
    "is_custom_bpm": False,
    "permalink": "/KaixReesefrfr/dark-phonk",
    "is_streamable": True,
    "is_stream_gated": False,
    "access": {"stream": True, "download": True},
    "play_count": 15234,
    "favorite_count": 321,
    "artwork": {"150x150": "https://val020.open-audio-validator.com/content/x/150x150.jpg", "480x480": "https://val020.open-audio-validator.com/content/x/480x480.jpg", "1000x1000": "https://val020.open-audio-validator.com/content/x/1000x1000.jpg"},
    "user": {"id": "nlGNe", "name": "K41", "handle": "KaixReesefrfr"},
    "release_date": "2024-05-01T00:00:00",
}


def test_audius_parse_and_canonical():
    p = AudiusProvider(httpx.AsyncClient())
    t = p.parse(AUDIUS_TRACK)
    assert t is not None
    assert t.id == "audius:Jx8a2"
    assert t.artist == "K41" and t.stream_kind == "full"
    assert t.bpm == 132.0 and t.musical_key == "D flat minor"
    assert t.extra["bpm_source"] == "audius-analysis"
    assert t.page_url == "https://audius.co/KaixReesefrfr/dark-phonk"
    canon = canonical_for(t)
    assert canon.get("phonk", 0) > 0.3 and "aggressive" in canon and "experimental" in canon
    gated = dict(AUDIUS_TRACK, is_stream_gated=True, access={"stream": False}, preview_cid=None)
    assert p.parse(gated).stream_kind == "none"
    gated_preview = dict(gated, preview_cid="Qm123")
    assert p.parse(gated_preview).stream_kind == "preview"
    assert p.parse(dict(AUDIUS_TRACK, is_delete=True)) is None


@pytest.mark.asyncio
async def test_audius_search_http_and_resolve():
    async with httpx.AsyncClient() as client:
        p = AudiusProvider(client)
        with respx.mock(assert_all_called=True) as mock:
            route = mock.get("https://api.audius.co/v1/tracks/search").mock(return_value=httpx.Response(200, json={"data": [AUDIUS_TRACK]}))
            res = await p.search("dark phonk", 10)
            assert [r.title for r in res] == ["Dark Phonk"]
            sent = route.calls[0].request.url
            assert sent.params["app_name"] and sent.params["query"] == "dark phonk"
        info = await p.resolve("Jx8a2", {"stream_kind": "full"})
        assert info.url.startswith("https://api.audius.co/v1/tracks/Jx8a2/stream?app_name=")


@pytest.mark.asyncio
async def test_audius_discover_sends_genre_mood_filters():
    async with httpx.AsyncClient() as client:
        p = AudiusProvider(client)
        with respx.mock() as mock:
            route = mock.get("https://api.audius.co/v1/tracks/search").mock(return_value=httpx.Response(200, json={"data": [AUDIUS_TRACK]}))
            mock.get("https://api.audius.co/v1/tracks/trending").mock(return_value=httpx.Response(200, json={"data": []}))
            res = await p.discover(DiscoverSpec(tags={"phonk": 1.0, "dark": 0.8}, bpm_min=120, bpm_max=160))
            assert res and res[0].provider_track_id == "Jx8a2"
            filtered = [c.request.url for c in route.calls if "mood" in str(c.request.url)]
            assert filtered, "a call with mood filters is expected"
            assert "Brooding" in filtered[0].params.get_list("mood")
            assert filtered[0].params["bpm_min"] == "120"


JAMENDO_PAYLOAD = {
    "headers": {"status": "success", "code": 0, "error_message": "", "warnings": "", "results_count": 1},
    "results": [
        {
            "id": "1532771",
            "name": "Into the Void",
            "duration": 215,
            "artist_id": "7006",
            "artist_name": "Nebula Drift",
            "album_name": "Deep Space",
            "album_id": "155063",
            "license_ccurl": "http://creativecommons.org/licenses/by-nc-sa/3.0/",
            "position": 2,
            "releasedate": "2018-06-01",
            "album_image": "https://usercontent.jamendo.com?type=album&id=155063&width=600",
            "audio": "https://prod-1.storage.jamendo.com/?trackid=1532771&format=mp32",
            "audiodownload": "https://prod-1.storage.jamendo.com/download/track/1532771/mp32/",
            "shareurl": "https://www.jamendo.com/track/1532771",
            "waveform": '{"peaks":[0,10,40,80,20,5,90,30]}',
            "musicinfo": {
                "vocalinstrumental": "instrumental",
                "gender": "",
                "acousticelectric": "electric",
                "speed": "low",
                "tags": {"genres": ["ambient", "electronic"], "instruments": ["synthesizer"], "vartags": ["dark", "space"]},
            },
            "audiodownload_allowed": True,
        }
    ],
}


def test_jamendo_parse(monkeypatch):
    monkeypatch.setenv("JAMENDO_CLIENT_ID", "abc")
    from app.config import get_settings

    get_settings.cache_clear()
    try:
        p = JamendoProvider(httpx.AsyncClient())
        [t] = p._parse_list(JAMENDO_PAYLOAD)
        assert t.id == "jamendo:1532771" and t.license == "CC BY-NC-SA 3.0"
        assert t.speed == "low" and t.vocal == "instrumental"
        assert t.extra["waveform"] and max(t.extra["waveform"]) == 1.0
        canon = canonical_for(t)
        assert {"ambient", "dark", "space", "instrumental"} <= set(canon)
        with pytest.raises(ProviderError) as e:
            p._parse_list({"headers": {"status": "failed", "error_message": "Invalid client_id"}})
        assert e.value.kind == "config"
    finally:
        get_settings.cache_clear()


@pytest.mark.asyncio
async def test_jamendo_data_saver_quality():
    p = JamendoProvider(httpx.AsyncClient())
    url = JAMENDO_PAYLOAD["results"][0]["audio"]
    high = await p.resolve("1532771", {"audio": url, "quality": "high"})
    low = await p.resolve("1532771", {"audio": url, "quality": "data_saver"})
    assert high.url == url
    assert "format=mp31" in low.url and "trackid=1532771" in low.url and "mp32" not in low.url


def test_jamendo_unconfigured_is_skipped():
    reg = Registry(httpx.AsyncClient())
    reg.providers["jamendo"] = JamendoProvider(reg.client)
    from app.music.registry import Health

    reg.health["jamendo"] = Health()
    assert reg.usable("jamendo") is False
    assert reg.state_of("jamendo") == "not_configured"


@pytest.mark.asyncio
async def test_archive_search_filters_licences_and_expands_files():
    search = {
        "response": {
            "docs": [
                {"identifier": "mnblck023", "title": "The Dark Side EP", "creator": "Otolith", "collection": ["mnbick", "netlabels"], "licenseurl": "http://creativecommons.org/licenses/by-nc-sa/3.0/de/", "downloads": 5000},
                {"identifier": "random-upload", "title": "Unknown", "collection": ["opensource_audio"]},
            ]
        }
    }
    meta = {
        "metadata": {"identifier": "mnblck023", "title": "mnblck023 - Otolith - The Dark Side EP (2009)", "creator": "Otolith", "subject": "ambient; dark ambient; soundscapes;isolationism", "licenseurl": "http://creativecommons.org/licenses/by-nc-sa/3.0/de/", "collection": ["mnbick", "netlabels"]},
        "files": [
            {"name": "01-Monolith1.mp3", "source": "original", "format": "192Kbps MP3", "title": "Monolith1", "track": "01/04", "creator": "Otolith", "album": "The Dark Side EP", "length": "369.26"},
            {"name": "01-Monolith1.ogg", "source": "derivative", "format": "Ogg Vorbis", "original": "01-Monolith1.mp3", "length": "369.16"},
            {"name": "02-Monolith2.mp3", "source": "original", "format": "192Kbps MP3", "title": "Monolith2", "track": "02/04", "length": "1057.56"},
            {"name": "cover.jpg", "source": "original", "format": "JPEG"},
        ],
    }
    async with httpx.AsyncClient() as client:
        p = ArchiveProvider(client)
        with respx.mock() as mock:
            mock.get("https://archive.org/advancedsearch.php").mock(return_value=httpx.Response(200, json=search))
            mock.get("https://archive.org/metadata/mnblck023").mock(return_value=httpx.Response(200, json=meta))
            res = await p.search("dark side", 10)
    assert [t.title for t in res] == ["Monolith1", "Monolith2"]  # one file per recording, no ogg duplicate
    t = res[0]
    assert t.license == "CC BY-NC-SA 3.0" and t.duration == pytest.approx(369.26)
    assert "dark_ambient" in canonical_for(t)
    info = await ArchiveProvider(httpx.AsyncClient()).resolve(t.provider_track_id, t.extra)
    assert info.url == "https://archive.org/download/mnblck023/01-Monolith1.mp3"


def test_wikimedia_filters_pronunciations_and_prefers_mp3():
    p = WikimediaProvider(httpx.AsyncClient())
    good = {
        "pageid": 123,
        "title": "File:Frederic Chopin - Nocturne Op. 9 no. 2.ogg",
        "videoinfo": [{
            "url": "https://upload.wikimedia.org/a.ogg", "descriptionurl": "https://commons.wikimedia.org/wiki/File:a.ogg",
            "mime": "application/ogg", "duration": 270.5,
            "derivatives": [{"src": "https://upload.wikimedia.org/transcoded/a.ogg.mp3", "type": "audio/mpeg"}],
            "extmetadata": {"Artist": {"value": "<a href='x'>Muriel Nguyen Xuan</a>"}, "LicenseShortName": {"value": "CC BY-SA 4.0"}},
        }],
    }
    t = p._parse_page(good)
    assert t is not None and t.artist == "Muriel Nguyen Xuan" and t.extra["url"].endswith(".mp3")
    assert "classical" in canonical_for(t) and "piano" in canonical_for(t)
    pron = dict(good, title="File:En-us-nocturne.ogg")
    assert p._parse_page(pron) is None
    short = {**good, "videoinfo": [{**good["videoinfo"][0], "duration": 2.0}]}
    assert p._parse_page(short) is None


def test_deezer_is_preview_only():
    p = DeezerProvider(httpx.AsyncClient())
    t = p.parse({"id": 3135556, "readable": True, "title": "Harder", "duration": 224, "rank": 900000, "preview": "https://cdnt-preview.dzcdn.net/x.mp3", "link": "https://www.deezer.com/track/3135556", "artist": {"id": 27, "name": "Daft Punk"}, "album": {"id": 302127, "title": "Discovery", "cover_xl": "https://e-cdns-images.dzcdn.net/x.jpg"}, "type": "track"})
    assert t.stream_kind == "preview" and "превью" in t.license


@pytest.mark.asyncio
async def test_registry_breaker_and_rate_limit():
    async with httpx.AsyncClient() as client:
        reg = Registry(client)
        from app.music.registry import Health

        p = AudiusProvider(client)
        reg.providers["audius"] = p
        reg.health["audius"] = Health()
        with respx.mock() as mock:
            mock.get("https://api.audius.co/v1/tracks/search").mock(return_value=httpx.Response(503))
            for _ in range(3):
                with pytest.raises(ProviderError):
                    await reg.run(p, "search", lambda: p.search("x"))
            assert reg.state_of("audius") == "degraded"
            with pytest.raises(ProviderError) as e:
                await reg.run(p, "search", lambda: p.search("x"))
            assert e.value.kind == "unavailable"
        reg.set_admin_disabled("audius", False)
        assert reg.state_of("audius") == "ok"
        with respx.mock() as mock:
            mock.get("https://api.audius.co/v1/tracks/search").mock(return_value=httpx.Response(429, headers={"Retry-After": "30"}))
            with pytest.raises(ProviderError) as e:
                await reg.run(p, "search", lambda: p.search("y"))
            assert e.value.kind == "rate_limited"
        assert reg.state_of("audius") == "rate_limited"


@pytest.mark.asyncio
async def test_registry_caches_results():
    async with httpx.AsyncClient() as client:
        reg = Registry(client)
        from app.music.registry import Health

        p = AudiusProvider(client)
        reg.providers["audius"] = p
        reg.health["audius"] = Health()
        with respx.mock() as mock:
            route = mock.get("https://api.audius.co/v1/tracks/search").mock(return_value=httpx.Response(200, json={"data": [AUDIUS_TRACK]}))
            for _ in range(3):
                await reg.run(p, "search", lambda: p.search("same"), cache_key="same")
            assert route.call_count == 1
        await asyncio.sleep(0)
