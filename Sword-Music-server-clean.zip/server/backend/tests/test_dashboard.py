"""New integrations are verified against deterministic upstream responses."""
import asyncio

import httpx
import pytest
import respx

from app.config import get_settings
from app.music.metadata import GeniusMetadata, LrclibLyrics, parse_lrc
from app.music.providers.musicbrainz import MusicBrainzProvider
from app.music.providers.youtube_link import YouTubeLinkProvider, video_id


def test_lrc_multiple_timestamps_fraction_and_metadata():
    lines = parse_lrc("[ar:Someone]\n[00:10.25][00:20.5]Hello\n[00:03.002]First\n[00:89]Bad")
    assert lines == [{"time": 3.002, "text": "First"}, {"time": 10.25, "text": "Hello"}, {"time": 20.5, "text": "Hello"}]


@pytest.mark.asyncio
async def test_genius_no_token_links_without_fabricating_lyrics(monkeypatch):
    monkeypatch.setattr(get_settings(), "genius_access_token", "")
    async with httpx.AsyncClient() as client:
        result = await GeniusMetadata(client).find("Song", "Artist")
    assert result["matched"] is False and result["configured"] is False
    assert result["url"].startswith("https://genius.com/search?")
    assert "lyrics" not in result


@pytest.mark.asyncio
@respx.mock
async def test_genius_token_is_server_side_and_wrong_artist_is_rejected(monkeypatch):
    monkeypatch.setattr(get_settings(), "genius_access_token", "server-test-token")
    route = respx.get("https://api.genius.com/search").mock(return_value=httpx.Response(200, json={"response": {"hits": [
        {"result": {"title": "Song", "primary_artist": {"name": "Unrelated Person"}, "url": "https://genius.com/wrong"}}
    ]}}))
    async with httpx.AsyncClient() as client:
        result = await GeniusMetadata(client).find("Song", "Artist")
    assert route.calls[0].request.headers["Authorization"] == "Bearer server-test-token"
    assert result["matched"] is False and "server-test-token" not in str(result)


@pytest.mark.asyncio
@respx.mock
async def test_lrclib_does_not_sync_a_different_recording():
    respx.get("https://lrclib.net/api/get").mock(return_value=httpx.Response(200, json={
        "trackName": "Song", "artistName": "Artist", "duration": 400,
        "syncedLyrics": "[00:01]Wrong version", "plainLyrics": "Wrong version"}))
    async with httpx.AsyncClient() as client:
        result = await LrclibLyrics(client).find("Song", "Artist", None, 180)
    assert not result["synced"] and result["lines"] == []


@pytest.mark.asyncio
@respx.mock
async def test_lrclib_uses_only_real_supplied_timestamps(monkeypatch):
    monkeypatch.setattr(get_settings(), "lyrics_enabled", True)
    respx.get("https://lrclib.net/api/get").mock(return_value=httpx.Response(200, json={
        "trackName": "Song", "artistName": "Artist", "duration": 180,
        "syncedLyrics": "[00:04.5]One line\n[00:10.0]Next line", "plainLyrics": "One line\nNext line"}))
    async with httpx.AsyncClient() as client:
        result = await LrclibLyrics(client).find("Song", "Artist", None, 180)
    assert result["synced"] and result["lines"][0] == {"time": 4.5, "text": "One line"}


@pytest.mark.asyncio
@respx.mock
async def test_genius_returns_attributed_metadata_not_page_text(monkeypatch):
    monkeypatch.setattr(get_settings(), "genius_access_token", "server-test-token")
    song = {"id": 123, "title": "Song", "primary_artist": {"name": "Artist"}, "url": "https://genius.com/artist-song-lyrics"}
    respx.get("https://api.genius.com/search").mock(return_value=httpx.Response(200, json={"response": {"hits": [{"result": song}]}}))
    respx.get("https://api.genius.com/songs/123").mock(return_value=httpx.Response(200, json={"response": {"song": {**song, "album": {"name": "Album"}}}}))
    async with httpx.AsyncClient() as client:
        result = await GeniusMetadata(client).find("Song", "Artist")
    assert result["matched"] and result["album"] == "Album"
    assert result["source"] == "Genius" and "lyrics" not in result


def test_open_catalog_never_claims_to_stream_recordings():
    recording = {"id": "00000000-0000-0000-0000-000000000001", "title": "Recording", "length": 185000,
        "artist-credit": [{"name": "Performer", "artist": {"id": "00000000-0000-0000-0000-000000000002"}}]}
    provider = MusicBrainzProvider(httpx.AsyncClient())
    track = provider.parse(recording)
    assert track.stream_kind == "none" and track.duration == 185
    assert track.artist == "Performer" and track.page_url.startswith("https://musicbrainz.org/recording/")
    assert provider.parse({"id": "../../unsafe"}) is None


def test_dashboard_authentication(client):
    assert client.get("/api/dashboard").status_code == 401


def test_dashboard_empty_state_does_not_fabricate_trends(admin):
    response = admin.get("/api/dashboard")
    assert response.status_code == 200, response.text
    data = response.json()
    assert "weekly" in data and "song_of_month" in data
    if not data["weekly"]:
        assert data["weekly_error"]
    assert "genius_access_token" not in str(data)


def test_lyrics_unknown_recording_is_not_exposed(admin):
    response = admin.get("/api/tracks/no-such-track/lyrics")
    assert response.status_code == 404


def test_youtube_links_reject_other_hosts_and_accept_official_urls():
    assert video_id("https://youtu.be/abcdefghijk?t=20") == "abcdefghijk"
    assert video_id("https://www.youtube.com/watch?v=abcdefghijk") == "abcdefghijk"
    assert video_id("https://youtube.com.evil.example/watch?v=abcdefghijk") is None
    assert video_id("https://user:pass@youtube.com/watch?v=abcdefghijk") is None
    assert video_id("a normal artist search") is None


@pytest.mark.asyncio
@respx.mock
async def test_youtube_link_uses_official_oembed_and_needs_no_search_key():
    respx.get("https://www.youtube.com/oembed").mock(return_value=httpx.Response(200, json={
        "title": "Artist - A Song (Official Video)", "author_name": "Artist", "thumbnail_url": "https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg"}))
    async with httpx.AsyncClient() as client:
        provider = YouTubeLinkProvider(client)
        tracks = await provider.search("https://youtu.be/abcdefghijk")
        stream = await provider.resolve(tracks[0].provider_track_id, {})
    assert tracks[0].stream_kind == "embed" and tracks[0].duration is None
    assert tracks[0].artist == "Artist" and stream.kind == "embed"
