"""The Alembic migration must create exactly the schema described by the models."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]


def test_upgrade_check_downgrade_on_fresh_sqlite(tmp_path):
    env = {
        **os.environ,
        "DATA_DIR": str(tmp_path),
        "DATABASE_URL": f"sqlite+aiosqlite:///{tmp_path}/m.db",
        "SECRET_KEY": "x",
    }
    for args in (["upgrade", "head"], ["check"], ["downgrade", "base"], ["upgrade", "head"]):
        r = subprocess.run([sys.executable, "-m", "alembic", *args], cwd=BACKEND, env=env, capture_output=True, text=True)
        assert r.returncode == 0, r.stderr + r.stdout
