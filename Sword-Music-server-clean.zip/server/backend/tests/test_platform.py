"""Platform glue: Android app links file and installability assets."""
from __future__ import annotations

import json
from pathlib import Path

from app.config import get_settings


def test_android_asset_links(client):
    target = Path(get_settings().data_dir) / "assetlinks.json"
    target.unlink(missing_ok=True)
    r = client.get("/.well-known/assetlinks.json")
    assert r.status_code == 200 and r.json() == []
    links = [{"relation": ["delegate_permission/common.handle_all_urls"], "target": {"namespace": "android_app", "package_name": "music.swordai.app", "sha256_cert_fingerprints": ["AA:BB"]}}]
    target.write_text(json.dumps(links))
    try:
        r = client.get("/.well-known/assetlinks.json")
        assert r.status_code == 200 and r.headers["content-type"].startswith("application/json")
        assert r.json()[0]["target"]["package_name"] == "music.swordai.app"
    finally:
        target.unlink()
