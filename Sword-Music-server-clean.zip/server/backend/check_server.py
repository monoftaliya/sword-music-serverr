"""Dependency-free preflight for Windows launchers. Never stop an occupied port."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import socket
import subprocess
from urllib.request import ProxyHandler, build_opener


def server_state(port: int = 8000) -> str:
    try:
        # Local requests must not go through a system or corporate proxy.
        with build_opener(ProxyHandler({})).open(f"http://127.0.0.1:{port}/api/health", timeout=1.5) as response:
            data = json.loads(response.read(65537))
        providers = data.get("providers") if isinstance(data, dict) else None
        if data.get("ok") is True and isinstance(providers, dict) and {"audius", "uploads", "youtube"} <= providers.keys():
            return "ready"
    except (OSError, ValueError, AttributeError):
        pass
    with socket.socket() as connection:
        connection.settimeout(.5)
        return "busy" if connection.connect_ex(("127.0.0.1", port)) == 0 else "free"


def open_desktop(project: Path) -> None:
    for executable in (project.parent / "Sword Music.exe", project / "desktop/dist/Sword Music-win32-x64/Sword Music.exe"):
        if executable.is_file():
            try:
                subprocess.Popen([str(executable)], cwd=executable.parent)
            except OSError:
                print("Откройте Sword Music.exe и подключитесь к localhost:8000.")
            return


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--open", action="store_true")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args(argv)
    state = server_state(args.port)
    if state == "ready":
        print(f"Sword Music уже работает: http://localhost:{args.port}")
        print("Повторно запускать сервер не нужно.")
        if args.open:
            open_desktop(Path(__file__).resolve().parent.parent)
        return 0
    if state == "busy":
        print(f"Адрес localhost:{args.port} занят другой программой или сервер ещё запускается.")
        print("Работающие программы не остановлены. Попробуйте запустить Sword Music немного позже.")
        return 2
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
