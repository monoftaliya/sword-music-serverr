@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo Вставьте ключ YouTube Data API v3 (правый клик в этом окне) и нажмите Enter:
set /p KEY=
if "%KEY%"=="" (
  echo Ключ не введён.
  pause
  exit /b 1
)
if exist ".env" (
  findstr /v /b "YOUTUBE_API_KEY=" ".env" > ".env.tmp"
  move /y ".env.tmp" ".env" >nul
)
>>".env" echo YOUTUBE_API_KEY=%KEY%
echo.
echo Готово: ключ сохранён в файле .env
echo Теперь перезапустите сервер: закройте его окно и снова запустите start-swordai.bat
pause
