@echo off
call "%~dp0start-sword-music.bat"
exit /b %errorlevel%
