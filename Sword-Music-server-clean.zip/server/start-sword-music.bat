@echo off
chcp 65001 >nul
setlocal
set "PYTHONIOENCODING=utf-8"
title Sword Music
cd /d "%~dp0backend"

set "SWORD_PY="
if exist ".venv\Scripts\python.exe" set "SWORD_PY=.venv\Scripts\python.exe"
if not defined SWORD_PY (
  py -3 --version >nul 2>nul
  if not errorlevel 1 set "SWORD_PY=py -3"
)
if not defined SWORD_PY (
  python --version >nul 2>nul
  if not errorlevel 1 set "SWORD_PY=python"
)
if not defined SWORD_PY (
  echo Не найден Python. Установите Python 3.12 или новее с python.org
  echo и при установке отметьте галочку "Add python.exe to PATH".
  pause
  exit /b 1
)

rem Check before installing dependencies or starting a second server.
%SWORD_PY% check_server.py --open
if errorlevel 2 goto port_busy
if not errorlevel 1 exit /b 0

if not exist ".venv\Scripts\python.exe" (
  echo Первый запуск: устанавливаю Sword Music, это займёт пару минут...
  %SWORD_PY% -m venv .venv
  if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto failed

rem Another window may have finished starting while dependencies were checked.
".venv\Scripts\python.exe" check_server.py --open
if errorlevel 2 goto port_busy
if not errorlevel 1 exit /b 0

echo.
echo Запускаю сервер Sword Music...
echo После сообщения "Uvicorn running" откройте Sword Music.exe.
echo Адрес сервера: http://localhost:8000
echo Чтобы остановить этот сервер, закройте это окно.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8000
if errorlevel 1 goto check_after_exit
echo Сервер остановлен.
pause
exit /b 0

:check_after_exit
".venv\Scripts\python.exe" check_server.py --open
if not errorlevel 1 exit /b 0
echo Не удалось запустить сервер. Подробности указаны выше.
pause
exit /b 1

:port_busy
pause
exit /b 2

:failed
echo Не удалось установить зависимости. Проверьте интернет и запустите файл ещё раз.
pause
exit /b 1
