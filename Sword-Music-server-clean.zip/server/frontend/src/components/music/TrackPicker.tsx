"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { api } from "@/lib/api";
import { usePlayer } from "@/lib/player/store";
import type { Track } from "@/lib/types";
import { Cover } from "../ui/Cover";
import { Dialog } from "../ui/Dialog";
import { RowsSkeleton } from "../ui/controls";
import styles from "./LibraryDialogs.module.css";

/** Pick a track from what the user already knows: now playing, queue, recents, favourites, or a quick search. */
export function TrackPicker({ open, onClose, onPick, title = "Выберите трек", exclude = [] }: { open: boolean; onClose: () => void; onPick: (t: Track) => void; title?: string; exclude?: string[] }) {
  const [filter, setFilter] = useState("");
  const queue = usePlayer((s) => s.queue);
  const recent = useQuery({ queryKey: ["recent"], queryFn: () => api.get<{ items: Track[] }>("/api/library/recent", { limit: 60 }), enabled: open });
  const favs = useQuery({ queryKey: ["favorites", 100], queryFn: () => api.get<{ items: Track[]; total: number }>("/api/library/favorites", { limit: 100 }), enabled: open });
  const term = filter.trim();
  const search = useQuery({
    queryKey: ["picker-search", term],
    queryFn: ({ signal }) => api.get<{ results: Track[] }>("/api/search", { q: term, mode: "text", limit: 20, deep: false }, { signal }),
    enabled: open && term.length >= 3,
  });
  const items = useMemo(() => {
    const all = [...queue, ...(recent.data?.items ?? []), ...(favs.data?.items ?? []), ...(search.data?.results ?? [])];
    const seen = new Set<string>(exclude);
    const f = term.toLowerCase();
    return all.filter((t) => {
      if (seen.has(t.id)) return false;
      seen.add(t.id);
      return !f || t.title.toLowerCase().includes(f) || t.artist.toLowerCase().includes(f) || (search.data?.results ?? []).some((r) => r.id === t.id);
    });
  }, [queue, recent.data, favs.data, search.data, term, exclude]);
  return (
    <Dialog open={open} onClose={onClose} title={title} width={520}>
      <input className="input" placeholder="Фильтр или поиск по названию" value={filter} onChange={(e) => setFilter(e.target.value)} style={{ marginBottom: 14 }} />
      {(recent.isLoading || favs.isLoading) && <RowsSkeleton rows={4} />}
      {!recent.isLoading && items.length === 0 && <p className="t-small">Ничего не нашлось. Послушайте что-нибудь или найдите трек в поиске.</p>}
      <ul className={styles.list}>
        {items.slice(0, 80).map((t) => (
          <li key={t.id}>
            <button
              className={styles.item}
              onClick={() => {
                onPick(t);
                onClose();
              }}
            >
              <Cover src={t.artwork_small} seed={t.id} size={42} radius={9} />
              <span className={styles.meta}>
                <span className="clamp1">{t.title}</span>
                <span className="t-tiny clamp1">{t.artist}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </Dialog>
  );
}
