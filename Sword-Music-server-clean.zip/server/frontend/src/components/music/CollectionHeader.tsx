"use client";

import type { ReactNode } from "react";
import styles from "./CollectionHeader.module.css";

/** Header for playlist / album / artist pages: artwork left, large title, quiet meta, actions. */
export function CollectionHeader({
  art,
  kicker,
  title,
  meta,
  description,
  actions,
  round,
}: {
  art: ReactNode;
  kicker?: string;
  title: string;
  meta?: ReactNode;
  description?: string;
  actions?: ReactNode;
  round?: boolean;
}) {
  return (
    <header className={styles.head} data-round={round || undefined}>
      <div className={styles.art}>{art}</div>
      <div className={styles.text}>
        {kicker && <span className="t-small">{kicker}</span>}
        <h1 className={styles.title}>{title}</h1>
        {description && <p className={styles.desc}>{description}</p>}
        {meta && <div className={styles.meta}>{meta}</div>}
        {actions && <div className={styles.actions}>{actions}</div>}
      </div>
    </header>
  );
}
