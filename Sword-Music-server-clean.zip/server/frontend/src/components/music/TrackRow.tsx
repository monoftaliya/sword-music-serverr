"use client";

import { Heart, Play } from "lucide-react";
import Link from "next/link";
import { memo, type CSSProperties, type ReactNode } from "react";
import { duration } from "@/lib/format";
import { toggleLike, useLiked } from "@/lib/likes";
import { useLostTracks } from "@/lib/player/store";
import type { Track } from "@/lib/types";
import { artistHref } from "@/lib/ui";
import { Cover } from "../ui/Cover";
import { PlayingBars } from "./PlayingBars";
import { TrackMenu, type TrackMenuExtra } from "./TrackMenu";
import styles from "./TrackRow.module.css";

interface Props {
  track: Track;
  index?: number;
  active?: boolean;
  playing?: boolean;
  onPlay: () => void;
  context: string;
  showTags?: boolean;
  showSource?: boolean;
  reason?: string | null;
  extra?: TrackMenuExtra[];
  /** animation state managed by TrackList: undefined = no animation */
  reveal?: "pending" | "shown" | "static";
  revealIndex?: number;
  leading?: ReactNode;
}

function TrackRowBase({
  track,
  active,
  playing,
  onPlay,
  context,
  showTags = true,
  showSource = true,
  reason,
  extra,
  reveal = "static",
  revealIndex = 0,
  leading,
}: Props) {
  const liked = useLiked(track);
  const lost = useLostTracks((s) => s.ids[track.id]);
  const unavailable = !track.playable || !!lost;
  const alts = track.alternatives?.length ?? 0;
  return (
    <div
      className={styles.row}
      data-active={active || undefined}
      data-unavailable={unavailable || undefined}
      data-reveal={reveal}
      style={{ "--i": revealIndex } as CSSProperties}
      onClick={(e) => {
        if ((e.target as HTMLElement).closest("a,button")) return;
        if (!track.playable) return;
        onPlay();
      }}
      onDoubleClick={(e) => e.preventDefault()}
    >
      {leading}
      <button
        className={styles.coverBtn}
        onClick={onPlay}
        disabled={!track.playable}
        aria-label={`${active && playing ? "Сейчас играет" : "Слушать"}: ${track.title} — ${track.artist}`}
      >
        <Cover src={track.artwork_small || track.artwork} seed={track.id} size={46} radius={10} className={styles.cover} />
        <span className={styles.coverOverlay} data-visible={active || undefined}>
          {active && playing ? <PlayingBars /> : <Play size={18} fill="currentColor" />}
        </span>
      </button>

      <div className={styles.main}>
        <div className={styles.titleLine}>
          <span className={`${styles.title} clamp1`}>{track.title}</span>
          {track.provider === "spotify_link" && <span className="badge badge-preview">версию определяет Spotify</span>}
          {track.stream === "preview" && !unavailable && <span className="badge badge-preview">превью 30 с</span>}
          {unavailable && <span className="badge badge-off">{track.stream === "none" ? "каталог · без аудио" : "недоступен"}</span>}
        </div>
        <div className={styles.sub}>
          {track.artist ? <Link href={artistHref(track)} className={`${styles.artist} clamp1`} onClick={(e) => e.stopPropagation()}>
            {track.artist}
          </Link> : <span className="t-tiny">{track.provider === "spotify_link" ? "Spotify" : "Исполнитель не указан"}</span>}
          {reason && <span className={`${styles.reason} clamp1`}>{reason}</span>}
          {track.stream === "none" && <a className="t-tiny" href={`https://www.youtube.com/results?search_query=${encodeURIComponent(`${track.artist} ${track.title}`)}`} target="_blank" rel="noopener noreferrer">Найти на YouTube ↗</a>}
        </div>
      </div>

      {showTags && track.tags.length > 0 && (
        <div className={styles.tags}>
          {track.tags.slice(0, 2).map((t) => (
            <span key={t.key} className="chip chip-tag">
              {t.label}
            </span>
          ))}
        </div>
      )}

      {showSource && (
        <span className={styles.source} title={track.license ? `${track.source}, ${track.license}` : track.source}>
          {track.source}
          {alts > 0 && <span className={styles.alts}>+{alts}</span>}
        </span>
      )}

      <span className={`${styles.time} num`}>{duration(track.duration)}</span>

      <button
        className={`icon-btn icon-btn-sm ${styles.like}`}
        data-active={liked}
        aria-pressed={liked}
        aria-label={liked ? "Убрать из избранного" : "Добавить в избранное"}
        onClick={() => void toggleLike(track, context)}
      >
        <Heart size={17} fill={liked ? "currentColor" : "none"} />
      </button>

      <TrackMenu track={track} context={context} extra={extra} />
    </div>
  );
}

export const TrackRow = memo(TrackRowBase);
