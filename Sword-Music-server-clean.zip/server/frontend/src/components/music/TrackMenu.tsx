"use client";

import {
  Ban,
  CornerDownRight,
  Copy,
  Disc3,
  Dna,
  Ellipsis,
  ExternalLink,
  Infinity as InfinityIcon,
  ListEnd,
  ListPlus,
  Mic,
  Minus,
  Plus,
  Trash2,
} from "lucide-react";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { api, errorMessage } from "@/lib/api";
import { usePlayer } from "@/lib/player/store";
import { toast } from "@/lib/toast";
import type { Track } from "@/lib/types";
import { albumHref, artistHref, useDialogs } from "@/lib/ui";
import { Menu, type MenuEntry } from "../ui/Menu";

export interface TrackMenuExtra {
  label: string;
  icon?: ReactNode;
  onSelect: () => void;
  danger?: boolean;
}

export async function sendFeedback(track: Track, kind: "more" | "less" | "exclude_artist" | "dislike", context: string) {
  try {
    const res = await api.post<{ tags?: string[]; artist?: string; note?: string }>("/api/wave/feedback", { track_id: track.id, kind, context });
    if (kind === "more") toast.success("Больше такого", res.tags?.length ? `Усилим: ${res.tags.join(", ")}` : res.note);
    if (kind === "less") toast.success("Меньше такого звучания", res.tags?.length ? `Ослабим: ${res.tags.join(", ")}` : res.note);
    if (kind === "exclude_artist") toast.success("Исполнитель исключён", `${track.artist} больше не попадёт в рекомендации.`);
    if (kind === "dislike") toast.info("Не нравится", "Учтём это в рекомендациях.");
  } catch (err) {
    toast.error("Не удалось сохранить оценку", errorMessage(err));
  }
}

export function TrackMenu({ track, context, extra }: { track: Track; context: string; extra?: TrackMenuExtra[] }) {
  const router = useRouter();
  const items = (): MenuEntry[] => {
    const p = usePlayer.getState();
    const inWave = context.startsWith("wave") || context.startsWith("mode");
    const album = albumHref(track);
    const list: MenuEntry[] = [
      { label: "Играть следующим", icon: <CornerDownRight size={16} />, onSelect: () => p.playNext(track), disabled: !track.playable || !!p.controller },
      { label: "Добавить в очередь", icon: <ListEnd size={16} />, onSelect: () => p.addToQueue(track), disabled: !track.playable || !!p.controller },
      { label: "Добавить в плейлист", icon: <ListPlus size={16} />, onSelect: () => useDialogs.getState().openAddToPlaylist([track]) },
      "separator",
      { label: "Исполнитель", icon: <Mic size={16} />, onSelect: () => router.push(artistHref(track)) },
    ];
    if (album) list.push({ label: "Альбом", icon: <Disc3 size={16} />, onSelect: () => router.push(album) });
    list.push(
      { label: "Music DNA", icon: <Dna size={16} />, onSelect: () => router.push(`/dna/?track=${encodeURIComponent(track.id)}`) },
      { label: "Infinite Descent отсюда", icon: <InfinityIcon size={16} />, onSelect: () => router.push(`/descent/?center=${encodeURIComponent(track.id)}`) },
      { label: "Другие версии", icon: <Copy size={16} />, onSelect: () => useDialogs.getState().openAlternatives(track) },
    );
    if (track.page_url) {
      list.push({ label: `Открыть на ${track.source}`, icon: <ExternalLink size={16} />, onSelect: () => window.open(track.page_url!, "_blank", "noopener") });
    }
    list.push("separator", { heading: inWave ? "Настроить волну" : "Рекомендации" });
    list.push(
      { label: "Больше такого", icon: <Plus size={16} />, onSelect: () => void sendFeedback(track, "more", context) },
      { label: "Меньше такого звучания", icon: <Minus size={16} />, onSelect: () => void sendFeedback(track, "less", context) },
      { label: "Исключить исполнителя", icon: <Ban size={16} />, onSelect: () => void sendFeedback(track, "exclude_artist", context), danger: true },
    );
    if (extra?.length) {
      list.push("separator");
      for (const e of extra) list.push({ label: e.label, icon: e.icon ?? <Trash2 size={16} />, onSelect: e.onSelect, danger: e.danger });
    }
    return list;
  };
  return (
    <Menu
      items={items}
      trigger={(props) => (
        <button {...props} className="icon-btn icon-btn-sm" aria-label={`Действия: ${track.title}`}>
          <Ellipsis size={18} />
        </button>
      )}
    />
  );
}
