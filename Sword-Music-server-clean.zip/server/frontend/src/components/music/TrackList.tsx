"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePlayer } from "@/lib/player/store";
import { useMotionLevel } from "@/lib/settings";
import { collectionKey } from "@/lib/dashboard";
import type { Track } from "@/lib/types";
import type { TrackMenuExtra } from "./TrackMenu";
import { TrackRow } from "./TrackRow";
import styles from "./TrackList.module.css";

interface Props {
  tracks: Track[];
  context: string;
  /** play the whole list starting from the clicked track (default) or only that track */
  playMode?: "list" | "single";
  showTags?: boolean;
  showSource?: boolean;
  showReasons?: boolean;
  animate?: boolean;
  extras?: (t: Track, index: number) => TrackMenuExtra[] | undefined;
  numbered?: boolean;
  onPlay?: (t: Track, index: number) => void;
}

/**
 * Rows materialise from the dark when they first become visible: rows visible at
 * mount rise one after another with a short stagger; rows reached later by
 * scrolling rise once and never re-animate.
 */
export function TrackList(props: Props) {
  const level = useMotionLevel();
  const [displayed, setDisplayed] = useState(props.tracks);
  const [phase, setPhase] = useState("stable");
  const [revision, setRevision] = useState(0);
  const wrapper = useRef<HTMLDivElement>(null);
  const previous = useRef(collectionKey(props.tracks.map((t) => t.id)));
  const latest = useRef(props.tracks);
  latest.current = props.tracks;
  const fingerprint = collectionKey(props.tracks.map((t) => t.id));

  useEffect(() => {
    const oldKey = previous.current;
    if (fingerprint === oldKey) {
      setDisplayed(latest.current); setPhase("stable");
      if (wrapper.current) wrapper.current.style.minHeight = "";
      return;
    }
    previous.current = fingerprint;
    const oldIds = new Set(oldKey.split("\u001f"));
    const shared = latest.current.filter((t) => oldIds.has(t.id)).length;
    // Incremental search results preserve existing rows; only a replaced collection exits.
    if (level !== "full" || props.animate === false || !oldKey || shared >= oldIds.size * 0.5) {
      setDisplayed(latest.current); setPhase("stable");
      if (wrapper.current) wrapper.current.style.minHeight = "";
      return;
    }
    if (wrapper.current) wrapper.current.style.minHeight = `${wrapper.current.getBoundingClientRect().height}px`;
    setPhase("leaving");
    const change = window.setTimeout(() => {
      setDisplayed(latest.current); setRevision((value) => value + 1); setPhase("arriving");
    }, 140);
    const finish = window.setTimeout(() => {
      setPhase("stable");
      if (wrapper.current) wrapper.current.style.minHeight = "";
    }, 700);
    return () => { window.clearTimeout(change); window.clearTimeout(finish); };
  }, [fingerprint, level, props.animate]);

  // Likes and metadata updates do not replay collection animations.
  const shown = collectionKey(displayed.map((t) => t.id)) === fingerprint && phase === "stable" ? props.tracks : displayed;
  return <div ref={wrapper} className={styles.collection} data-phase={phase}>
    <TrackListRows key={revision} {...props} tracks={shown} />
  </div>;
}

function TrackListRows({
  tracks,
  context,
  playMode = "list",
  showTags = true,
  showSource = true,
  showReasons = true,
  animate = true,
  extras,
  numbered,
  onPlay,
}: Props) {
  const motion = useMotionLevel();
  const current = usePlayer((s) => s.queue[s.order[s.pos]]?.id ?? null);
  const status = usePlayer((s) => s.status);
  const playList = usePlayer((s) => s.playList);
  const toggle = usePlayer((s) => s.toggle);
  const listRef = useRef<HTMLOListElement>(null);
  const [shown, setShown] = useState<Record<string, number>>({});
  const doAnimate = animate && motion !== "off";

  const playable = useMemo(() => tracks.filter((t) => t.playable), [tracks]);

  const handlePlay = useCallback(
    (t: Track, i: number) => {
      if (onPlay) return onPlay(t, i);
      if (t.id === current) return toggle();
      if (playMode === "single" || !t.playable) {
        playList([t], 0, context);
        return;
      }
      const idx = playable.findIndex((x) => x.id === t.id);
      playList(playable, Math.max(0, idx), context);
    },
    [onPlay, current, toggle, playMode, playList, playable, context],
  );

  useEffect(() => {
    if (!doAnimate || !listRef.current) return;
    const io = new IntersectionObserver(
      (entries) => {
        const fresh = entries.filter((e) => e.isIntersecting).map((e) => (e.target as HTMLElement).dataset.key!);
        if (!fresh.length) return;
        setShown((prev) => {
          const next = { ...prev };
          let k = 0;
          for (const key of fresh) {
            if (next[key] === undefined) next[key] = Math.min(k++, 12);
          }
          return next;
        });
        entries.forEach((e) => e.isIntersecting && io.unobserve(e.target));
      },
      { rootMargin: "0px 0px -4% 0px", threshold: 0.01 },
    );
    listRef.current.querySelectorAll<HTMLElement>("[data-key]").forEach((el) => {
      if (shown[el.dataset.key!] === undefined) io.observe(el);
    });
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tracks, doAnimate]);

  const seen = new Map<string, number>();
  return (
    <ol className={styles.list} ref={listRef}>
      {tracks.map((t, i) => {
        // keyed by track, not position: when more results arrive, rows already shown stay put
        const n = seen.get(t.id) ?? 0;
        seen.set(t.id, n + 1);
        const key = n ? `${t.id}#${n}` : t.id;
        const rev = !doAnimate ? "static" : shown[key] === undefined ? "pending" : "shown";
        return (
          <li key={key} data-key={key} className={styles.item}>
            <TrackRow
              track={t}
              index={i}
              active={t.id === current}
              playing={t.id === current && (status === "playing" || status === "loading")}
              onPlay={() => handlePlay(t, i)}
              context={context}
              showTags={showTags}
              showSource={showSource}
              reason={showReasons ? t.reason : null}
              extra={extras?.(t, i)}
              reveal={rev}
              revealIndex={shown[key] ?? 0}
              leading={numbered ? <span className={`${styles.num} num`}>{i + 1}</span> : undefined}
            />
          </li>
        );
      })}
    </ol>
  );
}
