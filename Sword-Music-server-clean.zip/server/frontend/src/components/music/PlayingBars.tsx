import styles from "./PlayingBars.module.css";

/** Small "now playing" indicator. Purely decorative — it is not an audio analyser. */
export function PlayingBars({ paused = false }: { paused?: boolean }) {
  return (
    <span className={styles.bars} data-paused={paused || undefined} aria-hidden>
      <span />
      <span />
      <span />
    </span>
  );
}
