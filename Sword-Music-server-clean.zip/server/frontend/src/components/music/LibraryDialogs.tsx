"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Plus } from "lucide-react";
import { useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { count } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import { toast } from "@/lib/toast";
import type { PlaylistSummary, Track } from "@/lib/types";
import { useDialogs } from "@/lib/ui";
import { Cover } from "../ui/Cover";
import { Dialog } from "../ui/Dialog";
import { EmptyState, RowsSkeleton, Spinner } from "../ui/controls";
import styles from "./LibraryDialogs.module.css";

export function AddToPlaylistDialog() {
  const tracks = useDialogs((s) => s.addToPlaylist);
  const close = useDialogs((s) => s.close);
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [done, setDone] = useState<string | null>(null);
  const open = !!tracks;
  const { data, isLoading } = useQuery({
    queryKey: ["playlists"],
    queryFn: () => api.get<{ playlists: PlaylistSummary[] }>("/api/playlists"),
    enabled: open,
  });
  const add = useMutation({
    mutationFn: async (pl: { id: string; name: string }) => {
      const res = await api.post<{ added: number; skipped: number }>(`/api/playlists/${pl.id}/tracks`, { track_ids: tracks!.map((t) => t.id) });
      return { ...res, pl };
    },
    onSuccess: ({ added, pl }) => {
      setDone(pl.id);
      void qc.invalidateQueries({ queryKey: ["playlists"] });
      void qc.invalidateQueries({ queryKey: ["playlist", pl.id] });
      toast.success(added ? `Добавлено в «${pl.name}»` : `Уже есть в «${pl.name}»`);
      setTimeout(() => {
        setDone(null);
        close();
      }, 450);
    },
    onError: (err) => toast.error("Не удалось добавить", errorMessage(err)),
  });
  const create = useMutation({
    mutationFn: () => api.post<PlaylistSummary>("/api/playlists", { name: name.trim() }),
    onSuccess: (pl) => {
      setName("");
      add.mutate({ id: pl.id, name: pl.name });
    },
    onError: (err) => toast.error("Не удалось создать плейлист", errorMessage(err)),
  });
  const what = tracks?.length === 1 ? `«${tracks[0].title}»` : tracks ? count(tracks.length, ["трек", "трека", "треков"]) : "";
  return (
    <Dialog open={open} onClose={close} title="Добавить в плейлист" description={what}>
      <form
        className={styles.create}
        onSubmit={(e) => {
          e.preventDefault();
          if (name.trim()) create.mutate();
        }}
      >
        <input className="input" placeholder="Новый плейлист" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} />
        <button className="btn btn-primary" disabled={!name.trim() || create.isPending}>
          {create.isPending ? <Spinner size={16} /> : <Plus size={16} />}
          Создать
        </button>
      </form>
      {isLoading && <RowsSkeleton rows={3} />}
      {data && data.playlists.length === 0 && <EmptyState title="Пока нет плейлистов" text="Создайте первый — трек сразу окажется в нём." />}
      <ul className={styles.list}>
        {data?.playlists.map((pl) => (
          <li key={pl.id}>
            <button className={styles.item} onClick={() => add.mutate({ id: pl.id, name: pl.name })} disabled={add.isPending}>
              <Cover src={pl.cover ?? pl.mosaic[0]} seed={pl.id} size={44} radius={10} />
              <span className={styles.meta}>
                <span className="clamp1">{pl.name}</span>
                <span className="t-tiny">{count(pl.track_count, ["трек", "трека", "треков"])}</span>
              </span>
              {done === pl.id && <Check size={18} className={styles.check} />}
            </button>
          </li>
        ))}
      </ul>
    </Dialog>
  );
}

export function AlternativesDialog() {
  const track = useDialogs((s) => s.alternatives);
  const close = useDialogs((s) => s.close);
  const playList = usePlayer((s) => s.playList);
  const { data, isLoading, error } = useQuery({
    queryKey: ["alternatives", track?.id],
    queryFn: () => api.get<{ alternatives: Track[] }>(`/api/tracks/${encodeURIComponent(track!.id)}/alternatives`),
    enabled: !!track,
  });
  const fromSearch = track?.alternatives ?? [];
  const merged = [...fromSearch, ...(data?.alternatives ?? [])].filter((t, i, arr) => arr.findIndex((x) => x.id === t.id) === i);
  return (
    <Dialog open={!!track} onClose={close} title="Другие версии" description={track ? `${track.artist} — ${track.title}` : ""} width={520}>
      {isLoading && <RowsSkeleton rows={3} />}
      {error && <p className="t-small">{errorMessage(error)}</p>}
      {!isLoading && merged.length === 0 && (
        <EmptyState title="Других версий не нашлось" text="В подключённых источниках нет другой доступной записи этой композиции." />
      )}
      <ul className={styles.list}>
        {merged.map((t) => (
          <li key={t.id}>
            <button
              className={styles.item}
              disabled={!t.playable}
              onClick={() => {
                playList([t], 0, "alternatives");
                close();
              }}
            >
              <Cover src={t.artwork_small} seed={t.id} size={44} radius={10} />
              <span className={styles.meta}>
                <span className="clamp1">{t.title}</span>
                <span className="t-tiny">
                  {t.source}
                  {t.stream === "preview" ? ", превью 30 с" : ""}
                  {!t.playable ? ", недоступен" : ""}
                </span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </Dialog>
  );
}
