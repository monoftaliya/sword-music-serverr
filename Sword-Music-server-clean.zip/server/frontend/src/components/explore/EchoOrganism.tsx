"use client";

import { useEffect, useRef, useState } from "react";
import { getMotion } from "@/lib/settings";
import type { EchoLobe } from "@/lib/types";
import styles from "./EchoOrganism.module.css";

interface Live {
  key: string;
  label: string;
  angle: number;
  r: number;
  share: number;
  color: [number, number, number];
  ta: number;
  tr: number;
  ts: number;
}

function hsl(h: number, s: number, l: number): [number, number, number] {
  s /= 100;
  l /= 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
}

/** Colour of a tag from its place in mood space: dark→violet, intense→magenta/red, calm→teal, bright→gold. */
function tagColor(v: number, e: number): [number, number, number] {
  let hue: number;
  if (v < -0.2) hue = e > 0.6 ? 335 : 265;
  else if (v > 0.35) hue = e > 0.6 ? 28 : 44;
  else hue = e > 0.6 ? 300 : e < 0.3 ? 188 : 222;
  return hsl(hue, 72, 60);
}

function layout(lobes: EchoLobe[]): { key: string; label: string; angle: number; share: number; color: [number, number, number] }[] {
  const items = lobes.map((l) => ({
    key: l.key,
    label: l.label,
    angle: Math.atan2(-(l.e - 0.5) * 2, l.v === 0 ? 0.001 : l.v),
    share: l.weight,
    color: tagColor(l.v, l.e),
  }));
  items.sort((a, b) => a.angle - b.angle);
  // relax angles so neighbouring lobes never overlap
  const min = Math.min(0.7, (Math.PI * 2) / Math.max(items.length, 1) * 0.75);
  for (let it = 0; it < 30; it++) {
    for (let i = 0; i < items.length; i++) {
      const a = items[i];
      const b = items[(i + 1) % items.length];
      let d = b.angle - a.angle;
      if (i === items.length - 1) d += Math.PI * 2;
      if (d < min && items.length > 1) {
        const push = (min - d) / 2;
        a.angle -= push;
        b.angle += push;
      }
    }
  }
  return items;
}

export function EchoOrganism({ lobes, energy = 0.5, diversity = 0.5 }: { lobes: EchoLobe[]; energy?: number; diversity?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const live = useRef<Live[]>([]);
  const params = useRef({ energy, diversity });
  const [hover, setHover] = useState<{ x: number; y: number; label: string; share: number } | null>(null);
  const tips = useRef<{ x: number; y: number; label: string; share: number }[]>([]);

  useEffect(() => {
    params.current = { energy, diversity };
    const maxShare = Math.max(...lobes.map((l) => l.weight), 0.0001);
    const next = layout(lobes);
    const map = new Map(live.current.map((l) => [l.key, l]));
    const out: Live[] = [];
    for (const n of next) {
      const tr = 0.42 + (n.share / maxShare) * 0.58;
      const ex = map.get(n.key);
      if (ex) {
        ex.ta = n.angle;
        ex.tr = tr;
        ex.ts = n.share;
        ex.color = n.color;
        out.push(ex);
        map.delete(n.key);
      } else {
        out.push({ key: n.key, label: n.label, angle: n.angle, r: 0, share: 0, color: n.color, ta: n.angle, tr, ts: n.share });
      }
    }
    for (const gone of map.values()) {
      gone.tr = 0;
      gone.ts = 0;
      out.push(gone);
    }
    live.current = out;
  }, [lobes, energy, diversity]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let w = 0;
    let h = 0;
    let dpr = 1;
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = r.width;
      h = r.height;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    let t = 0;
    let raf = 0;
    let last = performance.now();
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (document.hidden) return;
      const motion = getMotion();
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const { energy: en, diversity: dv } = params.current;
      if (motion !== "off") t += dt * (0.25 + en * 0.6) * (motion === "reduced" ? 0.3 : 1);
      const k = 1 - Math.exp(-dt * 2.4);
      live.current = live.current.filter((l) => l.tr > 0 || l.r > 0.01);
      for (const l of live.current) {
        let da = l.ta - l.angle;
        while (da > Math.PI) da -= Math.PI * 2;
        while (da < -Math.PI) da += Math.PI * 2;
        l.angle += da * k;
        l.r += (l.tr - l.r) * k;
        l.share += (l.ts - l.share) * k;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const cx = w / 2;
      const cy = h / 2;
      const R = Math.min(w, h) * 0.36;
      const lobesNow = [...live.current].sort((a, b) => a.angle - b.angle);
      tips.current = [];
      if (!lobesNow.length) {
        ctx.strokeStyle = "rgba(244,245,250,0.12)";
        ctx.setLineDash([3, 6]);
        ctx.beginPath();
        ctx.arc(cx, cy, R * 0.5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        return;
      }
      // radius function around the circle: smooth bumps at lobe angles
      const radiusAt = (th: number, scale: number) => {
        let r = 0.36;
        for (const l of lobesNow) {
          let d = th - l.angle;
          while (d > Math.PI) d -= Math.PI * 2;
          while (d < -Math.PI) d += Math.PI * 2;
          const width = 0.42 + dv * 0.25;
          r = Math.max(r, 0.32 + l.r * Math.exp(-(d * d) / (2 * width * width)));
        }
        const wob = 0.03 * Math.sin(th * 3 + t * 1.3) + 0.02 * Math.sin(th * 5 - t * 0.9) * dv;
        return R * (r + wob) * scale;
      };
      // fill: blended colours of the strongest lobes
      const top = [...lobesNow].sort((a, b) => b.share - a.share);
      const c1 = top[0]?.color ?? [139, 92, 255];
      const c2 = top[1]?.color ?? c1;
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.25);
      grad.addColorStop(0, `rgba(${c1[0]},${c1[1]},${c1[2]},0.32)`);
      grad.addColorStop(0.6, `rgba(${c2[0]},${c2[1]},${c2[2]},0.12)`);
      grad.addColorStop(1, "rgba(8,9,13,0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      const N = 180;
      for (let j = 0; j <= N; j++) {
        const th = (j / N) * Math.PI * 2 - Math.PI;
        const r = radiusAt(th, 1);
        const x = cx + Math.cos(th) * r;
        const y = cy + Math.sin(th) * r;
        if (j === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      // topographic contour lines
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < 9; i++) {
        const s = 1 - i * 0.095;
        const col = i % 2 ? c2 : c1;
        ctx.strokeStyle = `rgba(${col[0]},${col[1]},${col[2]},${(0.5 - i * 0.04).toFixed(3)})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let j = 0; j <= N; j++) {
          const th = (j / N) * Math.PI * 2 - Math.PI;
          const r = radiusAt(th + Math.sin(t * 0.4 + i) * 0.02, s);
          const x = cx + Math.cos(th) * r;
          const y = cy + Math.sin(th) * r;
          if (j === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.stroke();
      }
      ctx.globalCompositeOperation = "source-over";
      for (const l of lobesNow) {
        if (l.tr <= 0) continue;
        const rr = radiusAt(l.angle, 1) + 14;
        tips.current.push({ x: cx + Math.cos(l.angle) * rr, y: cy + Math.sin(l.angle) * rr, label: l.label, share: l.ts });
        ctx.fillStyle = `rgba(${l.color[0]},${l.color[1]},${l.color[2]},0.9)`;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(l.angle) * (rr - 14), cy + Math.sin(l.angle) * (rr - 14), 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    raf = requestAnimationFrame(frame);
    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      let best: (typeof tips.current)[number] | null = null;
      let bd = 50 * 50;
      for (const tip of tips.current) {
        const d = (tip.x - x) ** 2 + (tip.y - y) ** 2;
        if (d < bd) {
          bd = d;
          best = tip;
        }
      }
      setHover(best);
    };
    const onLeave = () => setHover(null);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerleave", onLeave);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  const sorted = [...lobes].sort((a, b) => b.weight - a.weight);
  return (
    <div className={styles.wrap}>
      <canvas ref={canvasRef} className={styles.canvas} aria-hidden />
      {hover && (
        <span className={styles.tip} style={{ left: hover.x, top: hover.y }}>
          {hover.label} <span className="num">{Math.round(hover.share * 100)}%</span>
        </span>
      )}
      <ul className="sr-only">
        {sorted.map((l) => (
          <li key={l.key}>
            {l.label}: {Math.round(l.weight * 100)}%
          </li>
        ))}
      </ul>
    </div>
  );
}
