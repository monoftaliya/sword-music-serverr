"use client";

import { useEffect, useRef } from "react";
import { getMotion } from "@/lib/settings";

type Style = "void" | "rage" | "ego" | "oblivion" | "ascension" | "afterdark";

function hex(c: string): [number, number, number] {
  const h = c.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/**
 * A living field with its own visual grammar for each AFTER DARK mode:
 * VOID sinks, RAGE fractures, EGO radiates, OBLIVION dissolves, ASCENSION rises,
 * AFTER DARK drifts like city lights in rain. Pure decoration — selection logic is server-side.
 */
export function ModeField({ mode, colors, className }: { mode: string; colors: [string, string, string]; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const state = useRef({ mode: mode as Style, colors });
  useEffect(() => {
    state.current = { mode: mode as Style, colors };
  }, [mode, colors]);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let w = 0;
    let h = 0;
    let dpr = 1;
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = r.width;
      h = r.height;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    const seeds = Array.from({ length: 90 }, (_, i) => ({ a: Math.random(), b: Math.random(), c: Math.random(), i }));
    let t = 0;
    let fade = 0;
    let shown = state.current.mode;
    let raf = 0;
    let last = performance.now();
    let c1 = hex(state.current.colors[0]);
    let c2 = hex(state.current.colors[1]);
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (document.hidden) return;
      const motion = getMotion();
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (motion === "off") {
        if (fade >= 1) return;
      } else t += dt * (motion === "reduced" ? 0.25 : 1);
      const st = state.current;
      if (st.mode !== shown) {
        fade -= dt * 2.2; // fade out the old field, then switch
        if (fade <= 0) {
          shown = st.mode;
          fade = 0;
        }
      } else fade = Math.min(1, fade + dt * 1.1);
      const k = 1 - Math.exp(-dt * 2);
      const t1 = hex(st.colors[0]);
      const t2 = hex(st.colors[1]);
      c1 = c1.map((v, i) => v + (t1[i] - v) * k) as [number, number, number];
      c2 = c2.map((v, i) => v + (t2[i] - v) * k) as [number, number, number];
      const col = (c: number[], a: number) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${(a * fade).toFixed(3)})`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const cx = w * 0.5;
      const cy = h * 0.5;
      const S = Math.min(w, h);
      ctx.globalCompositeOperation = "lighter";
      ctx.lineWidth = 1;
      switch (shown) {
        case "void": {
          for (let i = 0; i < 18; i++) {
            const p = ((i / 18 + t * 0.03) % 1);
            const r = S * (0.05 + p * 0.55);
            ctx.strokeStyle = col(i % 2 ? c1 : c2, 0.28 * Math.sin(p * Math.PI));
            ctx.beginPath();
            ctx.ellipse(cx, cy + S * 0.04, r, r * 0.42, 0, 0, Math.PI * 2);
            ctx.stroke();
          }
          const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, S * 0.22);
          g.addColorStop(0, `rgba(0,0,0,${0.9 * fade})`);
          g.addColorStop(1, "rgba(0,0,0,0)");
          ctx.globalCompositeOperation = "source-over";
          ctx.fillStyle = g;
          ctx.fillRect(0, 0, w, h);
          break;
        }
        case "rage": {
          for (const s of seeds.slice(0, 46)) {
            const ang = s.a * Math.PI * 2 + t * (0.2 + s.b * 0.4);
            const pulse = Math.pow(Math.max(0, Math.sin(t * 5.2 + s.i)), 6);
            const r0 = S * (0.08 + s.c * 0.1);
            const r1 = r0 + S * (0.18 + pulse * 0.28) * s.b;
            ctx.strokeStyle = col(s.i % 3 ? c1 : c2, 0.25 + pulse * 0.5);
            ctx.beginPath();
            ctx.moveTo(cx + Math.cos(ang) * r0, cy + Math.sin(ang) * r0);
            const mid = (r0 + r1) / 2;
            ctx.lineTo(cx + Math.cos(ang + 0.06) * mid, cy + Math.sin(ang + 0.06) * mid);
            ctx.lineTo(cx + Math.cos(ang) * r1, cy + Math.sin(ang) * r1);
            ctx.stroke();
          }
          break;
        }
        case "ego": {
          for (let i = 0; i < 64; i++) {
            const ang = (i / 64) * Math.PI * 2 + t * 0.05;
            const len = S * (0.3 + 0.12 * Math.sin(i * 1.7 + t * 0.8));
            const g = ctx.createLinearGradient(cx, cy, cx + Math.cos(ang) * len, cy + Math.sin(ang) * len);
            g.addColorStop(0, col(c1, 0.0));
            g.addColorStop(0.35, col(c1, 0.35));
            g.addColorStop(1, col(c2, 0));
            ctx.strokeStyle = g;
            ctx.beginPath();
            ctx.moveTo(cx + Math.cos(ang) * S * 0.07, cy + Math.sin(ang) * S * 0.07);
            ctx.lineTo(cx + Math.cos(ang) * len, cy + Math.sin(ang) * len);
            ctx.stroke();
          }
          ctx.fillStyle = col(c1, 0.5);
          ctx.beginPath();
          ctx.arc(cx, cy, S * 0.045, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "oblivion": {
          for (const s of seeds) {
            const x = (s.a + Math.sin(t * 0.05 + s.i) * 0.03) * w;
            const y = (s.b + Math.cos(t * 0.04 + s.i * 0.7) * 0.03) * h;
            const r = S * (0.03 + s.c * 0.09) * (1 + 0.2 * Math.sin(t * 0.3 + s.i));
            const g = ctx.createRadialGradient(x, y, 0, x, y, r);
            g.addColorStop(0, col(s.i % 2 ? c1 : c2, 0.07));
            g.addColorStop(1, col(c2, 0));
            ctx.fillStyle = g;
            ctx.fillRect(x - r, y - r, r * 2, r * 2);
          }
          break;
        }
        case "ascension": {
          for (const s of seeds.slice(0, 60)) {
            const x = s.a * w;
            const y = h - (((s.b + t * (0.04 + s.c * 0.06)) % 1) * (h + 120)) + 60;
            const len = 20 + s.c * 90;
            const g = ctx.createLinearGradient(x, y, x, y + len);
            g.addColorStop(0, col(c1, 0.55));
            g.addColorStop(1, col(c2, 0));
            ctx.strokeStyle = g;
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x, y + len);
            ctx.stroke();
          }
          break;
        }
        default: {
          // after dark: bokeh of distant lights + diagonal rain
          for (const s of seeds.slice(0, 34)) {
            const x = (s.a + t * 0.004 * (s.c - 0.5)) % 1 * w;
            const y = (0.35 + s.b * 0.5) * h;
            const r = 6 + s.c * 26;
            const g = ctx.createRadialGradient(x, y, 0, x, y, r);
            g.addColorStop(0, col(s.i % 3 ? c1 : c2, 0.22 + 0.1 * Math.sin(t + s.i)));
            g.addColorStop(1, col(c1, 0));
            ctx.fillStyle = g;
            ctx.fillRect(x - r, y - r, r * 2, r * 2);
          }
          ctx.strokeStyle = col([200, 210, 255], 0.08);
          for (const s of seeds.slice(34)) {
            const x = ((s.a + t * 0.05) % 1) * w;
            const y = ((s.b + t * (0.5 + s.c)) % 1) * h;
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x - 6, y + 18);
            ctx.stroke();
          }
        }
      }
      ctx.globalCompositeOperation = "source-over";
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return <canvas ref={ref} className={className} aria-hidden style={{ display: "block", width: "100%", height: "100%" }} />;
}
