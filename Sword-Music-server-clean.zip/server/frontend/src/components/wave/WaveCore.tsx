"use client";

import { useEffect, useRef } from "react";
import { getIntensity, getMotion } from "@/lib/settings";
import styles from "./WaveCore.module.css";

export type WaveMode = "flow" | "void" | "chaos";

interface Params {
  rings: number;
  spread: number;
  amp: number;
  speed: number;
  twist: number;
  jitter: number;
  core: number; // >0 glowing core, <0 dark void core
  warm: number; // 0..1 shift towards warm hues (CHAOS)
  desat: number; // 0..1 (SHADOW lens)
  harmonics: [number, number, number, number];
}

const MODES: Record<WaveMode, Params> = {
  flow: { rings: 22, spread: 0.0125, amp: 0.055, speed: 0.22, twist: 0.018, jitter: 0, core: 0.9, warm: 0, desat: 0, harmonics: [2, 3, 5, 0] },
  void: { rings: 15, spread: 0.019, amp: 0.032, speed: 0.1, twist: 0, jitter: 0, core: -0.8, warm: 0, desat: 0.25, harmonics: [1, 2, 3, 0] },
  chaos: { rings: 26, spread: 0.0105, amp: 0.1, speed: 0.42, twist: 0.075, jitter: 0.35, core: 0.6, warm: 0.85, desat: 0, harmonics: [3, 5, 7, 11] },
};

interface Props {
  mode: WaveMode;
  lens?: "main" | "shadow";
  energy?: number | null;
  bpm?: number | null;
  playing?: boolean;
  trackKey?: string | null;
  className?: string;
}

type RGB = [number, number, number];

function parseColor(v: string, fb: RGB): RGB {
  const c = v.trim();
  if (c.startsWith("#") && (c.length === 7 || c.length === 4)) {
    const h = c.length === 4 ? c.slice(1).split("").map((x) => x + x).join("") : c.slice(1);
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  const m = c.match(/[\d.]+/g);
  return m && m.length >= 3 ? [Number(m[0]), Number(m[1]), Number(m[2])] : fb;
}

const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const mixRgb = (a: RGB, b: RGB, k: number): RGB => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const grey = (c: RGB, k: number): RGB => {
  const l = c[0] * 0.3 + c[1] * 0.59 + c[2] * 0.11;
  return mixRgb(c, [l, l, l], k);
};
const rgba = (c: RGB, a: number) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a.toFixed(3)})`;

/**
 * The My Wave core: a liquid form made of thin contour lines. Shape, motion and
 * colour respond to the wave mode, the cover palette, the track's energy and its
 * BPM *from metadata* (the pulse is a tempo-driven breath, not audio analysis).
 */
export function WaveCore({ mode, lens = "main", energy, bpm, playing = false, trackKey, className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const target = useRef({ mode, lens, energy: energy ?? 0.5, bpm: bpm ?? null, playing });
  const burst = useRef(0);

  useEffect(() => {
    target.current = { mode, lens, energy: energy ?? 0.5, bpm: bpm ?? null, playing };
  }, [mode, lens, energy, bpm, playing]);

  useEffect(() => {
    burst.current = 1;
  }, [trackKey]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let w = 0;
    let h = 0;
    let dpr = 1;
    const small = window.matchMedia("(max-width: 860px)").matches;
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, small ? 1.5 : 2);
      w = Math.max(10, r.width);
      h = Math.max(10, r.height);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const p: Params = { ...MODES[target.current.mode], harmonics: [...MODES[target.current.mode].harmonics] as Params["harmonics"] };
    let hCur = [...p.harmonics] as Params["harmonics"];
    let hPrev = hCur;
    let hMix = 1;
    let accent: RGB = [139, 92, 255];
    let glow: RGB = [92, 141, 255];
    let targetAccent = accent;
    let targetGlow = glow;
    const warmA: RGB = [255, 92, 138];
    const warmB: RGB = [255, 181, 71];
    let colorClock = 1;
    let t = 0;
    let appear = 0;
    let amp = 0.6;
    let pulsePhase = 0;
    let visible = true;
    let pointer = { x: 0, y: 0, k: 0 };
    let raf = 0;
    let last = performance.now();

    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting));
    io.observe(canvas);
    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      pointer = { x: (e.clientX - r.left) / r.width - 0.5, y: (e.clientY - r.top) / r.height - 0.5, k: 1 };
    };
    const onLeave = () => (pointer.k = 0);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerleave", onLeave);

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const motion = getMotion();
      const intensity = getIntensity();
      const still = motion === "off";
      const slow = motion === "reduced";
      if (!visible || document.hidden) {
        last = now;
        return;
      }
      if ((still || slow) && now - last < (still ? 600 : 80)) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const tg = target.current;
      const goal = MODES[tg.mode];
      const k = 1 - Math.exp(-dt * 2.2); // ~1.5 s to settle: modes morph, never jump

      p.rings = lerp(p.rings, goal.rings * (small ? 0.75 : 1) * (intensity === "minimal" ? 0.7 : 1), k);
      p.spread = lerp(p.spread, goal.spread, k);
      p.speed = lerp(p.speed, goal.speed, k);
      p.twist = lerp(p.twist, goal.twist, k);
      p.jitter = lerp(p.jitter, goal.jitter, k);
      p.core = lerp(p.core, tg.lens === "shadow" ? -Math.abs(goal.core) - 0.2 : goal.core, k);
      p.warm = lerp(p.warm, goal.warm, k);
      p.desat = lerp(p.desat, tg.lens === "shadow" ? 0.75 : goal.desat, k);
      // Harmonics must stay integers or the closed contour gets a seam: crossfade whole sets instead.
      if (goal.harmonics.some((v, i) => v !== hCur[i])) {
        hPrev = hCur;
        hCur = [...goal.harmonics] as Params["harmonics"];
        hMix = 0;
      }
      hMix = Math.min(1, hMix + dt / 1.4);
      const energyAmp = 0.65 + Math.max(0, Math.min(1, tg.energy)) * 0.8;
      const playAmp = tg.playing ? 1 : 0.55;
      amp = lerp(amp, goal.amp * energyAmp * playAmp, k);
      p.amp = amp;

      if ((colorClock += dt) > 0.5) {
        colorClock = 0;
        const cs = getComputedStyle(document.documentElement);
        targetAccent = parseColor(cs.getPropertyValue("--dyn-accent"), accent);
        targetGlow = parseColor(cs.getPropertyValue("--dyn-glow"), glow);
      }
      accent = mixRgb(accent, targetAccent, k);
      glow = mixRgb(glow, targetGlow, k);
      let cA = mixRgb(accent, warmA, p.warm * 0.7);
      let cB = mixRgb(glow, warmB, p.warm * 0.6);
      cA = grey(cA, p.desat);
      cB = grey(cB, p.desat * 0.9);

      if (!still) t += dt * p.speed * (tg.playing ? 1 : 0.35) * (slow ? 0.4 : 1);
      appear = Math.min(1, appear + dt / 1.6);
      const ease = 1 - Math.pow(1 - appear, 3);
      burst.current = Math.max(0, burst.current - dt / 1.3);

      // tempo-driven breath from metadata BPM (fallback: slow 0.4 Hz breathing)
      const hz = tg.bpm && tg.bpm > 40 ? tg.bpm / 60 / (tg.bpm > 125 ? 2 : 1) : 0.4;
      if (!still && tg.playing) pulsePhase += dt * hz * Math.PI * 2;
      const beat = tg.playing && !slow ? Math.pow(Math.max(0, Math.sin(pulsePhase)), 10) : 0;

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const size = Math.min(w, h);
      const cx = w / 2 + pointer.x * size * 0.04 * pointer.k;
      const cy = h / 2 + pointer.y * size * 0.04 * pointer.k;
      const R = size * 0.27 * (0.7 + 0.3 * ease) * (1 + beat * 0.012 + burst.current * 0.03);

      // core light (or a dark void with a cold rim)
      const coreR = R * 1.35;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR);
      if (p.core >= 0) {
        g.addColorStop(0, rgba(cA, 0.34 * p.core * ease));
        g.addColorStop(0.45, rgba(cB, 0.14 * p.core * ease));
        g.addColorStop(1, rgba(cB, 0));
      } else {
        const d = -p.core;
        g.addColorStop(0, `rgba(4,5,8,${(0.85 * d * ease).toFixed(3)})`);
        g.addColorStop(0.62, `rgba(4,5,8,${(0.55 * d * ease).toFixed(3)})`);
        g.addColorStop(0.8, rgba(cB, 0.16 * d * ease));
        g.addColorStop(1, rgba(cB, 0));
      }
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, coreR, 0, Math.PI * 2);
      ctx.fill();

      const rings = Math.max(4, Math.round(p.rings));
      const pts = small ? 96 : 150;
      const mixK = hMix * hMix * (3 - 2 * hMix);
      const deform = (H: Params["harmonics"], th: number, i: number, a: number, rot: number) => {
        let d =
          a * 0.55 * Math.sin(H[0] * th + t * 1.3 + i * 0.21 + rot) +
          a * 0.3 * Math.sin(H[1] * th - t * 0.9 + i * 0.37) +
          a * 0.18 * Math.sin(H[2] * th + t * 1.7 - i * 0.13);
        if (H[3] > 0) d += a * 0.12 * Math.sin(H[3] * th - t * 2.3 + i);
        return d;
      };
      ctx.lineWidth = 1;
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < rings; i++) {
        const ringT = i / (rings - 1);
        const shown = Math.max(0, Math.min(1, ease * 1.4 - ringT * 0.5));
        if (shown <= 0) continue;
        const base = R * (0.52 + ringT * 0.95) + i * size * p.spread * 0.15;
        const a = size * p.amp * (0.35 + ringT * 0.9) * (1 + burst.current * 0.9);
        const rot = t * 0.25 + i * p.twist;
        const col = mixRgb(cA, cB, ringT);
        const alpha = (0.55 - ringT * 0.4) * shown * (p.core < 0 ? 0.85 : 1) + beat * 0.08 * (1 - ringT);
        ctx.strokeStyle = rgba(col, Math.max(0.03, alpha));
        ctx.beginPath();
        for (let j = 0; j <= pts; j++) {
          const th = (j / pts) * Math.PI * 2;
          let r = base + (mixK >= 1 ? deform(hCur, th, i, a, rot) : lerp(deform(hPrev, th, i, a, rot), deform(hCur, th, i, a, rot), mixK));
          if (p.jitter > 0.01) r += a * p.jitter * 0.25 * Math.sin(th * 23 + t * 6 + i * 3.1) * Math.sin(t * 1.9 + i);
          const x = cx + Math.cos(th) * r;
          const y = cy + Math.sin(th) * r * 0.92;
          if (j === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.stroke();
      }
      // SHADOW lens: a faint ghost of the form, offset like a cast shadow
      if (p.desat > 0.5) {
        ctx.strokeStyle = rgba(cB, 0.08 * (p.desat - 0.5) * 2 * ease);
        ctx.beginPath();
        for (let j = 0; j <= pts; j++) {
          const th = (j / pts) * Math.PI * 2;
          const r = R * 1.1 + size * p.amp * 0.6 * Math.sin(2 * th - t);
          const x = cx + size * 0.03 + Math.cos(th) * r;
          const y = cy + size * 0.04 + Math.sin(th) * r * 0.92;
          if (j === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      ctx.globalCompositeOperation = "source-over";
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  return <canvas ref={canvasRef} className={`${styles.canvas} ${className ?? ""}`} aria-hidden />;
}
