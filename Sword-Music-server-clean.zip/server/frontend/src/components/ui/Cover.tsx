"use client";

import { useState } from "react";
import { proceduralColors } from "@/lib/palette";
import styles from "./Cover.module.css";

interface Props {
  src: string | null | undefined;
  seed: string;
  size?: number | string;
  radius?: number;
  alt?: string;
  className?: string;
  priority?: boolean;
  round?: boolean;
}

/** Artwork with a soft load-in and a deterministic gradient when the source has no image. */
export function Cover({ src, seed, size = 48, radius, alt = "", className, priority, round }: Props) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [c1, c2, angle] = proceduralColors(seed);
  const dim = typeof size === "number" ? `${size}px` : size;
  const showImg = src && !failed;
  return (
    <span
      className={`${styles.cover} ${className ?? ""}`}
      style={{
        width: dim,
        height: typeof size === "number" ? dim : "auto",
        aspectRatio: "1 / 1",
        borderRadius: round ? "50%" : radius !== undefined ? radius : undefined,
        background: `linear-gradient(${angle}deg, ${c1}, ${c2})`,
      }}
      aria-hidden={alt ? undefined : true}
    >
      {!showImg && <span className={styles.mark} />}
      {showImg && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={src}
          alt={alt}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          draggable={false}
          referrerPolicy="no-referrer"
          className={styles.img}
          data-loaded={loaded}
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
        />
      )}
    </span>
  );
}
