"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import styles from "./Menu.module.css";

export interface MenuItem {
  label: string;
  icon?: ReactNode;
  onSelect: () => void;
  danger?: boolean;
  disabled?: boolean;
  hint?: string;
}

export type MenuEntry = MenuItem | "separator" | { heading: string };

interface Props {
  trigger: (props: { onClick: (e: React.MouseEvent) => void; "aria-expanded": boolean; "aria-haspopup": "menu" }) => ReactNode;
  items: MenuEntry[] | (() => MenuEntry[]);
  align?: "start" | "end";
}

export function Menu({ trigger, items, align = "end" }: Props) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ x: number; y: number; up: boolean }>({ x: 0, y: 0, up: false });
  const anchor = useRef<HTMLElement | null>(null);
  const menu = useRef<HTMLDivElement>(null);
  const list = typeof items === "function" ? (open ? items() : []) : items;

  const close = useCallback(() => setOpen(false), []);

  const onClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    anchor.current = e.currentTarget as HTMLElement;
    setOpen((v) => !v);
  };

  useLayoutEffect(() => {
    if (!open || !anchor.current) return;
    const r = anchor.current.getBoundingClientRect();
    const h = menu.current?.offsetHeight ?? 260;
    const w = menu.current?.offsetWidth ?? 240;
    const up = r.bottom + h + 12 > window.innerHeight && r.top - h - 12 > 0;
    let x = align === "end" ? r.right - w : r.left;
    x = Math.max(8, Math.min(x, window.innerWidth - w - 8));
    setPos({ x, y: up ? r.top - h - 6 : r.bottom + 6, up });
  }, [open, align]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (menu.current?.contains(e.target as Node) || anchor.current?.contains(e.target as Node)) return;
      close();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        close();
        anchor.current?.focus();
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const items = Array.from(menu.current?.querySelectorAll<HTMLButtonElement>("button:not([disabled])") ?? []);
        const i = items.indexOf(document.activeElement as HTMLButtonElement);
        const next = e.key === "ArrowDown" ? (i + 1) % items.length : (i - 1 + items.length) % items.length;
        items[next]?.focus();
      }
    };
    const onScroll = () => close();
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    window.addEventListener("resize", onScroll);
    document.addEventListener("scroll", onScroll, true);
    setTimeout(() => menu.current?.querySelector<HTMLButtonElement>("button:not([disabled])")?.focus(), 20);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onScroll);
      document.removeEventListener("scroll", onScroll, true);
    };
  }, [open, close]);

  return (
    <>
      {trigger({ onClick, "aria-expanded": open, "aria-haspopup": "menu" })}
      {typeof document !== "undefined" &&
        createPortal(
          <AnimatePresence>
            {open && (
              <motion.div
                ref={menu}
                role="menu"
                className={styles.menu}
                style={{ left: pos.x, top: pos.y }}
                initial={{ opacity: 0, y: pos.up ? 6 : -6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, transition: { duration: 0.12 } }}
                transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                onClick={(e) => e.stopPropagation()}
              >
                {list.map((it, i) => {
                  if (it === "separator") return <div key={i} className={styles.sep} />;
                  if ("heading" in it) return <div key={i} className={styles.heading}>{it.heading}</div>;
                  return (
                    <button
                      key={i}
                      role="menuitem"
                      className={styles.item}
                      data-danger={it.danger || undefined}
                      disabled={it.disabled}
                      onClick={() => {
                        close();
                        it.onSelect();
                      }}
                    >
                      <span className={styles.icon}>{it.icon}</span>
                      <span className={styles.label}>{it.label}</span>
                      {it.hint && <span className={styles.hint}>{it.hint}</span>}
                    </button>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>,
          document.body,
        )}
    </>
  );
}
