"use client";

import { motion } from "framer-motion";
import { LoaderCircle } from "lucide-react";
import { useCallback, useId, useRef, type ReactNode } from "react";
import styles from "./controls.module.css";

/* ----------------------------------------------------------------- Segmented */
interface SegOption<T extends string> {
  value: T;
  label: ReactNode;
  hint?: string;
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  size = "md",
  label,
}: {
  options: SegOption<T>[];
  value: T;
  onChange: (v: T) => void;
  size?: "sm" | "md";
  label: string;
}) {
  const id = useId();
  return (
    <div className={styles.seg} data-size={size} role="tablist" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.value}
          role="tab"
          aria-selected={o.value === value}
          title={o.hint}
          className={styles.segItem}
          data-active={o.value === value}
          onClick={() => onChange(o.value)}
        >
          {o.value === value && (
            <motion.span layoutId={`seg-${id}`} className={styles.segPill} transition={{ type: "spring", stiffness: 520, damping: 42 }} />
          )}
          <span className={styles.segLabel}>{o.label}</span>
        </button>
      ))}
    </div>
  );
}

/* ----------------------------------------------------------------- Switch */
export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      className={styles.switch}
      data-on={checked}
      onClick={() => onChange(!checked)}
    >
      <span className={styles.knob} />
    </button>
  );
}

/* ----------------------------------------------------------------- Slider */
export function Slider({
  value,
  min = 0,
  max = 1,
  step = 0.01,
  onChange,
  onCommit,
  label,
  className,
  format,
}: {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (v: number) => void;
  onCommit?: (v: number) => void;
  label: string;
  className?: string;
  format?: (v: number) => string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const pct = max > min ? ((value - min) / (max - min)) * 100 : 0;

  const fromEvent = useCallback(
    (clientX: number) => {
      const r = ref.current?.getBoundingClientRect();
      if (!r) return value;
      const p = Math.max(0, Math.min(1, (clientX - r.left) / r.width));
      const raw = min + p * (max - min);
      return Math.round(raw / step) * step;
    },
    [min, max, step, value],
  );

  return (
    <div
      ref={ref}
      className={`${styles.slider} ${className ?? ""}`}
      role="slider"
      tabIndex={0}
      aria-label={label}
      aria-valuemin={min}
      aria-valuemax={max}
      aria-valuenow={value}
      aria-valuetext={format ? format(value) : undefined}
      onPointerDown={(e) => {
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        onChange(fromEvent(e.clientX));
      }}
      onPointerMove={(e) => {
        if (e.buttons !== 1) return;
        onChange(fromEvent(e.clientX));
      }}
      onPointerUp={(e) => onCommit?.(fromEvent(e.clientX))}
      onKeyDown={(e) => {
        const d = e.key === "ArrowRight" || e.key === "ArrowUp" ? step : e.key === "ArrowLeft" || e.key === "ArrowDown" ? -step : 0;
        if (!d) return;
        e.preventDefault();
        const v = Math.max(min, Math.min(max, value + d * (e.shiftKey ? 5 : 1)));
        onChange(v);
        onCommit?.(v);
      }}
    >
      <div className={styles.track}>
        <div className={styles.fill} style={{ width: `${pct}%` }} />
      </div>
      <div className={styles.thumb} style={{ left: `${pct}%` }} />
    </div>
  );
}

/* ----------------------------------------------------------------- misc */
export function Spinner({ size = 18, label = "Загрузка" }: { size?: number; label?: string }) {
  return <LoaderCircle size={size} className="spin" aria-label={label} role="status" />;
}

export function EmptyState({ icon, title, text, action }: { icon?: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className={styles.empty}>
      {icon && <div className={styles.emptyIcon}>{icon}</div>}
      <div className={styles.emptyTitle}>{title}</div>
      {text && <p className={styles.emptyText}>{text}</p>}
      {action && <div className={styles.emptyAction}>{action}</div>}
    </div>
  );
}

export function ErrorState({ text, onRetry }: { text: string; onRetry?: () => void }) {
  return (
    <div className={styles.error} role="alert">
      <span>{text}</span>
      {onRetry && (
        <button className="btn btn-quiet btn-sm" onClick={onRetry}>
          Повторить
        </button>
      )}
    </div>
  );
}

export function RowsSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <div className={styles.skel} aria-hidden>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className={styles.skelRow} style={{ opacity: 1 - i * (0.8 / rows) }}>
          <div className="skeleton" style={{ width: 48, height: 48, borderRadius: 10 }} />
          <div style={{ flex: 1, display: "grid", gap: 8 }}>
            <div className="skeleton" style={{ width: `${46 + ((i * 17) % 30)}%`, height: 12 }} />
            <div className="skeleton" style={{ width: `${22 + ((i * 11) % 18)}%`, height: 10 }} />
          </div>
        </div>
      ))}
    </div>
  );
}
