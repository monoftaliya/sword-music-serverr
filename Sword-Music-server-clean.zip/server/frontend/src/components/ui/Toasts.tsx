"use client";

import { AnimatePresence, motion } from "framer-motion";
import { CircleAlert, CircleCheck, Info, X } from "lucide-react";
import { useToasts } from "@/lib/toast";
import styles from "./Toasts.module.css";

const ICONS = { info: Info, success: CircleCheck, error: CircleAlert };

export function Toasts() {
  const toasts = useToasts((s) => s.toasts);
  const dismiss = useToasts((s) => s.dismiss);
  return (
    <div className={styles.stack} aria-live="polite" aria-atomic="false">
      <AnimatePresence initial={false}>
        {toasts.map((t) => {
          const Icon = ICONS[t.kind];
          return (
            <motion.div
              key={t.id}
              layout
              className={styles.toast}
              data-kind={t.kind}
              role={t.kind === "error" ? "alert" : "status"}
              initial={{ opacity: 0, y: 16, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, transition: { duration: 0.18 } }}
              transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
            >
              <Icon size={18} className={styles.icon} />
              <div className={styles.text}>
                <div className={styles.title}>{t.title}</div>
                {t.message && <div className={styles.message}>{t.message}</div>}
              </div>
              {t.action && (
                <button
                  className={styles.action}
                  onClick={() => {
                    t.action?.run();
                    dismiss(t.id);
                  }}
                >
                  {t.action.label}
                </button>
              )}
              <button className={styles.close} aria-label="Скрыть уведомление" onClick={() => dismiss(t.id)}>
                <X size={15} />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
