"use client";
import { ExternalLink, Radio, Link2 } from "lucide-react";
import { useState } from "react";
import { EXTERNAL_SOURCES, isTrackLink, VERSIONS, type Version } from "@/lib/music-sources";
import styles from "./SourceExplorer.module.css";

const ARTISTS = {
  ru: ["kizaru", "PHARAOH", "OG BUDA", "GONE.Fludd", "Miyagi", "Скриптонит", "Boulevard Depo", "SALUKI", "Big Baby Tape", "Friendly Thug 52 NGG"],
  west: ["Playboi Carti", "Travis Scott", "Kendrick Lamar", "A$AP Rocky", "Future", "21 Savage", "Lil Uzi Vert", "Don Toliver", "Yeat", "Juice WRLD"],
};
export function SourceExplorer({ query, version, onVersion, source, onSource, onSearch }: {
  query: string; version: Version; onVersion: (v: Version) => void;
  source: string; onSource: (v: string) => void; onSearch: (q: string) => void;
}) {
  const [scene, setScene] = useState<"ru" | "west">("ru");
  const link = isTrackLink(query);
  return <section className={styles.panel} aria-label="Источники и версии музыки">
    <div className={styles.heading}><Radio size={18} /><strong>Музыка без границ</strong><span>Русский рэп · западный рэп · ремиксы</span></div>
    <div className={styles.versions} role="group" aria-label="Версия трека">
      {VERSIONS.map((v) => <button key={v.id} className="chip" aria-pressed={version === v.id} data-active={version === v.id} disabled={link} onClick={() => onVersion(v.id)}>{v.label}</button>)}
    </div>
    <div className={styles.filter}>
      <label htmlFor="music-source">Искать в приложении</label>
      <select id="music-source" value={source} onChange={(e) => onSource(e.target.value)}>
        <option value="">Все подключённые источники</option>
        <option value="audius">Audius · полные записи</option>
        <option value="archive">Internet Archive · открытые записи</option>
        <option value="wikimedia">Wikimedia Commons · открытые записи</option>
        <option value="jamendo">Jamendo · нужен ключ источника</option>
        <option value="youtube">YouTube · нужен ключ поиска</option>
        <option value="itunes">iTunes · каталог без аудио</option>
        <option value="musicbrainz">MusicBrainz · каталог без аудио</option>
        <option value="deezer">Deezer · превью, если включён</option>
      </select>
    </div>
    <p className={styles.hint}><Link2 size={14} />Вставьте полную ссылку на трек YouTube, SoundCloud или Spotify в строку поиска. Spotify может дать только фрагмент.</p>
    {!link && query.trim() && <div className={styles.external}>
      <span>Открыть поиск на сайте</span>
      {EXTERNAL_SOURCES.map((s) => <a key={s.id} href={s.search(query)} target="_blank" rel="noopener noreferrer">{s.name}<ExternalLink size={12} /></a>)}
    </div>}
    <details className={styles.artists} open={!query.trim()}>
      <summary>Исполнители — быстрый поиск</summary>
      <div className={styles.scenes} role="group" aria-label="Музыкальная сцена">
        <button onClick={() => setScene("ru")} aria-pressed={scene === "ru"}>Русские</button>
        <button onClick={() => setScene("west")} aria-pressed={scene === "west"}>Зарубежные</button>
      </div>
      <div className={styles.names}>{ARTISTS[scene].map((artist) => <button key={artist} className="chip" onClick={() => onSearch(artist)}>{artist}</button>)}</div>
      <p className={styles.hint}>Это примеры запросов. Можно ввести любого исполнителя; состав записей зависит от источника.</p>
    </details>
  </section>;
}
