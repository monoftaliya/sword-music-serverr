"use client";

import { useEffect, useRef } from "react";
import { getIntensity, getMotion } from "@/lib/settings";

/** Very faint motes drifting upward, like dust in a beam of light. Focus makes them a touch brighter. */
export function Particles({ focused, className }: { focused: boolean; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const focus = useRef(focused);
  useEffect(() => {
    focus.current = focused;
  }, [focused]);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let w = 0;
    let h = 0;
    let dpr = 1;
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      w = r.width;
      h = r.height;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    const count = window.matchMedia("(max-width: 860px)").matches ? 28 : 56;
    const motes = Array.from({ length: count }, () => ({
      x: Math.random(),
      y: Math.random(),
      z: 0.3 + Math.random() * 0.7,
      s: 0.4 + Math.random() * 1.3,
      tw: Math.random() * Math.PI * 2,
    }));
    let glow = 0;
    let raf = 0;
    let last = performance.now();
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const motion = getMotion();
      if (motion === "off" || getIntensity() === "minimal" || document.hidden) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        return;
      }
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      glow += ((focus.current ? 1 : 0) - glow) * (1 - Math.exp(-dt * 3));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const speed = motion === "reduced" ? 0.15 : 1;
      for (const m of motes) {
        m.y -= dt * 0.012 * m.z * speed;
        m.x += Math.sin(now / 4000 + m.tw) * dt * 0.002 * speed;
        m.tw += dt * 0.6;
        if (m.y < -0.02) {
          m.y = 1.02;
          m.x = Math.random();
        }
        const a = (0.06 + 0.1 * m.z) * (0.6 + 0.4 * Math.sin(m.tw)) * (1 + glow * 0.9);
        ctx.fillStyle = `rgba(200, 205, 255, ${a.toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(m.x * w, m.y * h, m.s * m.z, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return <canvas ref={ref} className={className} aria-hidden style={{ width: "100%", height: "100%", display: "block" }} />;
}
