"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { LogoMark } from "../layout/Logo";
import styles from "./AuthFrame.module.css";

export function AuthFrame({ title, lead, children, footer }: { title: string; lead?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  return (
    <motion.section
      className={styles.frame}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className={styles.brand}>
        <LogoMark size={34} />
        <span className={styles.brandName}>Sword Music</span>
      </div>
      <h1 className={styles.title}>{title}</h1>
      {lead && <p className={styles.lead}>{lead}</p>}
      <div className="edge-line" data-lit="true" style={{ margin: "26px 0 28px" }} />
      {children}
      {footer && <div className={styles.footer}>{footer}</div>}
    </motion.section>
  );
}

export function FormError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p className={styles.error} role="alert">
      {message}
    </p>
  );
}
