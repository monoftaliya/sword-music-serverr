"use client";

import { useQuery } from "@tanstack/react-query";
import { ExternalLink, Mic2, RotateCw, Droplet } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/api";
import { activeLyric, type LyricsData } from "@/lib/dashboard";
import { useCurrentTrack, usePlayer } from "@/lib/player/store";
import { useMotionLevel } from "@/lib/settings";
import styles from "./dashboard.module.css";

export function LyricsPanel() {
  const track = useCurrentTrack();
  const position = usePlayer((s) => s.position);
  const seek = usePlayer((s) => s.seek);
  const motion = useMotionLevel();
  const [crimson, setCrimson] = useState(false);
  const [follow, setFollow] = useState(true);
  const [preferenceReady, setPreferenceReady] = useState(false);
  const active = useRef<HTMLButtonElement | null>(null);
  const scroller = useRef<HTMLDivElement | null>(null);
  const lyrics = useQuery({ queryKey: ["lyrics", track?.id], enabled: !!track,
    queryFn: ({ signal }) => api.get<LyricsData>(`/api/tracks/${encodeURIComponent(track!.id)}/lyrics`, undefined, { signal }),
    staleTime: 60 * 60_000, retry: 1 });
  const lines = lyrics.data?.lyrics.lines ?? [];
  const index = activeLyric(lines, position);

  useEffect(() => {
    try { setCrimson(localStorage.getItem("sword:crimson-lyrics") === "true"); } catch { /* Storage is optional. */ }
    setPreferenceReady(true);
  }, []);
  useEffect(() => { if (preferenceReady) { try { localStorage.setItem("sword:crimson-lyrics", String(crimson)); } catch { /* Storage is optional. */ } } }, [crimson, preferenceReady]);
  useEffect(() => { setFollow(true); if (scroller.current) scroller.current.scrollTop = 0; }, [track?.id]);
  useEffect(() => {
    if (!follow || !active.current || !scroller.current) return;
    const box = scroller.current;
    const relative = active.current.offsetTop;
    box.scrollTo({ top: Math.max(0, relative - box.clientHeight * 0.35), behavior: motion === "full" ? "smooth" : "instant" });
  }, [index, follow, motion]);

  const text = lyrics.data?.lyrics;
  return <section className={`${styles.panel} ${styles.lyricsPanel}`} aria-label="Текст песни">
    <div className={styles.panelHead}>
      <h2>Текст песни</h2>
      <div className={styles.lyricActions}>
        {lines.length > 0 && <button className="icon-btn icon-btn-sm" aria-label="Багровый акцент строки" aria-pressed={crimson} onClick={() => setCrimson(!crimson)} title="Багровый акцент строки"><Droplet size={14} /></button>}
        <a href={lyrics.data?.genius.url ?? `https://genius.com/search?q=${encodeURIComponent(track ? `${track.artist} ${track.title}` : "")}`} target="_blank" rel="noopener noreferrer" className={styles.geniusLink}>Genius <ExternalLink size={11} /></a>
      </div>
    </div>
    {!track && <div className={styles.lyricsEmpty}><Mic2 size={27} strokeWidth={1.2} /><p>У каждой песни<br />есть свои слова.</p><span>Выберите трек — текст появится здесь.</span></div>}
    {track && lyrics.isPending && <div className={styles.lyricSkeleton} aria-label="Загружаем текст">{[82, 66, 92, 74, 87, 56].map((w, i) => <i key={i} style={{ width: `${w}%` }} />)}</div>}
    {track && lyrics.isError && <div className={styles.lyricsEmpty}><p>Не удалось загрузить текст.</p><button className="btn btn-quiet btn-sm" onClick={() => void lyrics.refetch()}><RotateCw size={14} />Повторить</button></div>}
    {track && lyrics.data && <>
      <div className={styles.lyricTrack}><strong>{track.title}</strong><span>{track.artist}</span></div>
      <div ref={scroller} className={styles.lyricScroll} onWheel={() => setFollow(false)} onTouchMove={() => setFollow(false)} data-crimson={crimson || undefined}>
        {lines.length > 0 ? lines.map((line, i) => <button key={`${line.time}:${i}`} ref={i === index ? active : undefined} className={styles.lyricLine} data-current={i === index || undefined} data-past={i < index || undefined} onClick={() => { seek(line.time); setFollow(true); }} aria-current={i === index ? "true" : undefined}>{line.text}</button>)
          : text?.plain ? <p className={styles.plainLyrics}>{text.plain}</p>
          : <div className={styles.lyricsEmpty}><Mic2 size={25} strokeWidth={1.2} /><p>{text?.instrumental ? "Только музыка. Без слов." : "Текст пока не найден."}</p><span>{text?.instrumental ? "Источник пометил запись как инструментальную." : "Проверьте страницу песни на Genius."}</span></div>}
      </div>
      <div className={styles.lyricFooter}>
        <span>{lines.length ? "Синхронизация · LRCLIB" : text?.plain ? "LRCLIB · без синхронизации" : lyrics.data.genius.matched ? "Метаданные · Genius" : "Поиск текста · Genius"}</span>
        {lines.length > 0 && !follow && <button onClick={() => setFollow(true)}>К текущей строке</button>}
      </div>
    </>}
  </section>;
}
