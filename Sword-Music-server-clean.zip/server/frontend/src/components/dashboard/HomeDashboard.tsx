"use client";

import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, AudioLines, Disc3, Heart, Headphones, Music2, Pause, Play, Search, Settings2, Shuffle, Users, Waves } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { TrackList } from "@/components/music/TrackList";
import { Cover } from "@/components/ui/Cover";
import { ErrorState, RowsSkeleton } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import type { DashboardData } from "@/lib/dashboard";
import { duration, greeting } from "@/lib/format";
import { toggleLike, useLiked } from "@/lib/likes";
import { useCurrentTrack, usePlayer } from "@/lib/player/store";
import type { HomeData, RecResponse, Track } from "@/lib/types";
import { albumHref, artistHref } from "@/lib/ui";
import { LyricsPanel } from "./LyricsPanel";
import styles from "./dashboard.module.css";

function Waveform({ playing = false, small = false }: { playing?: boolean; small?: boolean }) {
  return <span className={styles.waveform} data-playing={playing || undefined} data-small={small || undefined} aria-hidden="true">{Array.from({ length: small ? 22 : 38 }, (_, i) => <i key={i} style={{ height: `${5 + ((i * 17 + 11) % 37)}px`, animationDelay: `${i * -61}ms` }} />)}</span>;
}

function Feature({ track }: { track?: Track }) {
  const current = useCurrentTrack();
  const status = usePlayer((s) => s.status);
  const play = usePlayer((s) => s.playTrack);
  const toggle = usePlayer((s) => s.toggle);
  const liked = useLiked(track);
  const on = current?.id === track?.id && status === "playing";
  return <section className={styles.feature} aria-label="Трек в центре внимания">
    <div className={styles.featureArt} aria-hidden="true" />
    <div className={styles.featureTop}><span className={styles.eyebrow}>ВАШ МОМЕНТ</span><AudioLines size={18} strokeWidth={1.4} /></div>
    <div className={styles.featureBody}>
      <span className={styles.featureKicker}>{track ? "На одной частоте" : "Там, где звучишь ты"}</span>
      <h2>{track?.title ?? "Почувствуй\nсвою музыку."}</h2>
      <p>{track ? <Link href={artistHref(track)}>{track.artist}</Link> : "Оставь шум снаружи. Всё остальное — в музыке."}{track?.duration ? ` · ${duration(track.duration)}` : ""}</p>
      <div className={styles.featureControls}>
        {track ? <button className={styles.roundPlay} aria-label={`${on ? "Пауза" : "Слушать"}: ${track.title}`} onClick={() => current?.id === track.id ? toggle() : play(track, "home:feature")}>{on ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}</button>
          : <Link href="/wave/?autoplay=1" className={styles.roundPlay} aria-label="Запустить мою волну"><Play size={18} fill="currentColor" /></Link>}
        {track && <button className="icon-btn" aria-label={liked ? "Убрать из избранного" : "Добавить в избранное"} aria-pressed={liked} onClick={() => void toggleLike(track, "home:feature")}><Heart size={19} fill={liked ? "currentColor" : "none"} /></button>}
        <Waveform playing={on} />
        {track && <Link href={artistHref(track)} className={styles.featureArtist} aria-label={`Открыть исполнителя ${track.artist}`}><ArrowUpRight size={18} /></Link>}
      </div>
    </div>
  </section>;
}

export default function HomeDashboard() {
  const { user } = useAuth();
  const [hello, setHello] = useState("Добрый вечер");
  useEffect(() => setHello(greeting()), []);
  const current = useCurrentTrack();
  const playing = usePlayer((s) => s.status === "playing");
  const play = usePlayer((s) => s.playTrack);
  const playList = usePlayer((s) => s.playList);
  const home = useQuery({ queryKey: ["home"], queryFn: () => api.get<HomeData>("/api/home") });
  const facts = useQuery({ queryKey: ["dashboard"], queryFn: () => api.get<DashboardData>("/api/dashboard"), staleTime: 5 * 60_000 });
  const recommendations = useQuery({ queryKey: ["wave-peek"], queryFn: () => api.get<RecResponse>("/api/wave/next", { mode: "flow", count: 6, peek: true }), staleTime: 5 * 60_000 });
  const discoveries = useQuery({ queryKey: ["dashboard-discover"], queryFn: () => api.get<RecResponse>("/api/wave/next", { mode: "chaos", count: 4, peek: true }), staleTime: 10 * 60_000 });
  const data = facts.data;
  const album = data?.album_of_month;
  const song = data?.song_of_month;
  const selected = current ?? home.data?.continue?.track ?? recommendations.data?.items[0] ?? data?.weekly[0];
  const recent = home.data?.recent ?? [];
  const publicTrack = data?.weekly[0];
  const name = user?.display_name?.split(" ")[0] ?? "";

  return <div className={styles.dashboard}>
    <div className={styles.backdrop} aria-hidden="true" />
    <header className={styles.topbar}>
      <Link href="/search/" className={styles.search}><Search size={17} /><span>Поиск треков, исполнителей, альбомов, настроения…</span><kbd>Ctrl K</kbd></Link>
      <div className={styles.topActions}><Link href="/rooms/" className="icon-btn" aria-label="Слушать вместе"><Users size={20} strokeWidth={1.5} /></Link><Link href="/settings/" className={styles.avatar} aria-label="Открыть профиль">{user?.avatar_url ? <Cover src={user.avatar_url} seed={user.id} size={36} round /> : <span>{name.charAt(0) || "S"}</span>}</Link></div>
    </header>

    <div className={styles.columns}>
      <div className={styles.mainColumn}>
        <section className={styles.hero}><span className={styles.eyebrow}>ТВОЯ МУЗЫКА. ТВОЯ ЧАСТОТА.</span><h1>{hello}{name ? "," : ""}<br />{name || "Добро пожаловать"}</h1><p>«Музыка — это не просто звук.<br />Это способ чувствовать мир иначе.»</p></section>
        <div className={styles.widgets}>
          <section className={`${styles.panel} ${styles.widget}`}>
            <span className={styles.tag}>Ваш выбор</span><h2>Альбом месяца</h2>
            {album ? <Link href={`/album/?key=${encodeURIComponent(album.key)}`} className={styles.widgetTrack} title={data?.monthly_basis}><Cover src={album.artwork} seed={album.key} size={48} radius={6} /><span><strong className="clamp1">{album.name}</strong><small className="clamp1">{album.artist}</small>{album.release_date && <small>{album.release_date}</small>}</span><ArrowUpRight size={15} /></Link>
              : <div className={styles.widgetEmpty}><Disc3 size={23} strokeWidth={1.2} /><span>Ваш любимый альбом<br />появится после прослушиваний.</span></div>}
          </section>
          <section className={`${styles.panel} ${styles.widget}`}>
            <span className={styles.tag}>Ваш выбор</span><h2>Песня месяца</h2>
            {song ? <button className={styles.widgetTrack} onClick={() => play(song, "home:month")} title={data?.monthly_basis}><Cover src={song.artwork_small || song.artwork} seed={song.id} size={48} radius={6} /><span><strong className="clamp1">{song.title}</strong><small className="clamp1">{song.artist}</small></span><Play size={15} /></button>
              : <div className={styles.widgetEmpty}><Music2 size={22} strokeWidth={1.2} /><span>Слушайте любимое.<br />Мы сохраним ваш выбор.</span></div>}
          </section>
          <section className={`${styles.panel} ${styles.widget}`}>
            <h2>Популярные жанры</h2><div className={styles.genreBody}><div className={styles.genres}>{data?.genres.length ? data.genres.map((g) => <Link key={g.key} href={`/search/?q=${encodeURIComponent(g.name)}`}>{g.name}</Link>) : <span className="t-tiny">Жанры появятся<br />вместе с чартом.</span>}</div><Waveform small /></div><small className={styles.widgetNote}>{data?.genres_basis ?? "По метаданным источников"}</small>
          </section>
          <section className={`${styles.panel} ${styles.widget}`}>
            <div className={styles.widgetHead}><h2>{current ? "Сейчас играет" : "В тренде"}</h2><Headphones size={14} /></div>
            {current || publicTrack ? <button className={styles.widgetTrack} onClick={() => play((current ?? publicTrack)!, "home:trending")}><Cover src={(current ?? publicTrack)!.artwork_small} seed={(current ?? publicTrack)!.id} size={43} radius={6} /><span><strong className="clamp1">{(current ?? publicTrack)!.title}</strong><small className="clamp1">{(current ?? publicTrack)!.artist}</small></span></button> : <span className={styles.noTrack}>Выберите свою первую песню.</span>}
            <Waveform small playing={!!current && playing} />
          </section>
        </div>

        <div className={styles.bodyGrid}>
          <section className={styles.recommendations}>
            <div className={styles.sectionHead}><h2>Рекомендации для тебя</h2><Link href="/wave/">Все <ArrowUpRight size={12} /></Link></div>
            {recommendations.isPending && <RowsSkeleton rows={5} />}
            {recommendations.isError && <ErrorState text={errorMessage(recommendations.error)} onRetry={() => void recommendations.refetch()} />}
            {recommendations.data?.items.length ? <TrackList tracks={recommendations.data.items} context="wave:flow:main" showTags={false} showSource={false} showReasons={false} /> : !recommendations.isPending && !recommendations.isError ? <div className={styles.collectionEmpty}><Waves size={28} /><h3>Здесь начнётся ваш поток</h3><p>Найдите любимого исполнителя или добавьте собственные треки.</p><Link href="/search/" className="btn btn-quiet btn-sm">Найти музыку <ArrowUpRight size={14} /></Link></div> : null}
            <Link href="/wave/?autoplay=1" className={styles.waveLink}><Waves size={19} /><span><strong>Моя волна</strong><small>Музыка, которая чувствует тебя</small></span><Play size={16} /></Link>
          </section>
          <div className={styles.featureColumn}>
            <Feature track={selected} />
            <section className={styles.recent}><div className={styles.sectionHead}><h2>Недавно прослушанное</h2><Link href="/library/?tab=recent">Все</Link></div>
              {recent.length ? <div className={styles.coverStrip}>{recent.slice(0, 4).map((t, i) => <button key={t.id} className={styles.coverCard} onClick={() => playList(recent, i, "recent")}><Cover src={t.artwork_small || t.artwork} seed={t.id} size="100%" radius={9} /><strong className="clamp1">{t.title}</strong><small className="clamp1">{t.artist}</small></button>)}</div> : <div className={styles.recentEmpty}><Headphones size={18} /><span>Ваша история ещё впереди.</span><Link href="/search/">Найти первый трек</Link></div>}
            </section>
          </div>
        </div>

        {!!discoveries.data?.items.length && <section className={styles.discovery}><div className={styles.sectionHead}><h2><Shuffle size={17} /> За пределами привычного</h2><Link href="/wave/?mode=chaos">Ещё открытия</Link></div><div className={styles.coverStrip}>{discoveries.data.items.map((t) => <button key={t.id} className={styles.discoveryCard} onClick={() => play(t, "home:discover")}><Cover src={t.artwork_small || t.artwork} seed={t.id} size={56} radius={8} /><span><strong className="clamp1">{t.title}</strong><small className="clamp1">{t.artist}</small></span><ArrowUpRight size={14} /></button>)}</div></section>}
        {!!home.data?.playlists.length && <section className={styles.playlists}><div className={styles.sectionHead}><h2>Твои плейлисты</h2><Link href="/library/?tab=playlists">Все</Link></div><div className={styles.coverStrip}>{home.data.playlists.slice(0, 4).map((p) => <Link key={p.id} className={styles.coverCard} href={`/playlist/?id=${p.id}`}><Cover src={p.cover ?? p.mosaic[0]} seed={p.id} size="100%" radius={9} /><strong className="clamp1">{p.name}</strong></Link>)}</div></section>}
        {home.isError && <ErrorState text={errorMessage(home.error)} onRetry={() => void home.refetch()} />}
      </div>

      <aside className={styles.sideColumn}>
        <section className={`${styles.panel} ${styles.chart}`}><div className={styles.panelHead}><h2>Топ недели</h2><Link href="/search/" aria-label="Найти больше музыки">Все</Link></div>
          {facts.isPending && <RowsSkeleton rows={5} />}
          {data?.weekly.length ? <ol>{data.weekly.map((t) => <li key={t.id}><span className={styles.rank}>{t.rank}</span><button className={styles.chartTrack} onClick={() => play(t, "home:weekly")}><Cover src={t.artwork_small || t.artwork} seed={t.id} size={39} radius={5} /><span><strong className="clamp1">{t.title}</strong><small className="clamp1">{t.artist}</small></span><ArrowUpRight size={15} /></button></li>)}</ol> : !facts.isPending && <div className={styles.chartEmpty}><AudioLines size={26} /><p>Чарт пока недоступен</p><button onClick={() => void facts.refetch()}>Попробовать снова</button></div>}
          {data?.weekly.length ? <div className={styles.chartSource}>{data.weekly_url ? <a href={data.weekly_url} target="_blank" rel="noopener noreferrer">{data.weekly_source} <ExternalArrow /></a> : data.weekly_source}</div> : null}
        </section>
        <LyricsPanel />
        {data?.sources.youtube !== "ok" && data?.sources.youtube !== undefined && <Link href={user?.is_admin ? "/admin/#sources" : "/search/"} className={styles.catalogNote}><Settings2 size={15} /><span>Больше исполнителей — с YouTube<small>{data.sources.youtube === "not_configured" ? "Нужен ключ источника в настройках сервера" : "Источник сейчас не подключён"}</small></span><ArrowUpRight size={14} /></Link>}
      </aside>
    </div>
  </div>;
}

function ExternalArrow() { return <ArrowUpRight size={11} />; }
