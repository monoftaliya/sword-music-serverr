"use client";

import { useEffect, useRef } from "react";
import { getIntensity, getMotion } from "@/lib/settings";
import styles from "./LivingBackground.module.css";

interface Blob {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  hue: "accent" | "glow" | "violet" | "cold";
  phase: number;
}

function cssColor(name: string, fallback: string): string {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function toRgb(color: string): [number, number, number] {
  const c = color.trim();
  if (c.startsWith("#")) {
    const h = c.length === 4 ? c.slice(1).split("").map((x) => x + x).join("") : c.slice(1, 7);
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  const m = c.match(/(\d+(?:\.\d+)?)/g);
  return m && m.length >= 3 ? [Number(m[0]), Number(m[1]), Number(m[2])] : [139, 92, 255];
}

/**
 * Ink slowly diffusing in black water. Rendered on a tiny canvas (1/12 of the
 * viewport) and scaled up by the browser — soft by construction, cheap to draw,
 * capped at ~24 fps and paused when the tab is hidden or motion is off.
 */
export function LivingBackground() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;
    const SCALE = 12;
    let w = 0;
    let h = 0;
    const resize = () => {
      w = Math.max(32, Math.round(window.innerWidth / SCALE));
      h = Math.max(32, Math.round(window.innerHeight / SCALE));
      canvas.width = w;
      canvas.height = h;
    };
    resize();
    const blobs: Blob[] = [
      { x: 0.18, y: 0.22, r: 0.55, vx: 0.012, vy: 0.008, hue: "accent", phase: 0 },
      { x: 0.82, y: 0.3, r: 0.45, vx: -0.009, vy: 0.011, hue: "glow", phase: 1.7 },
      { x: 0.6, y: 0.85, r: 0.6, vx: 0.007, vy: -0.01, hue: "violet", phase: 3.1 },
      { x: 0.1, y: 0.9, r: 0.4, vx: 0.01, vy: -0.006, hue: "cold", phase: 4.4 },
    ];
    let colors = { accent: toRgb("#8b5cff"), glow: toRgb("#5c8dff"), violet: toRgb("#8b5cff"), cold: toRgb("#5c8dff"), base: toRgb("#08090d") };
    const readColors = () => {
      colors = {
        accent: toRgb(cssColor("--dyn-accent", "#8b5cff")),
        glow: toRgb(cssColor("--dyn-glow", "#5c8dff")),
        violet: toRgb("#8b5cff"),
        cold: toRgb("#5c8dff"),
        base: toRgb(cssColor("--void", "#08090d")),
      };
    };
    readColors();

    let raf = 0;
    let last = 0;
    let t = 0;
    let colorTick = 0;
    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      const motion = getMotion();
      const intensity = getIntensity();
      const still = motion !== "full" || intensity === "minimal";
      if (now - last < (still ? 1000 : 42)) return; // ~24 fps, or a slow refresh when still
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      if (!still) t += dt;
      if ((colorTick += dt) > 0.8 || still) {
        colorTick = 0;
        readColors();
      }
      const [br, bg, bb] = colors.base;
      ctx.fillStyle = `rgb(${br},${bg},${bb})`;
      ctx.fillRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";
      const strength = intensity === "rich" ? 0.2 : intensity === "minimal" ? 0.09 : 0.14;
      for (const b of blobs) {
        const x = (b.x + Math.sin(t * b.vx * 9 + b.phase) * 0.12) * w;
        const y = (b.y + Math.cos(t * b.vy * 9 + b.phase) * 0.1) * h;
        const r = b.r * Math.max(w, h) * (1 + Math.sin(t * 0.21 + b.phase) * 0.08);
        const [cr, cg, cb] = colors[b.hue];
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(${cr},${cg},${cb},${strength})`);
        g.addColorStop(0.55, `rgba(${cr},${cg},${cb},${strength * 0.32})`);
        g.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, w, h);
      }
      ctx.globalCompositeOperation = "source-over";
    };
    raf = requestAnimationFrame(draw);
    const onVis = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else {
        last = 0;
        raf = requestAnimationFrame(draw);
      }
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div className={styles.bg} aria-hidden>
      <canvas ref={ref} className={styles.canvas} />
      <div className={styles.vignette} />
    </div>
  );
}
