"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { api } from "@/lib/api";
import { isPublicRoute, useAuth } from "@/lib/auth";
import { usePlayer, wirePlayer } from "@/lib/player/store";
import { ConfirmHost } from "@/lib/confirm";
import { applySettings } from "@/lib/settings";
import type { Track } from "@/lib/types";
import { AddToPlaylistDialog, AlternativesDialog } from "../music/LibraryDialogs";
import { FullPlayer } from "../player/FullPlayer";
import { PlayerBar } from "../player/PlayerBar";
import { VideoDock } from "../player/VideoDock";
import { DiscordPresenceBridge } from "../player/DiscordPresenceBridge";
import { Toasts } from "../ui/Toasts";
import { LivingBackground } from "./LivingBackground";
import { LogoMark } from "./Logo";
import { BottomNav, NavRail } from "./Nav";
import styles from "./AppShell.module.css";

interface SavedState {
  queue: Track[];
  index: number;
  position_ms: number;
  context: string;
}

function isTyping(el: EventTarget | null): boolean {
  const t = el as HTMLElement | null;
  if (!t) return false;
  return t.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName);
}

/** A quiet strip shown while the device has no network; React Query refetches on reconnect. */
function OfflineBanner() {
  const [offline, setOffline] = useState(false);
  useEffect(() => {
    const update = () => setOffline(!navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);
  if (!offline) return null;
  return (
    <div className={styles.offline} role="status">
      Нет сети. Уже загруженный трек доиграет, а поиск и волна вернутся, когда соединение восстановится.
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { status, user, refresh } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  const isPublic = isPublicRoute(pathname);
  const restored = useRef(false);

  useEffect(() => {
    wirePlayer();
  }, []);

  useEffect(() => {
    applySettings(user?.settings);
  }, [user?.settings]);

  useEffect(() => {
    if (status === "anon" && !isPublic) {
      const next = window.location.pathname + window.location.search;
      router.replace(`/login/${next && next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`);
    }
    if (status === "authed" && isPublic && !pathname.startsWith("/reset")) router.replace("/");
  }, [status, isPublic, pathname, router]);

  useEffect(() => {
    if (status !== "authed" || restored.current) return;
    restored.current = true;
    api
      .get<{ state: SavedState | null }>("/api/me/player-state")
      .then(({ state }) => {
        if (state?.queue?.length) usePlayer.getState().restore(state.queue, state.index, state.position_ms / 1000, state.context || "restored");
      })
      .catch(() => undefined);
  }, [status]);

  useEffect(() => {
    if (status === "anon") {
      restored.current = false;
      usePlayer.getState().stop();
    }
  }, [status]);

  useEffect(() => {
    const p = pathname.replace(/\/+$/, "");
    document.body.dataset.space = p.startsWith("/search") ? "search" : p.startsWith("/wave") ? "wave" : "";
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); router.push("/search/"); return; }
      if (isTyping(e.target) || e.metaKey || e.ctrlKey || e.altKey) return;
      const p = usePlayer.getState();
      if (e.code === "Space" && p.queue.length) {
        e.preventDefault();
        p.toggle();
      } else if (e.key === "/" && !window.location.pathname.startsWith("/search")) {
        e.preventDefault();
        router.push("/search/");
      } else if (e.shiftKey && e.key === "ArrowRight") {
        p.next(true);
      } else if (e.shiftKey && e.key === "ArrowLeft") {
        p.prev();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [router]);

  useEffect(() => {
    if (process.env.NODE_ENV !== "production" || !("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  }, []);

  if (isPublic) {
    return (
      <>
        <LivingBackground />
        <main className={styles.publicMain}>{children}</main>
        <Toasts />
      </>
    );
  }

  if (status === "offline") {
    return (
      <>
        <LivingBackground />
        <div className={styles.splash} role="alert">
          <LogoMark size={44} />
          <p className={styles.splashText}>Сервер Sword сейчас недоступен. Проверьте интернет — мы переподключимся сами.</p>
          <button className="btn btn-quiet btn-sm" onClick={() => void refresh()}>
            Повторить
          </button>
        </div>
      </>
    );
  }

  if (status !== "authed") {
    return (
      <>
        <LivingBackground />
        <div className={styles.splash} role="status" aria-label="Загрузка">
          <LogoMark size={44} />
          <span className={styles.splashLine} />
        </div>
      </>
    );
  }

  return (
    <>
      <LivingBackground />
      <a href="#main" className={styles.skip}>
        К содержимому
      </a>
      <NavRail />
      <main className={styles.main} id="main">
        {children}
      </main>
      <PlayerBar />
      <FullPlayer />
      <VideoDock />
      <DiscordPresenceBridge />
      <BottomNav />
      <AddToPlaylistDialog />
      <AlternativesDialog />
      <ConfirmHost />
      <OfflineBanner />
      <Toasts />
    </>
  );
}
