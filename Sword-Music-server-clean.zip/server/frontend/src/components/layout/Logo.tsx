import { useId } from "react";

/** The Sword mark: a slim blade crossing a wave. */
export function LogoMark({ size = 28 }: { size?: number }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <defs>
        <linearGradient id={`b${id}`} x1="6" y1="28" x2="26" y2="4" gradientUnits="userSpaceOnUse">
          <stop stopColor="#D6D2E2" />
          <stop offset="1" stopColor="#9994AC" />
        </linearGradient>
      </defs>
      <path d="M7.2 27.6 25.1 3.4c.4-.5 1.2-.3 1.2.4l-.6 3.3a2 2 0 0 1-.4.8L9.2 28.6c-.3.4-.9.5-1.3.2l-.5-.3a.6.6 0 0 1-.2-.9Z" fill={`url(#b${id})`} />
      <path d="M3 19.5c3.2-3.6 6.3-3.6 9.4 0s6.3 3.6 9.4 0 5.2-3.2 7.2-1.6" stroke="#F4F5FA" strokeWidth="1.6" strokeLinecap="round" opacity=".92" />
    </svg>
  );
}

export function Wordmark() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
      <LogoMark size={26} />
      <span style={{ fontFamily: "var(--font-display)", fontWeight: 400, fontSize: 16, letterSpacing: "-0.01em" }}>
        Sword <span style={{ color: "var(--ink-3)", fontWeight: 300 }}>Music</span>
      </span>
    </span>
  );
}
