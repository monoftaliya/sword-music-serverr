"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Compass, Ellipsis, House, Library, LogOut, Search, Settings, Shield, Users, Waves } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { translate as t } from "@/lib/i18n";
import { Cover } from "../ui/Cover";
import { LogoMark } from "./Logo";
import styles from "./Nav.module.css";

const MAIN = [
  { href: "/", label: t("home"), icon: House },
  { href: "/search/", label: t("search"), icon: Search },
  { href: "/wave/", label: t("wave"), icon: Waves },
  { href: "/library/", label: t("library"), icon: Library },
  { href: "/explore/", label: t("discoveries"), icon: Compass },
  { href: "/rooms/", label: t("rooms"), icon: Users },
];

const EXPLORE_PATHS = ["/explore", "/after-dark", "/dna", "/echo", "/descent"];
const LIBRARY_PATHS = ["/library", "/playlist", "/artist", "/album", "/shared"];

export function activeKey(pathname: string): string {
  const p = pathname.replace(/\/+$/, "") || "/";
  if (p === "/") return "/";
  if (EXPLORE_PATHS.some((x) => p.startsWith(x))) return "/explore/";
  if (LIBRARY_PATHS.some((x) => p.startsWith(x))) return "/library/";
  if (p.startsWith("/room")) return "/rooms/";
  const hit = MAIN.find((m) => m.href !== "/" && p.startsWith(m.href.replace(/\/$/, "")));
  return hit?.href ?? p + "/";
}

export function NavRail() {
  const pathname = usePathname();
  const { user } = useAuth();
  const active = activeKey(pathname);
  return (
    <nav className={styles.rail} aria-label="Основная навигация">
      <Link href="/" className={styles.logo} aria-label="Sword Music — на главную">
        <LogoMark size={39} /><span className={styles.wordmark}>Sword <span>Music</span></span>
      </Link>
      <ul className={styles.items}>
        {MAIN.map(({ href, label, icon: Icon }) => {
          const on = active === href;
          return (
            <li key={href}>
              <Link href={href} className={styles.item} data-active={on || undefined} aria-current={on ? "page" : undefined}>
                {on && <motion.span layoutId="rail-edge" className={styles.edge} transition={{ type: "spring", stiffness: 420, damping: 38 }} />}
                <Icon size={21} strokeWidth={on ? 2 : 1.7} />
                <span className={styles.label}>{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
      <div className={styles.bottom}>
        {user?.is_admin && (
          <Link href="/admin/" className={styles.item} data-active={active === "/admin/" || undefined} aria-label="Администрирование">
            {active === "/admin/" && <motion.span layoutId="rail-edge" className={styles.edge} />}
            <Shield size={19} strokeWidth={1.7} /><span className={styles.label}>Администрирование</span>
          </Link>
        )}
        <Link href="/settings/" className={styles.item} data-active={active === "/settings/" || undefined} aria-label="Настройки">
          {active === "/settings/" && <motion.span layoutId="rail-edge" className={styles.edge} />}
          {user?.avatar_url ? <Cover src={user.avatar_url} seed={user.id} size={32} round /> : <span className={styles.initial}>{user?.display_name?.charAt(0) || "S"}</span>}<span className={styles.profile}><strong>{user?.display_name || "Профиль"}</strong><small>Ваше пространство</small></span><Settings size={17} strokeWidth={1.5} />
        </Link>
      </div>
    </nav>
  );
}

export function BottomNav() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout } = useAuth();
  const [more, setMore] = useState(false);
  const active = activeKey(pathname);
  const items = MAIN.slice(0, 4);
  const moreActive = !items.some((i) => i.href === active);
  return (
    <>
      <nav className={styles.bottomNav} aria-label="Основная навигация">
        {items.map(({ href, label, icon: Icon }) => {
          const on = active === href;
          return (
            <Link key={href} href={href} className={styles.tab} data-active={on || undefined} aria-current={on ? "page" : undefined}>
              {on && <motion.span layoutId="tab-edge" className={styles.tabEdge} transition={{ type: "spring", stiffness: 420, damping: 38 }} />}
              <Icon size={21} strokeWidth={on ? 2 : 1.7} />
              <span>{label}</span>
            </Link>
          );
        })}
        <button className={styles.tab} data-active={moreActive || undefined} onClick={() => setMore(true)} aria-haspopup="dialog">
          {moreActive && <motion.span layoutId="tab-edge" className={styles.tabEdge} />}
          <Ellipsis size={21} />
          <span>Ещё</span>
        </button>
      </nav>
      <AnimatePresence>
        {more && (
          <motion.div className={styles.sheetBackdrop} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMore(false)}>
            <motion.div
              className={styles.sheet}
              role="dialog"
              aria-label="Ещё"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ duration: 0.42, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
            >
              <span className={styles.sheetHandle} />
              {[
                { href: "/explore/", label: "Открытия", icon: Compass, hint: "After Dark, Music DNA, Echo Self, Infinite Descent" },
                { href: "/rooms/", label: "Комнаты", icon: Users, hint: "Слушать вместе с друзьями" },
                { href: "/settings/", label: "Настройки", icon: Settings, hint: "Профиль, тема, анимации, приватность" },
                ...(user?.is_admin ? [{ href: "/admin/", label: "Администрирование", icon: Shield, hint: "Приглашения, пользователи, источники" }] : []),
              ].map(({ href, label, icon: Icon, hint }) => (
                <button
                  key={href}
                  className={styles.sheetItem}
                  onClick={() => {
                    setMore(false);
                    router.push(href);
                  }}
                >
                  <Icon size={20} />
                  <span>
                    <span className={styles.sheetLabel}>{label}</span>
                    <span className="t-tiny">{hint}</span>
                  </span>
                </button>
              ))}
              <button
                className={styles.sheetItem}
                onClick={() => {
                  setMore(false);
                  void logout().then(() => router.replace("/login/"));
                }}
              >
                <LogOut size={20} />
                <span className={styles.sheetLabel}>Выйти</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
