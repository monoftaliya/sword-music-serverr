"use client";

import { motion, Reorder, useDragControls } from "framer-motion";
import { GripVertical, X } from "lucide-react";
import { useMemo } from "react";
import { duration } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import type { Track } from "@/lib/types";
import { PlayingBars } from "../music/PlayingBars";
import { Cover } from "../ui/Cover";
import { Spinner } from "../ui/controls";
import styles from "./QueuePanel.module.css";

function QueueItem({ qi, track, pos }: { qi: number; track: Track; pos: number }) {
  const controls = useDragControls();
  const jumpTo = usePlayer((s) => s.jumpTo);
  const removeAt = usePlayer((s) => s.removeAt);
  return (
    <Reorder.Item value={qi} dragListener={false} dragControls={controls} className={styles.item} whileDrag={{ scale: 1.02, boxShadow: "0 16px 40px rgba(0,0,0,.5)" }}>
      <button className={styles.grip} onPointerDown={(e) => controls.start(e)} aria-label={`Перетащить: ${track.title}`}>
        <GripVertical size={16} />
      </button>
      <button className={styles.track} onClick={() => jumpTo(pos)} disabled={!track.playable}>
        <Cover src={track.artwork_small} seed={track.id} size={40} radius={8} />
        <span className={styles.meta}>
          <span className="clamp1">{track.title}</span>
          <span className="t-tiny clamp1">{track.artist}</span>
        </span>
        <span className="t-tiny num">{duration(track.duration)}</span>
      </button>
      <button className="icon-btn icon-btn-sm" onClick={() => removeAt(pos)} aria-label={`Убрать из очереди: ${track.title}`}>
        <X size={15} />
      </button>
    </Reorder.Item>
  );
}

export function QueuePanel({ onClose }: { onClose: () => void }) {
  const queue = usePlayer((s) => s.queue);
  const order = usePlayer((s) => s.order);
  const pos = usePlayer((s) => s.pos);
  const status = usePlayer((s) => s.status);
  const continuing = usePlayer((s) => s.continuing);
  const context = usePlayer((s) => s.context);
  const controller = usePlayer((s) => s.controller);
  const reorderUpcoming = usePlayer((s) => s.reorderUpcoming);
  const clearUpcoming = usePlayer((s) => s.clearUpcoming);
  const current = queue[order[pos]];
  const upcoming = useMemo(() => order.slice(pos + 1), [order, pos]);
  const wave = context.startsWith("wave") || context.startsWith("mode");

  return (
    <motion.aside
      className={styles.panel}
      initial={{ x: "104%" }}
      animate={{ x: 0 }}
      exit={{ x: "104%" }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      aria-label="Очередь воспроизведения"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <header className={styles.head}>
        <h3 className="t-section">Очередь</h3>
        {upcoming.length > 0 && !controller && (
          <button className="link-quiet" onClick={clearUpcoming}>
            Очистить
          </button>
        )}
        <button className="icon-btn icon-btn-sm" onClick={onClose} aria-label="Закрыть очередь">
          <X size={17} />
        </button>
      </header>
      {controller && <p className={styles.note}>Очередью управляет комната — откройте её, чтобы предложить трек.</p>}
      {current && (
        <div className={styles.now}>
          <Cover src={current.artwork_small} seed={current.id} size={48} radius={10} />
          <span className={styles.meta}>
            <span className="clamp1">{current.title}</span>
            <span className="t-tiny clamp1">{current.artist}</span>
          </span>
          <PlayingBars paused={status !== "playing"} />
        </div>
      )}
      <div className={styles.listHead}>
        <span className="t-small">Далее</span>
        {wave && <span className="t-tiny">{continuing ? "Волна подбирает ещё…" : "Волна продолжится сама"}</span>}
      </div>
      <div className={styles.scroll}>
        {upcoming.length === 0 && !continuing && <p className={styles.note}>Очередь пуста. Добавьте треки из поиска или запустите волну.</p>}
        {continuing && upcoming.length === 0 && (
          <div className={styles.note}>
            <Spinner size={16} /> Подбираем треки…
          </div>
        )}
        <Reorder.Group axis="y" values={upcoming} onReorder={reorderUpcoming} className={styles.list}>
          {upcoming.map((qi, k) => (
            <QueueItem key={qi} qi={qi} track={queue[qi]} pos={pos + 1 + k} />
          ))}
        </Reorder.Group>
      </div>
    </motion.aside>
  );
}
