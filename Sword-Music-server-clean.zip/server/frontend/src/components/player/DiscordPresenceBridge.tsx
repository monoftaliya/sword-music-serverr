"use client";
import { useEffect } from "react";
import { usePlayer } from "@/lib/player/store";
import { useAuth } from "@/lib/auth";

/** Local desktop IPC only. Track metadata comes from the same player the user sees. */
export function DiscordPresenceBridge() {
  const { user } = useAuth();
  useEffect(() => {
    const bridge = window.swordDesktop;
    if (!bridge?.updateDiscordPresence) return;
    let last = "", lastAt = 0;
    const publish = () => {
      const s = usePlayer.getState();
      const track = s.queue[s.order[s.pos]];
      const playing = s.status === "playing";
      const artwork = track && track.provider !== "upload" ? track.artwork || track.artwork_small : null;
      const eligible = user && track && s.loadedId === track.id && ["playing", "paused"].includes(s.status);
      const key = eligible ? `${track.id}|${artwork ?? ""}|${track.album ?? ""}|${s.status}|${Math.floor(s.position / 15)}` : "clear";
      if (key === last && Date.now() - lastAt < 15000) return;
      last = key; lastAt = Date.now();
      bridge.updateDiscordPresence!(eligible ? {
        title: track.title, artist: track.artist, album: track.album, source: track.source, url: track.page_url, artwork,
        status: playing ? "playing" : "paused", position: s.position, duration: s.duration,
      } : null);
    };
    publish();
    const unsubscribe = usePlayer.subscribe(publish);
    const interval = setInterval(publish, 15000);
    const clear = () => bridge.updateDiscordPresence!(null);
    window.addEventListener("pagehide", clear);
    return () => { unsubscribe(); clearInterval(interval); window.removeEventListener("pagehide", clear); clear(); };
  }, [user?.id]);
  return null;
}
