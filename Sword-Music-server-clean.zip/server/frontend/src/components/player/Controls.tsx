"use client";

import { Pause, Play, Repeat, Repeat1, Shuffle, SkipBack, SkipForward, Volume1, Volume2, VolumeX } from "lucide-react";
import { usePlayer } from "@/lib/player/store";
import { Slider, Spinner } from "../ui/controls";
import styles from "./Controls.module.css";

export function PlayButton({ size = 52, className }: { size?: number; className?: string }) {
  const status = usePlayer((s) => s.status);
  const toggle = usePlayer((s) => s.toggle);
  const controller = usePlayer((s) => s.controller);
  const hasTrack = usePlayer((s) => s.queue.length > 0);
  const playing = status === "playing";
  const loading = status === "loading";
  const locked = controller ? !controller.canControl : false;
  const icon = Math.round(size * 0.4);
  return (
    <button
      className={`${styles.play} ${className ?? ""}`}
      style={{ width: size, height: size }}
      onClick={toggle}
      disabled={!hasTrack || locked}
      aria-label={playing || loading ? "Пауза" : "Слушать"}
      title={locked ? "Воспроизведением управляет владелец комнаты" : undefined}
    >
      <span className={styles.playIcon} data-show={!(playing || loading) || undefined}>
        <Play size={icon} fill="currentColor" strokeWidth={0} style={{ marginLeft: Math.round(size * 0.05) }} />
      </span>
      <span className={styles.playIcon} data-show={playing || undefined}>
        <Pause size={icon} fill="currentColor" strokeWidth={0} />
      </span>
      <span className={styles.playIcon} data-show={loading || undefined}>
        <Spinner size={icon} />
      </span>
    </button>
  );
}

export function Transport({ size = "md", showModes = true }: { size?: "md" | "lg"; showModes?: boolean }) {
  const prev = usePlayer((s) => s.prev);
  const next = usePlayer((s) => s.next);
  const shuffle = usePlayer((s) => s.shuffle);
  const repeat = usePlayer((s) => s.repeat);
  const toggleShuffle = usePlayer((s) => s.toggleShuffle);
  const cycleRepeat = usePlayer((s) => s.cycleRepeat);
  const controller = usePlayer((s) => s.controller);
  const hasTrack = usePlayer((s) => s.queue.length > 0);
  const locked = controller ? !controller.canControl : false;
  const ic = size === "lg" ? 24 : 19;
  const RepeatIcon = repeat === "one" ? Repeat1 : Repeat;
  const repeatLabel = repeat === "off" ? "Повтор выключен" : repeat === "all" ? "Повтор очереди" : "Повтор трека";
  return (
    <div className={styles.transport} data-size={size}>
      {showModes && (
        <button
          className="icon-btn"
          data-active={shuffle}
          aria-pressed={shuffle}
          onClick={toggleShuffle}
          disabled={!!controller}
          aria-label={shuffle ? "Перемешивание включено" : "Перемешать"}
          title={shuffle ? "Перемешивание включено" : "Перемешать"}
        >
          <Shuffle size={ic - 2} />
        </button>
      )}
      <button className="icon-btn" onClick={prev} disabled={!hasTrack || locked} aria-label="Предыдущий трек">
        <SkipBack size={ic} fill="currentColor" />
      </button>
      <PlayButton size={size === "lg" ? 68 : 46} />
      <button className="icon-btn" onClick={() => next(true)} disabled={!hasTrack || locked} aria-label="Следующий трек">
        <SkipForward size={ic} fill="currentColor" />
      </button>
      {showModes && (
        <button
          className="icon-btn"
          data-active={repeat !== "off"}
          onClick={cycleRepeat}
          disabled={!!controller}
          aria-label={repeatLabel}
          title={repeatLabel}
        >
          <RepeatIcon size={ic - 2} />
        </button>
      )}
    </div>
  );
}

export function VolumeControl({ compact }: { compact?: boolean }) {
  const volume = usePlayer((s) => s.volume);
  const muted = usePlayer((s) => s.muted);
  const setVolume = usePlayer((s) => s.setVolume);
  const toggleMute = usePlayer((s) => s.toggleMute);
  const spotify = usePlayer((s) => s.attribution?.provider === "spotify_link" && s.streamKind === "embed");
  const Icon = muted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;
  if (spotify) return <span className="t-tiny" title="Встроенный плеер Spotify не предоставляет управление громкостью приложению.">Громкость — в системе</span>;
  return (
    <div className={styles.volume} data-compact={compact || undefined}>
      <button className="icon-btn icon-btn-sm" onClick={toggleMute} aria-label={muted ? "Включить звук" : "Выключить звук"}>
        <Icon size={18} />
      </button>
      <Slider value={muted ? 0 : volume} onChange={setVolume} label="Громкость" className={styles.volSlider} format={(v) => `${Math.round(v * 100)}%`} />
    </div>
  );
}
