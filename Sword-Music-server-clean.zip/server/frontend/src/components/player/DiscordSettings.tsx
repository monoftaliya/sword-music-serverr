"use client";
import { useEffect, useState } from "react";
import type { DiscordState } from "@/lib/types";
import { Switch } from "@/components/ui/controls";

const LABELS = { disabled: "Выключено", needs_id: "Укажите Application ID", waiting: "Ожидаем настольный Discord", connecting: "Подключаемся к Discord…", connected: "Discord подключён", error: "Discord отклонил обновление статуса" };
export function DiscordSettings() {
  const [state, setState] = useState<DiscordState | null>(null);
  const [clientId, setClientId] = useState("1117870705334296686");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const bridge = window.swordDesktop;
    if (!bridge?.discordStatus) return;
    bridge.discordStatus().then((v) => { setState(v); if (v) setClientId(v.clientId); }).catch(() => undefined);
    const timer = setInterval(() => { bridge.discordStatus!().then(setState).catch(() => undefined); }, 5000);
    return () => clearInterval(timer);
  }, []);
  const save = async (enabled: boolean) => {
    const bridge = window.swordDesktop;
    if (!bridge?.configureDiscord) return;
    setBusy(true); setError("");
    try {
      const result = await bridge.configureDiscord({ enabled, clientId: enabled ? clientId : state?.clientId ?? clientId });
      if (!result.ok) setError(result.error ?? "Не удалось сохранить настройку.");
      else { setState(result); setClientId(result.clientId); }
    } catch { setError("Не удалось связаться с приложением. Перезапустите Sword Music."); }
    finally { setBusy(false); }
  };
  if (!state) return <p className="t-small">Статус Discord доступен в обновлённом приложении Sword Music для компьютера. В браузере он не подключается.</p>;
  return <div style={{ display: "grid", gap: 18 }}>
    <div className="row" style={{ justifyContent: "space-between", gap: 16 }}>
      <div><strong>Показывать, что я слушаю</strong><p className="t-small">Название трека, исполнитель и время прослушивания появятся в профиле Discord.</p></div>
      <Switch checked={state.enabled} onChange={(enabled) => void save(enabled)} label="Показывать музыку в Discord" disabled={busy} />
    </div>
    <p className="t-small" role="status">{state.message || LABELS[state.state]}</p>
    <label className="field"><span className="field-label">Application ID</span><div className="row wrap">
      <input className="input" value={clientId} onChange={(e) => setClientId(e.target.value)} inputMode="numeric" maxLength={22} aria-label="Discord Application ID" style={{ maxWidth: 300 }} />
      <button className="btn btn-line btn-sm" disabled={busy || !/^\d{17,22}$/.test(clientId)} onClick={() => void save(state.enabled)}>Сохранить</button>
    </div></label>
    {error && <p className="t-small" role="alert">{error}</p>}
    <p className="t-small">Discord должен быть запущен на этом компьютере. В его настройках конфиденциальности активности включите показ текущей активности.</p>
    <details className="t-small"><summary>Настроить приложение Discord</summary><p>В <a href="https://discord.com/developers/applications" target="_blank" rel="noopener noreferrer">Discord Developer Portal ↗</a> откройте приложение с этим ID. Назовите его Sword Music — это имя будет видно в статусе. Пароль, токен бота и подписка не нужны.</p></details>
  </div>;
}
