"use client";

import { motion } from "framer-motion";
import { Heart, ListMusic, Maximize2, Music2, SkipForward } from "lucide-react";
import Link from "next/link";
import { toggleLike, useLiked } from "@/lib/likes";
import { useCurrentTrack, usePlayer } from "@/lib/player/store";
import { Cover } from "../ui/Cover";
import { PlayButton, Transport, VolumeControl } from "./Controls";
import { SeekBar } from "./SeekBar";
import styles from "./PlayerBar.module.css";

export function PlayerBar() {
  const track = useCurrentTrack();
  const fullOpen = usePlayer((s) => s.fullOpen);
  const setFullOpen = usePlayer((s) => s.setFullOpen);
  const setQueueOpen = usePlayer((s) => s.setQueueOpen);
  const next = usePlayer((s) => s.next);
  const context = usePlayer((s) => s.context);
  const streamKind = usePlayer((s) => s.streamKind);
  const controller = usePlayer((s) => s.controller);
  const liked = useLiked(track);
  if (!track) return <div className={`${styles.bar} ${styles.empty}`} role="region" aria-label="Мини-плеер"><Music2 size={22} strokeWidth={1.3} /><span><strong>Твоя музыка начинается здесь</strong><small>Выберите трек, чтобы начать слушать.</small></span><Link className="btn btn-quiet btn-sm" href="/search/">Найти музыку</Link></div>;
  const locked = controller ? !controller.canControl : false;

  return (
    <motion.div
      className={styles.bar}
      role="region"
      aria-label="Мини-плеер"
      data-hidden={fullOpen || undefined}
      initial={{ y: 24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={{ top: 0.25, bottom: 0.05 }}
      onDragEnd={(_, info) => {
        if (info.offset.y < -36 || info.velocity.y < -400) setFullOpen(true);
      }}
    >
      <div className={styles.edgeProgress}>
        <SeekBar variant="edge" />
      </div>
      <button className={styles.trackBtn} onClick={() => setFullOpen(true)} aria-label="Открыть плеер">
        {!fullOpen && (
          <motion.span layoutId="player-cover" className={styles.coverWrap} transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}>
            <Cover src={track.artwork_small || track.artwork} seed={track.id} size="100%" radius={10} />
          </motion.span>
        )}
        {fullOpen && <span className={styles.coverWrap} />}
        <span className={styles.meta}>
          <span className={`${styles.title} clamp1`}>{track.title}</span>
          <span className={`${styles.artist} clamp1`}>
            {controller ? controller.label : track.artist}
            {streamKind === "preview" && <span className="badge badge-preview">превью</span>}
          </span>
        </span>
      </button>

      <button
        className={`icon-btn icon-btn-sm ${styles.like}`}
        data-active={liked}
        aria-pressed={liked}
        aria-label={liked ? "Убрать из избранного" : "В избранное"}
        onClick={() => void toggleLike(track, context)}
      >
        <Heart size={18} fill={liked ? "currentColor" : "none"} />
      </button>

      <div className={styles.center}>
        <Transport />
        <div className={styles.seek}>
          <SeekBar variant="full" />
        </div>
      </div>

      <div className={styles.right}>
        <button className="icon-btn icon-btn-sm" onClick={() => { setFullOpen(true); setQueueOpen(true); }} aria-label="Очередь">
          <ListMusic size={18} />
        </button>
        <VolumeControl compact />
        <button className="icon-btn icon-btn-sm" onClick={() => setFullOpen(true)} aria-label="Развернуть плеер">
          <Maximize2 size={17} />
        </button>
      </div>

      <div className={styles.mobileControls}>
        <PlayButton size={42} />
        <button className="icon-btn" onClick={() => next(true)} aria-label="Следующий трек" disabled={locked}>
          <SkipForward size={20} fill="currentColor" />
        </button>
      </div>
    </motion.div>
  );
}
