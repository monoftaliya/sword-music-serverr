"use client";

import { AnimatePresence, motion, useDragControls } from "framer-motion";
import { ChevronDown, Dna, ExternalLink, Heart, Infinity as InfinityIcon, ListMusic, ListPlus, Minus, Plus } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { toggleLike, useLiked } from "@/lib/likes";
import { useCurrentTrack, usePlayer } from "@/lib/player/store";
import { useMotionLevel } from "@/lib/settings";
import { artistHref, useDialogs } from "@/lib/ui";
import { sendFeedback, TrackMenu } from "../music/TrackMenu";
import { Cover } from "../ui/Cover";
import { Transport, VolumeControl } from "./Controls";
import { QueuePanel } from "./QueuePanel";
import { SeekBar } from "./SeekBar";
import styles from "./FullPlayer.module.css";

function contextLabel(context: string): string | null {
  if (context.startsWith("wave:")) {
    const [, mode, lens] = context.split(":");
    return `Волна ${mode?.toUpperCase()}${lens === "shadow" ? " в режиме SHADOW" : ""}`;
  }
  if (context.startsWith("mode:")) return `After Dark: ${context.split(":")[1]?.toUpperCase()}`;
  if (context.startsWith("playlist:")) return "Из плейлиста";
  if (context.startsWith("room:")) return "Комната";
  if (context === "search") return "Из поиска";
  if (context === "favorites") return "Избранное";
  if (context.startsWith("descent")) return "Infinite Descent";
  return null;
}

export function FullPlayer() {
  const open = usePlayer((s) => s.fullOpen);
  const setOpen = usePlayer((s) => s.setFullOpen);
  const queueOpen = usePlayer((s) => s.queueOpen);
  const setQueueOpen = usePlayer((s) => s.setQueueOpen);
  const track = useCurrentTrack();
  const status = usePlayer((s) => s.status);
  const context = usePlayer((s) => s.context);
  const streamKind = usePlayer((s) => s.streamKind);
  const attribution = usePlayer((s) => s.attribution);
  const controller = usePlayer((s) => s.controller);
  const liked = useLiked(track);
  const motionLevel = useMotionLevel();
  const router = useRouter();
  const drag = useDragControls();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (usePlayer.getState().queueOpen) setQueueOpen(false);
        else setOpen(false);
      }
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, setOpen, setQueueOpen]);

  useEffect(() => {
    if (!track && open) setOpen(false);
  }, [track, open, setOpen]);

  const go = (href: string) => {
    setOpen(false);
    router.push(href);
  };
  const inWave = context.startsWith("wave") || context.startsWith("mode");
  const label = controller ? controller.label : contextLabel(context);

  return (
    <AnimatePresence>
      {open && track && (
        <motion.div
          className={styles.full}
          role="dialog"
          aria-modal="true"
          aria-label="Плеер"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.32, delay: 0.05 } }}
          transition={{ duration: 0.38 }}
          drag="y"
          dragControls={drag}
          dragListener={false}
          dragConstraints={{ top: 0, bottom: 0 }}
          dragElastic={{ top: 0, bottom: 0.6 }}
          onDragEnd={(_, info) => {
            if (info.offset.y > 120 || info.velocity.y > 700) setOpen(false);
          }}
        >
          <div className={styles.ambient} data-playing={status === "playing" || undefined} data-motion={motionLevel} />

          <header className={styles.header} onPointerDown={(e) => drag.start(e)}>
            <button className="icon-btn" onClick={() => setOpen(false)} aria-label="Свернуть плеер">
              <ChevronDown size={22} />
            </button>
            <span className={styles.handle} aria-hidden />
            <span className={`${styles.context} clamp1`}>{label}</span>
            <TrackMenu track={track} context={context} />
          </header>

          <div className={styles.stage} data-queue={queueOpen || undefined}>
            <div className={styles.coverCol}>
              {streamKind === "embed" ? (
                // the YouTube player (VideoDock) positions itself over this slot
                <div className={styles.videoSlot} data-video-slot />
              ) : (
              <motion.div layoutId="player-cover" className={styles.coverLayout} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}>
                <div className={styles.breath} data-playing={status === "playing" || undefined}>
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.div
                      key={track.id}
                      className={styles.coverSwap}
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 1.02 }}
                      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <Cover src={track.artwork || track.artwork_small} seed={track.id} size="100%" radius={22} priority />
                    </motion.div>
                  </AnimatePresence>
                </div>
              </motion.div>
              )}
            </div>

            <div className={styles.info}>
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={track.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
                  className={styles.titles}
                >
                  <h2 className={`${styles.title}`}>{track.title}</h2>
                  <Link href={artistHref(track)} className={styles.artist} onClick={() => setOpen(false)}>
                    {track.artist}
                  </Link>
                  {(track.tags.length > 0 || track.reason) && (
                    <div className={styles.tagLine}>
                      {track.tags.slice(0, 4).map((t) => (
                        <span key={t.key} className="chip chip-tag">
                          {t.label}
                        </span>
                      ))}
                      {track.reason && <span className={styles.reason}>{track.reason}</span>}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

              <div className={styles.seek}>
                <SeekBar variant="full" />
              </div>
              <Transport size="lg" />

              <div className={styles.actions}>
                <button
                  className="icon-btn"
                  data-active={liked}
                  aria-pressed={liked}
                  aria-label={liked ? "Убрать из избранного" : "В избранное"}
                  onClick={() => void toggleLike(track, context)}
                >
                  <Heart size={20} fill={liked ? "currentColor" : "none"} />
                </button>
                <button className="icon-btn" aria-label="Добавить в плейлист" onClick={() => useDialogs.getState().openAddToPlaylist([track])}>
                  <ListPlus size={20} />
                </button>
                {inWave && (
                  <>
                    <button className="icon-btn" aria-label="Больше такого" title="Больше такого" onClick={() => void sendFeedback(track, "more", context)}>
                      <Plus size={20} />
                    </button>
                    <button className="icon-btn" aria-label="Меньше такого" title="Меньше такого звучания" onClick={() => void sendFeedback(track, "less", context)}>
                      <Minus size={20} />
                    </button>
                  </>
                )}
                <button className="icon-btn" aria-label="Music DNA" title="Music DNA" onClick={() => go(`/dna/?track=${encodeURIComponent(track.id)}`)}>
                  <Dna size={20} />
                </button>
                <button className="icon-btn" aria-label="Infinite Descent" title="Infinite Descent отсюда" onClick={() => go(`/descent/?center=${encodeURIComponent(track.id)}`)}>
                  <InfinityIcon size={20} />
                </button>
                <span className="spacer" />
                <div className={styles.volume}>
                  <VolumeControl />
                </div>
                <button className="icon-btn" data-active={queueOpen} aria-pressed={queueOpen} aria-label="Очередь" onClick={() => setQueueOpen(!queueOpen)}>
                  <ListMusic size={20} />
                </button>
              </div>

              <div className={styles.attribution}>
                {streamKind === "preview" && (
                  <p className={styles.preview}>Это официальное 30-секундное превью. Полная версия в Sword Music недоступна.</p>
                )}
                {attribution && (
                  <p>
                    {attribution.source}
                    {attribution.license && (
                      <>
                        {", "}
                        {attribution.license_url ? (
                          <a href={attribution.license_url} target="_blank" rel="noopener noreferrer">
                            {attribution.license}
                          </a>
                        ) : (
                          attribution.license
                        )}
                      </>
                    )}
                    {attribution.page_url && (
                      <a href={attribution.page_url} target="_blank" rel="noopener noreferrer" className={styles.pageLink}>
                        страница трека <ExternalLink size={12} />
                      </a>
                    )}
                  </p>
                )}
              </div>
            </div>
          </div>

          <AnimatePresence>{queueOpen && <QueuePanel onClose={() => setQueueOpen(false)} />}</AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
