"use client";

import { useEffect, useRef } from "react";
import { usePlayer } from "@/lib/player/store";
import { YT_HOST_ID } from "@/lib/player/youtube";
import { SC_HOST_ID, SP_HOST_ID } from "@/lib/player/widgets";
import styles from "./VideoDock.module.css";

/**
 * Home of the official YouTube player. It is always mounted (the player is created inside it on
 * first use) and becomes visible whenever a YouTube track is the current one: YouTube does not
 * allow hidden or audio-only playback. With the full player open it covers the full player's
 * video slot instead of the corner. The iframe is never moved in the DOM, which would reload it.
 */
export function VideoDock() {
  const visible = usePlayer((s) => s.streamKind === "embed" && s.loadedId !== null && s.status !== "idle");
  const full = usePlayer((s) => s.fullOpen);
  const provider = usePlayer((s) => s.attribution?.provider);
  const pageUrl = usePlayer((s) => s.attribution?.page_url);
  const service = provider === "soundcloud" ? "soundcloud" : provider === "spotify_link" ? "spotify" : "youtube";
  const title = service === "soundcloud" ? "SoundCloud" : service === "spotify" ? "Spotify" : "YouTube";
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || !full || !visible) {
      if (el) el.removeAttribute("style");
      return;
    }
    let raf = 0;
    const follow = () => {
      const slot = document.querySelector<HTMLElement>("[data-video-slot]");
      if (slot) {
        const r = slot.getBoundingClientRect();
        el.style.cssText = `top:${r.top}px;left:${r.left}px;width:${r.width}px;height:${Math.max(200, r.height)}px;right:auto;bottom:auto;transform:none;aspect-ratio:auto;min-height:0;max-height:none`;
      }
      raf = requestAnimationFrame(follow);
    };
    follow();
    return () => {
      cancelAnimationFrame(raf);
      el.removeAttribute("style");
    };
  }, [full, visible]);

  return (
    <div ref={ref} className={styles.dock} data-service={service} data-visible={visible || undefined} data-full={full || undefined} aria-hidden={!visible} aria-label={`Плеер ${title}`}>
      {service !== "youtube" && <div className={styles.notice}>
        <span>{service === "spotify" ? "Spotify · доступен фрагмент или версия сервиса" : "SoundCloud · официальный плеер"}</span>
        {pageUrl && <a href={pageUrl} target="_blank" rel="noopener noreferrer" aria-label={`Открыть на ${title}`}>↗</a>}
      </div>}
      <div className={styles.host} hidden={service !== "youtube"}><div id={YT_HOST_ID} /></div>
      <div className={styles.host} hidden={service !== "soundcloud"}><div id={SC_HOST_ID} /></div>
      <div className={styles.host} hidden={service !== "spotify"}><div id={SP_HOST_ID} /></div>
    </div>
  );
}
