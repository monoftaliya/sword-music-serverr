"use client";

import { useRef, useState } from "react";
import { duration as fmt } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import styles from "./SeekBar.module.css";

/** Playback position as a blade of light: the played part is lit, the head glows while playing. */
export function SeekBar({ variant = "full", disabled }: { variant?: "full" | "mini" | "edge"; disabled?: boolean }) {
  const position = usePlayer((s) => s.position);
  const duration = usePlayer((s) => s.duration);
  const buffered = usePlayer((s) => s.buffered);
  const status = usePlayer((s) => s.status);
  const seek = usePlayer((s) => s.seek);
  const controller = usePlayer((s) => s.controller);
  const spotify = usePlayer((s) => s.attribution?.provider === "spotify_link" && s.streamKind === "embed");
  const ref = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<number | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const locked = disabled || spotify || (controller ? !controller.canControl : false) || !duration;

  const shown = drag ?? position;
  const pct = duration ? Math.min(100, (shown / duration) * 100) : 0;
  const bufPct = duration ? Math.min(100, (buffered / duration) * 100) : 0;

  const at = (clientX: number) => {
    const r = ref.current!.getBoundingClientRect();
    return Math.max(0, Math.min(1, (clientX - r.left) / r.width)) * duration;
  };

  if (variant === "edge") {
    return (
      <div className={styles.edge} aria-hidden>
        <div className={styles.edgeFill} style={{ transform: `scaleX(${pct / 100})` }} />
      </div>
    );
  }

  return (
    <div className={styles.wrap} data-variant={variant}>
      {variant === "full" && <span className={`${styles.time} num`}>{fmt(shown)}</span>}
      <div
        ref={ref}
        className={styles.bar}
        data-playing={status === "playing" || undefined}
        data-locked={locked || undefined}
        role="slider"
        tabIndex={locked ? -1 : 0}
        aria-label="Позиция воспроизведения"
        aria-disabled={!!locked}
        title={spotify ? "Перемотка — в официальном плеере Spotify" : undefined}
        aria-valuemin={0}
        aria-valuemax={Math.round(duration)}
        aria-valuenow={Math.round(shown)}
        aria-valuetext={`${fmt(shown)} из ${fmt(duration)}`}
        onPointerDown={(e) => {
          if (locked) return;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          setDrag(at(e.clientX));
        }}
        onPointerMove={(e) => {
          if (locked) return;
          const t = at(e.clientX);
          setHover(t);
          if (drag !== null) setDrag(t);
        }}
        onPointerLeave={() => setHover(null)}
        onPointerUp={(e) => {
          if (drag === null) return;
          seek(at(e.clientX));
          setDrag(null);
        }}
        onPointerCancel={() => setDrag(null)}
        onKeyDown={(e) => {
          if (locked) return;
          if (e.key === "ArrowRight") seek(Math.min(duration, position + 5));
          if (e.key === "ArrowLeft") seek(Math.max(0, position - 5));
        }}
      >
        <div className={styles.rail}>
          <div className={styles.buffer} style={{ width: `${bufPct}%` }} />
          <div className={styles.fill} style={{ width: `${pct}%` }} />
        </div>
        <div className={styles.head} style={{ left: `${pct}%` }} />
        {hover !== null && !locked && variant === "full" && (
          <div className={`${styles.tip} num`} style={{ left: `${(hover / duration) * 100}%` }}>
            {fmt(hover)}
          </div>
        )}
      </div>
      {variant === "full" && <span className={`${styles.time} num`}>{fmt(duration)}</span>}
    </div>
  );
}
