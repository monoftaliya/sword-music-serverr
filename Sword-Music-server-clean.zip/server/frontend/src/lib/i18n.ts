/** New interface copy is keyed so another locale can provide the same dictionary. */
export const ru = {
  home: "Главная", search: "Поиск", wave: "Моя волна", library: "Библиотека",
  discoveries: "Открытия", rooms: "Комнаты", settings: "Настройки",
  lyrics: "Текст песни", albumOfMonth: "Альбом месяца", songOfMonth: "Песня месяца",
  topWeek: "Топ недели", popularGenres: "Популярные жанры", recentlyPlayed: "Недавно прослушанное",
  recommendations: "Рекомендации для тебя", all: "Все",
} as const;

export type Messages = { [K in keyof typeof ru]: string };
export function translate<K extends keyof Messages>(key: K, messages: Messages = ru): string { return messages[key]; }
