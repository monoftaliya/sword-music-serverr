"use client";

import { create } from "zustand";
import { Dialog } from "@/components/ui/Dialog";

interface ConfirmRequest {
  title: string;
  text?: string;
  confirmLabel: string;
  danger?: boolean;
  resolve: (v: boolean) => void;
}

const useConfirm = create<{ req: ConfirmRequest | null; set: (r: ConfirmRequest | null) => void }>((set) => ({
  req: null,
  set: (req) => set({ req }),
}));

/** Promise-based confirmation in the app's own dialog style. */
export function confirmAction(opts: { title: string; text?: string; confirmLabel: string; danger?: boolean }): Promise<boolean> {
  return new Promise((resolve) => useConfirm.getState().set({ ...opts, resolve }));
}

export function ConfirmHost() {
  const req = useConfirm((s) => s.req);
  const set = useConfirm((s) => s.set);
  const done = (v: boolean) => {
    req?.resolve(v);
    set(null);
  };
  return (
    <Dialog
      open={!!req}
      onClose={() => done(false)}
      title={req?.title ?? ""}
      width={420}
      footer={
        <>
          <button className="btn btn-line" onClick={() => done(false)}>
            Отмена
          </button>
          <button className={`btn ${req?.danger ? "btn-danger" : "btn-primary"}`} onClick={() => done(true)} data-autofocus>
            {req?.confirmLabel}
          </button>
        </>
      }
    >
      {req?.text && <p className="t-small" style={{ color: "var(--ink-2)" }}>{req.text}</p>}
    </Dialog>
  );
}
