"use client";

import { useEffect, useState } from "react";
import { setAccentMode } from "./palette";
import { usePlayer } from "./player/store";
import type { UserSettings } from "./types";

export function applySettings(s: Partial<UserSettings> | undefined) {
  if (typeof document === "undefined" || !s) return;
  const root = document.documentElement;
  root.dataset.theme = s.theme ?? "liquid";
  root.dataset.intensity = s.intensity ?? "balanced";
  root.dataset.motionPref = s.motion ?? "system";
  setAccentMode(s.accent ?? "adaptive");
  usePlayer.getState().setCrossfade(s.crossfade ?? 0);
  updateMotion();
}

let mq: MediaQueryList | null = null;

/** Resolve the effective motion level from the user setting and the OS preference. */
export function updateMotion() {
  if (typeof window === "undefined") return;
  const root = document.documentElement;
  mq = mq ?? window.matchMedia("(prefers-reduced-motion: reduce)");
  const pref = root.dataset.motionPref ?? "system";
  const level = pref === "off" ? "off" : pref === "reduced" ? "reduced" : pref === "full" ? "full" : mq.matches ? "reduced" : "full";
  root.dataset.motion = level;
  window.dispatchEvent(new CustomEvent("sword:motion", { detail: level }));
}

export type MotionLevel = "full" | "reduced" | "off";

export function getMotion(): MotionLevel {
  if (typeof document === "undefined") return "full";
  return (document.documentElement.dataset.motion as MotionLevel) ?? "full";
}

export function useMotionLevel(): MotionLevel {
  const [level, setLevel] = useState<MotionLevel>("full");
  useEffect(() => {
    setLevel(getMotion());
    const on = (e: Event) => setLevel((e as CustomEvent<MotionLevel>).detail);
    window.addEventListener("sword:motion", on);
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onMq = () => updateMotion();
    m.addEventListener("change", onMq);
    return () => {
      window.removeEventListener("sword:motion", on);
      m.removeEventListener("change", onMq);
    };
  }, []);
  return level;
}

export function getIntensity(): "minimal" | "balanced" | "rich" {
  if (typeof document === "undefined") return "balanced";
  return (document.documentElement.dataset.intensity as "minimal" | "balanced" | "rich") ?? "balanced";
}
