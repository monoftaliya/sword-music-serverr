export const VERSIONS = [
  { id: "all", label: "Все версии", suffix: "" },
  { id: "original", label: "Оригинал", suffix: "" },
  { id: "sped", label: "Sped up", suffix: "sped up" },
  { id: "slowed", label: "Slowed", suffix: "slowed" },
  { id: "reverb", label: "Slowed + reverb", suffix: "slowed reverb" },
  { id: "nightcore", label: "Nightcore", suffix: "nightcore" },
] as const;
export type Version = typeof VERSIONS[number]["id"];
export function isTrackLink(value: string) { return /^(https?:\/\/|spotify:track:)/i.test(value.trim()); }
export function versionQuery(query: string, version: Version): string {
  const trimmed = query.trim();
  if (!trimmed || isTrackLink(trimmed)) return trimmed;
  const suffix = VERSIONS.find((v) => v.id === version)?.suffix;
  return suffix ? `${trimmed} ${suffix}`.slice(0, 200) : trimmed;
}
export const EXTERNAL_SOURCES = [
  { id: "youtube", name: "YouTube", search: (q: string) => `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}` },
  { id: "soundcloud", name: "SoundCloud", search: (q: string) => `https://soundcloud.com/search/sounds?q=${encodeURIComponent(q)}` },
  { id: "spotify", name: "Spotify", search: (q: string) => `https://open.spotify.com/search/${encodeURIComponent(q)}` },
  { id: "yandex", name: "Яндекс Музыка", search: (q: string) => `https://music.yandex.ru/search?text=${encodeURIComponent(q)}` },
  { id: "bandcamp", name: "Bandcamp", search: (q: string) => `https://bandcamp.com/search?q=${encodeURIComponent(q)}&item_type=t` },
  { id: "deezer", name: "Deezer", search: (q: string) => `https://www.deezer.com/search/${encodeURIComponent(q)}` },
] as const;
