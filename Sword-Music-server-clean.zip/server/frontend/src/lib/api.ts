/** Thin fetch wrapper: same-origin cookies, CSRF header, uniform errors, abortable. */

export class ApiError extends Error {
  status: number;
  code: string;
  data: Record<string, unknown>;

  constructor(status: number, code: string, message: string, data: Record<string, unknown> = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

type Query = Record<string, string | number | boolean | null | undefined>;

export function qs(params: Query): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

let onUnauthorized: (() => void) | null = null;
export function setUnauthorizedHandler(fn: (() => void) | null) {
  onUnauthorized = fn;
}

async function request<T>(method: string, url: string, body?: unknown, init: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = { "X-Sword-Client": "1", ...(init.headers as Record<string, string>) };
  let payload: BodyInit | undefined;
  if (body instanceof FormData) {
    payload = body;
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  let res: Response;
  try {
    res = await fetch(url, { method, credentials: "same-origin", ...init, headers, body: payload });
  } catch (err) {
    if ((err as Error).name === "AbortError") throw err;
    throw new ApiError(0, "offline", "Нет соединения с сервером. Проверьте интернет.");
  }
  if (res.status === 204) return undefined as T;
  let data: unknown = null;
  const text = await res.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }
  if (!res.ok) {
    const err = (data as { error?: { code?: string; message?: string } } | null)?.error;
    if (res.status === 401 && onUnauthorized) onUnauthorized();
    throw new ApiError(
      res.status,
      err?.code ?? "http_" + res.status,
      err?.message ?? (res.status >= 500 ? "Сервер временно недоступен." : "Не удалось выполнить запрос."),
      (err as Record<string, unknown>) ?? {},
    );
  }
  return data as T;
}

export const api = {
  get: <T>(url: string, params?: Query, init?: RequestInit) => request<T>("GET", url + (params ? qs(params) : ""), undefined, init),
  post: <T>(url: string, body?: unknown, init?: RequestInit) => request<T>("POST", url, body ?? {}, init),
  put: <T>(url: string, body?: unknown) => request<T>("PUT", url, body ?? {}),
  patch: <T>(url: string, body?: unknown) => request<T>("PATCH", url, body ?? {}),
  del: <T>(url: string) => request<T>("DELETE", url),
  upload: <T>(url: string, file: File, field = "file") => {
    const fd = new FormData();
    fd.append(field, file);
    return request<T>("POST", url, fd);
  },
};

export function errorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error && err.name !== "AbortError") return err.message;
  return "Что-то пошло не так.";
}
