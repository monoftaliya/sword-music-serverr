import { describe, expect, it } from "vitest";
import { duration, plural, relativeTime, totalDuration } from "./format";

describe("format", () => {
  it("formats durations", () => {
    expect(duration(0)).toBe("0:00");
    expect(duration(61.9)).toBe("1:01");
    expect(duration(3725)).toBe("1:02:05");
    expect(duration(null)).toBe("–:––");
  });

  it("uses Russian plural forms", () => {
    const f: [string, string, string] = ["трек", "трека", "треков"];
    expect(plural(1, f)).toBe("трек");
    expect(plural(3, f)).toBe("трека");
    expect(plural(5, f)).toBe("треков");
    expect(plural(11, f)).toBe("треков");
    expect(plural(21, f)).toBe("трек");
    expect(plural(112, f)).toBe("треков");
  });

  it("summarises total time", () => {
    expect(totalDuration(59 * 60)).toBe("59 минут");
    expect(totalDuration(125 * 60)).toBe("2 часа 5 мин");
  });

  it("describes relative time", () => {
    const now = Date.parse("2026-01-01T12:00:00Z");
    expect(relativeTime("2026-01-01T11:58:00Z", now)).toBe("2 минуты назад");
    expect(relativeTime("2026-01-01T07:00:00Z", now)).toBe("5 часов назад");
  });
});
