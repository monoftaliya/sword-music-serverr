import { create } from "zustand";

export interface Toast {
  id: number;
  title: string;
  message?: string;
  kind: "info" | "success" | "error";
  action?: { label: string; run: () => void };
  ttl: number;
}

interface ToastStore {
  toasts: Toast[];
  push: (t: Omit<Toast, "id" | "ttl"> & { ttl?: number }) => number;
  dismiss: (id: number) => void;
}

let seq = 1;

export const useToasts = create<ToastStore>((set, get) => ({
  toasts: [],
  push: (t) => {
    const id = seq++;
    const toast: Toast = { ttl: t.kind === "error" ? 6500 : 3800, ...t, id };
    set({ toasts: [...get().toasts.filter((x) => x.title !== t.title).slice(-3), toast] });
    if (toast.ttl > 0) setTimeout(() => get().dismiss(id), toast.ttl);
    return id;
  },
  dismiss: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),
}));

export const toast = {
  info: (title: string, message?: string, action?: Toast["action"]) => useToasts.getState().push({ kind: "info", title, message, action }),
  success: (title: string, message?: string, action?: Toast["action"]) => useToasts.getState().push({ kind: "success", title, message, action }),
  error: (title: string, message?: string, action?: Toast["action"]) => useToasts.getState().push({ kind: "error", title, message, action }),
};
