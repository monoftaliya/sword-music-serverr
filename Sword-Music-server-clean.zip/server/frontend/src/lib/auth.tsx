"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, ApiError, setUnauthorizedHandler } from "./api";
import type { User } from "./types";

/** "offline": the server could not be reached, so we do not know yet — never treat that as logged out. */
type Status = "loading" | "authed" | "anon" | "offline";

interface AuthState {
  user: User | null;
  status: Status;
  setUser: (u: User | null) => void;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthCtx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<User | null>(null);
  const [status, setStatus] = useState<Status>("loading");

  const setUser = useCallback((u: User | null) => {
    setUserState(u);
    setStatus(u ? "authed" : "anon");
  }, []);

  const refresh = useCallback(async () => {
    try {
      const { user: u } = await api.get<{ user: User }>("/api/auth/me");
      setUser(u);
    } catch (e) {
      if (e instanceof ApiError && (e.status === 0 || e.status >= 500)) {
        setStatus((s) => (s === "authed" ? s : "offline"));
        return;
      }
      setUser(null);
    }
  }, [setUser]);

  const logout = useCallback(async () => {
    try {
      await api.post("/api/auth/logout");
    } finally {
      setUser(null);
    }
  }, [setUser]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  useEffect(() => {
    setUnauthorizedHandler(() => setUser(null));
    return () => setUnauthorizedHandler(null);
  }, [setUser]);

  useEffect(() => {
    if (status !== "offline") return;
    const retry = () => void refresh();
    const timer = window.setInterval(retry, 8000);
    window.addEventListener("online", retry);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener("online", retry);
    };
  }, [status, refresh]);

  const value = useMemo(() => ({ user, status, setUser, refresh, logout }), [user, status, setUser, refresh, logout]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth outside AuthProvider");
  return ctx;
}

export const PUBLIC_ROUTES = ["/login", "/register", "/forgot", "/reset"];

export function isPublicRoute(pathname: string): boolean {
  const p = pathname.replace(/\/+$/, "") || "/";
  return PUBLIC_ROUTES.some((r) => p === r);
}
