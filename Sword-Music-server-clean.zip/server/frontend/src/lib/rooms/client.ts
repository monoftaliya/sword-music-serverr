"use client";

import { create } from "zustand";
import { getEngine } from "../player/engine";
import { usePlayer } from "../player/store";
import { toast } from "../toast";
import type { RoomState } from "../types";
import { bestOffset, correction, expectedPosition, sampleFrom, type ClockSample } from "./sync";

type Status = "idle" | "connecting" | "open" | "reconnecting" | "closed";

interface RoomStore {
  code: string | null;
  state: RoomState | null;
  status: Status;
  drift: number | null;
  unlocked: boolean;
  userId: string | null;
}

export const useRoom = create<RoomStore>(() => ({ code: null, state: null, status: "idle", drift: null, unlocked: false, userId: null }));

function wsUrl(code: string): string {
  const env = process.env.NEXT_PUBLIC_WS_ORIGIN;
  if (env) return `${env.replace(/\/$/, "")}/api/rooms/${code}/ws`;
  const { protocol, hostname, port, host } = window.location;
  const scheme = protocol === "https:" ? "wss" : "ws";
  // `next dev` runs on :3000 and cannot proxy WebSockets — talk to the API directly
  const target = port === "3000" ? `${hostname}:8000` : host;
  return `${scheme}://${target}/api/rooms/${code}/ws`;
}

class RoomClient {
  private ws: WebSocket | null = null;
  private samples: ClockSample[] = [];
  private offset = 0;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private driftTimer: ReturnType<typeof setInterval> | null = null;
  private retries = 0;
  private wantOpen = false;
  private loadingTrack: string | null = null;
  private unsubEngine: (() => void) | null = null;

  connect(code: string, userId: string) {
    if (useRoom.getState().code === code && this.ws && this.ws.readyState <= 1) return;
    this.disconnect(false);
    this.wantOpen = true;
    this.retries = 0;
    useRoom.setState({ code, status: "connecting", state: null, drift: null, userId });
    this.open(code);
  }

  private open(code: string) {
    const ws = new WebSocket(wsUrl(code));
    this.ws = ws;
    ws.onopen = () => {
      this.retries = 0;
      useRoom.setState({ status: "open" });
      this.samples = [];
      for (let i = 0; i < 5; i++) setTimeout(() => this.ping(), i * 150);
      this.pingTimer = setInterval(() => this.ping(), 10_000);
      this.driftTimer = setInterval(() => this.correct(), 1000);
      if (!this.unsubEngine) {
        this.unsubEngine = getEngine().on((e) => {
          if (e.type !== "ended") return;
          const st = useRoom.getState().state;
          if (st && st.room.owner_id === useRoom.getState().userId) this.send({ t: "ended", item_id: st.now.item_id });
        });
      }
    };
    ws.onmessage = (ev) => {
      let msg: { t: string } & Record<string, unknown>;
      try {
        msg = JSON.parse(ev.data as string);
      } catch {
        return;
      }
      if (msg.t === "pong") {
        this.samples = [...this.samples.slice(-9), sampleFrom(msg.c as number, msg.s as number, Date.now())];
        this.offset = bestOffset(this.samples) ?? this.offset;
      } else if (msg.t === "state") {
        this.apply(msg as unknown as RoomState);
      } else if (msg.t === "error") {
        toast.error("Комната", msg.message as string);
      } else if (msg.t === "closed" || msg.t === "kicked") {
        toast.info(msg.t === "closed" ? "Комната закрыта владельцем" : "Вас удалили из комнаты");
        this.disconnect();
      }
    };
    ws.onclose = (ev) => {
      this.clearTimers();
      if (!this.wantOpen) return;
      if ([4401, 4403, 4404].includes(ev.code)) {
        toast.error("Нет доступа к комнате", ev.code === 4404 ? "Комната закрыта или не существует." : "Сначала присоединитесь к комнате.");
        this.disconnect();
        return;
      }
      if (this.retries < 6) {
        this.retries++;
        useRoom.setState({ status: "reconnecting" });
        setTimeout(() => this.wantOpen && this.open(code), Math.min(8000, 600 * 2 ** this.retries));
      } else {
        useRoom.setState({ status: "closed" });
      }
    };
  }

  private clearTimers() {
    if (this.pingTimer) clearInterval(this.pingTimer);
    if (this.driftTimer) clearInterval(this.driftTimer);
    this.pingTimer = null;
    this.driftTimer = null;
  }

  send(msg: Record<string, unknown>) {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(msg));
    else toast.error("Нет соединения с комнатой", "Переподключаемся…");
  }

  private ping() {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ t: "ping", c: Date.now() }));
  }

  serverNow(): number {
    return Date.now() + this.offset;
  }

  /** User gesture: browsers only allow audio after the listener interacts with the page. */
  unlock() {
    useRoom.setState({ unlocked: true });
    const st = useRoom.getState().state;
    if (st) this.apply(st, true);
  }

  private apply(st: RoomState, force = false) {
    const me = useRoom.getState().userId;
    useRoom.setState({ state: st });
    const isOwner = st.room.owner_id === me;
    const p = usePlayer.getState();
    p.setController({
      label: `Комната «${st.room.name}»`,
      canControl: isOwner,
      toggle: () => {
        const cur = useRoom.getState().state;
        if (!cur?.now.track) return;
        if (!useRoom.getState().unlocked) this.unlock();
        this.send(cur.now.playing ? { t: "pause", pos: Math.round(getEngine().position * 1000) } : { t: "play" });
      },
      next: () => this.send({ t: "next" }),
      prev: () => this.send({ t: "seek", pos: 0 }),
      seek: (sec) => this.send({ t: "seek", pos: Math.round(sec * 1000) }),
    });
    const track = st.now.track;
    const engine = getEngine();
    if (!track) {
      if (!engine.paused) engine.pause();
      return;
    }
    const expected = expectedPosition(st.now.position_ms, st.now.server_ts, st.now.playing, this.serverNow());
    const unlocked = useRoom.getState().unlocked;
    if (p.loadedId !== track.id || force) {
      if (this.loadingTrack === track.id && !force) return;
      this.loadingTrack = track.id;
      usePlayer.setState({ queue: [track], order: [0], pos: 0, context: `room:${st.room.code}` });
      void usePlayer
        .getState()
        .loadCurrent({ autoplay: st.now.playing && unlocked, startAt: expected })
        .finally(() => {
          this.loadingTrack = null;
        });
      return;
    }
    if (st.now.playing && unlocked && engine.paused) void engine.play();
    if (!st.now.playing && !engine.paused) engine.pause();
    if (!st.now.playing) {
      engine.seek(expected);
      usePlayer.setState({ position: expected });
    } else {
      this.correct();
    }
  }

  private correct() {
    const st = useRoom.getState().state;
    if (!st?.now.track || !st.now.playing) {
      useRoom.setState({ drift: null });
      return;
    }
    const engine = getEngine();
    if (engine.paused || usePlayer.getState().loadedId !== st.now.track.id) return;
    const expected = expectedPosition(st.now.position_ms, st.now.server_ts, true, this.serverNow());
    const actual = engine.position;
    const c = correction(actual, expected, true);
    if (c.kind === "seek") engine.seek(c.to);
    else if (c.kind === "rate") engine.setRate(c.rate);
    else engine.setRate(1);
    useRoom.setState({ drift: actual - expected });
  }

  disconnect(stopAudio = true) {
    this.wantOpen = false;
    this.clearTimers();
    try {
      this.ws?.close();
    } catch {
      /* ignore */
    }
    this.ws = null;
    this.unsubEngine?.();
    this.unsubEngine = null;
    const p = usePlayer.getState();
    p.setController(null);
    if (stopAudio && p.context.startsWith("room:")) p.stop();
    try {
      getEngine().setRate(1);
    } catch {
      /* engine not created */
    }
    useRoom.setState({ code: null, state: null, status: "idle", drift: null });
  }
}

export const roomClient = typeof window !== "undefined" ? new RoomClient() : (null as unknown as RoomClient);
