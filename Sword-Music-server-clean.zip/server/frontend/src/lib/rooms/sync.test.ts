import { describe, expect, it } from "vitest";
import { bestOffset, correction, expectedPosition, sampleFrom } from "./sync";

describe("room clock sync", () => {
  it("estimates offset from a symmetric round trip", () => {
    // client sends at 1000, server (ahead by 500 ms) answers at 1550, client receives at 1100
    const s = sampleFrom(1000, 1550, 1100);
    expect(s.rtt).toBe(100);
    expect(s.offset).toBe(500);
  });

  it("prefers low-latency samples", () => {
    const samples = [
      { rtt: 400, offset: 900 },
      { rtt: 30, offset: 505 },
      { rtt: 35, offset: 498 },
      { rtt: 300, offset: 100 },
      { rtt: 40, offset: 502 },
      { rtt: 250, offset: 750 },
    ];
    expect(bestOffset(samples)).toBeGreaterThanOrEqual(498);
    expect(bestOffset(samples)).toBeLessThanOrEqual(505);
    expect(bestOffset([])).toBeNull();
  });

  it("computes the expected position only while playing", () => {
    expect(expectedPosition(10_000, 5_000, true, 7_500)).toBe(12.5);
    expect(expectedPosition(10_000, 5_000, false, 7_500)).toBe(10);
  });

  it("chooses rate nudges for small drift and seeks for large drift", () => {
    expect(correction(10.05, 10, true)).toEqual({ kind: "none" });
    expect(correction(10.4, 10, true)).toEqual({ kind: "rate", rate: 0.96 });
    expect(correction(9.6, 10, true)).toEqual({ kind: "rate", rate: 1.04 });
    expect(correction(12, 10, true)).toEqual({ kind: "seek", to: 10 });
    expect(correction(10.5, 10, false)).toEqual({ kind: "seek", to: 10 });
  });
});
