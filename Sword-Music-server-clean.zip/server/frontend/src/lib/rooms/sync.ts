/** Pure clock-sync and drift maths (unit-tested). */

export interface ClockSample {
  rtt: number;
  offset: number;
}

/** NTP-style offset estimate from one ping/pong: server_time - client_midpoint. */
export function sampleFrom(clientSent: number, serverTime: number, clientReceived: number): ClockSample {
  const rtt = Math.max(0, clientReceived - clientSent);
  return { rtt, offset: serverTime - (clientSent + rtt / 2) };
}

/** Use the samples with the lowest round-trip time — they carry the least network asymmetry. */
export function bestOffset(samples: ClockSample[]): number | null {
  if (!samples.length) return null;
  const sorted = [...samples].sort((a, b) => a.rtt - b.rtt);
  const best = sorted.slice(0, Math.max(1, Math.ceil(sorted.length / 3)));
  const offsets = best.map((s) => s.offset).sort((a, b) => a - b);
  return offsets[Math.floor(offsets.length / 2)];
}

/** Where the room's playback should be right now (seconds). */
export function expectedPosition(positionMs: number, serverTs: number, playing: boolean, serverNow: number): number {
  return (positionMs + (playing ? Math.max(0, serverNow - serverTs) : 0)) / 1000;
}

export type Correction = { kind: "none" } | { kind: "seek"; to: number } | { kind: "rate"; rate: number };

/**
 * Small drift is absorbed by nudging the playback rate (inaudible ±4%), large
 * drift by a seek. Thresholds are deliberately conservative to avoid ping-pong.
 */
export function correction(actual: number, expected: number, canRate: boolean): Correction {
  const drift = actual - expected;
  const abs = Math.abs(drift);
  if (abs > 1.2 || (!canRate && abs > 0.35)) return { kind: "seek", to: expected };
  if (abs > 0.12 && canRate) return { kind: "rate", rate: drift > 0 ? 0.96 : 1.04 };
  return { kind: "none" };
}
