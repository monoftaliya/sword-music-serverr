import type { Track } from "./types";

export interface DashboardData {
  weekly: (Track & { rank: number; plays: number | null })[];
  weekly_source: string;
  weekly_url: string | null;
  weekly_error: string | null;
  song_of_month: Track | null;
  album_of_month: { key: string; name: string; artist: string; artwork: string | null; plays: number; track: Track; release_date: string | null } | null;
  monthly_basis: string;
  genres: { key: string; name: string; tracks: number }[];
  genres_basis: string;
  sources: { youtube: string; genius: boolean; lyrics: boolean; musicbrainz: string };
}

export interface LyricsData {
  genius: { configured: boolean; matched: boolean; url: string; title?: string; album?: string; release_date?: string; unavailable?: boolean };
  lyrics: { source: string; synced: boolean; instrumental: boolean; lines: { time: number; text: string }[]; plain: string | null; url?: string; unavailable?: boolean };
}

/** Binary search prevents a full lyric scan on every playback time update. */
export function activeLyric(lines: { time: number }[], position: number): number {
  let left = 0, right = lines.length - 1, result = -1;
  while (left <= right) {
    const middle = (left + right) >>> 1;
    if (lines[middle].time <= position) { result = middle; left = middle + 1; }
    else right = middle - 1;
  }
  return result;
}

export function collectionKey(ids: string[]): string { return ids.join("\u001f"); }
