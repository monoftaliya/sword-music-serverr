import { expect, it } from "vitest";
import { EXTERNAL_SOURCES, versionQuery } from "./music-sources";

it("keeps the user's artist query and appends only the selected recording version", () => {
  expect(versionQuery(" PHARAOH ", "slowed")).toBe("PHARAOH slowed");
  expect(versionQuery("Playboi Carti", "sped")).toBe("Playboi Carti sped up");
  expect(versionQuery("Скриптонит", "original")).toBe("Скриптонит");
  expect(versionQuery("", "reverb")).toBe("");
});
it("doesn't corrupt imported service URLs when a version filter is selected", () => {
  for (const url of ["https://soundcloud.com/a/b?si=x", "https://youtu.be/abcdefghijk", "spotify:track:4cOdK2wGLETKBW3PvgPWqT"]) {
    expect(versionQuery(url, "nightcore")).toBe(url);
  }
});
it("encodes Russian text and special characters into genuine service searches", () => {
  const q = "Скриптонит & A$AP / slowed+reverb";
  for (const source of EXTERNAL_SOURCES) {
    const url = new URL(source.search(q));
    expect(url.protocol).toBe("https:");
    expect(decodeURIComponent(url.href)).toContain(q);
    expect(url.hash).toBe("");
  }
});
