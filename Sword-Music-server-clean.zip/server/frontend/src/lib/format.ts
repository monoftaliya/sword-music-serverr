export function duration(sec: number | null | undefined): string {
  if (sec === null || sec === undefined || !Number.isFinite(sec) || sec < 0) return "–:––";
  const s = Math.floor(sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}` : `${m}:${String(r).padStart(2, "0")}`;
}

/** Russian plural forms: plural(5, ["трек", "трека", "треков"]) -> "треков" */
export function plural(n: number, forms: [string, string, string]): string {
  const abs = Math.abs(n) % 100;
  const last = abs % 10;
  if (abs > 10 && abs < 20) return forms[2];
  if (last > 1 && last < 5) return forms[1];
  if (last === 1) return forms[0];
  return forms[2];
}

export function count(n: number, forms: [string, string, string]): string {
  return `${n} ${plural(n, forms)}`;
}

export function totalDuration(sec: number): string {
  const m = Math.round(sec / 60);
  if (m < 60) return count(m, ["минута", "минуты", "минут"]);
  const h = Math.floor(m / 60);
  const rest = m % 60;
  return rest ? `${count(h, ["час", "часа", "часов"])} ${rest} мин` : count(h, ["час", "часа", "часов"]);
}

export function greeting(date = new Date()): string {
  const h = date.getHours();
  if (h >= 5 && h < 12) return "Доброе утро";
  if (h >= 12 && h < 17) return "Добрый день";
  if (h >= 17 && h < 23) return "Добрый вечер";
  return "Доброй ночи";
}

export function relativeTime(iso: string | null | undefined, now = Date.now()): string {
  if (!iso) return "";
  const t = new Date(iso).getTime();
  const diff = Math.max(0, now - t) / 1000;
  if (diff < 60) return "только что";
  if (diff < 3600) return `${count(Math.floor(diff / 60), ["минуту", "минуты", "минут"])} назад`;
  if (diff < 86400) return `${count(Math.floor(diff / 3600), ["час", "часа", "часов"])} назад`;
  if (diff < 86400 * 7) return `${count(Math.floor(diff / 86400), ["день", "дня", "дней"])} назад`;
  return new Date(iso).toLocaleDateString("ru-RU", { day: "numeric", month: "short" });
}

export function bytes(n: number): string {
  if (n < 1024) return `${n} Б`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(0)} КБ`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} МБ`;
  return `${(n / 1024 ** 3).toFixed(2)} ГБ`;
}

/** Deterministic hash for procedural covers. */
export function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "♪";
  return (parts[0][0] + (parts[1]?.[0] ?? "")).toUpperCase();
}
