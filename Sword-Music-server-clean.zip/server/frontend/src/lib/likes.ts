"use client";

import { create } from "zustand";
import { api, errorMessage } from "./api";
import { usePlayer } from "./player/store";
import { toast } from "./toast";
import type { Track } from "./types";

interface LikeStore {
  overrides: Record<string, boolean>;
  set: (id: string, v: boolean) => void;
}

/** Optimistic like state shared by every list, the player and the wave. */
export const useLikeStore = create<LikeStore>((set, get) => ({
  overrides: {},
  set: (id, v) => set({ overrides: { ...get().overrides, [id]: v } }),
}));

export function useLiked(track: Track | null | undefined): boolean {
  return useLikeStore((s) => (track ? (s.overrides[track.id] ?? track.liked) : false));
}

export async function toggleLike(track: Track, context = "") {
  const store = useLikeStore.getState();
  const was = store.overrides[track.id] ?? track.liked;
  store.set(track.id, !was);
  usePlayer.getState().updateTrack(track.id, { liked: !was });
  try {
    if (context.startsWith("wave") || context.startsWith("mode")) {
      await api.post("/api/wave/feedback", { track_id: track.id, kind: was ? "unlike" : "like", context });
    } else if (was) {
      await api.del(`/api/library/favorites/${encodeURIComponent(track.id)}`);
    } else {
      await api.put(`/api/library/favorites/${encodeURIComponent(track.id)}`);
    }
  } catch (err) {
    store.set(track.id, was);
    usePlayer.getState().updateTrack(track.id, { liked: was });
    toast.error("Не удалось обновить избранное", errorMessage(err));
  }
}
