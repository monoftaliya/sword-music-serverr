/**
 * Audio engine: two <audio> elements so the next track can be faded in while the
 * current one fades out. Crossfade relies on element.volume, which iOS Safari does
 * not allow scripts to change — there the engine falls back to a hard cut and the
 * settings screen says so. The engine never touches raw audio data, so it works
 * with any source that allows plain playback (no CORS needed).
 * YouTube tracks ("embed") play in the official YouTube player instead (see youtube.ts);
 * the engine routes every command to whichever one is active.
 */
import { YouTubeBackend } from "./youtube";
import { OfficialWidgetBackend } from "./widgets";

export type EngineEvent =
  | { type: "time"; position: number; duration: number; buffered: number }
  | { type: "state"; state: "loading" | "playing" | "paused" }
  | { type: "ended" }
  | { type: "error"; code: number; message: string }
  | { type: "crossfaded" };

type Listener = (e: EngineEvent) => void;

function detectVolumeControl(): boolean {
  try {
    const a = document.createElement("audio");
    a.volume = 0.5;
    return Math.abs(a.volume - 0.5) < 0.01;
  } catch {
    return false;
  }
}

const MEDIA_ERRORS: Record<number, string> = {
  1: "Воспроизведение прервано.",
  2: "Сетевая ошибка при загрузке трека.",
  3: "Не удалось декодировать аудио.",
  4: "Источник не отдаёт этот трек или формат не поддерживается браузером.",
};

export class AudioEngine {
  private els: [HTMLAudioElement, HTMLAudioElement];
  private active = 0;
  private listeners = new Set<Listener>();
  private raf = 0;
  private fadeRaf = 0;
  private lastEmit = 0;
  private volume = 0.9;
  private muted = false;
  private fading = false;
  private mode: "audio" | "yt" | "soundcloud" | "spotify" = "audio";
  private yt: YouTubeBackend;
  private sc: OfficialWidgetBackend;
  private sp: OfficialWidgetBackend;
  private get embed() { return this.mode === "soundcloud" ? this.sc : this.mode === "spotify" ? this.sp : this.yt; }
  readonly canControlVolume: boolean;

  constructor() {
    this.yt = new YouTubeBackend((e) => { if (this.mode === "yt") this.emit(e); });
    this.sc = new OfficialWidgetBackend("soundcloud", (e) => { if (this.mode === "soundcloud") this.emit(e); });
    this.sp = new OfficialWidgetBackend("spotify", (e) => { if (this.mode === "spotify") this.emit(e); });
    this.els = [this.make(), this.make()];
    this.canControlVolume = detectVolumeControl();
    this.applyVolume();
  }

  private make(): HTMLAudioElement {
    const el = document.createElement("audio");
    el.preload = "auto";
    el.setAttribute("playsinline", "");
    el.dataset.swordAudio = "1";
    el.style.display = "none";
    document.body.appendChild(el);
    el.addEventListener("playing", () => this.isAudio(el) && this.emit({ type: "state", state: "playing" }));
    el.addEventListener("pause", () => this.isAudio(el) && !this.fading && this.emit({ type: "state", state: "paused" }));
    el.addEventListener("waiting", () => this.isAudio(el) && this.emit({ type: "state", state: "loading" }));
    el.addEventListener("ended", () => this.isAudio(el) && this.emit({ type: "ended" }));
    el.addEventListener("error", () => {
      if (!this.isAudio(el) || !el.getAttribute("src")) return;
      const code = el.error?.code ?? 0;
      this.emit({ type: "error", code, message: MEDIA_ERRORS[code] ?? "Ошибка воспроизведения." });
    });
    el.addEventListener("durationchange", () => el === this.el && this.tick(true));
    el.addEventListener("seeked", () => el === this.el && this.tick(true));
    return el;
  }

  private isAudio(el: HTMLAudioElement): boolean {
    return this.mode === "audio" && el === this.el;
  }

  /** True when a YouTube video is the current source. */
  get isEmbed(): boolean {
    return this.mode !== "audio";
  }

  /** Something is loaded and can be resumed without resolving the track again. */
  get hasSource(): boolean {
    return this.isEmbed ? this.embed.active : !!this.el.getAttribute("src");
  }

  get el(): HTMLAudioElement {
    return this.els[this.active];
  }

  private get standby(): HTMLAudioElement {
    return this.els[1 - this.active];
  }

  on(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(e: EngineEvent) {
    this.listeners.forEach((fn) => fn(e));
  }

  private tick(force = false) {
    if (this.isEmbed) return;
    const now = performance.now();
    if (!force && now - this.lastEmit < 200) return;
    this.lastEmit = now;
    const el = this.el;
    let buffered = 0;
    try {
      if (el.buffered.length) buffered = el.buffered.end(el.buffered.length - 1);
    } catch {
      buffered = 0;
    }
    this.emit({
      type: "time",
      position: el.currentTime || 0,
      duration: Number.isFinite(el.duration) ? el.duration : 0,
      buffered,
    });
  }

  private loop = () => {
    this.tick();
    this.raf = requestAnimationFrame(this.loop);
  };

  private startLoop() {
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
  }

  async load(url: string, { autoplay = true, startAt = 0, kind = "full", provider = "youtube" }: { autoplay?: boolean; startAt?: number; kind?: string; provider?: string } = {}) {
    this.cancelFade();
    this.yt.stop(); this.sc.stop(); this.sp.stop();
    if (kind === "embed") {
      for (const el of this.els) {
        el.pause();
        el.removeAttribute("src");
      }
      cancelAnimationFrame(this.raf);
      this.mode = provider === "soundcloud" ? "soundcloud" : provider === "spotify_link" ? "spotify" : "yt";
      this.embed.setVolume(this.volume, this.muted);
      await this.embed.load(url, autoplay, startAt);
      return;
    }
    this.mode = "audio";
    this.standby.pause();
    this.standby.removeAttribute("src");
    const el = this.el;
    el.src = url;
    el.load();
    if (startAt > 0) {
      const seek = () => {
        try {
          el.currentTime = startAt;
        } catch {
          /* not seekable yet */
        }
      };
      el.addEventListener("loadedmetadata", seek, { once: true });
    }
    this.applyVolume();
    this.emit({ type: "state", state: autoplay ? "loading" : "paused" });
    this.startLoop();
    if (autoplay) await this.play();
  }

  async play(): Promise<boolean> {
    if (this.isEmbed) {
      this.embed.play();
      return true;
    }
    try {
      await this.el.play();
      this.startLoop();
      return true;
    } catch (err) {
      if ((err as Error).name === "NotAllowedError") {
        this.emit({ type: "state", state: "paused" });
        return false; // autoplay policy: user must press play
      }
      if ((err as Error).name !== "AbortError") {
        this.emit({ type: "error", code: 0, message: "Браузер не смог начать воспроизведение." });
      }
      return false;
    }
  }

  pause() {
    if (this.isEmbed) return this.embed.pause();
    this.el.pause();
    this.tick(true);
  }

  seek(sec: number) {
    const el = this.el;
    if (!Number.isFinite(sec)) return;
    if (this.isEmbed) return this.embed.seek(sec);
    try {
      el.currentTime = Math.max(0, Math.min(sec, Number.isFinite(el.duration) ? el.duration - 0.25 : sec));
    } catch {
      /* ignore */
    }
    this.tick(true);
  }

  setRate(rate: number) {
    if (this.isEmbed) return;
    this.el.playbackRate = rate;
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    this.applyVolume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.applyVolume();
  }

  private applyVolume() {
    this.yt.setVolume(this.volume, this.muted);
    this.sc.setVolume(this.volume, this.muted);
    this.sp.setVolume(this.volume, this.muted);
    if (this.fading) return;
    for (const el of this.els) {
      el.muted = this.muted;
      el.volume = this.volume;
    }
  }

  get position(): number {
    if (this.isEmbed) return this.embed.position;
    return this.el.currentTime || 0;
  }

  get duration(): number {
    if (this.isEmbed) return this.embed.duration;
    return Number.isFinite(this.el.duration) ? this.el.duration : 0;
  }

  get paused(): boolean {
    if (this.isEmbed) return this.embed.paused;
    return this.el.paused;
  }

  /** Fade the next track in over `seconds`, then make it the active element. */
  async crossfade(url: string, seconds: number): Promise<boolean> {
    if (!this.canControlVolume || seconds <= 0 || this.fading || this.isEmbed) return false;
    const from = this.el;
    const to = this.standby;
    to.src = url;
    to.load();
    to.volume = 0;
    to.muted = this.muted;
    try {
      await to.play();
    } catch {
      to.removeAttribute("src");
      return false;
    }
    this.fading = true;
    this.active = 1 - this.active;
    this.emit({ type: "crossfaded" });
    const start = performance.now();
    const target = this.volume;
    const step = () => {
      const p = Math.min(1, (performance.now() - start) / (seconds * 1000));
      // equal-power curve keeps loudness steady through the transition
      to.volume = target * Math.sin((p * Math.PI) / 2);
      from.volume = target * Math.cos((p * Math.PI) / 2);
      if (p < 1) {
        this.fadeRaf = requestAnimationFrame(step);
      } else {
        from.pause();
        from.removeAttribute("src");
        from.volume = target;
        this.fading = false;
        this.applyVolume();
      }
    };
    this.fadeRaf = requestAnimationFrame(step);
    this.startLoop();
    return true;
  }

  private cancelFade() {
    if (!this.fading) return;
    cancelAnimationFrame(this.fadeRaf);
    this.fading = false;
    this.standby.pause();
    this.standby.removeAttribute("src");
    this.applyVolume();
  }

  stop() {
    this.cancelFade();
    this.yt.stop(); this.sc.stop(); this.sp.stop();
    this.mode = "audio";
    for (const el of this.els) {
      el.pause();
      el.removeAttribute("src");
      el.load();
    }
    cancelAnimationFrame(this.raf);
  }
}

let engine: AudioEngine | null = null;

export function getEngine(): AudioEngine {
  if (typeof window === "undefined") throw new Error("AudioEngine is browser-only");
  if (!engine) engine = new AudioEngine();
  return engine;
}

export function hasEngine(): boolean {
  return engine !== null;
}
