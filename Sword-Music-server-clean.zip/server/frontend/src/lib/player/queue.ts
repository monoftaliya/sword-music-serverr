/** Pure queue logic (unit-tested). `order` holds indices into `queue`; `pos` points into `order`. */
import type { Track } from "../types";

export type Repeat = "off" | "all" | "one";

export interface Q {
  queue: Track[];
  order: number[];
  pos: number;
  shuffle: boolean;
  repeat: Repeat;
}

export function shuffled<T>(items: T[], rng: () => number = Math.random): T[] {
  const a = items.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeOrder(n: number, start: number, shuffle: boolean, rng?: () => number): number[] {
  const all = Array.from({ length: n }, (_, i) => i);
  if (!shuffle || n < 2) return all;
  const rest = shuffled(all.filter((i) => i !== start), rng);
  return [start, ...rest];
}

export function create(queue: Track[], start: number, shuffle: boolean, repeat: Repeat, rng?: () => number): Q {
  const s = Math.max(0, Math.min(start, queue.length - 1));
  const order = makeOrder(queue.length, s, shuffle, rng);
  return { queue, order, pos: shuffle ? 0 : s, shuffle, repeat };
}

export function current(q: Q): Track | null {
  if (!q.queue.length) return null;
  return q.queue[q.order[q.pos]] ?? null;
}

export function upcoming(q: Q): { track: Track; pos: number }[] {
  return q.order.slice(q.pos + 1).map((i, k) => ({ track: q.queue[i], pos: q.pos + 1 + k }));
}

export function history(q: Q): { track: Track; pos: number }[] {
  return q.order.slice(0, q.pos).map((i, k) => ({ track: q.queue[i], pos: k }));
}

/** Position after the current track. `manual` = user pressed "next" (repeat-one doesn't trap them). */
export function nextPos(q: Q, manual: boolean): number | null {
  if (!q.queue.length) return null;
  if (q.repeat === "one" && !manual) return q.pos;
  if (q.pos + 1 < q.order.length) return q.pos + 1;
  if (q.repeat === "all" || (q.repeat === "one" && manual)) return 0;
  return null;
}

export function prevPos(q: Q): number {
  if (q.pos > 0) return q.pos - 1;
  return q.repeat === "all" ? q.order.length - 1 : 0;
}

export function append(q: Q, tracks: Track[]): Q {
  const known = new Set(q.queue.map((t) => t.id));
  const fresh = tracks.filter((t) => !known.has(t.id));
  if (!fresh.length) return q;
  const base = q.queue.length;
  return {
    ...q,
    queue: [...q.queue, ...fresh],
    order: [...q.order, ...fresh.map((_, i) => base + i)],
  };
}

export function insertNext(q: Q, track: Track): Q {
  const queue = [...q.queue, track];
  const idx = queue.length - 1;
  const order = [...q.order];
  order.splice(q.queue.length ? q.pos + 1 : 0, 0, idx);
  return { ...q, queue, order };
}

export function removeAt(q: Q, pos: number): Q {
  if (pos === q.pos || pos < 0 || pos >= q.order.length) return q;
  const qi = q.order[pos];
  const queue = q.queue.filter((_, i) => i !== qi);
  const order = q.order.filter((_, p) => p !== pos).map((i) => (i > qi ? i - 1 : i));
  return { ...q, queue, order, pos: pos < q.pos ? q.pos - 1 : q.pos };
}

/** Move an upcoming item (positions after the current one only). */
export function move(q: Q, from: number, to: number): Q {
  if (from <= q.pos || to <= q.pos || from >= q.order.length || to >= q.order.length || from === to) return q;
  const order = [...q.order];
  const [item] = order.splice(from, 1);
  order.splice(to, 0, item);
  return { ...q, order };
}

export function setShuffle(q: Q, on: boolean, rng?: () => number): Q {
  if (on === q.shuffle) return q;
  const cur = q.order[q.pos] ?? 0;
  if (on) {
    const rest = shuffled(
      Array.from({ length: q.queue.length }, (_, i) => i).filter((i) => i !== cur),
      rng,
    );
    return { ...q, shuffle: true, order: q.queue.length ? [cur, ...rest] : [], pos: 0 };
  }
  return { ...q, shuffle: false, order: Array.from({ length: q.queue.length }, (_, i) => i), pos: cur };
}
