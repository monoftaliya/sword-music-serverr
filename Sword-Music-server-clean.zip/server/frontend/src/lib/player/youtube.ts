/**
 * YouTube playback through the official IFrame Player API.
 * The player lives in a visible window (components/player/VideoDock) for as long as a YouTube
 * track plays: YouTube's policies forbid audio-only, hidden or background players and blocking ads.
 */
import type { EngineEvent } from "./engine";

/* Minimal typing of the parts of the IFrame API we use. */
interface YTPlayer {
  loadVideoById(o: { videoId: string; startSeconds?: number }): void;
  cueVideoById(o: { videoId: string; startSeconds?: number }): void;
  playVideo(): void;
  pauseVideo(): void;
  stopVideo(): void;
  seekTo(seconds: number, allowSeekAhead: boolean): void;
  setVolume(v: number): void;
  mute(): void;
  unMute(): void;
  getCurrentTime(): number;
  getDuration(): number;
  getPlayerState(): number;
  getVideoLoadedFraction(): number;
}
interface YTNamespace {
  Player: new (el: HTMLElement, opts: Record<string, unknown>) => YTPlayer;
}
declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

export const YT_HOST_ID = "sword-yt-host";

const ERRORS: Record<number, string> = {
  2: "YouTube не принял этот ролик.",
  5: "Плеер YouTube не смог воспроизвести ролик.",
  100: "Ролик удалён или стал приватным.",
  101: "Владелец ролика запретил воспроизведение на других сайтах.",
  150: "Владелец ролика запретил воспроизведение на других сайтах.",
};

let apiPromise: Promise<YTNamespace> | null = null;

function loadApi(): Promise<YTNamespace> {
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (!apiPromise) {
    apiPromise = new Promise<YTNamespace>((resolve, reject) => {
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        prev?.();
        if (window.YT) resolve(window.YT);
      };
      const s = document.createElement("script");
      s.src = "https://www.youtube.com/iframe_api";
      s.async = true;
      s.onerror = () => {
        apiPromise = null;
        reject(new Error("YouTube недоступен"));
      };
      document.head.appendChild(s);
    });
  }
  return apiPromise;
}

export class YouTubeBackend {
  private player: YTPlayer | null = null;
  private ready: Promise<void> | null = null;
  private videoId: string | null = null;
  private timer = 0;
  private volume = 0.9;
  private muted = false;

  constructor(private emit: (e: EngineEvent) => void) {}

  get active(): boolean {
    return this.videoId !== null;
  }

  private ensure(): Promise<void> {
    if (this.ready) return this.ready;
    this.ready = loadApi().then(
      (YT) =>
        new Promise<void>((resolve, reject) => {
          const host = document.getElementById(YT_HOST_ID);
          if (!host) return reject(new Error("Нет места для плеера YouTube"));
          const mount = document.createElement("div");
          host.replaceChildren(mount);
          this.player = new YT.Player(mount, {
            width: "100%",
            height: "100%",
            playerVars: { playsinline: 1, rel: 0, origin: window.location.origin },
            events: {
              onReady: () => resolve(),
              onStateChange: (e: { data: number }) => this.onState(e.data),
              onError: (e: { data: number }) => this.onError(e.data),
            },
          });
        }),
    );
    this.ready.catch(() => {
      this.ready = null;
    });
    return this.ready;
  }

  async load(videoId: string, autoplay: boolean, startAt: number): Promise<void> {
    this.videoId = videoId;
    this.emit({ type: "state", state: autoplay ? "loading" : "paused" });
    try {
      await this.ensure();
    } catch {
      this.emit({ type: "error", code: 9001, message: "Не удалось загрузить плеер YouTube. Проверьте интернет." });
      return;
    }
    if (this.videoId !== videoId || !this.player) return;
    this.applyVolume();
    const opts = { videoId, startSeconds: Math.max(0, Math.floor(startAt)) };
    if (autoplay) this.player.loadVideoById(opts);
    else this.player.cueVideoById(opts);
    this.startPoll();
  }

  private onState(state: number) {
    if (!this.videoId) return;
    // -1 unstarted, 0 ended, 1 playing, 2 paused, 3 buffering, 5 cued
    if (state === 1) this.emit({ type: "state", state: "playing" });
    else if (state === 2 || state === 5) this.emit({ type: "state", state: "paused" });
    else if (state === 3) this.emit({ type: "state", state: "loading" });
    else if (state === 0) this.emit({ type: "ended" });
    this.tick();
  }

  private onError(code: number) {
    if (!this.videoId) return;
    this.emit({ type: "error", code: 9000 + code, message: ERRORS[code] ?? "Ошибка плеера YouTube." });
  }

  private tick() {
    const p = this.player;
    if (!p || !this.videoId) return;
    try {
      const duration = p.getDuration() || 0;
      this.emit({ type: "time", position: p.getCurrentTime() || 0, duration, buffered: duration * (p.getVideoLoadedFraction() || 0) });
    } catch {
      /* player not ready yet */
    }
  }

  private startPoll() {
    window.clearInterval(this.timer);
    this.timer = window.setInterval(() => this.tick(), 250);
  }

  play() {
    this.player?.playVideo();
  }

  pause() {
    this.player?.pauseVideo();
    this.tick();
  }

  seek(sec: number) {
    this.player?.seekTo(Math.max(0, sec), true);
    this.tick();
  }

  setVolume(v: number, muted: boolean) {
    this.volume = v;
    this.muted = muted;
    this.applyVolume();
  }

  private applyVolume() {
    const p = this.player;
    if (!p) return;
    try {
      p.setVolume(Math.round(this.volume * 100));
      if (this.muted) p.mute();
      else p.unMute();
    } catch {
      /* not ready */
    }
  }

  get position(): number {
    try {
      return this.player?.getCurrentTime() ?? 0;
    } catch {
      return 0;
    }
  }

  get duration(): number {
    try {
      return this.player?.getDuration() ?? 0;
    } catch {
      return 0;
    }
  }

  get paused(): boolean {
    try {
      return this.player?.getPlayerState() !== 1;
    } catch {
      return true;
    }
  }

  stop() {
    window.clearInterval(this.timer);
    this.videoId = null;
    try {
      this.player?.stopVideo();
    } catch {
      /* ignore */
    }
  }
}
