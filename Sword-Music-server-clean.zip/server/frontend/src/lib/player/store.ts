"use client";

import { create } from "zustand";
import { ApiError, api } from "../api";
import { applyPalette } from "../palette";
import { toast } from "../toast";
import type { Palette, Track } from "../types";
import { getEngine, hasEngine } from "./engine";
import * as Q from "./queue";

export interface Attribution {
  source: string;
  provider: string;
  artist: string;
  page_url: string | null;
  license: string | null;
  license_url: string | null;
}

interface PlayResponse {
  url: string;
  kind: "full" | "preview" | "embed";
  mime: string | null;
  attribution: Attribution;
}

/** A room (or another remote controller) can take over transport controls. */
export interface ExternalController {
  label: string;
  canControl: boolean;
  toggle: () => void;
  next: () => void;
  prev: () => void;
  seek: (sec: number) => void;
}

type Status = "idle" | "loading" | "playing" | "paused" | "error";

interface PlayerState extends Q.Q {
  context: string;
  status: Status;
  position: number;
  duration: number;
  buffered: number;
  volume: number;
  muted: boolean;
  streamKind: "full" | "preview" | "embed";
  attribution: Attribution | null;
  palette: Palette | null;
  error: string | null;
  loadedId: string | null;
  fullOpen: boolean;
  queueOpen: boolean;
  crossfade: number;
  controller: ExternalController | null;
  continuing: boolean;

  playList: (tracks: Track[], start: number, context: string) => void;
  playTrack: (track: Track, context: string) => void;
  loadCurrent: (opts?: { autoplay?: boolean; startAt?: number; explicit?: boolean }) => Promise<void>;
  toggle: () => void;
  play: () => void;
  pause: () => void;
  next: (manual?: boolean) => void;
  prev: () => void;
  jumpTo: (pos: number) => void;
  seek: (sec: number) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  addToQueue: (t: Track) => void;
  playNext: (t: Track) => void;
  removeAt: (pos: number) => void;
  move: (from: number, to: number) => void;
  reorderUpcoming: (queueIndices: number[]) => void;
  clearUpcoming: () => void;
  appendTracks: (tracks: Track[]) => void;
  replaceCurrent: (t: Track) => void;
  updateTrack: (id: string, patch: Partial<Track>) => void;
  setFullOpen: (v: boolean) => void;
  setQueueOpen: (v: boolean) => void;
  setCrossfade: (s: number) => void;
  setController: (c: ExternalController | null) => void;
  restore: (queue: Track[], index: number, positionSec: number, context: string) => void;
  stop: () => void;
}

// ------------------------------------------------------------------ listening events
let evTrack: Track | null = null;
let evContext = "";
let evPlayedMs = 0;
let evLastPos = 0;
let skipStreak = 0;
const resolved = new Map<string, { at: number; data: PlayResponse }>();

function modeOf(context: string): string | null {
  if (context.startsWith("wave:")) return context.split(":")[1] ?? null;
  if (context.startsWith("mode:")) return context.split(":")[1] ?? null;
  return null;
}

function flushEvent(reason: "ended" | "skip" | "prev" | "stop" | "switch" | "error") {
  const t = evTrack;
  if (!t) return;
  const played = Math.round(evPlayedMs);
  evTrack = null;
  evPlayedMs = 0;
  if (played < 4000 && reason !== "skip") return;
  const body = {
    track_id: t.id,
    played_ms: played,
    duration_ms: Math.round((t.duration ?? 0) * 1000),
    end_reason: reason,
    context: evContext.slice(0, 80),
    mode: modeOf(evContext),
  };
  fetch("/api/events/play", {
    method: "POST",
    keepalive: true,
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-Sword-Client": "1" },
    body: JSON.stringify(body),
  }).catch(() => undefined);
}

async function resolveTrack(id: string, signal?: AbortSignal): Promise<PlayResponse> {
  const hit = resolved.get(id);
  if (hit && Date.now() - hit.at < 5 * 60 * 1000) return hit.data;
  const data = await api.get<PlayResponse>(`/api/tracks/${encodeURIComponent(id)}/play`, undefined, { signal });
  resolved.set(id, { at: Date.now(), data });
  return data;
}

// ------------------------------------------------------------------ persistence
let saveTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleSave(get: () => PlayerState, delay = 1500) {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => saveNow(get), delay);
}
export function saveNow(get: () => PlayerState, keepalive = false) {
  const s = get();
  if (!s.queue.length || s.context.startsWith("room:")) return;
  const ids = s.order.map((i) => s.queue[i]?.id).filter(Boolean).slice(0, 500);
  const body = {
    queue: ids,
    index: Math.min(s.pos, ids.length - 1),
    position_ms: Math.round(s.position * 1000),
    shuffle: s.shuffle,
    repeat: s.repeat,
    context: s.context.slice(0, 120),
    device: typeof navigator !== "undefined" ? navigator.platform.slice(0, 60) : "",
  };
  fetch("/api/me/player-state", {
    method: "PUT",
    keepalive,
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-Sword-Client": "1" },
    body: JSON.stringify(body),
  }).catch(() => undefined);
}

let loadSeq = 0;
let loadAbort: AbortController | null = null;

/** Tracks found to be unavailable during this session, so every list marks them, not just the queue. */
export const useLostTracks = create<{ ids: Record<string, string> }>(() => ({ ids: {} }));
export function markLost(id: string, message: string) {
  useLostTracks.setState((s) => ({ ids: { ...s.ids, [id]: message } }));
}

export const usePlayer = create<PlayerState>((set, get) => ({
  queue: [],
  order: [],
  pos: 0,
  shuffle: false,
  repeat: "off",
  context: "",
  status: "idle",
  position: 0,
  duration: 0,
  buffered: 0,
  volume: 0.9,
  muted: false,
  streamKind: "full",
  attribution: null,
  palette: null,
  error: null,
  loadedId: null,
  fullOpen: false,
  queueOpen: false,
  crossfade: 0,
  controller: null,
  continuing: false,

  playList: (tracks, start, context) => {
    if (!tracks.length) return;
    if (get().controller) {
      toast.info("Сейчас вы в комнате", "Выйдите из комнаты, чтобы слушать отдельно.");
      return;
    }
    flushEvent("switch");
    const q = Q.create(tracks, start, get().shuffle, get().repeat);
    set({ ...q, context, position: 0, duration: tracks[start]?.duration ?? 0, error: null });
    skipStreak = 0;
    void get().loadCurrent({ autoplay: true, explicit: true });
  },

  playTrack: (track, context) => get().playList([track], 0, context),

  loadCurrent: async ({ autoplay = true, startAt = 0, explicit = false } = {}) => {
    const s = get();
    const track = Q.current(s);
    if (!track) return;
    const seq = ++loadSeq;
    loadAbort?.abort();
    loadAbort = new AbortController();
    const engine = getEngine();
    set({ status: autoplay ? "loading" : "paused", error: null, loadedId: track.id, position: startAt, duration: track.duration ?? 0 });
    evTrack = track;
    evContext = s.context;
    evPlayedMs = 0;
    evLastPos = startAt;
    updateMediaSession(track);
    fetchPalette(track, set, get);

    if (!track.playable) {
      handleUnavailable(track, track.unavailable || "Источник не разрешает воспроизведение.", [], explicit);
      return;
    }
    try {
      const res = await resolveTrack(track.id, loadAbort.signal);
      if (seq !== loadSeq) return;
      set({ streamKind: res.kind, attribution: res.attribution });
      await engine.load(res.url, { autoplay, startAt, kind: res.kind, provider: res.attribution.provider });
      skipStreak = 0;
    } catch (err) {
      if (seq !== loadSeq || (err as Error).name === "AbortError") return;
      if (err instanceof ApiError && (err.status === 409 || err.status === 410)) {
        resolved.delete(track.id);
        get().updateTrack(track.id, { playable: false, unavailable: err.message });
        markLost(track.id, err.message);
        handleUnavailable(track, err.message, (err.data.alternatives as Track[]) ?? [], explicit);
        return;
      }
      set({ status: "error", error: err instanceof ApiError ? err.message : "Не удалось загрузить трек." });
      toast.error("Не удалось начать воспроизведение", err instanceof ApiError ? err.message : undefined, {
        label: "Повторить",
        run: () => void get().loadCurrent({ autoplay: true }),
      });
    }
    scheduleSave(get);
  },

  toggle: () => {
    const c = get().controller;
    if (c) return c.toggle();
    const { status, loadedId } = get();
    const track = Q.current(get());
    if (!track) return;
    if (status === "playing" || status === "loading") return get().pause();
    if (!hasEngine() || loadedId !== track.id || !getEngine().hasSource) {
      void get().loadCurrent({ autoplay: true, startAt: get().position });
      return;
    }
    get().play();
  },

  play: () => {
    void getEngine().play();
  },

  pause: () => {
    if (hasEngine()) getEngine().pause();
    set({ status: "paused" });
    saveNow(get);
  },

  next: (manual = true) => {
    const c = get().controller;
    if (c && manual) return c.next();
    const s = get();
    const pos = Q.nextPos(s, manual);
    flushEvent(manual ? (s.duration && s.position / s.duration > 0.9 ? "ended" : "skip") : "ended");
    if (pos === null) {
      if (isContinuous(s.context)) {
        void continueWave(get, set).then((added) => {
          if (added) get().next(false);
          else set({ status: "paused" });
        });
        return;
      }
      if (hasEngine()) getEngine().pause();
      set({ status: "paused", position: 0 });
      return;
    }
    set({ pos, position: 0 });
    void get().loadCurrent({ autoplay: true });
  },

  prev: () => {
    const c = get().controller;
    if (c) return c.prev();
    const s = get();
    if (s.position > 4) {
      get().seek(0);
      return;
    }
    flushEvent("prev");
    set({ pos: Q.prevPos(s), position: 0 });
    void get().loadCurrent({ autoplay: true });
  },

  jumpTo: (pos) => {
    if (get().controller) return;
    if (pos < 0 || pos >= get().order.length) return;
    flushEvent("switch");
    set({ pos, position: 0 });
    void get().loadCurrent({ autoplay: true, explicit: true });
  },

  seek: (sec) => {
    const c = get().controller;
    if (c) return c.seek(sec);
    if (!hasEngine() || get().loadedId !== Q.current(get())?.id) {
      set({ position: sec });
      return;
    }
    getEngine().seek(sec);
    evLastPos = sec;
    set({ position: sec });
  },

  setVolume: (v) => {
    const vol = Math.max(0, Math.min(1, v));
    set({ volume: vol, muted: vol === 0 ? true : false });
    if (hasEngine()) {
      getEngine().setVolume(vol);
      getEngine().setMuted(vol === 0);
    }
    try {
      localStorage.setItem("sword.volume", String(vol));
    } catch {
      /* storage unavailable */
    }
  },

  toggleMute: () => {
    const m = !get().muted;
    set({ muted: m });
    if (hasEngine()) getEngine().setMuted(m);
  },

  toggleShuffle: () => {
    const s = get();
    set({ ...Q.setShuffle(s, !s.shuffle) });
    scheduleSave(get);
  },

  cycleRepeat: () => {
    const r = get().repeat;
    set({ repeat: r === "off" ? "all" : r === "all" ? "one" : "off" });
    scheduleSave(get);
  },

  addToQueue: (t) => {
    const s = get();
    if (!s.queue.length) return get().playTrack(t, "queue");
    if (s.queue.some((x) => x.id === t.id)) {
      toast.info("Уже в очереди", t.title);
      return;
    }
    set({ ...Q.append(s, [t]) });
    toast.success("Добавлено в очередь", t.title);
    scheduleSave(get);
  },

  playNext: (t) => {
    const s = get();
    if (!s.queue.length) return get().playTrack(t, "queue");
    set({ ...Q.insertNext(s, t) });
    toast.success("Сыграет следующим", t.title);
    scheduleSave(get);
  },

  removeAt: (pos) => {
    set({ ...Q.removeAt(get(), pos) });
    scheduleSave(get);
  },

  move: (from, to) => {
    set({ ...Q.move(get(), from, to) });
    scheduleSave(get);
  },

  reorderUpcoming: (queueIndices) => {
    const s = get();
    const head = s.order.slice(0, s.pos + 1);
    const rest = new Set(s.order.slice(s.pos + 1));
    if (queueIndices.length !== rest.size || !queueIndices.every((i) => rest.has(i))) return;
    set({ order: [...head, ...queueIndices] });
    scheduleSave(get);
  },

  clearUpcoming: () => {
    const s = get();
    const cur = Q.current(s);
    if (!cur) return;
    set({ queue: [cur], order: [0], pos: 0 });
    scheduleSave(get);
  },

  appendTracks: (tracks) => {
    set({ ...Q.append(get(), tracks) });
    scheduleSave(get);
  },

  replaceCurrent: (t) => {
    const s = get();
    const qi = s.order[s.pos];
    const queue = s.queue.slice();
    queue[qi] = t;
    set({ queue });
    void get().loadCurrent({ autoplay: true, explicit: true });
  },

  updateTrack: (id, patch) => {
    const s = get();
    if (!s.queue.some((t) => t.id === id)) return;
    set({ queue: s.queue.map((t) => (t.id === id ? { ...t, ...patch } : t)) });
  },

  setFullOpen: (v) => set({ fullOpen: v, queueOpen: v ? get().queueOpen : false }),
  setQueueOpen: (v) => set({ queueOpen: v }),
  setCrossfade: (s) => set({ crossfade: s }),
  setController: (c) => set({ controller: c }),

  restore: (queue, index, positionSec, context) => {
    if (get().queue.length || !queue.length) return;
    const q = Q.create(queue, index, false, "off");
    set({ ...q, context, position: positionSec, duration: queue[index]?.duration ?? 0, status: "paused" });
    const cur = Q.current(q);
    if (cur) {
      updateMediaSession(cur);
      fetchPalette(cur, set, get);
    }
  },

  stop: () => {
    flushEvent("stop");
    if (hasEngine()) getEngine().stop();
    set({ status: "idle", queue: [], order: [], pos: 0, position: 0, duration: 0, loadedId: null, attribution: null });
    applyPalette(null);
  },
}));

function isContinuous(context: string) {
  return context.startsWith("wave:") || context.startsWith("mode:");
}

function handleUnavailable(track: Track, message: string, alternatives: Track[], explicit: boolean) {
  const store = usePlayer.getState();
  usePlayer.setState({ status: "error", error: message });
  const alt = alternatives.find((a) => a.playable);
  toast.error(`«${track.title}» сейчас недоступен`, message, alt ? { label: `Версия из ${alt.source}`, run: () => usePlayer.getState().replaceCurrent(alt) } : undefined);
  const s = usePlayer.getState();
  skipStreak += 1;
  if (!explicit && skipStreak < Math.max(3, s.queue.length) && Q.nextPos(s, true) !== null) {
    setTimeout(() => {
      if (usePlayer.getState().loadedId === track.id) store.next(false);
    }, 900);
  }
}

// ------------------------------------------------------------------ palette
function fetchPalette(track: Track, set: (p: Partial<PlayerState>) => void, get: () => PlayerState) {
  if (track.palette) {
    set({ palette: track.palette });
    applyPalette(track.palette);
    return;
  }
  if (!track.artwork) {
    set({ palette: null });
    applyPalette(null);
    return;
  }
  api
    .get<{ palette: Palette | null }>(`/api/tracks/${encodeURIComponent(track.id)}/palette`)
    .then(({ palette }) => {
      if (Q.current(get())?.id !== track.id) return;
      set({ palette });
      applyPalette(palette);
      if (palette) get().updateTrack(track.id, { palette });
    })
    .catch(() => undefined);
}

// ------------------------------------------------------------------ wave continuation
let continuingPromise: Promise<boolean> | null = null;
let continuationContext = "";
let nextContinuationAt = 0;
function continueWave(get: () => PlayerState, set: (p: Partial<PlayerState>) => void): Promise<boolean> {
  if (continuingPromise) return continuingPromise;
  const s = get();
  if (continuationContext !== s.context) {
    continuationContext = s.context;
    nextContinuationAt = 0;
  }
  if (Date.now() < nextContinuationAt) return Promise.resolve(false);
  // A depleted catalog must not trigger a new request on every audio time update.
  nextContinuationAt = Date.now() + 3000;
  const [kind, mode, lens] = s.context.split(":");
  const cur = Q.current(s);
  const exclude = s.queue.slice(-80).map((t) => t.id).join(",");
  const url = kind === "mode" ? `/api/modes/${mode}/next` : "/api/wave/next";
  const params = kind === "mode" ? { count: 10, current: cur?.id, exclude } : { mode, lens, count: 10, current: cur?.id, exclude };
  set({ continuing: true });
  continuingPromise = api
    .get<{ items: Track[] }>(url, params)
    .then(({ items }) => {
      if (get().context !== s.context) return false;
      const before = get().queue.length;
      get().appendTracks(items.filter((t) => t.playable));
      const grew = get().queue.length > before;
      if (!grew) nextContinuationAt = Date.now() + 30000;
      return grew;
    })
    .catch((error) => {
      const retry = error instanceof ApiError ? Number(error.data.retry_after) : 0;
      nextContinuationAt = Date.now() + Math.max(30000, Number.isFinite(retry) ? retry * 1000 : 0);
      return false;
    })
    .finally(() => {
      continuingPromise = null;
      set({ continuing: false });
    });
  return continuingPromise;
}

// ------------------------------------------------------------------ media session
function updateMediaSession(track: Track) {
  if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
  try {
    const art = track.artwork || track.artwork_small;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist,
      album: track.album ?? "Sword Music",
      artwork: art ? [{ src: art, sizes: "512x512" }] : [{ src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" }],
    });
  } catch {
    /* ignore */
  }
}

let wired = false;
/** Connect engine events, Media Session and lifecycle hooks. Call once on the client. */
export function wirePlayer() {
  if (wired || typeof window === "undefined") return;
  wired = true;
  const engine = getEngine();
  try {
    const v = parseFloat(localStorage.getItem("sword.volume") ?? "");
    if (Number.isFinite(v)) usePlayer.setState({ volume: v });
  } catch {
    /* ignore */
  }
  engine.setVolume(usePlayer.getState().volume);
  let lastSaveAt = 0;
  let preresolvedFor = "";

  engine.on((e) => {
    const s = usePlayer.getState();
    switch (e.type) {
      case "time": {
        if (s.status === "playing") {
          const delta = e.position - evLastPos;
          if (delta > 0 && delta < 2) evPlayedMs += delta * 1000;
        }
        evLastPos = e.position;
        usePlayer.setState({ position: e.position, duration: e.duration || s.duration, buffered: e.buffered });
        const remaining = e.duration - e.position;
        const nextP = Q.nextPos(s, false);
        // resolve the next stream early so the switch (or crossfade) is instant
        if (e.duration > 0 && remaining < Math.max(25, s.crossfade + 8) && nextP !== null && nextP !== s.pos) {
          const nt = s.queue[s.order[nextP]];
          if (nt && nt.playable && preresolvedFor !== nt.id) {
            preresolvedFor = nt.id;
            resolveTrack(nt.id).catch(() => undefined);
          }
        }
        if (isContinuous(s.context) && Q.upcoming(s).length <= 2 && !s.continuing) void continueWave(usePlayer.getState, usePlayer.setState);
        if (s.crossfade > 0 && engine.canControlVolume && e.duration > s.crossfade * 2 && remaining <= s.crossfade && remaining > 0.3 && s.status === "playing" && !s.controller) {
          if (nextP !== null && nextP !== s.pos) {
            const nt = s.queue[s.order[nextP]];
            const hit = nt ? resolved.get(nt.id) : undefined;
            if (nt && hit && hit.data.kind !== "embed" && !engine.isEmbed) {
              void engine.crossfade(hit.data.url, Math.max(0.5, remaining)).then((ok) => {
                if (!ok) return;
                flushEvent("ended");
                usePlayer.setState({ pos: nextP, position: 0, loadedId: nt.id, streamKind: hit.data.kind, attribution: hit.data.attribution });
                evTrack = nt;
                evContext = usePlayer.getState().context;
                evPlayedMs = 0;
                evLastPos = 0;
                updateMediaSession(nt);
                fetchPalette(nt, usePlayer.setState, usePlayer.getState);
                scheduleSave(usePlayer.getState);
              });
            }
          }
        }
        if (s.status === "playing" && Date.now() - lastSaveAt > 20000) {
          lastSaveAt = Date.now();
          saveNow(usePlayer.getState);
        }
        if ("mediaSession" in navigator && e.duration > 0 && Math.floor(e.position) % 5 === 0) {
          try {
            navigator.mediaSession.setPositionState({ duration: e.duration, position: Math.min(e.position, e.duration), playbackRate: 1 });
          } catch {
            /* ignore */
          }
        }
        break;
      }
      case "state":
        usePlayer.setState({ status: e.state });
        if ("mediaSession" in navigator) navigator.mediaSession.playbackState = e.state === "paused" ? "paused" : "playing";
        break;
      case "ended":
        if (s.controller) break; // rooms advance from the server clock
        s.next(false);
        break;
      case "error": {
        const track = Q.current(s);
        if (!track) break;
        resolved.delete(track.id);
        usePlayer.setState({ status: "error", error: e.message });
        api
          .post<{ available: boolean | null; alternatives: Track[] }>(`/api/tracks/${encodeURIComponent(track.id)}/report`, { error: `media-${e.code}` })
          .then((r) => {
            if (r.available === false) {
              usePlayer.getState().updateTrack(track.id, { playable: false, unavailable: "Трек удалён или закрыт в источнике." });
              markLost(track.id, "Трек удалён или закрыт в источнике.");
            }
            handleUnavailable(track, r.available === false ? "Трек удалён или закрыт в источнике." : e.message, r.alternatives ?? [], false);
          })
          .catch(() => handleUnavailable(track, e.message, [], false));
        break;
      }
      case "crossfaded":
        break;
    }
  });

  if ("mediaSession" in navigator) {
    const ms = navigator.mediaSession;
    const safe = (action: MediaSessionAction, fn: MediaSessionActionHandler) => {
      try {
        ms.setActionHandler(action, fn);
      } catch {
        /* unsupported action */
      }
    };
    safe("play", () => usePlayer.getState().toggle());
    safe("pause", () => usePlayer.getState().pause());
    safe("previoustrack", () => usePlayer.getState().prev());
    safe("nexttrack", () => usePlayer.getState().next(true));
    safe("seekto", (d) => d.seekTime !== undefined && usePlayer.getState().seek(d.seekTime));
    safe("seekbackward", (d) => usePlayer.getState().seek(Math.max(0, usePlayer.getState().position - (d.seekOffset ?? 10))));
    safe("seekforward", (d) => usePlayer.getState().seek(usePlayer.getState().position + (d.seekOffset ?? 10)));
  }

  window.addEventListener("pagehide", () => {
    flushEvent("stop");
    saveNow(usePlayer.getState, true);
  });
}

export const currentTrack = (s: PlayerState) => Q.current(s);
export const upcomingOf = (s: PlayerState) => Q.upcoming(s);

export function useCurrentTrack(): Track | null {
  return usePlayer((s) => (s.queue.length ? (s.queue[s.order[s.pos]] ?? null) : null));
}
