import { describe, expect, it } from "vitest";
import type { Track } from "../types";
import * as Q from "./queue";

const t = (id: string) => ({ id, title: id }) as unknown as Track;
const tracks = ["a", "b", "c", "d", "e"].map(t);
const seq = (() => {
  let s = 1;
  return () => ((s = (s * 16807) % 2147483647) - 1) / 2147483646;
})();

describe("queue", () => {
  it("plays in order and stops at the end without repeat", () => {
    let q = Q.create(tracks, 3, false, "off");
    expect(Q.current(q)?.id).toBe("d");
    q = { ...q, pos: Q.nextPos(q, false)! };
    expect(Q.current(q)?.id).toBe("e");
    expect(Q.nextPos(q, false)).toBeNull();
  });

  it("repeat-one loops automatically but not on manual next", () => {
    const q = Q.create(tracks, 1, false, "one");
    expect(Q.nextPos(q, false)).toBe(1);
    expect(Q.nextPos(q, true)).toBe(2);
  });

  it("repeat-all wraps", () => {
    const q = { ...Q.create(tracks, 4, false, "all") };
    expect(Q.nextPos(q, false)).toBe(0);
    expect(Q.prevPos({ ...q, pos: 0 })).toBe(4);
  });

  it("shuffle keeps the current track first and visits every track once", () => {
    const q = Q.create(tracks, 2, true, "off", seq);
    expect(Q.current(q)?.id).toBe("c");
    expect(new Set(q.order).size).toBe(5);
    const off = Q.setShuffle(q, false);
    expect(Q.current(off)?.id).toBe("c");
    expect(off.order).toEqual([0, 1, 2, 3, 4]);
  });

  it("insertNext, append without duplicates, remove and move", () => {
    let q = Q.create(tracks.slice(0, 3), 0, false, "off");
    q = Q.insertNext(q, t("x"));
    expect(Q.upcoming(q).map((u) => u.track.id)).toEqual(["x", "b", "c"]);
    q = Q.append(q, [t("b"), t("y")]);
    expect(Q.upcoming(q).map((u) => u.track.id)).toEqual(["x", "b", "c", "y"]);
    q = Q.removeAt(q, 2); // remove "b"
    expect(Q.upcoming(q).map((u) => u.track.id)).toEqual(["x", "c", "y"]);
    q = Q.move(q, 3, 1);
    expect(Q.upcoming(q).map((u) => u.track.id)).toEqual(["y", "x", "c"]);
    expect(Q.removeAt(q, 0)).toBe(q); // current track can't be removed
  });
});
