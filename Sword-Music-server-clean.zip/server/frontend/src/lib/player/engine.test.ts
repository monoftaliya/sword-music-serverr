import { beforeEach, expect, it, vi } from "vitest";
const { backends } = vi.hoisted(() => ({ backends: [] as Array<Record<string, any>> }));
vi.mock("./youtube", () => ({ YouTubeBackend: class {
  active = false; position = 13; duration = 130; paused = false;
  constructor(public emit: (e: unknown) => void) { backends.push(this); }
  load = vi.fn(async () => { this.active = true; });
  stop = vi.fn(() => { this.active = false; });
  play = vi.fn(); pause = vi.fn(); seek = vi.fn(); setVolume = vi.fn();
} }));
vi.mock("./widgets", () => ({ OfficialWidgetBackend: class {
  active = false; position = 25; duration = 250; paused = false;
  constructor(public service: string, public emit: (e: unknown) => void) { backends.push(this); }
  load = vi.fn(async () => { this.active = true; });
  stop = vi.fn(() => { this.active = false; });
  play = vi.fn(); pause = vi.fn(); seek = vi.fn(); setVolume = vi.fn();
} }));
import { AudioEngine } from "./engine";
class FakeAudio extends EventTarget {
  volume = 1; muted = false; paused = true; currentTime = 0; duration = 0;
  style = {}; dataset = {}; buffered = { length: 0 }; attrs = new Map<string, string>();
  set src(value: string) { this.attrs.set("src", value); }
  get src() { return this.attrs.get("src") ?? ""; }
  setAttribute(key: string, value: string) { this.attrs.set(key, value); }
  getAttribute(key: string) { return this.attrs.get(key) ?? null; }
  removeAttribute(key: string) { this.attrs.delete(key); }
  load() {} pause() { this.paused = true; } async play() { this.paused = false; }
}
beforeEach(() => {
  backends.length = 0;
  vi.stubGlobal("document", { createElement: () => new FakeAudio(), body: { appendChild() {} } });
  vi.stubGlobal("requestAnimationFrame", () => 1); vi.stubGlobal("cancelAnimationFrame", () => {});
});
it("routes SoundCloud controls and progress to its widget and excludes crossfade", async () => {
  const engine = new AudioEngine();
  await engine.load("https://soundcloud.com/a/b", { kind: "embed", provider: "soundcloud" });
  const sc = backends.find((b) => b.service === "soundcloud")!;
  expect(engine.hasSource).toBe(true); expect(engine.position).toBe(25); expect(engine.duration).toBe(250);
  engine.seek(60); await engine.play(); engine.pause();
  expect(sc.seek).toHaveBeenCalledWith(60); expect(sc.play).toHaveBeenCalled(); expect(sc.pause).toHaveBeenCalled();
  expect(await engine.crossfade("https://audio.example/new.mp3", 3)).toBe(false);
  engine.stop();
});
it("ignores old widget events after changing providers and clears every widget on stop", async () => {
  const engine = new AudioEngine(), events: unknown[] = [];
  engine.on((event) => events.push(event));
  await engine.load("https://soundcloud.com/a/b", { kind: "embed", provider: "soundcloud" });
  const sc = backends.find((b) => b.service === "soundcloud")!;
  await engine.load("spotify:track:4cOdK2wGLETKBW3PvgPWqT", { kind: "embed", provider: "spotify_link" });
  const sp = backends.find((b) => b.service === "spotify")!;
  sc.emit({ type: "state", state: "playing" }); expect(events).toEqual([]);
  sp.emit({ type: "state", state: "paused" }); expect(events).toEqual([{ type: "state", state: "paused" }]);
  engine.stop(); expect(engine.hasSource).toBe(false);
  expect(sc.stop).toHaveBeenCalled(); expect(sp.stop).toHaveBeenCalled();
  sp.emit({ type: "state", state: "playing" }); expect(events).toHaveLength(1);
});
