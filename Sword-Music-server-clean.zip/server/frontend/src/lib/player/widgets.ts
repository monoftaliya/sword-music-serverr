/** Controls official visible widgets. Audio is never extracted from either service. */
import type { EngineEvent } from "./engine";

export const SC_HOST_ID = "sword-soundcloud-host";
export const SP_HOST_ID = "sword-spotify-host";
type Emit = (event: EngineEvent) => void;
interface SCWidget {
  bind(event: string, callback: (data?: { currentPosition?: number; loadProgress?: number }) => void): void;
  load(url: string, options: Record<string, unknown>): void;
  play(): void; pause(): void; seekTo(ms: number): void; setVolume(volume: number): void;
  getDuration(callback: (ms: number) => void): void;
}
interface SCApi { Widget: { (iframe: HTMLIFrameElement): SCWidget; Events: Record<string, string> }; }
interface SPController { loadEntity(uri: string): void; play(): void; pause(): void; }
declare global { interface Window { SC?: SCApi; } }

let scApi: Promise<SCApi> | null = null;
function loadSoundCloud(): Promise<SCApi> {
  if (window.SC) return Promise.resolve(window.SC);
  if (!scApi) scApi = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://w.soundcloud.com/player/api.js"; script.async = true;
    const timeout = window.setTimeout(() => { scApi = null; reject(new Error("SoundCloud не ответил.")); }, 15000);
    script.onload = () => { window.clearTimeout(timeout); if (window.SC) resolve(window.SC); else { scApi = null; reject(new Error("Плеер SoundCloud недоступен.")); } };
    script.onerror = () => { window.clearTimeout(timeout); scApi = null; reject(new Error("SoundCloud недоступен.")); };
    document.head.appendChild(script);
  });
  return scApi;
}
export class OfficialWidgetBackend {
  private sc: SCWidget | null = null;
  private sp: SPController | null = null;
  private ready: Promise<void> | null = null;
  private source: string | null = null;
  private readySource: string | null = null;
  private lastPosition = 0;
  private lastDuration = 0;
  private isPaused = true;
  private finished = false;
  private volume = .9;
  private muted = false;
  constructor(private service: "soundcloud" | "spotify", private emit: Emit) {}
  get active() { return this.source !== null; }
  get position() { return this.lastPosition; }
  get duration() { return this.lastDuration; }
  get paused() { return this.isPaused; }

  private state(state: "playing" | "paused" | "loading") {
    if (!this.active || (this.service === "soundcloud" && this.readySource !== this.source)) return;
    this.isPaused = state !== "playing";
    this.emit({ type: "state", state });
  }
  private time(position: number, duration: number) {
    if (!this.active || (this.service === "soundcloud" && this.readySource !== this.source)) return;
    this.lastPosition = Math.max(0, position); this.lastDuration = Math.max(0, duration);
    this.emit({ type: "time", position: this.lastPosition, duration: this.lastDuration, buffered: 0 });
  }

  private async ensure(url: string): Promise<void> {
    if (this.ready) return this.ready;
    this.ready = this.service === "soundcloud" ? loadSoundCloud().then((api) => new Promise<void>((resolve, reject) => {
      const host = document.getElementById(SC_HOST_ID);
      if (!host) return reject(new Error("Нет места для SoundCloud."));
      const iframe = document.createElement("iframe");
      iframe.title = "SoundCloud"; iframe.allow = "autoplay";
      iframe.src = `https://w.soundcloud.com/player/?url=${encodeURIComponent(url)}&auto_play=false&show_user=true`;
      host.replaceChildren(iframe);
      const widget = this.sc = api.Widget(iframe);
      const events = api.Widget.Events;
      const timeout = window.setTimeout(() => reject(new Error("Плеер SoundCloud не загрузился.")), 20000);
      widget.bind(events.READY, () => { window.clearTimeout(timeout); resolve(); });
      widget.bind(events.PLAY, () => this.state("playing"));
      widget.bind(events.PAUSE, () => this.state("paused"));
      widget.bind(events.FINISH, () => { if (this.active && this.readySource === this.source) this.emit({ type: "ended" }); });
      widget.bind(events.PLAY_PROGRESS, (data) => this.time((data?.currentPosition ?? 0) / 1000, this.lastDuration));
      widget.bind(events.ERROR, () => { window.clearTimeout(timeout); reject(new Error("Запись SoundCloud недоступна.")); if (this.active) this.emit({ type: "error", code: 9100, message: "SoundCloud не разрешил воспроизвести эту запись." }); });
    })) : new Promise<void>((resolve, reject) => {
      const host = document.getElementById(SP_HOST_ID);
      if (!host) return reject(new Error("Нет места для Spotify."));
      const iframe = document.createElement("iframe");
      iframe.title = "Spotify"; iframe.allow = "autoplay; encrypted-media";
      iframe.sandbox.add("allow-scripts", "allow-same-origin");
      const send = (command: string, uri?: string) => iframe.contentWindow?.postMessage({ channel: "sword-spotify", command, uri }, window.location.origin);
      const receive = (event: MessageEvent) => {
        if (event.source !== iframe.contentWindow || event.origin !== window.location.origin || event.data?.channel !== "sword-spotify") return;
        const { type, data } = event.data;
        if (type === "ready") { window.clearTimeout(timeout); resolve(); }
        else if (type === "error") { window.clearTimeout(timeout); reject(new Error("Плеер Spotify недоступен.")); }
        else if (type === "update" && data && this.active && (!data.playingURI || data.playingURI === this.source)) {
          const position = (Number(data.position) || 0) / 1000;
          const duration = (Number(data.duration) || 0) / 1000;
          const ended = !this.finished && data.isPaused && !data.isBuffering && duration > 0 && position >= duration - .1 && this.lastPosition > 0;
          this.state(data.isBuffering ? "loading" : data.isPaused ? "paused" : "playing");
          this.time(position, duration);
          if (ended) { this.finished = true; this.emit({ type: "ended" }); }
        }
      };
      const timeout = window.setTimeout(() => { window.removeEventListener("message", receive); reject(new Error("Плеер Spotify не загрузился.")); }, 20000);
      window.addEventListener("message", receive);
      this.sp = { loadEntity: (uri) => send("load", uri), play: () => send("play"), pause: () => send("pause") };
      iframe.src = `/players/spotify.html#${encodeURIComponent(url)}`;
      host.replaceChildren(iframe);
    });
    this.ready.catch(() => { this.ready = null; });
    return this.ready;
  }

  async load(url: string, autoplay: boolean, startAt: number): Promise<void> {
    this.source = url; this.readySource = null; this.lastPosition = startAt; this.lastDuration = 0;
    this.isPaused = true; this.finished = false;
    this.emit({ type: "state", state: autoplay ? "loading" : "paused" });
    try {
      const existed = this.ready !== null;
      await this.ensure(url);
      if (this.source !== url) return;
      if (this.sc) {
        const begin = () => {
          if (this.source !== url || !this.sc) return;
          this.readySource = url;
          this.sc.setVolume(this.muted ? 0 : this.volume * 100);
          this.sc.getDuration((ms) => { if (this.source === url) this.time(startAt, ms / 1000); });
          if (startAt > 0) this.sc.seekTo(startAt * 1000);
          if (autoplay) this.sc.play(); else this.sc.pause();
        };
        if (existed) this.sc.load(url, { auto_play: false, callback: begin }); else begin();
      } else if (this.sp) {
        if (existed) this.sp.loadEntity(url);
        if (autoplay) this.sp.play(); else this.sp.pause();
      }
    } catch (error) {
      if (this.source === url) this.emit({ type: "error", code: 9101, message: error instanceof Error ? error.message : "Встроенный плеер недоступен." });
    }
  }
  play() { if (!this.active) return; this.sc?.play(); this.sp?.play(); }
  pause() { this.sc?.pause(); this.sp?.pause(); }
  seek(seconds: number) { this.sc?.seekTo(seconds * 1000); }
  setVolume(volume: number, muted: boolean) { this.volume = volume; this.muted = muted; this.sc?.setVolume(muted ? 0 : volume * 100); }
  stop() { this.source = null; this.pause(); this.isPaused = true; }
}
