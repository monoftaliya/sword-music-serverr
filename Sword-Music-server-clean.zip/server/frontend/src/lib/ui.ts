"use client";

import { create } from "zustand";
import type { Track } from "./types";

interface DialogStore {
  addToPlaylist: Track[] | null;
  alternatives: Track | null;
  openAddToPlaylist: (tracks: Track[]) => void;
  openAlternatives: (t: Track) => void;
  close: () => void;
}

export const useDialogs = create<DialogStore>((set) => ({
  addToPlaylist: null,
  alternatives: null,
  openAddToPlaylist: (tracks) => set({ addToPlaylist: tracks, alternatives: null }),
  openAlternatives: (t) => set({ alternatives: t, addToPlaylist: null }),
  close: () => set({ addToPlaylist: null, alternatives: null }),
}));

const enc = encodeURIComponent;

export function artistHref(t: Pick<Track, "artist_key" | "artist" | "provider" | "artist_ref">): string {
  const ref = t.artist_ref ? `&provider=${enc(t.provider)}&ref=${enc(t.artist_ref)}` : "";
  return `/artist/?key=${enc(t.artist_key)}&name=${enc(t.artist)}${ref}`;
}

export function albumHref(t: Pick<Track, "provider" | "album_ref" | "album" | "artist">): string | null {
  if (!t.album) return null;
  if (t.album_ref) return `/album/?key=${enc(`${t.provider}:${t.album_ref}`)}`;
  return null;
}

/**
 * Copy text to the clipboard. `navigator.clipboard` only exists on HTTPS/localhost,
 * so friends opening the app by LAN address over plain HTTP get the legacy fallback.
 */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to the legacy path */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}
