import { describe, expect, it } from "vitest";
import { activeLyric, collectionKey } from "./dashboard";

describe("lyric timeline", () => {
  const lines = [{ time: 2.5 }, { time: 10 }, { time: 10 }, { time: 14.9 }];
  it("does not highlight before the first timestamp or on an empty timeline", () => {
    expect(activeLyric(lines, 0)).toBe(-1);
    expect(activeLyric([], 100)).toBe(-1);
  });
  it("handles exact timestamps, shared timestamps, seeking backward and the end", () => {
    expect(activeLyric(lines, 2.5)).toBe(0);
    expect(activeLyric(lines, 10)).toBe(2);
    expect(activeLyric(lines, 300)).toBe(3);
    expect(activeLyric(lines, 4)).toBe(0);
  });
});
describe("collection identity", () => {
  it("distinguishes reordered and replaced recordings without using playback state", () => {
    expect(collectionKey(["a", "b"])).not.toBe(collectionKey(["b", "a"]));
    expect(collectionKey(["a", "b"])).not.toBe(collectionKey(["ab"]));
    expect(collectionKey(["a", "b"])).toBe(collectionKey(["a", "b"]));
  });
});
