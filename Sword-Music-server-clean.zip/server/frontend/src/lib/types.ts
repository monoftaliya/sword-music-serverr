export type StreamKind = "full" | "preview" | "embed" | "none";

export interface TagRef {
  key: string;
  label: string;
}

export interface Palette {
  base: string;
  surface: string;
  accent: string;
  glow: string;
  dominant: string;
  mono: boolean;
  light: boolean;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  artist_key: string;
  artist_ref: string | null;
  album: string | null;
  album_ref: string | null;
  duration: number | null;
  artwork: string | null;
  artwork_small: string | null;
  provider: string;
  source: string;
  stream: StreamKind;
  playable: boolean;
  unavailable: string | null;
  license: string | null;
  license_url: string | null;
  page_url: string | null;
  tags: TagRef[];
  bpm: number | null;
  key: string | null;
  liked: boolean;
  palette: Palette | null;
  reason?: string;
  score?: number;
  point?: [number, number, number] | null;
  alternatives?: Track[];
}

export interface User {
  id: string;
  display_name: string;
  avatar_url: string | null;
  email: string;
  is_admin: boolean;
  settings: UserSettings;
  created_at: string;
}

export interface UserSettings {
  theme: "liquid" | "oled" | "midnight";
  accent: "adaptive" | "violet" | "blue";
  intensity: "minimal" | "balanced" | "rich";
  motion: "system" | "full" | "reduced" | "off";
  crossfade: number;
  quality: "high" | "data_saver";
  history_enabled: boolean;
  show_listening_in_rooms: boolean;
  seed_tags: string[];
  wave_lens: "main" | "shadow";
}

export interface SourceStatus {
  id: string;
  name: string;
  status: "ok" | "error" | "skipped";
  count: number;
  message?: string | null;
  kind?: string | null;
}

export interface Chip {
  label: string;
  kind: string;
}

export interface Interpretation {
  query: string;
  descriptive: boolean;
  confidence: number;
  tags: Record<string, number>;
  avoid: string[];
  target: [number, number, number] | null;
  bpm: [number | null, number | null];
  vocal: string | null;
  similar: boolean;
  keywords: string[];
  chips: Chip[];
  source: string;
}

export interface SearchResponse {
  query: string;
  mode: "text" | "mood" | "mixed";
  interpretation: Interpretation | null;
  results: Track[];
  sources: SourceStatus[];
  /** sources with a small daily quota that were not asked yet (asked once typing settles) */
  deferred?: string[];
  took_ms: number;
}

export interface Suggestions {
  history: string[];
  tracks: Track[];
  artists: { key: string; name: string }[];
  moods: string[];
  interpretation?: Chip[];
}

export interface PlaylistSummary {
  id: string;
  name: string;
  description: string;
  cover: string | null;
  mosaic: string[];
  track_count: number;
  duration: number;
  shared: boolean;
  updated_at: string;
  created_at: string;
}

export interface PlaylistItem {
  item_id: number;
  added_at: string;
  track: Track;
}

export interface PlaylistDetail extends PlaylistSummary {
  items: PlaylistItem[];
  owner: { id: string; display_name: string };
  is_owner: boolean;
  share_token: string | null;
}

export interface ArtistSummary {
  key: string;
  name: string;
  score: number;
  tracks?: number;
  artwork: string | null;
  provider: string;
  ref: string | null;
}

export interface AlbumSummary {
  key: string;
  name: string;
  artist: string;
  provider: string;
  ref: string | null;
  artwork: string | null;
  tracks: number;
}

export interface ProfileSummary {
  signals: number;
  cold: boolean;
  top_tags: (TagRef & { weight: number })[];
  avoided: TagRef[];
  top_artists: { key: string; name: string }[];
  excluded_artists: { key: string; name: string }[];
  centroid: [number, number, number] | null;
  bpm: number | null;
  seed_tags: string[];
  shadow_tags: (TagRef & { weight: number })[];
}

export interface RecResponse {
  mode: string;
  lens: string;
  items: Track[];
  cold_start: boolean;
  seed_suggestions: (TagRef & { group: string })[];
  profile: ProfileSummary;
  sources: SourceStatus[];
  pool_size: number;
}

export interface ModeInfo {
  id: string;
  name: string;
  tagline: string;
  description: string;
  tags: TagRef[];
  avoid: string[];
  colors: [string, string, string];
  target: [number, number, number] | null;
}

export interface HomeData {
  user: { display_name: string };
  continue: { track: Track; position_ms: number; queue_length: number } | null;
  recent: Track[];
  artists: ArtistSummary[];
  playlists: PlaylistSummary[];
  stats: { favorites: number; plays: number };
}

export interface DnaParam {
  key: string;
  label: string;
  value: string;
  source: string;
  kind: "measured" | "metadata";
  url?: string | null;
}

export interface DnaData {
  track: Track;
  params: DnaParam[];
  tags: (TagRef & { group: string; weight: number })[];
  mood: { valence: number; energy: number; atmosphere: number; note: string } | null;
  waveform: number[] | null;
  waveform_source: string | null;
  completeness: number;
}

export interface EchoLobe {
  key: string;
  label: string;
  group: string;
  weight: number;
  v: number;
  e: number;
  a: number;
}

export interface EchoData {
  period: string;
  plays: number;
  skips: number;
  likes: number;
  lobes: EchoLobe[];
  centroid: [number, number, number] | null;
  bpm: number | null;
  diversity: number;
  novelty: { new_artists: number; share: number } | null;
  top_artists: { key: string; name: string }[];
  nearest_mode: { id: string; name: string; affinity: number } | null;
  disclaimer: string;
}

export interface DescentNode {
  track: Track;
  relation: "artist" | "genre" | "mood" | "tempo" | "drift";
  label: string;
  similarity: number | null;
}

export interface DescentData {
  center: Track;
  mode: "explore" | "descend";
  depth: number;
  nodes: DescentNode[];
  band: [number, number] | null;
  sources: SourceStatus[];
  note: string | null;
}

export interface RoomMemberInfo {
  id: string;
  name: string;
  avatar: string | null;
  role: "owner" | "member";
  online: boolean;
}

export interface RoomQueueEntry {
  item_id: number;
  track: Track;
  added_by: string;
  added_by_id: string | null;
}

export interface RoomState {
  t: "state";
  room: {
    id: string;
    code: string;
    name: string;
    owner_id: string;
    allow_member_queue: boolean;
    allow_suggestions: boolean;
    closed: boolean;
  };
  members: RoomMemberInfo[];
  now: { item_id: number | null; track: Track | null; playing: boolean; position_ms: number; server_ts: number };
  queue: RoomQueueEntry[];
  suggestions: RoomQueueEntry[];
}

export interface ProviderState {
  id: string;
  name: string;
  state: string;
  enabled_in_env: boolean;
  requires_key: boolean;
  configured: boolean;
  config_hint: string;
  stream: string;
  terms: string;
  homepage: string;
  calls: number;
  errors: number;
  avg_ms: number | null;
  last_error: string | null;
  retry_in_s: number;
}

/** Bridge exposed by the Sword Music desktop app (desktop/src/preload.js); absent in browsers. */
export interface SwordDesktop {
  isDesktop: true;
  platform: string;
  currentServer: () => Promise<string | null>;
  changeServer: () => Promise<void>;
  discordStatus?: () => Promise<DiscordState | null>;
  configureDiscord?: (config: { enabled: boolean; clientId: string }) => Promise<DiscordState & { ok: boolean; error?: string }>;
  updateDiscordPresence?: (track: { title: string; artist: string; album: string | null; source: string; url: string | null; artwork: string | null; status: "playing" | "paused"; position: number; duration: number } | null) => void;
}

export interface DiscordState {
  enabled: boolean;
  clientId: string;
  state: "disabled" | "needs_id" | "waiting" | "connecting" | "connected" | "error";
  message: string;
}

declare global {
  interface Window {
    swordDesktop?: SwordDesktop;
  }
}
