import type { Palette } from "./types";
import { hash } from "./format";

const DEFAULT = { accent: "#8B5CFF", glow: "#5C8DFF", base: "#0b0c14", surface: "#141722" };

let accentMode: "adaptive" | "violet" | "blue" = "adaptive";
let lastPalette: Palette | null = null;

export function setAccentMode(mode: "adaptive" | "violet" | "blue") {
  accentMode = mode;
  applyPalette(lastPalette);
}

export function applyPalette(p: Palette | null) {
  lastPalette = p;
  if (typeof document === "undefined") return;
  const root = document.documentElement.style;
  let accent = DEFAULT.accent;
  let glow = DEFAULT.glow;
  let base = DEFAULT.base;
  let surface = DEFAULT.surface;
  if (accentMode === "blue") {
    accent = "#5C8DFF";
    glow = "#8B5CFF";
  } else if (accentMode === "adaptive" && p && !p.mono) {
    accent = p.accent;
    glow = p.glow;
    base = p.base;
    surface = p.surface;
  } else if (accentMode === "adaptive" && p?.mono) {
    base = p.base;
    surface = p.surface;
  }
  root.setProperty("--dyn-accent", accent);
  root.setProperty("--dyn-glow", glow);
  root.setProperty("--dyn-base", base);
  root.setProperty("--dyn-surface", surface);
}

/** Deterministic two-tone gradient for tracks without artwork. */
export function proceduralColors(seed: string): [string, string, number] {
  const h = hash(seed);
  const hue1 = h % 360;
  const hue2 = (hue1 + 40 + ((h >> 9) % 80)) % 360;
  const angle = (h >> 3) % 360;
  return [`hsl(${hue1} 55% 22%)`, `hsl(${hue2} 70% 52%)`, angle];
}
