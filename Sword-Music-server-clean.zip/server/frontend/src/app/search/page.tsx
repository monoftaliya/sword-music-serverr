"use client";

import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { History, Mic, Search as SearchIcon, Sparkles, X } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { TrackList } from "@/components/music/TrackList";
import { Particles } from "@/components/search/Particles";
import { SourceExplorer } from "@/components/search/SourceExplorer";
import { VERSIONS, versionQuery, type Version } from "@/lib/music-sources";
import { Cover } from "@/components/ui/Cover";
import { ErrorState, RowsSkeleton, Segmented } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { count } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import type { SearchResponse, Suggestions } from "@/lib/types";
import { artistHref } from "@/lib/ui";
import styles from "./search.module.css";

const PROMPTS = [
  "мрачный фонк с тяжёлым басом",
  "ночной Токио, дождь, одиночество",
  "музыка, будто я главный злодей аниме",
  "музыка для размышлений в три часа ночи",
  "космос и бесконечность",
  "что-нибудь похожее на этот трек, но атмосфернее",
];

type Mode = "auto" | "text" | "mood";

function useDebounced<T>(value: T, ms: number): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

function SearchSpace() {
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [mode, setMode] = useState<Mode>((params.get("mode") as Mode) || "auto");
  const [version, setVersion] = useState<Version>(VERSIONS.find((v) => v.id === params.get("version"))?.id ?? "all");
  const [source, setSource] = useState(params.get("source") ?? "");
  const [focused, setFocused] = useState(false);
  const [committed, setCommitted] = useState(params.get("q") ?? "");
  const [promptIdx, setPromptIdx] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const currentId = usePlayer((s) => s.queue[s.order[s.pos]]?.id ?? null);
  const playTrack = usePlayer((s) => s.playTrack);
  const debounced = useDebounced(q.trim(), 380);
  const settled = useDebounced(q.trim(), 1200);
  const term = debounced.length >= 2 ? versionQuery(debounced, version) : "";
  const active = term || committed;
  // sources with a small daily quota (YouTube) are asked only once the user stops typing
  const deep = !!term && (versionQuery(settled, version) === term || versionQuery(committed, version) === term);
  const searchMode = version === "all" ? mode : "text";

  useEffect(() => {
    if (!params.get("q")) input.current?.focus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const t = setInterval(() => setPromptIdx((i) => (i + 1) % PROMPTS.length), 3800);
    return () => clearInterval(t);
  }, []);

  // keep the URL shareable without adding history entries on each keystroke
  useEffect(() => {
    const url = term ? `/search/?q=${encodeURIComponent(debounced)}${mode !== "auto" ? `&mode=${mode}` : ""}${version !== "all" ? `&version=${version}` : ""}${source ? `&source=${encodeURIComponent(source)}` : ""}` : "/search/";
    window.history.replaceState(null, "", url);
  }, [term, debounced, mode, source, version]);

  const fast = useQuery({
    queryKey: ["search", term, searchMode, source, version, currentId],
    queryFn: ({ signal }) => api.get<SearchResponse>("/api/search", { q: term, mode: searchMode, sources: source || undefined, version, context: currentId ?? undefined, limit: 50, deep: false }, { signal }),
    enabled: !!term,
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });
  const wantsDeep = deep && fast.data?.query === term && (fast.data?.deferred?.length ?? 0) > 0;
  const full = useQuery({
    queryKey: ["search-deep", term, searchMode, source, version, currentId],
    queryFn: ({ signal }) => api.get<SearchResponse>("/api/search", { q: term, mode: searchMode, sources: source || undefined, version, context: currentId ?? undefined, limit: 50 }, { signal }),
    enabled: wantsDeep,
    staleTime: 5 * 60_000,
  });
  const results = wantsDeep && full.data && !full.isError ? full : fast;

  const suggest = useQuery({
    queryKey: ["suggest", q.trim()],
    queryFn: ({ signal }) => api.get<Suggestions>("/api/search/suggest", { q: q.trim() }, { signal }),
    enabled: focused,
    staleTime: 20_000,
  });

  const submit = (value = q) => {
    const v = value.trim();
    if (!v) return;
    setQ(v);
    setCommitted(v);
    input.current?.blur();
    // record in history once the user commits to a query
    api.get("/api/search", { q: versionQuery(v, version), mode: searchMode, sources: source || undefined, version, record: true, limit: 1, deep: false }).catch(() => undefined);
  };

  const data = results.data;
  const showSuggestions = focused && !!suggest.data && (q.trim().length < 2 || !data || results.isFetching);
  const interp = data?.interpretation;
  const okSources = useMemo(() => data?.sources.filter((s) => s.status === "ok" && s.count > 0) ?? [], [data]);
  const badSources = useMemo(() => data?.sources.filter((s) => s.status !== "ok") ?? [], [data]);

  return (
    <div className={styles.space} data-active={active ? "true" : undefined}>
      <div className={styles.particles}>
        <Particles focused={focused} />
      </div>
      <LayoutGroup>
        <motion.div layout transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className={styles.core}>
          <motion.div layout="position" className={styles.blade} data-focused={focused || undefined}>
            <SearchIcon size={22} className={styles.icon} />
            <div className={styles.inputWrap}>
              <input
                ref={input}
                className={styles.input}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onFocus={() => setFocused(true)}
                onBlur={() => setTimeout(() => setFocused(false), 140)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") submit();
                  if (e.key === "Escape") {
                    if (q) setQ("");
                    else input.current?.blur();
                  }
                }}
                aria-label="Поиск: название, исполнитель, настроение или ссылка на трек"
                autoComplete="off"
                spellCheck={false}
                enterKeyHint="search"
              />
              {!q && (
                <AnimatePresence mode="wait">
                  <motion.span
                    key={promptIdx}
                    className={styles.placeholder}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    aria-hidden
                  >
                    {PROMPTS[promptIdx]}
                  </motion.span>
                </AnimatePresence>
              )}
            </div>
            {q && (
              <button className="icon-btn" onClick={() => { setQ(""); setCommitted(""); input.current?.focus(); }} aria-label="Очистить">
                <X size={18} />
              </button>
            )}
            <div className={`edge-line ${styles.edge}`} data-lit={focused || !!q} />
          </motion.div>

          <motion.div layout="position" className={styles.underBlade}>
            <Segmented
              size="sm"
              label="Режим поиска"
              value={mode}
              onChange={(next) => { setMode(next); if (next === "mood") setVersion("all"); }}
              options={[
                { value: "auto", label: "Авто", hint: "Сам поймёт, ищете ли вы трек или настроение" },
                { value: "text", label: "Название и исполнитель" },
                { value: "mood", label: <><Sparkles size={13} /> Настроение</> },
              ]}
            />
            {interp && interp.chips.length > 0 && (
              <div className={styles.chips} aria-label="Распознано в запросе">
                <span className="t-tiny">Распознано</span>
                {interp.chips.map((c, i) => (
                  <span key={i} className={`chip chip-tag ${c.kind === "avoid" ? "chip-avoid" : ""}`}>
                    {c.label}
                  </span>
                ))}
                {interp.source === "rules+llm" && <span className="t-tiny">с помощью языковой модели</span>}
              </div>
            )}
          </motion.div>

          <AnimatePresence>
            {showSuggestions && (
              <motion.div
                className={styles.suggest}
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, transition: { duration: 0.12 } }}
                transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
                onMouseDown={(e) => e.preventDefault()}
              >
                {suggest.data!.tracks.length > 0 && (
                  <div className={styles.sugGroup}>
                    <div className="t-tiny">Быстрый переход</div>
                    {suggest.data!.tracks.map((t) => (
                      <button key={t.id} className={styles.sugTrack} onClick={() => playTrack(t, "search")} disabled={!t.playable}>
                        <Cover src={t.artwork_small} seed={t.id} size={34} radius={7} />
                        <span className="clamp1">{t.title}</span>
                        <span className="t-tiny clamp1">{t.artist}</span>
                      </button>
                    ))}
                  </div>
                )}
                {suggest.data!.artists.length > 0 && (
                  <div className={styles.sugGroup}>
                    <div className="t-tiny">Исполнители</div>
                    <div className={styles.sugRow}>
                      {suggest.data!.artists.map((a) => (
                        <Link key={a.key} href={artistHref({ artist_key: a.key, artist: a.name, provider: "", artist_ref: null })} className="chip">
                          <Mic size={13} /> {a.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
                {suggest.data!.history.length > 0 && (
                  <div className={styles.sugGroup}>
                    <div className="t-tiny">История</div>
                    <div className={styles.sugRow}>
                      {suggest.data!.history.map((h) => (
                        <button key={h} className="chip" onClick={() => submit(h)}>
                          <History size={13} /> {h}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {suggest.data!.moods.length > 0 && (
                  <div className={styles.sugGroup}>
                    <div className="t-tiny">Попробуйте описать настроение</div>
                    <div className={styles.sugRow}>
                      {suggest.data!.moods.map((m) => (
                        <button key={m} className="chip" onClick={() => submit(m)}>
                          {m}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        <motion.section layout="position" className={styles.results} aria-live="polite" aria-busy={results.isFetching || full.isFetching}>
          <SourceExplorer query={versionQuery(q, version)} version={version} onVersion={(next) => { setVersion(next); if (next !== "all") setMode("text"); }} source={source} onSource={setSource} onSearch={(value) => { setMode("text"); submit(value); }} />
          {!active && (
            <div className={styles.intro}>
              <p>Ищите по названию, исполнителю, альбому или жанру — или опишите, что хочется услышать.</p>
              <div className={styles.examples}>
                {PROMPTS.slice(0, 5).map((p) => (
                  <button key={p} className="chip" onClick={() => submit(p)}>
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}
          {term && results.isLoading && <RowsSkeleton rows={7} />}
          {results.error && <ErrorState text={errorMessage(results.error)} onRetry={() => results.refetch()} />}
          {data && term && (
            <>
              <div className={styles.meta}>
                <span className="t-small">
                  {data.results.length ? count(data.results.length, ["результат", "результата", "результатов"]) : "Ничего не нашлось"}
                  {data.mode !== "text" && data.results.length > 0 ? " по смыслу запроса" : ""}
                </span>
                <span className={styles.sources}>
                  {okSources.map((s) => (
                    <span key={s.id} className={styles.src} title={`${s.name}: ${s.count}`}>
                      <span className="dot" data-state="ok" /> {s.name}
                    </span>
                  ))}
                  {badSources.map((s) => (
                    <span key={s.id} className={styles.src} title={s.message ?? ""}>
                      <span className="dot" data-state={s.kind ?? s.status} /> {s.name}
                    </span>
                  ))}
                </span>
              </div>
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={`${data.query}|${data.mode}`}
                  initial={{ opacity: 1 }}
                  animate={{ opacity: results.isFetching && results.isPlaceholderData ? 0.45 : 1 }}
                  exit={{ opacity: 0, y: -6, transition: { duration: 0.16 } }}
                >
                  {data.results.length > 0 ? (
                    <TrackList tracks={data.results} context="search" />
                  ) : (
                    <div className={styles.empty}>
                      <p>
                        {mode === "text"
                          ? "Попробуйте другое написание или режим «Настроение»."
                          : "Попробуйте описать иначе: жанр, настроение, темп или похожего исполнителя."}
                      </p>
                      {badSources.length > 0 && (
                        <p className="t-small">Часть источников сейчас недоступна — результатов может быть меньше обычного.</p>
                      )}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </>
          )}
        </motion.section>
      </LayoutGroup>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense>
      <SearchSpace />
    </Suspense>
  );
}
