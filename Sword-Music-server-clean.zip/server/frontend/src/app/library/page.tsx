"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart, History, ListMusic, Pencil, Play, Plus, Shuffle, Trash2, Upload } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useRef, useState } from "react";
import { TrackList } from "@/components/music/TrackList";
import { Cover } from "@/components/ui/Cover";
import { Dialog } from "@/components/ui/Dialog";
import { EmptyState, ErrorState, RowsSkeleton, Segmented, Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { confirmAction } from "@/lib/confirm";
import { bytes, count, relativeTime } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import { toast } from "@/lib/toast";
import type { AlbumSummary, ArtistSummary, PlaylistSummary, Track } from "@/lib/types";
import { artistHref } from "@/lib/ui";
import styles from "./library.module.css";

type Tab = "favorites" | "playlists" | "recent" | "artists" | "albums" | "uploads" | "history";

const TABS: { value: Tab; label: string }[] = [
  { value: "favorites", label: "Избранное" },
  { value: "playlists", label: "Плейлисты" },
  { value: "recent", label: "Недавние" },
  { value: "artists", label: "Исполнители" },
  { value: "albums", label: "Альбомы" },
  { value: "uploads", label: "Мои файлы" },
  { value: "history", label: "История поиска" },
];

function Favorites() {
  const [limit, setLimit] = useState(100);
  const q = useQuery({ queryKey: ["favorites", limit], queryFn: () => api.get<{ items: Track[]; total: number }>("/api/library/favorites", { limit }) });
  const playList = usePlayer((s) => s.playList);
  if (q.isLoading) return <RowsSkeleton />;
  if (q.error) return <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />;
  const items = q.data!.items;
  if (!items.length)
    return <EmptyState icon={<Heart size={28} />} title="Здесь появятся любимые треки" text="Нажмите на сердце у любого трека — в поиске, волне или плеере." action={<Link href="/search/" className="btn btn-primary">Найти музыку</Link>} />;
  const playable = items.filter((t) => t.playable);
  return (
    <>
      <div className={styles.actions}>
        <button className="btn btn-primary" onClick={() => playList(playable, 0, "favorites")} disabled={!playable.length}>
          <Play size={16} fill="currentColor" /> Слушать
        </button>
        <button
          className="btn btn-quiet"
          onClick={() => {
            const s = usePlayer.getState();
            if (!s.shuffle) s.toggleShuffle();
            playList(playable, Math.floor(Math.random() * playable.length), "favorites");
          }}
          disabled={!playable.length}
        >
          <Shuffle size={16} /> Перемешать
        </button>
        <span className="t-small">{count(q.data!.total, ["трек", "трека", "треков"])}</span>
      </div>
      <TrackList tracks={items} context="favorites" />
      {q.data!.total > items.length && (
        <button className="btn btn-line" style={{ marginTop: 16 }} onClick={() => setLimit((l) => l + 100)}>
          Показать ещё
        </button>
      )}
    </>
  );
}

function Playlists() {
  const qc = useQueryClient();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const q = useQuery({ queryKey: ["playlists"], queryFn: () => api.get<{ playlists: PlaylistSummary[] }>("/api/playlists") });
  const create = useMutation({
    mutationFn: () => api.post<PlaylistSummary>("/api/playlists", { name: name.trim(), description: desc.trim() }),
    onSuccess: (pl) => {
      void qc.invalidateQueries({ queryKey: ["playlists"] });
      setOpen(false);
      setName("");
      setDesc("");
      router.push(`/playlist/?id=${pl.id}`);
    },
    onError: (e) => toast.error("Не удалось создать плейлист", errorMessage(e)),
  });
  return (
    <>
      <div className={styles.actions}>
        <button className="btn btn-primary" onClick={() => setOpen(true)}>
          <Plus size={16} /> Новый плейлист
        </button>
      </div>
      {q.isLoading && <RowsSkeleton rows={3} />}
      {q.error && <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />}
      {q.data && q.data.playlists.length === 0 && (
        <EmptyState icon={<ListMusic size={28} />} title="Плейлистов пока нет" text="Соберите первый: треки добавляются из любого меню «…» или из плеера." />
      )}
      <div className={styles.grid}>
        {q.data?.playlists.map((p) => (
          <Link key={p.id} href={`/playlist/?id=${p.id}`} className={styles.tile}>
            {p.cover ? (
              <Cover src={p.cover} seed={p.id} size="100%" radius={18} />
            ) : (
              <span className={styles.mosaic}>
                {[0, 1, 2, 3].map((i) => (
                  <Cover key={i} src={p.mosaic[i] ?? null} seed={`${p.id}-${i}`} size="100%" radius={0} />
                ))}
              </span>
            )}
            <span className={`${styles.tileTitle} clamp1`}>{p.name}</span>
            <span className="t-tiny">
              {count(p.track_count, ["трек", "трека", "треков"])}
              {p.shared ? ", по ссылке" : ""}
            </span>
          </Link>
        ))}
      </div>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Новый плейлист"
        footer={
          <>
            <button className="btn btn-line" onClick={() => setOpen(false)}>
              Отмена
            </button>
            <button className="btn btn-primary" disabled={!name.trim() || create.isPending} onClick={() => create.mutate()}>
              {create.isPending && <Spinner size={15} />} Создать
            </button>
          </>
        }
      >
        <div className="stack">
          <label className="field">
            <span className="field-label">Название</span>
            <input className="input" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && name.trim() && create.mutate()} />
          </label>
          <label className="field">
            <span className="field-label">Описание (необязательно)</span>
            <textarea className="input" value={desc} maxLength={600} onChange={(e) => setDesc(e.target.value)} />
          </label>
        </div>
      </Dialog>
    </>
  );
}

function Recent() {
  const q = useQuery({ queryKey: ["recent"], queryFn: () => api.get<{ items: (Track & { played_at: string })[] }>("/api/library/recent", { limit: 100 }) });
  if (q.isLoading) return <RowsSkeleton />;
  if (q.error) return <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />;
  if (!q.data!.items.length) return <EmptyState icon={<History size={28} />} title="История пуста" text="Здесь будут треки, которые вы слушали. Запись истории можно выключить в настройках приватности." />;
  return <TrackList tracks={q.data!.items} context="recent" />;
}

function Artists() {
  const q = useQuery({ queryKey: ["artists"], queryFn: () => api.get<{ items: ArtistSummary[] }>("/api/library/artists") });
  if (q.isLoading) return <RowsSkeleton rows={4} />;
  if (q.error) return <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />;
  if (!q.data!.items.length) return <EmptyState title="Исполнители появятся сами" text="Мы собираем их из избранного, прослушиваний и плейлистов." />;
  return (
    <div className={styles.artistGrid}>
      {q.data!.items.map((a) => (
        <Link key={a.key} href={artistHref({ artist_key: a.key, artist: a.name, provider: a.provider, artist_ref: a.ref })} className={styles.artist}>
          <Cover src={a.artwork} seed={a.key} size={112} round />
          <span className="clamp1">{a.name}</span>
          <span className="t-tiny">{count(a.tracks ?? 0, ["трек", "трека", "треков"])}</span>
        </Link>
      ))}
    </div>
  );
}

function Albums() {
  const q = useQuery({ queryKey: ["albums"], queryFn: () => api.get<{ items: AlbumSummary[] }>("/api/library/albums") });
  if (q.isLoading) return <RowsSkeleton rows={4} />;
  if (q.error) return <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />;
  if (!q.data!.items.length) return <EmptyState title="Альбомов пока нет" text="Альбомы появляются, когда вы слушаете или сохраняете треки из них." />;
  return (
    <div className={styles.grid}>
      {q.data!.items.map((a) => (
        <Link key={a.key} href={`/album/?key=${encodeURIComponent(a.key)}`} className={styles.tile}>
          <Cover src={a.artwork} seed={a.key} size="100%" radius={18} />
          <span className={`${styles.tileTitle} clamp1`}>{a.name}</span>
          <span className="t-tiny clamp1">{a.artist}</span>
        </Link>
      ))}
    </div>
  );
}

function Uploads() {
  const qc = useQueryClient();
  const input = useRef<HTMLInputElement>(null);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [edit, setEdit] = useState<Track | null>(null);
  const q = useQuery({
    queryKey: ["uploads"],
    queryFn: () => api.get<{ items: Track[]; used_bytes: number; quota_bytes: number }>("/api/library/uploads"),
  });
  const onFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    const list = Array.from(files);
    setProgress({ done: 0, total: list.length });
    let ok = 0;
    for (const f of list) {
      try {
        await api.upload("/api/uploads", f);
        ok++;
      } catch (err) {
        toast.error(`Не удалось загрузить «${f.name}»`, errorMessage(err));
      }
      setProgress((p) => (p ? { ...p, done: p.done + 1 } : p));
    }
    setProgress(null);
    if (ok) toast.success(`Загружено: ${count(ok, ["файл", "файла", "файлов"])}`);
    void qc.invalidateQueries({ queryKey: ["uploads"] });
    if (input.current) input.current.value = "";
  };
  const remove = async (t: Track) => {
    const ok = await confirmAction({ title: "Удалить файл?", text: `«${t.title}» исчезнет из библиотеки и плейлистов. Действие необратимо.`, confirmLabel: "Удалить", danger: true });
    if (!ok) return;
    try {
      await api.del(`/api/uploads/${encodeURIComponent(t.id)}`);
      void qc.invalidateQueries({ queryKey: ["uploads"] });
    } catch (err) {
      toast.error("Не удалось удалить", errorMessage(err));
    }
  };
  return (
    <div
      className={styles.drop}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        void onFiles(e.dataTransfer.files);
      }}
    >
      <div className={styles.actions}>
        <button className="btn btn-primary" onClick={() => input.current?.click()} disabled={!!progress}>
          {progress ? <Spinner size={15} /> : <Upload size={16} />}
          {progress ? `Загрузка ${progress.done}/${progress.total}` : "Загрузить файлы"}
        </button>
        <input ref={input} type="file" accept=".mp3,.m4a,.aac,.ogg,.oga,.opus,.flac,.wav,.webm,audio/*" multiple hidden onChange={(e) => void onFiles(e.target.files)} />
        {q.data && (
          <span className="t-small">
            Занято {bytes(q.data.used_bytes)} из {bytes(q.data.quota_bytes)}
          </span>
        )}
      </div>
      <p className={`t-tiny ${styles.note}`}>
        Файлы видите только вы: они не попадают в комнаты и общие плейлисты. Загружайте только то, что вам разрешено слушать. Можно перетащить файлы сюда.
      </p>
      {q.isLoading && <RowsSkeleton rows={3} />}
      {q.data && q.data.items.length === 0 && <EmptyState icon={<Upload size={28} />} title="Своих файлов пока нет" text="MP3, M4A, OGG/Opus, FLAC, WAV — теги и обложка подхватятся автоматически." />}
      {q.data && q.data.items.length > 0 && (
        <TrackList
          tracks={q.data.items}
          context="uploads"
          showSource={false}
          extras={(t) => [
            { label: "Изменить название", icon: <Pencil size={16} />, onSelect: () => setEdit(t) },
            { label: "Удалить файл", icon: <Trash2 size={16} />, onSelect: () => void remove(t), danger: true },
          ]}
        />
      )}
      {edit && <EditUpload track={edit} onClose={() => setEdit(null)} />}
    </div>
  );
}

function EditUpload({ track, onClose }: { track: Track; onClose: () => void }) {
  const qc = useQueryClient();
  const [title, setTitle] = useState(track.title);
  const [artist, setArtist] = useState(track.artist);
  const [album, setAlbum] = useState(track.album ?? "");
  const save = useMutation({
    mutationFn: () => api.patch(`/api/uploads/${encodeURIComponent(track.id)}`, { title, artist, album }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["uploads"] });
      onClose();
    },
    onError: (e) => toast.error("Не удалось сохранить", errorMessage(e)),
  });
  return (
    <Dialog
      open
      onClose={onClose}
      title="Данные файла"
      footer={
        <button className="btn btn-primary" onClick={() => save.mutate()} disabled={!title.trim() || !artist.trim() || save.isPending}>
          Сохранить
        </button>
      }
    >
      <div className="stack">
        <label className="field">
          <span className="field-label">Название</span>
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        <label className="field">
          <span className="field-label">Исполнитель</span>
          <input className="input" value={artist} onChange={(e) => setArtist(e.target.value)} />
        </label>
        <label className="field">
          <span className="field-label">Альбом</span>
          <input className="input" value={album} onChange={(e) => setAlbum(e.target.value)} />
        </label>
      </div>
    </Dialog>
  );
}

function SearchHistoryTab() {
  const qc = useQueryClient();
  const router = useRouter();
  const q = useQuery({ queryKey: ["search-history"], queryFn: () => api.get<{ items: { id: number; query: string; kind: string; results: number; created_at: string }[] }>("/api/search/history") });
  const clear = async () => {
    await api.del("/api/search/history");
    void qc.invalidateQueries({ queryKey: ["search-history"] });
  };
  if (q.isLoading) return <RowsSkeleton rows={4} />;
  if (!q.data?.items.length) return <EmptyState icon={<History size={28} />} title="История поиска пуста" text="Запросы сохраняются, когда вы нажимаете Enter или выбираете результат." />;
  return (
    <>
      <div className={styles.actions}>
        <button className="btn btn-line btn-sm" onClick={() => void clear()}>
          Очистить историю
        </button>
      </div>
      <ul className={styles.history}>
        {q.data.items.map((h) => (
          <li key={h.id}>
            <button className={styles.historyItem} onClick={() => router.push(`/search/?q=${encodeURIComponent(h.query)}`)}>
              <span className="clamp1">{h.query}</span>
              <span className="t-tiny">
                {h.kind === "mood" ? "по настроению, " : ""}
                {relativeTime(h.created_at)}
              </span>
            </button>
            <button
              className="icon-btn icon-btn-sm"
              aria-label={`Удалить «${h.query}» из истории`}
              onClick={async () => {
                await api.del(`/api/search/history/${h.id}`);
                void qc.invalidateQueries({ queryKey: ["search-history"] });
              }}
            >
              <Trash2 size={15} />
            </button>
          </li>
        ))}
      </ul>
    </>
  );
}

function LibraryInner() {
  const params = useSearchParams();
  const router = useRouter();
  const tab = (params.get("tab") as Tab) || "favorites";
  return (
    <div className="page">
      <h1 className="t-display">Библиотека</h1>
      <div className={styles.tabs}>
        <Segmented label="Раздел библиотеки" value={tab} onChange={(v) => router.replace(`/library/?tab=${v}`, { scroll: false })} options={TABS} />
      </div>
      <div className={styles.body}>
        {tab === "favorites" && <Favorites />}
        {tab === "playlists" && <Playlists />}
        {tab === "recent" && <Recent />}
        {tab === "artists" && <Artists />}
        {tab === "albums" && <Albums />}
        {tab === "uploads" && <Uploads />}
        {tab === "history" && <SearchHistoryTab />}
      </div>
    </div>
  );
}

export default function LibraryPage() {
  return (
    <Suspense>
      <LibraryInner />
    </Suspense>
  );
}
