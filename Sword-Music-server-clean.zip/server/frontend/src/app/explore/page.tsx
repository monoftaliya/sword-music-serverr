"use client";

import { Dna, Infinity as InfinityIcon, Moon, Orbit, Waves } from "lucide-react";
import Link from "next/link";
import styles from "./explore.module.css";

const FEATURES = [
  {
    href: "/after-dark/",
    name: "After Dark",
    icon: Moon,
    text: "Шесть ночных режимов — VOID, RAGE, EGO, OBLIVION, ASCENSION, AFTER DARK — со своей логикой подбора и визуальным характером.",
  },
  {
    href: "/dna/",
    name: "Music DNA",
    icon: Dna,
    text: "Характеристики трека только из проверяемых данных источника. Поиск по сочетанию: атмосфера одного трека и ритм другого.",
  },
  {
    href: "/echo/",
    name: "Echo Self",
    icon: Orbit,
    text: "Ваш вкус как живая форма: она меняется по неделям и месяцам вместе с тем, что вы слушаете.",
  },
  {
    href: "/descent/",
    name: "Infinite Descent",
    icon: InfinityIcon,
    text: "Пространство связей вокруг трека. Explore держится рядом, Descend уводит всё глубже и не возвращает назад.",
  },
  {
    href: "/wave/?mode=flow",
    name: "Shadow Profile",
    icon: Waves,
    text: "Переключатель MAIN / SHADOW в Моей волне: тень ведёт к соседним жанрам и новым исполнителям, которых вы ещё не слушали.",
  },
];

export default function ExplorePage() {
  return (
    <div className="page">
      <h1 className="t-display">Открытия</h1>
      <p className={styles.lead}>
        Способы слушать иначе. Все они работают на одной системе: вашей библиотеке, истории прослушиваний, оценках и каталоге открытых источников.
      </p>
      <ol className={styles.list}>
        {FEATURES.map(({ href, name, icon: Icon, text }) => (
          <li key={href}>
            <Link href={href} className={styles.item}>
              <span className={styles.glyph}>
                <Icon size={22} strokeWidth={1.5} />
              </span>
              <span className={styles.name}>{name}</span>
              <span className={styles.text}>{text}</span>
              <span className={styles.edge} aria-hidden />
            </Link>
          </li>
        ))}
      </ol>
    </div>
  );
}
