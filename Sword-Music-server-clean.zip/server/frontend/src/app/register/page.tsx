"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { AuthFrame, FormError } from "@/components/auth/AuthFrame";
import { Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import type { User } from "@/lib/types";

function RegisterForm() {
  const { setUser } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const [setup, setSetup] = useState<boolean | null>(null);
  const [invite, setInvite] = useState(params.get("invite") ?? "");
  const [inviteState, setInviteState] = useState<{ valid: boolean; reason: string | null } | null>(null);
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api
      .get<{ setup_required: boolean }>("/api/auth/status")
      .then((s) => setSetup(s.setup_required))
      .catch(() => setSetup(false));
  }, []);

  useEffect(() => {
    const c = invite.trim();
    if (setup || c.length < 8) {
      setInviteState(null);
      return;
    }
    const t = setTimeout(() => {
      api
        .get<{ valid: boolean; reason: string | null }>(`/api/auth/invite/${encodeURIComponent(c)}`)
        .then(setInviteState)
        .catch(() => setInviteState(null));
    }, 350);
    return () => clearTimeout(t);
  }, [invite, setup]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { user } = await api.post<{ user: User }>("/api/auth/register", {
        email,
        password,
        display_name: name,
        invite_code: setup ? undefined : invite.trim(),
        setup_code: setup ? code.trim() : undefined,
      });
      setUser(user);
      router.replace(user.is_admin ? "/admin/" : "/");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (setup === null) return <Spinner />;

  return (
    <AuthFrame
      title={setup ? "Первый запуск" : "Регистрация"}
      lead={
        setup
          ? "Создайте аккаунт администратора. Код настройки выведен в консоли сервера при запуске (или выполните python -m app.cli setup-code)."
          : "Sword Music открыт только для своих: для регистрации нужно приглашение от администратора."
      }
      footer={
        <span>
          Уже есть аккаунт? <Link href="/login/">Войти</Link>
        </span>
      }
    >
      <form className="stack" onSubmit={submit} noValidate>
        {setup ? (
          <label className="field">
            <span className="field-label">Код настройки</span>
            <input className="input" value={code} onChange={(e) => setCode(e.target.value)} placeholder="XXXX-XXXX-XXXX" autoComplete="off" required />
          </label>
        ) : (
          <label className="field">
            <span className="field-label">Код приглашения</span>
            <input
              className="input"
              value={invite}
              onChange={(e) => setInvite(e.target.value.toUpperCase())}
              placeholder="SWRD-XXXX-XXXX"
              autoComplete="off"
              aria-invalid={inviteState ? !inviteState.valid : undefined}
              required
            />
            {inviteState && (
              <span className={inviteState.valid ? "field-hint" : "field-error"}>{inviteState.valid ? "Приглашение действительно." : inviteState.reason}</span>
            )}
          </label>
        )}
        <label className="field">
          <span className="field-label">Имя</span>
          <input className="input" value={name} maxLength={40} onChange={(e) => setName(e.target.value)} autoComplete="nickname" required />
        </label>
        <label className="field">
          <span className="field-label">E-mail</span>
          <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
        </label>
        <label className="field">
          <span className="field-label">Пароль</span>
          <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" required />
          <span className="field-hint">Минимум 8 символов, не слишком простой.</span>
        </label>
        <FormError message={error} />
        <button className="btn btn-primary btn-lg" disabled={busy || !email || !password || !name || (setup ? !code : !invite)} style={{ marginTop: 8 }}>
          {busy && <Spinner size={16} />}
          {setup ? "Создать администратора" : "Создать аккаунт"}
        </button>
      </form>
    </AuthFrame>
  );
}

export default function RegisterPage() {
  return (
    <Suspense>
      <RegisterForm />
    </Suspense>
  );
}
