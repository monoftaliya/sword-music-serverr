"use client";

import Link from "next/link";
import { useState } from "react";
import { AuthFrame, FormError } from "@/components/auth/AuthFrame";
import { Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";

export default function ForgotPage() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState<null | { email_enabled: boolean }>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      setSent(await api.post<{ email_enabled: boolean }>("/api/auth/password/forgot", { email }));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthFrame
      title="Восстановление доступа"
      lead="Укажите e-mail аккаунта. Если на сервере настроена почта, мы пришлём ссылку для смены пароля."
      footer={<Link href="/login/">Вернуться ко входу</Link>}
    >
      {sent ? (
        <div className="stack">
          {sent.email_enabled ? (
            <p>Если такой аккаунт существует, письмо со ссылкой уже в пути. Ссылка действует 2 часа.</p>
          ) : (
            <p>
              На этом сервере отправка писем не настроена. Попросите администратора создать для вас ссылку сброса пароля в разделе
              «Администрирование».
            </p>
          )}
        </div>
      ) : (
        <form className="stack" onSubmit={submit}>
          <label className="field">
            <span className="field-label">E-mail</span>
            <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </label>
          <FormError message={error} />
          <button className="btn btn-primary btn-lg" disabled={busy || !email}>
            {busy && <Spinner size={16} />}
            Отправить ссылку
          </button>
        </form>
      )}
    </AuthFrame>
  );
}
