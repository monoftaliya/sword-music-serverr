"use client";

import { useQuery } from "@tanstack/react-query";
import { Pause, Play } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { EchoOrganism } from "@/components/explore/EchoOrganism";
import { ErrorState, Segmented, Slider, Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { count } from "@/lib/format";
import type { EchoData, EchoLobe } from "@/lib/types";
import styles from "./echo.module.css";

type Period = "7d" | "30d" | "90d" | "365d" | "all";

interface Frame {
  from: string;
  to: string;
  plays: number;
  likes: number;
  lobes: EchoLobe[];
  centroid: [number, number, number] | null;
  diversity: number;
  bpm: number | null;
  nearest_mode: { id: string; name: string } | null;
}

function diversityWords(d: number): string {
  if (d > 0.82) return "очень разнообразный вкус";
  if (d > 0.65) return "широкий вкус";
  if (d > 0.45) return "несколько любимых направлений";
  return "сфокусированный вкус";
}

function moodWords(c: [number, number, number] | null): string | null {
  if (!c) return null;
  const [v, e, a] = c;
  const tone = v < -0.25 ? "тёмное" : v > 0.25 ? "светлое" : "сдержанное";
  const energy = e > 0.62 ? "энергичное" : e < 0.35 ? "спокойное" : "умеренное";
  const depth = a > 0.7 ? ", с глубокой атмосферой" : "";
  return `${tone}, ${energy}${depth}`;
}

export default function EchoPage() {
  const [period, setPeriod] = useState<Period>("30d");
  const [frameIdx, setFrameIdx] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const echo = useQuery({ queryKey: ["echo", period], queryFn: () => api.get<EchoData>("/api/echo", { period }) });
  const timeline = useQuery({ queryKey: ["echo-timeline"], queryFn: () => api.get<{ frames: Frame[] }>("/api/echo/timeline", { months: 6 }), staleTime: 5 * 60_000 });
  const frames = timeline.data?.frames ?? [];

  useEffect(() => {
    if (!playing || !frames.length) return;
    const t = setInterval(() => {
      setFrameIdx((i) => {
        const n = i === null ? 0 : i + 1;
        if (n >= frames.length) {
          setPlaying(false);
          return frames.length - 1;
        }
        return n;
      });
    }, 1600);
    return () => clearInterval(t);
  }, [playing, frames.length]);

  const frame = frameIdx !== null ? frames[frameIdx] : null;
  const lobes = frame ? frame.lobes : (echo.data?.lobes ?? []);
  const centroid = frame ? frame.centroid : (echo.data?.centroid ?? null);
  const diversity = frame ? frame.diversity : (echo.data?.diversity ?? 0.5);
  const d = echo.data;
  const empty = d && d.plays === 0 && d.likes === 0 && !frame;

  return (
    <div className={styles.page}>
      <div className={styles.head}>
        <h1 className="t-display">Echo Self</h1>
        <Segmented
          size="sm"
          label="Период"
          value={period}
          onChange={(v) => {
            setFrameIdx(null);
            setPlaying(false);
            setPeriod(v);
          }}
          options={[
            { value: "7d", label: "Неделя" },
            { value: "30d", label: "Месяц" },
            { value: "90d", label: "3 месяца" },
            { value: "365d", label: "Год" },
            { value: "all", label: "Всё время" },
          ]}
        />
      </div>

      <div className={styles.stage}>
        <div className={styles.organism}>
          {echo.isLoading ? <Spinner size={22} /> : <EchoOrganism lobes={lobes} energy={centroid?.[1] ?? 0.5} diversity={diversity} />}
          {empty && (
            <p className={styles.emptyNote}>
              Форма проявится, когда вы начнёте слушать и отмечать треки. <Link href="/wave/">Запустить волну</Link>
            </p>
          )}
        </div>
        <aside className={styles.facts}>
          {echo.error && <ErrorState text={errorMessage(echo.error)} onRetry={() => echo.refetch()} />}
          {d && (
            <>
              <div className={styles.fact}>
                <span className={styles.factValue}>{frame ? frame.plays : d.plays}</span>
                <span className="t-small">{plural(frame ? frame.plays : d.plays)}</span>
              </div>
              <div className={styles.fact}>
                <span className={styles.factValue}>{frame ? frame.likes : d.likes}</span>
                <span className="t-small">новых в избранном</span>
              </div>
              {lobes.length > 0 && <p className={styles.sentence}>{diversityWords(diversity)}</p>}
              {moodWords(centroid) && <p className={styles.sentence}>Звучание: {moodWords(centroid)}</p>}
              {(frame ? frame.nearest_mode : d.nearest_mode) && (
                <p className={styles.sentence}>
                  Ближе всего к режиму{" "}
                  <Link href={`/after-dark/?mode=${(frame ? frame.nearest_mode : d.nearest_mode)!.id}`} className={styles.mode}>
                    {(frame ? frame.nearest_mode : d.nearest_mode)!.name}
                  </Link>
                </p>
              )}
              {!frame && d.novelty && d.novelty.new_artists > 0 && (
                <p className={styles.sentence}>{count(d.novelty.new_artists, ["новый исполнитель", "новых исполнителя", "новых исполнителей"])} за период</p>
              )}
              {!frame && d.bpm && <p className={styles.sentence}>Средний темп около {Math.round(d.bpm)} BPM</p>}
              {!frame && d.top_artists.length > 0 && (
                <div className={styles.artists}>
                  <span className="t-tiny">Чаще всего</span>
                  {d.top_artists.map((a) => (
                    <span key={a.key} className="clamp1">
                      {a.name}
                    </span>
                  ))}
                </div>
              )}
            </>
          )}
        </aside>
      </div>

      {frames.length > 1 && (
        <div className={styles.timeline}>
          <button className="icon-btn" onClick={() => setPlaying((p) => !p)} aria-label={playing ? "Остановить" : "Проиграть изменения по месяцам"}>
            {playing ? <Pause size={18} /> : <Play size={18} fill="currentColor" />}
          </button>
          <Slider
            value={frameIdx ?? frames.length - 1}
            min={0}
            max={frames.length - 1}
            step={1}
            onChange={(v) => setFrameIdx(Math.round(v))}
            label="Месяц"
            className={styles.scrub}
            format={(v) => frames[Math.round(v)]?.to ?? ""}
          />
          <span className="t-small num">
            {frame ? `${new Date(frame.from).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })} — ${new Date(frame.to).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}` : "по месяцам"}
          </span>
          {frame && (
            <button className="link-quiet" onClick={() => setFrameIdx(null)}>
              Вернуть период
            </button>
          )}
        </div>
      )}

      <p className={styles.disclaimer}>{d?.disclaimer ?? "Echo Self — художественная визуализация ваших прослушиваний и лайков. Это не психологический анализ."}</p>
    </div>
  );
}

function plural(n: number): string {
  const f: [string, string, string] = ["прослушивание", "прослушивания", "прослушиваний"];
  const abs = Math.abs(n) % 100;
  const l = abs % 10;
  if (abs > 10 && abs < 20) return f[2];
  if (l > 1 && l < 5) return f[1];
  if (l === 1) return f[0];
  return f[2];
}
