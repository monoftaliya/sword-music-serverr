import Link from "next/link";

export default function NotFound() {
  return (
    <div className="page" style={{ display: "grid", alignContent: "center", minHeight: "60vh", gap: 18 }}>
      <h1 className="t-display">Здесь тишина</h1>
      <p className="t-small" style={{ maxWidth: "48ch" }}>
        Такой страницы нет. Возможно, ссылка устарела или в адресе опечатка.
      </p>
      <div className="row wrap">
        <Link href="/" className="btn btn-primary">
          На главную
        </Link>
        <Link href="/search/" className="btn btn-quiet">
          Открыть поиск
        </Link>
      </div>
    </div>
  );
}
