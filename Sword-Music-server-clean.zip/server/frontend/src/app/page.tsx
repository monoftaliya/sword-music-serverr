"use client";

export { default } from "@/components/dashboard/HomeDashboard";
