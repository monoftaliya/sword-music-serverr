"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Copy, ExternalLink, KeyRound, Plus, RefreshCw } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Cover } from "@/components/ui/Cover";
import { Dialog } from "@/components/ui/Dialog";
import { ErrorState, RowsSkeleton, Segmented, Spinner, Switch } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { confirmAction } from "@/lib/confirm";
import { count, relativeTime } from "@/lib/format";
import { toast } from "@/lib/toast";
import type { ProviderState } from "@/lib/types";
import { copyText } from "@/lib/ui";
import styles from "./admin.module.css";

type Tab = "invites" | "users" | "sources";

interface Invite {
  id: string;
  code: string;
  note: string;
  max_uses: number;
  uses: number;
  expires_at: string | null;
  created_at: string;
  state: "active" | "used" | "expired" | "revoked";
  path: string;
}

interface AdminUser {
  id: string;
  email: string;
  display_name: string;
  is_admin: boolean;
  is_active: boolean;
  created_at: string;
  plays: number;
  last_seen: string | null;
}

const INVITE_STATE: Record<Invite["state"], string> = {
  active: "Активно",
  used: "Использовано",
  expired: "Истёк срок",
  revoked: "Отозвано",
};

function untilText(iso: string | null): string {
  if (!iso) return "бессрочно";
  const days = Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
  if (days <= 0) return "срок истёк";
  return `ещё ${count(days, ["день", "дня", "дней"])}`;
}

function sourceState(p: ProviderState): string {
  switch (p.state) {
    case "ok":
      return "Работает";
    case "degraded":
      return p.retry_in_s ? `Сбои, повтор через ${p.retry_in_s} с` : "Были сбои";
    case "rate_limited":
      return p.retry_in_s ? `Лимит запросов, пауза ${p.retry_in_s} с` : "Лимит запросов";
    case "not_configured":
      return "Нужна настройка";
    case "disabled":
      return "Выключен";
    default:
      return "Не подключён на сервере";
  }
}

export default function AdminPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("invites");

  useEffect(() => {
    if (user && !user.is_admin) router.replace("/");
  }, [user, router]);

  useEffect(() => {
    const fromHash = () => {
      const h = window.location.hash.slice(1);
      if (h === "users" || h === "sources" || h === "invites") setTab(h);
    };
    fromHash();
    window.addEventListener("hashchange", fromHash);
    return () => window.removeEventListener("hashchange", fromHash);
  }, []);

  if (!user?.is_admin) return null;

  return (
    <div className="page">
      <h1 className="t-display">Администрирование</h1>
      <p className={styles.lead}>Регистрация открыта только по приглашениям. Здесь вы приглашаете друзей, помогаете им с доступом и следите за источниками музыки.</p>
      <div className={styles.tabs}>
        <Segmented
          label="Раздел"
          value={tab}
          onChange={(v) => {
            setTab(v);
            history.replaceState(null, "", `#${v}`);
          }}
          options={[
            { value: "invites", label: "Приглашения" },
            { value: "users", label: "Пользователи" },
            { value: "sources", label: "Источники" },
          ]}
        />
      </div>
      {tab === "invites" && <Invites />}
      {tab === "users" && <Users selfId={user.id} />}
      {tab === "sources" && <Sources />}
    </div>
  );
}

/* ------------------------------------------------------------------ invites */

function Invites() {
  const qc = useQueryClient();
  const [note, setNote] = useState("");
  const [uses, setUses] = useState<"1" | "3" | "10">("1");
  const [days, setDays] = useState<"7" | "30" | "none">("7");
  const [fresh, setFresh] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const list = useQuery({ queryKey: ["admin", "invites"], queryFn: () => api.get<{ invites: Invite[] }>("/api/admin/invites") });

  const link = (inv: Invite) => `${window.location.origin}${inv.path}`;
  const copy = async (inv: Invite) => {
    if (await copyText(link(inv))) {
      setCopied(inv.id);
      setTimeout(() => setCopied((c) => (c === inv.id ? null : c)), 1600);
    } else {
      toast.error("Не удалось скопировать", link(inv));
    }
  };

  const create = useMutation({
    mutationFn: () =>
      api.post<Invite>("/api/admin/invites", {
        note,
        max_uses: Number(uses),
        expires_in_days: days === "none" ? null : Number(days),
      }),
    onSuccess: async (inv) => {
      setNote("");
      setFresh(inv.id);
      await qc.invalidateQueries({ queryKey: ["admin", "invites"] });
      void copy(inv);
    },
    onError: (e) => toast.error("Не удалось создать приглашение", errorMessage(e)),
  });

  return (
    <div className={styles.panel}>
      <form
        className={styles.create}
        onSubmit={(e) => {
          e.preventDefault();
          create.mutate();
        }}
      >
        <label className="field">
          <span className="field-label">Для кого</span>
          <input className="input" placeholder="Например, Лёша" maxLength={120} value={note} onChange={(e) => setNote(e.target.value)} />
        </label>
        <div className={styles.createOpts}>
          <div className="field">
            <span className="field-label">Сколько регистраций</span>
            <Segmented size="sm" label="Количество регистраций" value={uses} onChange={setUses} options={[{ value: "1", label: "Одна" }, { value: "3", label: "До 3" }, { value: "10", label: "До 10" }]} />
          </div>
          <div className="field">
            <span className="field-label">Срок действия</span>
            <Segmented size="sm" label="Срок действия" value={days} onChange={setDays} options={[{ value: "7", label: "Неделя" }, { value: "30", label: "Месяц" }, { value: "none", label: "Без срока" }]} />
          </div>
        </div>
        <button className="btn btn-primary" disabled={create.isPending}>
          {create.isPending ? <Spinner size={15} /> : <Plus size={16} />} Создать приглашение
        </button>
      </form>

      {list.isLoading && <RowsSkeleton rows={3} />}
      {list.isError && <ErrorState text={errorMessage(list.error)} onRetry={() => void list.refetch()} />}
      {list.data && list.data.invites.length === 0 && <p className="t-small">Приглашений пока нет. Создайте первое и отправьте ссылку другу.</p>}
      {list.data && list.data.invites.length > 0 && (
        <ul className={styles.list}>
          {list.data.invites.map((inv) => (
            <li key={inv.id} className={styles.invite} data-state={inv.state} data-fresh={fresh === inv.id || undefined}>
              <span className={`${styles.code} num`}>{inv.code}</span>
              <span className={styles.meta}>
                <span className="clamp1">{inv.note || "Без пометки"}</span>
                <span className="t-tiny">
                  {INVITE_STATE[inv.state]}, использовано {inv.uses} из {inv.max_uses}
                  {inv.state === "active" ? `, ${untilText(inv.expires_at)}` : ""}
                </span>
              </span>
              <span className={styles.actions}>
                {inv.state === "active" && (
                  <>
                    <button className="btn btn-quiet btn-sm" onClick={() => void copy(inv)}>
                      {copied === inv.id ? <Check size={14} /> : <Copy size={14} />} {copied === inv.id ? "Скопировано" : "Ссылка"}
                    </button>
                    <button
                      className="btn btn-line btn-sm"
                      onClick={async () => {
                        if (!(await confirmAction({ title: "Отозвать приглашение?", text: "По этой ссылке больше нельзя будет зарегистрироваться. Уже созданные аккаунты не пострадают.", confirmLabel: "Отозвать", danger: true }))) return;
                        try {
                          await api.del(`/api/admin/invites/${inv.id}`);
                          void qc.invalidateQueries({ queryKey: ["admin", "invites"] });
                        } catch (e) {
                          toast.error("Не удалось отозвать", errorMessage(e));
                        }
                      }}
                    >
                      Отозвать
                    </button>
                  </>
                )}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ users */

function Users({ selfId }: { selfId: string }) {
  const qc = useQueryClient();
  const [reset, setReset] = useState<{ name: string; url: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const list = useQuery({ queryKey: ["admin", "users"], queryFn: () => api.get<{ users: AdminUser[] }>("/api/admin/users") });

  const patch = async (u: AdminUser, body: Partial<Pick<AdminUser, "is_active" | "is_admin">>) => {
    try {
      await api.patch(`/api/admin/users/${u.id}`, body);
      void qc.invalidateQueries({ queryKey: ["admin", "users"] });
    } catch (e) {
      toast.error("Не удалось изменить", errorMessage(e));
    }
  };

  return (
    <div className={styles.panel}>
      {list.isLoading && <RowsSkeleton rows={4} />}
      {list.isError && <ErrorState text={errorMessage(list.error)} onRetry={() => void list.refetch()} />}
      {list.data && (
        <ul className={styles.list}>
          {list.data.users.map((u) => (
            <li key={u.id} className={styles.user} data-inactive={!u.is_active || undefined}>
              <Cover src={null} seed={u.id} size={44} round />
              <span className={styles.meta}>
                <span className="clamp1">
                  {u.display_name}
                  {u.id === selfId ? " (вы)" : ""}
                </span>
                <span className="t-tiny clamp1">
                  {u.email}, {u.last_seen ? `заходил(а) ${relativeTime(u.last_seen)}` : "ещё не заходил(а)"}, {count(u.plays, ["прослушивание", "прослушивания", "прослушиваний"])}
                </span>
              </span>
              <span className={styles.userControls}>
                <label className={styles.toggle}>
                  <span>Доступ</span>
                  <Switch checked={u.is_active} disabled={u.id === selfId} onChange={(v) => void patch(u, { is_active: v })} label={`Доступ для ${u.display_name}`} />
                </label>
                <label className={styles.toggle}>
                  <span>Админ</span>
                  <Switch checked={u.is_admin} disabled={u.id === selfId} onChange={(v) => void patch(u, { is_admin: v })} label={`Права администратора для ${u.display_name}`} />
                </label>
                <button
                  className="btn btn-line btn-sm"
                  disabled={!u.is_active}
                  onClick={async () => {
                    try {
                      const r = await api.post<{ url: string }>(`/api/admin/users/${u.id}/reset-link`);
                      setCopied(false);
                      setReset({ name: u.display_name, url: `${window.location.origin}${r.url}` });
                    } catch (e) {
                      toast.error("Не удалось создать ссылку", errorMessage(e));
                    }
                  }}
                >
                  <KeyRound size={14} /> Сброс пароля
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}

      <Dialog
        open={!!reset}
        onClose={() => setReset(null)}
        title={`Ссылка для ${reset?.name ?? ""}`}
        description="Отправьте её лично. Ссылка действует 2 часа и срабатывает один раз; после смены пароля все сеансы пользователя завершатся."
        footer={
          <button
            className="btn btn-primary"
            onClick={async () => {
              if (reset && (await copyText(reset.url))) setCopied(true);
            }}
          >
            {copied ? <Check size={15} /> : <Copy size={15} />} {copied ? "Скопировано" : "Скопировать ссылку"}
          </button>
        }
      >
        <code className={styles.resetUrl}>{reset?.url}</code>
      </Dialog>
    </div>
  );
}

/* ------------------------------------------------------------------ sources */

function Sources() {
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["admin", "providers"],
    queryFn: () => api.get<{ providers: ProviderState[] }>("/api/admin/providers"),
    refetchInterval: 15000,
  });

  const toggle = async (p: ProviderState, enabled: boolean) => {
    try {
      const r = await api.patch<{ providers: ProviderState[] }>(`/api/admin/providers/${p.id}`, { enabled });
      qc.setQueryData(["admin", "providers"], r);
    } catch (e) {
      toast.error("Не удалось переключить источник", errorMessage(e));
    }
  };

  return (
    <div className={styles.panel}>
      <div className={styles.sourcesHead}>
        <p className="t-small">Музыка не копируется на сервер: треки играют напрямую из источников. Отключённый источник пропадает из поиска и волны у всех.</p>
        <button className="btn btn-quiet btn-sm" onClick={() => void list.refetch()} disabled={list.isFetching}>
          <RefreshCw size={14} className={list.isFetching ? styles.spin : undefined} /> Обновить
        </button>
      </div>
      {list.isLoading && <RowsSkeleton rows={5} />}
      {list.isError && <ErrorState text={errorMessage(list.error)} onRetry={() => void list.refetch()} />}
      {list.data && (
        <ul className={styles.sources}>
          {list.data.providers.map((p) => {
            const switchable = p.enabled_in_env && p.id !== "uploads";
            return (
              <li key={p.id} className={styles.source} data-state={p.state}>
                <div className={styles.sourceTop}>
                  <span className="dot" data-state={p.state} />
                  <span className={styles.sourceName}>{p.name}</span>
                  <span className="t-small">{sourceState(p)}</span>
                  <span className="spacer" />
                  {switchable && <Switch checked={p.state !== "disabled"} onChange={(v) => void toggle(p, v)} label={`Источник ${p.name}`} />}
                </div>
                <div className={styles.sourceBody}>
                  <p>{p.terms}</p>
                  {p.state === "not_configured" && p.config_hint && <p className={styles.hint}>{p.config_hint}</p>}
                  {!p.enabled_in_env && p.id !== "uploads" && <p className={styles.hint}>Добавьте «{p.id}» в PROVIDERS_ENABLED в файле .env и перезапустите сервер.</p>}
                  {p.last_error && p.state !== "ok" && <p className={styles.error}>Последняя ошибка: {p.last_error}</p>}
                  <div className={styles.stats}>
                    <span>{p.stream === "preview" ? "Только 30-секундные фрагменты" : p.stream === "full" ? "Полные треки" : "Без воспроизведения"}</span>
                    {p.calls > 0 && (
                      <span className="num">
                        {count(p.calls, ["запрос", "запроса", "запросов"])}, ошибок {p.errors}
                        {p.avg_ms != null ? `, в среднем ${p.avg_ms} мс` : ""}
                      </span>
                    )}
                    {p.homepage && (
                      <a href={p.homepage} target="_blank" rel="noreferrer" className="link-quiet">
                        Сайт источника <ExternalLink size={12} />
                      </a>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
