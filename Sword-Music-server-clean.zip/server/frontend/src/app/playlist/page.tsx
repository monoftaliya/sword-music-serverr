"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Reorder, useDragControls } from "framer-motion";
import { ArrowUpDown, Check, Copy, ImagePlus, Link2, Link2Off, Pencil, Play, Shuffle, Trash2, X } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useRef, useState } from "react";
import { CollectionHeader } from "@/components/music/CollectionHeader";
import { TrackList } from "@/components/music/TrackList";
import { Cover } from "@/components/ui/Cover";
import { Dialog } from "@/components/ui/Dialog";
import { EmptyState, ErrorState, RowsSkeleton, Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { confirmAction } from "@/lib/confirm";
import { count, duration, totalDuration } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import { toast } from "@/lib/toast";
import type { PlaylistDetail, PlaylistItem } from "@/lib/types";
import { copyText } from "@/lib/ui";
import styles from "./playlist.module.css";

function OrderRow({ item }: { item: PlaylistItem }) {
  const controls = useDragControls();
  return (
    <Reorder.Item value={item} dragListener={false} dragControls={controls} className={styles.orderRow} whileDrag={{ scale: 1.02, boxShadow: "0 16px 40px rgba(0,0,0,.45)" }}>
      <button className={styles.grip} onPointerDown={(e) => controls.start(e)} aria-label={`Перетащить: ${item.track.title}`}>
        <ArrowUpDown size={16} />
      </button>
      <Cover src={item.track.artwork_small} seed={item.track.id} size={40} radius={8} />
      <span className={styles.orderMeta}>
        <span className="clamp1">{item.track.title}</span>
        <span className="t-tiny clamp1">{item.track.artist}</span>
      </span>
      <span className="t-tiny num">{duration(item.track.duration)}</span>
    </Reorder.Item>
  );
}

function PlaylistInner() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const qc = useQueryClient();
  const playList = usePlayer((s) => s.playList);
  const fileInput = useRef<HTMLInputElement>(null);
  const [editing, setEditing] = useState(false);
  const [ordering, setOrdering] = useState(false);
  const [order, setOrder] = useState<PlaylistItem[]>([]);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [copied, setCopied] = useState(false);

  const q = useQuery({ queryKey: ["playlist", id], queryFn: () => api.get<PlaylistDetail>(`/api/playlists/${id}`), enabled: !!id });
  const pl = q.data;
  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["playlist", id] });
    void qc.invalidateQueries({ queryKey: ["playlists"] });
  };

  useEffect(() => {
    if (pl) {
      setName(pl.name);
      setDesc(pl.description);
    }
  }, [pl]);

  const save = useMutation({
    mutationFn: () => api.patch(`/api/playlists/${id}`, { name: name.trim(), description: desc.trim() }),
    onSuccess: () => {
      setEditing(false);
      refresh();
    },
    onError: (e) => toast.error("Не удалось сохранить", errorMessage(e)),
  });

  const saveOrder = useMutation({
    mutationFn: () => api.put(`/api/playlists/${id}/order`, { item_ids: order.map((i) => i.item_id) }),
    onSuccess: () => {
      setOrdering(false);
      refresh();
      toast.success("Порядок сохранён");
    },
    onError: (e) => toast.error("Не удалось сохранить порядок", errorMessage(e)),
  });

  if (!id) return <div className="page"><ErrorState text="Плейлист не указан." /></div>;
  if (q.isLoading) return <div className="page"><RowsSkeleton rows={8} /></div>;
  if (q.error || !pl) return <div className="page"><ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} /></div>;

  const tracks = pl.items.map((i) => i.track);
  const playable = tracks.filter((t) => t.playable);
  const shareUrl = pl.share_token ? `${window.location.origin}/shared/?token=${pl.share_token}` : null;

  const share = async () => {
    try {
      const r = await api.post<{ token: string }>(`/api/playlists/${id}/share`);
      refresh();
      const copiedOk = await copyText(`${window.location.origin}/shared/?token=${r.token}`);
      toast.success(copiedOk ? "Ссылка создана и скопирована" : "Ссылка создана", "Друзья откроют плейлист после входа в свой аккаунт.");
    } catch (e) {
      toast.error("Не удалось создать ссылку", errorMessage(e));
    }
  };
  const unshare = async () => {
    await api.del(`/api/playlists/${id}/share`);
    refresh();
    toast.info("Доступ по ссылке закрыт");
  };
  const remove = async () => {
    const ok = await confirmAction({ title: "Удалить плейлист?", text: `«${pl.name}» будет удалён без возможности восстановления. Треки останутся в библиотеке.`, confirmLabel: "Удалить", danger: true });
    if (!ok) return;
    await api.del(`/api/playlists/${id}`);
    void qc.invalidateQueries({ queryKey: ["playlists"] });
    router.replace("/library/?tab=playlists");
  };
  const onCover = async (file: File | undefined) => {
    if (!file) return;
    try {
      await api.upload(`/api/playlists/${id}/cover`, file);
      refresh();
    } catch (e) {
      toast.error("Не удалось загрузить обложку", errorMessage(e));
    }
  };

  const art = pl.cover ? (
    <Cover src={pl.cover} seed={pl.id} size="100%" radius={22} priority />
  ) : (
    <span className={styles.mosaic}>
      {[0, 1, 2, 3].map((i) => (
        <Cover key={i} src={pl.mosaic[i] ?? null} seed={`${pl.id}-${i}`} size="100%" radius={0} />
      ))}
    </span>
  );

  return (
    <div className="page">
      <CollectionHeader
        kicker="Плейлист"
        title={pl.name}
        description={pl.description || undefined}
        art={
          <div className={styles.artWrap}>
            {art}
            <button className={styles.coverBtn} onClick={() => fileInput.current?.click()} aria-label="Сменить обложку">
              <ImagePlus size={18} /> Обложка
            </button>
            <input ref={fileInput} type="file" accept="image/*" hidden onChange={(e) => void onCover(e.target.files?.[0])} />
          </div>
        }
        meta={
          <>
            {count(pl.track_count, ["трек", "трека", "треков"])}
            {pl.duration > 0 && `, ${totalDuration(pl.duration)}`}
          </>
        }
        actions={
          <>
            <button className="btn btn-primary" disabled={!playable.length} onClick={() => playList(playable, 0, `playlist:${pl.id}`)}>
              <Play size={16} fill="currentColor" /> Слушать
            </button>
            <button
              className="btn btn-quiet"
              disabled={!playable.length}
              onClick={() => {
                const s = usePlayer.getState();
                if (!s.shuffle) s.toggleShuffle();
                playList(playable, Math.floor(Math.random() * playable.length), `playlist:${pl.id}`);
              }}
            >
              <Shuffle size={16} /> Перемешать
            </button>
            <button className="icon-btn" onClick={() => setEditing(true)} aria-label="Переименовать" title="Переименовать">
              <Pencil size={18} />
            </button>
            {pl.items.length > 1 && (
              <button
                className="icon-btn"
                data-active={ordering}
                onClick={() => {
                  setOrder(pl.items);
                  setOrdering(true);
                }}
                aria-label="Изменить порядок"
                title="Изменить порядок"
              >
                <ArrowUpDown size={18} />
              </button>
            )}
            {shareUrl ? (
              <button className="icon-btn" onClick={() => void unshare()} aria-label="Закрыть доступ по ссылке" title="Закрыть доступ по ссылке">
                <Link2Off size={18} />
              </button>
            ) : (
              <button className="icon-btn" onClick={() => void share()} aria-label="Поделиться с друзьями" title="Поделиться с друзьями">
                <Link2 size={18} />
              </button>
            )}
            <button className="icon-btn" onClick={() => void remove()} aria-label="Удалить плейлист" title="Удалить плейлист">
              <Trash2 size={18} />
            </button>
          </>
        }
      />

      {shareUrl && (
        <div className={styles.share}>
          <span className="t-small">Доступ по ссылке открыт:</span>
          <code className={`${styles.shareUrl} clamp1`}>{shareUrl}</code>
          <button
            className="btn btn-quiet btn-sm"
            onClick={async () => {
              if (!(await copyText(shareUrl))) return toast.error("Не удалось скопировать", "Выделите ссылку и скопируйте вручную.");
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            }}
          >
            {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Скопировано" : "Копировать"}
          </button>
        </div>
      )}

      {ordering ? (
        <div className={styles.ordering}>
          <div className={styles.orderBar}>
            <span className="t-small">Перетащите треки за ручку, затем сохраните.</span>
            <span className="spacer" />
            <button className="btn btn-line btn-sm" onClick={() => setOrdering(false)}>
              <X size={14} /> Отмена
            </button>
            <button className="btn btn-primary btn-sm" onClick={() => saveOrder.mutate()} disabled={saveOrder.isPending}>
              {saveOrder.isPending ? <Spinner size={14} /> : <Check size={14} />} Сохранить порядок
            </button>
          </div>
          <Reorder.Group axis="y" values={order} onReorder={setOrder} className={styles.orderList}>
            {order.map((it) => (
              <OrderRow key={it.item_id} item={it} />
            ))}
          </Reorder.Group>
        </div>
      ) : pl.items.length === 0 ? (
        <EmptyState title="Плейлист пуст" text="Добавляйте треки через меню «…» в поиске, волне или плеере." action={<Link href="/search/" className="btn btn-primary">Перейти к поиску</Link>} />
      ) : (
        <TrackList
          tracks={tracks}
          context={`playlist:${pl.id}`}
          numbered
          extras={(t, i) => [
            {
              label: "Убрать из плейлиста",
              icon: <Trash2 size={16} />,
              danger: true,
              onSelect: async () => {
                await api.del(`/api/playlists/${id}/tracks/${pl.items[i].item_id}`);
                refresh();
                toast.info("Убрано из плейлиста", t.title);
              },
            },
          ]}
        />
      )}

      <Dialog
        open={editing}
        onClose={() => setEditing(false)}
        title="Плейлист"
        footer={
          <>
            <button className="btn btn-line" onClick={() => setEditing(false)}>
              Отмена
            </button>
            <button className="btn btn-primary" onClick={() => save.mutate()} disabled={!name.trim() || save.isPending}>
              Сохранить
            </button>
          </>
        }
      >
        <div className="stack">
          <label className="field">
            <span className="field-label">Название</span>
            <input className="input" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="field">
            <span className="field-label">Описание</span>
            <textarea className="input" value={desc} maxLength={600} onChange={(e) => setDesc(e.target.value)} />
          </label>
        </div>
      </Dialog>
    </div>
  );
}

export default function PlaylistPage() {
  return (
    <Suspense>
      <PlaylistInner />
    </Suspense>
  );
}
