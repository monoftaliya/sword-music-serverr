"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { BookmarkPlus, Play } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { CollectionHeader } from "@/components/music/CollectionHeader";
import { TrackList } from "@/components/music/TrackList";
import { Cover } from "@/components/ui/Cover";
import { ErrorState, RowsSkeleton } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { count } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import { toast } from "@/lib/toast";
import type { PlaylistDetail, PlaylistSummary } from "@/lib/types";

function SharedInner() {
  const token = useSearchParams().get("token") ?? "";
  const router = useRouter();
  const playList = usePlayer((s) => s.playList);
  const q = useQuery({ queryKey: ["shared", token], queryFn: () => api.get<PlaylistDetail>(`/api/shared/${encodeURIComponent(token)}`), enabled: !!token });
  const copy = useMutation({
    mutationFn: () => api.post<PlaylistSummary>(`/api/shared/${encodeURIComponent(token)}/save`),
    onSuccess: (pl) => {
      toast.success("Плейлист сохранён в вашу библиотеку");
      router.push(`/playlist/?id=${pl.id}`);
    },
    onError: (e) => toast.error("Не удалось сохранить", errorMessage(e)),
  });
  if (!token) return <div className="page"><ErrorState text="В ссылке нет ключа доступа." /></div>;
  if (q.isLoading) return <div className="page"><RowsSkeleton rows={8} /></div>;
  if (q.error || !q.data) return <div className="page"><ErrorState text={errorMessage(q.error)} /></div>;
  const pl = q.data;
  const tracks = pl.items.map((i) => i.track);
  const playable = tracks.filter((t) => t.playable);
  return (
    <div className="page">
      <CollectionHeader
        kicker={`Плейлист ${pl.owner.display_name}`}
        title={pl.name}
        description={pl.description || undefined}
        art={<Cover src={pl.cover ?? pl.mosaic[0]} seed={pl.id} size="100%" radius={22} priority />}
        meta={count(pl.track_count, ["трек", "трека", "треков"])}
        actions={
          <>
            <button className="btn btn-primary" disabled={!playable.length} onClick={() => playList(playable, 0, `shared:${token.slice(0, 12)}`)}>
              <Play size={16} fill="currentColor" /> Слушать
            </button>
            {!pl.is_owner && (
              <button className="btn btn-quiet" onClick={() => copy.mutate()} disabled={copy.isPending}>
                <BookmarkPlus size={16} /> Сохранить к себе
              </button>
            )}
          </>
        }
      />
      <TrackList tracks={tracks} context="shared" numbered />
    </div>
  );
}

export default function SharedPage() {
  return (
    <Suspense>
      <SharedInner />
    </Suspense>
  );
}
