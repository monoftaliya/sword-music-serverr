"use client";

import { useQuery } from "@tanstack/react-query";
import { Check, Copy, DoorOpen, Headphones, ListPlus, LogOut, Play, Plus, Power, Search, Trash2, X } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { PlayButton } from "@/components/player/Controls";
import { SeekBar } from "@/components/player/SeekBar";
import { Cover } from "@/components/ui/Cover";
import { EmptyState, ErrorState, RowsSkeleton, Spinner, Switch } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { confirmAction } from "@/lib/confirm";
import { duration } from "@/lib/format";
import { roomClient, useRoom } from "@/lib/rooms/client";
import { toast } from "@/lib/toast";
import type { RoomState, SearchResponse } from "@/lib/types";
import { copyText } from "@/lib/ui";
import styles from "./room.module.css";

function useDebounced(v: string, ms: number) {
  const [d, setD] = useState(v);
  useEffect(() => {
    const t = setTimeout(() => setD(v), ms);
    return () => clearTimeout(t);
  }, [v, ms]);
  return d;
}

function AddMusic({ isOwner, room }: { isOwner: boolean; room: RoomState["room"] }) {
  const [q, setQ] = useState("");
  const term = useDebounced(q.trim(), 400);
  const res = useQuery({
    queryKey: ["room-search", term],
    queryFn: ({ signal }) => api.get<SearchResponse>("/api/search", { q: term, limit: 12, deep: false }, { signal }),
    enabled: term.length >= 2,
  });
  const direct = isOwner || room.allow_member_queue;
  const canSuggest = isOwner || room.allow_suggestions || room.allow_member_queue;
  return (
    <section className={styles.block}>
      <h2 className="t-section">{direct ? "Добавить в очередь" : "Предложить трек"}</h2>
      {!canSuggest ? (
        <p className="t-small">Владелец отключил предложения в этой комнате.</p>
      ) : (
        <>
          <label className={styles.searchBox}>
            <Search size={16} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Название, исполнитель или настроение" aria-label="Поиск трека для комнаты" />
          </label>
          {res.isFetching && <RowsSkeleton rows={3} />}
          <ul className={styles.results}>
            {res.data?.results
              .filter((t) => t.playable && t.stream === "full" && t.provider !== "upload")
              .map((t) => (
                <li key={t.id} className={styles.resultRow}>
                  <Cover src={t.artwork_small} seed={t.id} size={40} radius={8} />
                  <span className={styles.rowMeta}>
                    <span className="clamp1">{t.title}</span>
                    <span className="t-tiny clamp1">{t.artist}</span>
                  </span>
                  <button className="btn btn-quiet btn-sm" onClick={() => roomClient.send({ t: direct ? "queue_add" : "suggest", track_id: t.id })}>
                    {direct ? <ListPlus size={14} /> : <Plus size={14} />} {direct ? "В очередь" : "Предложить"}
                  </button>
                </li>
              ))}
          </ul>
          <p className="t-tiny">В комнату попадают только треки, которые источник отдаёт целиком. Личные файлы и превью не транслируются.</p>
        </>
      )}
    </section>
  );
}

function RoomInner() {
  const code = (useSearchParams().get("code") ?? "").toUpperCase();
  const router = useRouter();
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  const roomCode = useRoom((s) => s.code);
  const state = useRoom((s) => s.state);
  const status = useRoom((s) => s.status);
  const drift = useRoom((s) => s.drift);
  const unlocked = useRoom((s) => s.unlocked);
  const info = useQuery({
    queryKey: ["room-info", code],
    queryFn: () => api.get<{ joined: boolean; room: { code: string; name: string } }>(`/api/rooms/${code}`),
    enabled: !!code,
  });
  const joined = info.data?.joined;
  const connected = roomCode === code;

  useEffect(() => {
    if (joined && user && !connected) roomClient.connect(code, user.id);
  }, [joined, user, code, connected]);

  if (!code) return <div className="page"><ErrorState text="Не указан код комнаты." /></div>;
  if (info.isLoading) return <div className="page"><RowsSkeleton rows={5} /></div>;
  if (info.error) return <div className="page"><ErrorState text={errorMessage(info.error)} /></div>;

  if (!joined) {
    return (
      <div className="page">
        <h1 className="t-display">{info.data?.room.name}</h1>
        <p className={styles.lead}>Вас пригласили в комнату. После входа вы будете слышать то же, что и остальные.</p>
        <button
          className="btn btn-primary btn-lg"
          onClick={async () => {
            try {
              await api.post(`/api/rooms/${code}/join`);
              await info.refetch();
            } catch (e) {
              toast.error("Не удалось войти", errorMessage(e));
            }
          }}
        >
          <DoorOpen size={17} /> Присоединиться
        </button>
      </div>
    );
  }

  const st = connected ? state : null;
  const isOwner = !!st && st.room.owner_id === user?.id;
  const now = st?.now;
  const link = typeof window !== "undefined" ? `${window.location.origin}/room/?code=${code}` : "";

  return (
    <div className={styles.page}>
      <header className={styles.head}>
        <div>
          <span className="t-small">Комната</span>
          <h1 className="t-display">{st?.room.name ?? info.data?.room.name}</h1>
        </div>
        <div className={styles.headActions}>
          <button
            className={styles.code}
            onClick={async () => {
              if (!(await copyText(link))) return toast.error("Не удалось скопировать", link);
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            }}
            title="Скопировать ссылку-приглашение"
          >
            <span className="num">{code}</span>
            {copied ? <Check size={15} /> : <Copy size={15} />}
          </button>
          {connected ? (
            <button className="btn btn-line btn-sm" onClick={() => roomClient.disconnect()}>
              <Power size={14} /> Отключиться
            </button>
          ) : (
            <button className="btn btn-quiet btn-sm" onClick={() => user && roomClient.connect(code, user.id)}>
              <Headphones size={14} /> Подключиться
            </button>
          )}
        </div>
      </header>

      {connected && status !== "open" && (
        <p className={styles.status}>
          <Spinner size={14} /> {status === "reconnecting" ? "Переподключаемся…" : status === "closed" ? "Соединение потеряно." : "Подключаемся…"}
        </p>
      )}

      <div className={styles.grid}>
        <section className={styles.now}>
          {now?.track ? (
            <>
              <Cover src={now.track.artwork || now.track.artwork_small} seed={now.track.id} size="100%" radius={22} />
              <div className={styles.nowMeta}>
                <div className={styles.nowTitle}>{now.track.title}</div>
                <div className="t-small">{now.track.artist}</div>
              </div>
              <SeekBar variant="full" />
              <div className={styles.nowControls}>
                {!unlocked ? (
                  <button className="btn btn-primary" onClick={() => roomClient.unlock()}>
                    <Headphones size={16} /> Подключить звук
                  </button>
                ) : (
                  <PlayButton size={56} />
                )}
                {isOwner && (
                  <button className="btn btn-quiet btn-sm" onClick={() => roomClient.send({ t: "next" })}>
                    Следующий
                  </button>
                )}
              </div>
              <p className={styles.sync}>
                {!unlocked
                  ? "Браузер разрешает звук только после нажатия — подключите его, и воспроизведение догонит комнату."
                  : drift === null
                    ? now.playing
                      ? "Синхронизируем…"
                      : "Пауза у всех"
                    : Math.abs(drift) < 0.25
                      ? "Синхронно с комнатой"
                      : `Догоняем комнату: расхождение ${drift > 0 ? "+" : ""}${drift.toFixed(1)} с`}
                {!isOwner && unlocked && <> Воспроизведением управляет владелец.</>}
              </p>
            </>
          ) : (
            <EmptyState
              icon={<Play size={26} />}
              title="Пока тишина"
              text={isOwner ? "Добавьте трек в очередь — он сразу заиграет у всех." : "Предложите трек — владелец комнаты добавит его в очередь."}
            />
          )}
        </section>

        <div className={styles.side}>
          <section className={styles.block}>
            <h2 className="t-section">Очередь</h2>
            {st && st.queue.filter((q) => q.item_id !== st.now.item_id).length === 0 && <p className="t-small">Очередь пуста.</p>}
            <ol className={styles.queue}>
              {st?.queue
                .filter((it) => it.item_id !== st.now.item_id)
                .map((it, i) => (
                  <li key={it.item_id} className={styles.qRow}>
                    <Cover src={it.track.artwork_small} seed={it.track.id} size={40} radius={8} />
                    <span className={styles.rowMeta}>
                      <span className="clamp1">{it.track.title}</span>
                      <span className="t-tiny clamp1">
                        {it.track.artist}, добавил(а) {it.added_by}
                      </span>
                    </span>
                    <span className="t-tiny num">{duration(it.track.duration)}</span>
                    {isOwner && (
                      <>
                        <button className="icon-btn icon-btn-sm" onClick={() => roomClient.send({ t: "play_item", item_id: it.item_id })} aria-label={`Играть сейчас: ${it.track.title}`}>
                          <Play size={14} fill="currentColor" />
                        </button>
                        {i > 0 && (
                          <button className="icon-btn icon-btn-sm" onClick={() => roomClient.send({ t: "move", item_id: it.item_id, to: 0 })} aria-label="Поднять наверх" title="Сыграть следующим">
                            ↑
                          </button>
                        )}
                      </>
                    )}
                    {(isOwner || it.added_by_id === user?.id) && (
                      <button className="icon-btn icon-btn-sm" onClick={() => roomClient.send({ t: "remove", item_id: it.item_id })} aria-label={`Убрать: ${it.track.title}`}>
                        <Trash2 size={14} />
                      </button>
                    )}
                  </li>
                ))}
            </ol>
          </section>

          {st && st.suggestions.length > 0 && (
            <section className={styles.block}>
              <h2 className="t-section">Предложения</h2>
              <ol className={styles.queue}>
                {st.suggestions.map((it) => (
                  <li key={it.item_id} className={styles.qRow}>
                    <Cover src={it.track.artwork_small} seed={it.track.id} size={40} radius={8} />
                    <span className={styles.rowMeta}>
                      <span className="clamp1">{it.track.title}</span>
                      <span className="t-tiny clamp1">предложил(а) {it.added_by}</span>
                    </span>
                    {isOwner ? (
                      <>
                        <button className="icon-btn icon-btn-sm" onClick={() => roomClient.send({ t: "accept", item_id: it.item_id })} aria-label="Принять">
                          <Check size={15} />
                        </button>
                        <button className="icon-btn icon-btn-sm" onClick={() => roomClient.send({ t: "reject", item_id: it.item_id })} aria-label="Отклонить">
                          <X size={15} />
                        </button>
                      </>
                    ) : (
                      <span className="t-tiny">ждёт решения</span>
                    )}
                  </li>
                ))}
              </ol>
            </section>
          )}

          {st && <AddMusic isOwner={isOwner} room={st.room} />}

          {st && (
            <section className={styles.block}>
              <h2 className="t-section">Участники</h2>
              <ul className={styles.members}>
                {st.members.map((m) => (
                  <li key={m.id} className={styles.member} data-online={m.online || undefined}>
                    <Cover src={m.avatar} seed={m.id} size={30} round />
                    <span className="clamp1">{m.name}</span>
                    {m.role === "owner" && <span className="badge">владелец</span>}
                    <span className="dot" data-state={m.online ? "ok" : undefined} title={m.online ? "в сети" : "не в сети"} />
                    {isOwner && m.role !== "owner" && (
                      <button
                        className="icon-btn icon-btn-sm"
                        aria-label={`Удалить ${m.name} из комнаты`}
                        onClick={async () => {
                          if (await confirmAction({ title: `Удалить ${m.name}?`, text: "Участник сможет вернуться только по новому приглашению.", confirmLabel: "Удалить", danger: true }))
                            await api.del(`/api/rooms/${code}/members/${m.id}`).catch((e) => toast.error("Не удалось", errorMessage(e)));
                        }}
                      >
                        <X size={14} />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {st && isOwner && (
            <section className={styles.block}>
              <h2 className="t-section">Настройки комнаты</h2>
              <label className={styles.opt}>
                <span>Участники добавляют треки сразу</span>
                <Switch checked={st.room.allow_member_queue} onChange={(v) => void api.patch(`/api/rooms/${code}`, { allow_member_queue: v })} label="Участники добавляют треки сразу" />
              </label>
              <label className={styles.opt}>
                <span>Разрешить предложения</span>
                <Switch checked={st.room.allow_suggestions} onChange={(v) => void api.patch(`/api/rooms/${code}`, { allow_suggestions: v })} label="Разрешить предложения" />
              </label>
              <button
                className="btn btn-danger btn-sm"
                onClick={async () => {
                  if (!(await confirmAction({ title: "Закрыть комнату?", text: "Все участники будут отключены, очередь удалится.", confirmLabel: "Закрыть", danger: true }))) return;
                  await api.del(`/api/rooms/${code}`);
                  roomClient.disconnect();
                  router.replace("/rooms/");
                }}
              >
                <Power size={14} /> Закрыть комнату
              </button>
            </section>
          )}
          {st && !isOwner && (
            <button
              className="btn btn-line btn-sm"
              onClick={async () => {
                await api.post(`/api/rooms/${code}/leave`);
                roomClient.disconnect();
                router.replace("/rooms/");
              }}
            >
              <LogOut size={14} /> Покинуть комнату
            </button>
          )}
        </div>
      </div>
      <p className={styles.footnote}>
        Синхронизация: часы устройств сверяются с сервером, небольшие расхождения выравниваются скоростью, большие — перемоткой. Точность зависит от сети и источника
        потока; идеальная синхронизация не гарантируется. <Link href="/rooms/">Все комнаты</Link>
      </p>
    </div>
  );
}

export default function RoomPage() {
  return (
    <Suspense>
      <RoomInner />
    </Suspense>
  );
}
