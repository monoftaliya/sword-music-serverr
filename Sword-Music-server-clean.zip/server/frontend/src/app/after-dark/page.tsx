"use client";

import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Play, RefreshCw } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { ModeField } from "@/components/explore/ModeField";
import { TrackList } from "@/components/music/TrackList";
import { ErrorState, RowsSkeleton } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { usePlayer } from "@/lib/player/store";
import type { ModeInfo, RecResponse } from "@/lib/types";
import styles from "./afterdark.module.css";

function AfterDarkInner() {
  const params = useSearchParams();
  const router = useRouter();
  const [nonce, setNonce] = useState(0);
  const modes = useQuery({ queryKey: ["modes"], queryFn: () => api.get<{ modes: ModeInfo[] }>("/api/modes"), staleTime: Infinity });
  const list = modes.data?.modes ?? [];
  const id = params.get("mode") ?? "void";
  const mode = list.find((m) => m.id === id) ?? list[0];
  const playList = usePlayer((s) => s.playList);
  const context = usePlayer((s) => s.context);
  const recs = useQuery({
    queryKey: ["mode-recs", mode?.id, nonce],
    queryFn: () => api.get<RecResponse>(`/api/modes/${mode!.id}/next`, { count: 14 }),
    enabled: !!mode,
    staleTime: 5 * 60_000,
  });
  const playing = mode && context === `mode:${mode.id}`;

  return (
    <div className={styles.page} style={mode ? ({ ["--m1" as string]: mode.colors[0], ["--m2" as string]: mode.colors[1], ["--m3" as string]: mode.colors[2] }) : undefined}>
      <div className={styles.field}>{mode && <ModeField mode={mode.id} colors={mode.colors} />}</div>
      <div className={styles.inner}>
        <header className={styles.head}>
          <span className="t-small">After Dark</span>
          <nav className={styles.modes} aria-label="Режимы After Dark">
            {list.map((m) => (
              <button
                key={m.id}
                className={styles.mode}
                data-active={m.id === mode?.id || undefined}
                aria-current={m.id === mode?.id ? "true" : undefined}
                onClick={() => router.replace(`/after-dark/?mode=${m.id}`, { scroll: false })}
                style={{ ["--c" as string]: m.colors[0] }}
              >
                {m.name}
              </button>
            ))}
          </nav>
        </header>

        {mode && (
          <motion.section key={mode.id} className={styles.hero} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}>
            <h1 className={styles.name}>{mode.name}</h1>
            <p className={styles.tagline}>{mode.tagline}</p>
            <p className={styles.desc}>{mode.description}</p>
            <div className={styles.tags}>
              {mode.tags.map((t) => (
                <span key={t.key} className="chip chip-tag">
                  {t.label}
                </span>
              ))}
              {mode.avoid.length > 0 && <span className={styles.avoid}>избегает: {mode.avoid.join(", ")}</span>}
            </div>
            <div className="row wrap" style={{ marginTop: 10 }}>
              <button
                className="btn btn-primary btn-lg"
                disabled={!recs.data?.items.length}
                onClick={() => recs.data && playList(recs.data.items.filter((t) => t.playable), 0, `mode:${mode.id}`)}
              >
                <Play size={17} fill="currentColor" /> {playing ? "Играет" : `Запустить ${mode.name}`}
              </button>
              <button className="btn btn-line" onClick={() => setNonce((n) => n + 1)} disabled={recs.isFetching}>
                <RefreshCw size={15} /> Другая подборка
              </button>
            </div>
          </motion.section>
        )}

        <section className={styles.tracks}>
          {recs.isLoading && <RowsSkeleton rows={8} />}
          {recs.error && <ErrorState text={errorMessage(recs.error)} onRetry={() => recs.refetch()} />}
          {recs.data && recs.data.items.length === 0 && (
            <p className="t-small">Источники не вернули подходящих треков. Попробуйте позже или другой режим.</p>
          )}
          {recs.data && recs.data.items.length > 0 && <TrackList key={`${mode?.id}-${nonce}`} tracks={recs.data.items} context={`mode:${mode?.id}`} />}
          <p className={styles.note}>
            Подбор идёт по метаданным каталогов (жанры, настроения, теги, темп) с учётом вашего вкуса. Если у трека мало данных, совпадение приблизительное — это
            отмечено в пояснении.
          </p>
        </section>
      </div>
    </div>
  );
}

export default function AfterDarkPage() {
  return (
    <Suspense>
      <AfterDarkInner />
    </Suspense>
  );
}
