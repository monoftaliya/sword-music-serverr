"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { AuthFrame, FormError } from "@/components/auth/AuthFrame";
import { Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import type { User } from "@/lib/types";

function LoginForm() {
  const { setUser } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [setup, setSetup] = useState(false);

  useEffect(() => {
    api
      .get<{ setup_required: boolean }>("/api/auth/status")
      .then((s) => setSetup(s.setup_required))
      .catch(() => undefined);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { user } = await api.post<{ user: User }>("/api/auth/login", { email, password });
      setUser(user);
      const next = params.get("next");
      router.replace(next && next.startsWith("/") && !next.startsWith("//") ? next : "/");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthFrame
      title="Вход"
      lead="Ваше музыкальное пространство: волна, поиск по настроению, плейлисты и комнаты с друзьями."
      footer={
        <>
          <Link href="/forgot/">Забыли пароль?</Link>
          {setup ? (
            <span>
              Первый запуск сервера — <Link href="/register/">создайте аккаунт администратора</Link>.
            </span>
          ) : (
            <span>
              Есть приглашение? <Link href="/register/">Зарегистрироваться</Link>
            </span>
          )}
        </>
      }
    >
      <form className="stack" onSubmit={submit} noValidate>
        <label className="field">
          <span className="field-label">E-mail</span>
          <input className="input" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label className="field">
          <span className="field-label">Пароль</span>
          <input className="input" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <FormError message={error} />
        <button className="btn btn-primary btn-lg" disabled={busy || !email || !password} style={{ marginTop: 8 }}>
          {busy && <Spinner size={16} />}
          Войти
        </button>
      </form>
    </AuthFrame>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
