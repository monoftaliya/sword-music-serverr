"use client";

import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { Infinity as InfinityIcon, ListMusic, Play } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";
import { TrackPicker } from "@/components/music/TrackPicker";
import { Cover } from "@/components/ui/Cover";
import { ErrorState, Segmented, Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { usePlayer } from "@/lib/player/store";
import { useMotionLevel } from "@/lib/settings";
import type { DescentData, Track } from "@/lib/types";
import styles from "./descent.module.css";

type Mode = "explore" | "descend";

const RELATION_COLOR: Record<string, string> = {
  artist: "var(--ink)",
  genre: "var(--dyn-accent)",
  mood: "var(--dyn-glow)",
  tempo: "#ffbf5c",
  drift: "var(--ink-4)",
};

function DescentInner() {
  const params = useSearchParams();
  const router = useRouter();
  const startId = params.get("center");
  const [mode, setMode] = useState<Mode>("explore");
  const [trail, setTrail] = useState<Track[]>([]);
  const [centerId, setCenterId] = useState<string | null>(startId);
  const [depth, setDepth] = useState(0);
  const [picking, setPicking] = useState(false);
  const playList = usePlayer((s) => s.playList);
  const current = usePlayer((s) => s.queue[s.order[s.pos]] ?? null);
  const motionLevel = useMotionLevel();

  useEffect(() => {
    if (startId && startId !== centerId && !trail.length) setCenterId(startId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startId]);

  const visited = useMemo(() => trail.map((t) => t.id), [trail]);
  const q = useQuery({
    queryKey: ["descent", centerId, mode, depth, visited.join(",")],
    queryFn: () => api.get<DescentData>("/api/descent", { center: centerId!, mode, depth, visited: visited.join(","), count: 10 }),
    enabled: !!centerId,
    staleTime: Infinity,
    placeholderData: (prev) => prev,
  });
  const data = q.data;
  const center = data?.center;
  const nodes = q.isPlaceholderData ? [] : (data?.nodes ?? []);

  const go = (t: Track) => {
    if (center) setTrail((tr) => (tr.some((x) => x.id === center.id) ? tr : [...tr, center]));
    setCenterId(t.id);
    setDepth((d) => (mode === "descend" ? d + 1 : d));
    window.history.replaceState(null, "", `/descent/?center=${encodeURIComponent(t.id)}`);
  };

  const back = (i: number) => {
    const t = trail[i];
    setTrail(trail.slice(0, i));
    setCenterId(t.id);
    setDepth((d) => Math.max(0, d - (trail.length - i)));
  };

  if (!centerId) {
    return (
      <div className="page">
        <h1 className="t-display">Infinite Descent</h1>
        <p className={styles.lead}>Выберите отправную точку: трек станет центром пространства, вокруг появятся связанные композиции.</p>
        <div className="row wrap" style={{ marginTop: 24 }}>
          {current && (
            <button className="btn btn-primary" onClick={() => setCenterId(current.id)}>
              <InfinityIcon size={16} /> Начать с текущего трека
            </button>
          )}
          <button className="btn btn-line" onClick={() => setPicking(true)}>
            Выбрать трек
          </button>
        </div>
        <TrackPicker open={picking} onClose={() => setPicking(false)} onPick={(t) => setCenterId(t.id)} title="Отправная точка" />
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <header className={styles.head}>
        <h1 className="t-display">Infinite Descent</h1>
        <div className={styles.headRight}>
          <Segmented
            size="sm"
            label="Режим"
            value={mode}
            onChange={(m) => {
              setMode(m);
              setDepth(0);
            }}
            options={[
              { value: "explore", label: "Explore", hint: "Самые близкие связи" },
              { value: "descend", label: "Descend", hint: "Всё дальше от исходной точки" },
            ]}
          />
          {mode === "descend" && <span className={`t-small num ${styles.depth}`}>глубина {depth}</span>}
        </div>
      </header>

      {q.error && <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />}

      <LayoutGroup>
        <div className={styles.stage} data-mode={mode}>
          <svg className={styles.lines} viewBox="-50 -50 100 100" preserveAspectRatio="none" aria-hidden>
            {nodes.map((n, i) => {
              const a = (i / Math.max(nodes.length, 1)) * Math.PI * 2 - Math.PI / 2;
              const inner = (n.similarity ?? 0) > 0.62;
              const r = inner ? 30 : 43;
              return (
                <motion.line
                  key={n.track.id}
                  x1={0}
                  y1={0}
                  x2={Math.cos(a) * r}
                  y2={Math.sin(a) * r}
                  stroke={RELATION_COLOR[n.relation]}
                  strokeWidth={0.18}
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 0.35 + (n.similarity ?? 0.3) * 0.4 }}
                  transition={{ duration: motionLevel === "full" ? 0.9 : 0.01, delay: motionLevel === "full" ? 0.15 + i * 0.04 : 0 }}
                />
              );
            })}
          </svg>

          {center && (
            <div className={styles.center}>
              <motion.div layoutId={`dn-${center.id}`} className={styles.centerCover} transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}>
                <Cover src={center.artwork || center.artwork_small} seed={center.id} size="100%" round priority />
              </motion.div>
              <motion.div key={center.id} className={styles.centerText} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.35 }}>
                <div className={`${styles.centerTitle} clamp2`}>{center.title}</div>
                <div className="t-small clamp1">{center.artist}</div>
                <button className="btn btn-primary btn-sm" onClick={() => playList([center], 0, "descent")} disabled={!center.playable}>
                  <Play size={14} fill="currentColor" /> Слушать
                </button>
              </motion.div>
            </div>
          )}

          <AnimatePresence>
            {nodes.map((n, i) => {
              const a = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
              const inner = (n.similarity ?? 0) > 0.62;
              const r = inner ? 30 : 43;
              return (
                <motion.button
                  key={n.track.id}
                  className={styles.node}
                  style={{ left: `${50 + Math.cos(a) * r}%`, top: `${50 + Math.sin(a) * r}%` }}
                  initial={{ opacity: 0, scale: 0.6 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.7, transition: { duration: 0.25 } }}
                  transition={{ duration: 0.55, delay: motionLevel === "full" ? 0.1 + i * 0.05 : 0, ease: [0.22, 1, 0.36, 1] }}
                  onClick={() => go(n.track)}
                  aria-label={`${n.track.title} — ${n.track.artist}. Связь: ${n.label}`}
                  data-inner={inner || undefined}
                >
                  <motion.span layoutId={`dn-${n.track.id}`} className={styles.nodeCover}>
                    <Cover src={n.track.artwork_small || n.track.artwork} seed={n.track.id} size="100%" round />
                  </motion.span>
                  <span className={styles.nodeLabel} style={{ ["--rc" as string]: RELATION_COLOR[n.relation] }}>
                    {n.label}
                  </span>
                  <span className={`${styles.nodeTitle} clamp1`}>{n.track.title}</span>
                </motion.button>
              );
            })}
          </AnimatePresence>
          {q.isFetching && (
            <div className={styles.loading}>
              <Spinner size={18} />
            </div>
          )}
          {data && !q.isFetching && nodes.length === 0 && (
            <p className={styles.none}>Связей не нашлось: источники не вернули подходящих треков или вы уже посетили всё рядом. Попробуйте другой режим.</p>
          )}
        </div>
      </LayoutGroup>

      {data?.note && <p className={styles.note}>{data.note}</p>}

      <div className={styles.trail}>
        <span className="t-tiny">Путь</span>
        <div className={styles.trailItems}>
          {trail.map((t, i) => (
            <button key={t.id} className={styles.trailItem} onClick={() => back(i)} title={`${t.title} — ${t.artist}`} aria-label={`Вернуться к ${t.title}`}>
              <Cover src={t.artwork_small} seed={t.id} size={34} round />
            </button>
          ))}
          {center && (
            <span className={styles.trailItem} data-current aria-current="true">
              <Cover src={center.artwork_small} seed={center.id} size={34} round />
            </span>
          )}
        </div>
        {trail.length > 0 && center && (
          <button className="btn btn-quiet btn-sm" onClick={() => playList([...trail, center].filter((t) => t.playable), 0, "descent:path")}>
            <ListMusic size={15} /> Слушать путь
          </button>
        )}
        <button className="link-quiet" onClick={() => setPicking(true)}>
          Новая точка
        </button>
      </div>
      <TrackPicker
        open={picking}
        onClose={() => setPicking(false)}
        onPick={(t) => {
          setTrail([]);
          setDepth(0);
          setCenterId(t.id);
          router.replace(`/descent/?center=${encodeURIComponent(t.id)}`);
        }}
        title="Новая отправная точка"
      />
    </div>
  );
}

export default function DescentPage() {
  return (
    <Suspense>
      <DescentInner />
    </Suspense>
  );
}
