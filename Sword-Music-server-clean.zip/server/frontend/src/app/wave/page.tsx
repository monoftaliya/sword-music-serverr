"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Ban, Heart, Minus, Plus, RefreshCw, SkipForward, ThumbsDown } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { PlayButton } from "@/components/player/Controls";
import { sendFeedback } from "@/components/music/TrackMenu";
import { Cover } from "@/components/ui/Cover";
import { Spinner } from "@/components/ui/controls";
import { WaveCore, type WaveMode } from "@/components/wave/WaveCore";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { toggleLike, useLiked } from "@/lib/likes";
import { useCurrentTrack, usePlayer } from "@/lib/player/store";
import { toast } from "@/lib/toast";
import type { ProfileSummary, RecResponse, TagRef, UserSettings } from "@/lib/types";
import styles from "./wave.module.css";

const MODES: { id: WaveMode; name: string; text: string }[] = [
  { id: "flow", name: "FLOW", text: "Личный поток" },
  { id: "void", name: "VOID", text: "Погружение" },
  { id: "chaos", name: "CHAOS", text: "Открытия" },
];

type Lens = "main" | "shadow";

function energyOf(point: [number, number, number] | null | undefined, tags: TagRef[] | undefined): number {
  if (point) return point[1];
  const hot = ["aggressive", "energetic", "phonk", "metal", "dnb", "dubstep", "workout", "party", "heavy"];
  const calm = ["ambient", "calm", "sleep", "drone", "piano", "lofi", "dark_ambient"];
  const keys = (tags ?? []).map((t) => t.key);
  if (keys.some((k) => hot.includes(k))) return 0.8;
  if (keys.some((k) => calm.includes(k))) return 0.25;
  return 0.5;
}

function WaveSpace() {
  const params = useSearchParams();
  const router = useRouter();
  const qc = useQueryClient();
  const { user, setUser } = useAuth();
  const [mode, setMode] = useState<WaveMode>((params.get("mode") as WaveMode) || "flow");
  const [lens, setLens] = useState<Lens>(user?.settings.wave_lens ?? "main");
  const [busy, setBusy] = useState(false);
  const [cold, setCold] = useState<RecResponse | null>(null);
  const [seeds, setSeeds] = useState<string[]>([]);
  const autostarted = useRef(false);

  const track = useCurrentTrack();
  const context = usePlayer((s) => s.context);
  const status = usePlayer((s) => s.status);
  const order = usePlayer((s) => s.order);
  const pos = usePlayer((s) => s.pos);
  const queue = usePlayer((s) => s.queue);
  const liked = useLiked(track);
  const waveContext = `wave:${mode}:${lens}`;
  const inWave = context.startsWith("wave:");
  const inThisWave = context === waveContext;
  const upcoming = useMemo(() => (inWave ? order.slice(pos + 1, pos + 7).map((i) => queue[i]).filter(Boolean) : []), [inWave, order, pos, queue]);

  const profile = useQuery({
    queryKey: ["wave-profile"],
    queryFn: () => api.get<ProfileSummary>("/api/wave/profile"),
    staleTime: 60_000,
  });

  const start = useCallback(
    async (m: WaveMode, l: Lens, opts: { keepCurrent?: boolean } = {}) => {
      setBusy(true);
      try {
        const p = usePlayer.getState();
        const cur = p.queue[p.order[p.pos]];
        const res = await api.get<RecResponse>("/api/wave/next", {
          mode: m,
          lens: l,
          count: 10,
          current: opts.keepCurrent ? cur?.id : undefined,
          exclude: opts.keepCurrent ? p.queue.slice(-60).map((t) => t.id).join(",") : undefined,
        });
        const items = res.items.filter((t) => t.playable);
        if (res.cold_start && !profile.data?.seed_tags?.length) setCold(res);
        if (!items.length) {
          const failed = res.sources.filter((s) => s.status !== "ok");
          toast.error("Волна пока пуста", failed.length ? `Источники недоступны: ${failed.map((s) => s.name).join(", ")}` : "Не нашлось подходящих треков. Попробуйте другой режим.");
          return;
        }
        if (opts.keepCurrent && cur && p.context.startsWith("wave:")) {
          usePlayer.setState({ context: `wave:${m}:${l}` });
          const s = usePlayer.getState();
          const head = s.order.slice(0, s.pos + 1).map((i) => s.queue[i]);
          usePlayer.setState({ queue: [...head, ...items], order: [...head, ...items].map((_, i) => i), pos: head.length - 1 });
        } else {
          p.playList(items, 0, `wave:${m}:${l}`);
        }
        void qc.invalidateQueries({ queryKey: ["wave-profile"] });
      } catch (err) {
        toast.error("Не удалось запустить волну", errorMessage(err));
      } finally {
        setBusy(false);
      }
    },
    [qc, profile.data?.seed_tags],
  );

  useEffect(() => {
    if (autostarted.current || params.get("autoplay") !== "1") return;
    autostarted.current = true;
    if (!usePlayer.getState().context.startsWith(`wave:${mode}`)) void start(mode, lens);
    router.replace(`/wave/?mode=${mode}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const switchMode = (m: WaveMode) => {
    if (m === mode) return;
    setMode(m);
    window.history.replaceState(null, "", `/wave/?mode=${m}`);
    if (inWave) {
      void start(m, lens, { keepCurrent: true });
      toast.info(`${m.toUpperCase()}: следующие треки — в новом режиме`);
    }
  };

  const switchLens = (l: Lens) => {
    if (l === lens) return;
    setLens(l);
    api
      .patch<{ settings: UserSettings }>("/api/me/settings", { wave_lens: l })
      .then((r) => user && setUser({ ...user, settings: r.settings }))
      .catch(() => undefined);
    if (inWave) void start(mode, l, { keepCurrent: true });
  };

  const dislike = async () => {
    if (!track) return;
    await sendFeedback(track, "dislike", waveContext);
    usePlayer.getState().next(true);
  };
  const exclude = async () => {
    if (!track) return;
    await sendFeedback(track, "exclude_artist", waveContext);
    usePlayer.getState().next(true);
  };

  const saveSeeds = async () => {
    try {
      await api.put("/api/wave/seeds", { tags: seeds });
      setCold(null);
      void qc.invalidateQueries({ queryKey: ["wave-profile"] });
      void qc.invalidateQueries({ queryKey: ["wave-peek"] });
      await start(mode, lens);
    } catch (err) {
      toast.error("Не удалось сохранить", errorMessage(err));
    }
  };

  const showTrack = inWave && track;
  const energy = showTrack ? energyOf(track.point, track.tags) : mode === "chaos" ? 0.8 : mode === "void" ? 0.3 : 0.55;

  return (
    <div className={styles.page} data-mode={mode} data-lens={lens}>
      <header className={styles.header}>
        <h1 className="t-display">Моя волна</h1>
        <div className={styles.switches}>
          <div className={styles.modes} role="radiogroup" aria-label="Режим волны">
            {MODES.map((m) => (
              <button key={m.id} role="radio" aria-checked={mode === m.id} className={styles.mode} data-active={mode === m.id || undefined} onClick={() => switchMode(m.id)}>
                {mode === m.id && <motion.span layoutId="wave-mode" className={styles.modePill} transition={{ type: "spring", stiffness: 380, damping: 36 }} />}
                <span className={styles.modeName}>{m.name}</span>
                <span className={styles.modeText}>{m.text}</span>
              </button>
            ))}
          </div>
          <button
            className={styles.lens}
            role="switch"
            aria-checked={lens === "shadow"}
            onClick={() => switchLens(lens === "main" ? "shadow" : "main")}
            title="SHADOW исследует направления рядом с вашим вкусом, которые вы ещё не слушали"
          >
            <span data-on={lens === "main" || undefined}>MAIN</span>
            <span className={styles.lensTrack}>
              <motion.span className={styles.lensKnob} animate={{ x: lens === "shadow" ? 18 : 0 }} transition={{ type: "spring", stiffness: 500, damping: 34 }} />
            </span>
            <span data-on={lens === "shadow" || undefined}>SHADOW</span>
          </button>
        </div>
      </header>

      <section className={styles.stage}>
        <div className={styles.core}>
          <WaveCore mode={mode} lens={lens} energy={energy} bpm={showTrack ? track.bpm : null} playing={inWave && status === "playing"} trackKey={showTrack ? track.id : null} />
        </div>

        <motion.div className={styles.now} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}>
          {showTrack ? (
            <>
              <div className={styles.trackLine}>
                <Cover src={track.artwork_small || track.artwork} seed={track.id} size={56} radius={12} />
                <div className={styles.trackText}>
                  <div className={`${styles.title} clamp2`}>{track.title}</div>
                  <div className={`${styles.artist} clamp1`}>{track.artist}</div>
                </div>
              </div>
              {track.reason && <p className={styles.reason}>{track.reason}</p>}
              <div className={styles.controls}>
                <button className="icon-btn" onClick={() => void dislike()} aria-label="Не нравится" title="Не нравится — пропустить и учесть">
                  <ThumbsDown size={20} />
                </button>
                <PlayButton size={64} />
                <button className="icon-btn" onClick={() => usePlayer.getState().next(true)} aria-label="Следующий трек" title="Пропустить (это не дизлайк)">
                  <SkipForward size={21} fill="currentColor" />
                </button>
                <button className="icon-btn" data-active={liked} aria-pressed={liked} onClick={() => void toggleLike(track, waveContext)} aria-label={liked ? "Убрать лайк" : "Нравится"}>
                  <Heart size={20} fill={liked ? "currentColor" : "none"} />
                </button>
              </div>
              <div className={styles.tuning}>
                <button className="chip" onClick={() => void sendFeedback(track, "more", waveContext)}>
                  <Plus size={14} /> Больше такого
                </button>
                <button className="chip" onClick={() => void sendFeedback(track, "less", waveContext)}>
                  <Minus size={14} /> Меньше такого
                </button>
                <button className="chip" onClick={() => void exclude()}>
                  <Ban size={14} /> Исключить исполнителя
                </button>
                <button className="chip" onClick={() => void start(mode, lens, { keepCurrent: true })} disabled={busy}>
                  {busy ? <Spinner size={14} /> : <RefreshCw size={14} />} Обновить волну
                </button>
              </div>
            </>
          ) : (
            <div className={styles.idle}>
              <p className={styles.idleText}>
                {lens === "shadow"
                  ? "SHADOW ведёт туда, где вы ещё не были: соседние жанры и новые исполнители, без того, что вы отвергли."
                  : mode === "flow"
                    ? "Поток из ваших лайков, повторов и любимых исполнителей, с небольшой долей нового."
                    : mode === "void"
                      ? "Мрачное, атмосферное, пространственное — подобранное с учётом вашего вкуса."
                      : "Неожиданные жанры и новые имена — рядом с вашим вкусом, а не случайно."}
              </p>
              <button className="btn btn-primary btn-lg" onClick={() => void start(mode, lens)} disabled={busy}>
                {busy && <Spinner size={16} />}
                Запустить {MODES.find((m) => m.id === mode)?.name}
              </button>
            </div>
          )}
        </motion.div>
      </section>

      {cold && (
        <section className={styles.onboard}>
          <h2 className="t-section">Настройте волну</h2>
          <p className="t-small">Отметьте, что вам близко — это стартовая точка. Дальше волна учится на ваших лайках, повторах и пропусках.</p>
          <div className={styles.seedGrid}>
            {cold.seed_suggestions.map((s) => (
              <button
                key={s.key}
                className="chip"
                data-active={seeds.includes(s.key)}
                aria-pressed={seeds.includes(s.key)}
                onClick={() => setSeeds((v) => (v.includes(s.key) ? v.filter((x) => x !== s.key) : [...v, s.key].slice(0, 12)))}
              >
                {s.label}
              </button>
            ))}
          </div>
          <div className="row">
            <button className="btn btn-primary" disabled={!seeds.length} onClick={() => void saveSeeds()}>
              Сохранить и запустить
            </button>
            <button className="btn btn-line" onClick={() => setCold(null)}>
              Позже
            </button>
          </div>
        </section>
      )}

      {upcoming.length > 0 && (
        <motion.section className={styles.next} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9, duration: 0.6 }}>
          <h2 className="t-section">Дальше в волне</h2>
          <ol className={styles.nextList}>
            {upcoming.map((t, i) => (
              <li key={t.id}>
                <button className={styles.nextItem} onClick={() => usePlayer.getState().jumpTo(pos + 1 + i)}>
                  <Cover src={t.artwork_small || t.artwork} seed={t.id} size="100%" radius={14} />
                  <span className={`${styles.nextTitle} clamp1`}>{t.title}</span>
                  <span className="t-tiny clamp1">{t.artist}</span>
                  {t.reason && <span className={`${styles.nextReason} clamp2`}>{t.reason}</span>}
                </button>
              </li>
            ))}
          </ol>
        </motion.section>
      )}

      {profile.data && (
        <section className={styles.understand}>
          <h2 className="t-section">Как волна вас понимает</h2>
          {profile.data.signals === 0 && !profile.data.seed_tags.length ? (
            <p className="t-small">Пока сигналов нет. Слушайте, ставьте лайки и пропускайте — волна быстро подстроится.</p>
          ) : (
            <>
              <div className={styles.profileRow}>
                <span className="t-tiny">Любите</span>
                {profile.data.top_tags.slice(0, 7).map((t) => (
                  <span key={t.key} className="chip chip-tag">
                    {t.label}
                  </span>
                ))}
              </div>
              {profile.data.avoided.length > 0 && (
                <div className={styles.profileRow}>
                  <span className="t-tiny">Реже</span>
                  {profile.data.avoided.map((t) => (
                    <span key={t.key} className="chip chip-tag chip-avoid">
                      {t.label}
                    </span>
                  ))}
                </div>
              )}
              {lens === "shadow" && profile.data.shadow_tags.length > 0 && (
                <div className={styles.profileRow}>
                  <span className="t-tiny">Тень ведёт к</span>
                  {profile.data.shadow_tags.slice(0, 6).map((t) => (
                    <span key={t.key} className="chip chip-tag">
                      {t.label}
                    </span>
                  ))}
                </div>
              )}
              <p className="t-tiny">
                Учитываются лайки, дизлайки, полные прослушивания и повторы. Пропуск трека — мягкий сигнал, а не дизлайк. Сбросить историю можно в{" "}
                <Link href="/settings/#recs" style={{ textDecoration: "underline" }}>
                  настройках
                </Link>
                .
              </p>
            </>
          )}
        </section>
      )}
    </div>
  );
}

export default function WavePage() {
  return (
    <Suspense>
      <WaveSpace />
    </Suspense>
  );
}
