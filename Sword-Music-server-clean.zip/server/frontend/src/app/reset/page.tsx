"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { AuthFrame, FormError } from "@/components/auth/AuthFrame";
import { Spinner } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";

function ResetForm() {
  const token = useSearchParams().get("token") ?? "";
  const [password, setPassword] = useState("");
  const [repeat, setRepeat] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== repeat) {
      setError("Пароли не совпадают.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api.post("/api/auth/password/reset", { token, password });
      setDone(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthFrame title="Новый пароль" lead="После смены пароля все устройства будут разлогинены." footer={<Link href="/login/">Ко входу</Link>}>
      {!token ? (
        <p>Ссылка неполная. Откройте её из письма или попросите администратора создать новую.</p>
      ) : done ? (
        <div className="stack">
          <p>Пароль обновлён.</p>
          <Link href="/login/" className="btn btn-primary btn-lg">
            Войти
          </Link>
        </div>
      ) : (
        <form className="stack" onSubmit={submit}>
          <label className="field">
            <span className="field-label">Новый пароль</span>
            <input className="input" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          <label className="field">
            <span className="field-label">Повторите пароль</span>
            <input className="input" type="password" autoComplete="new-password" value={repeat} onChange={(e) => setRepeat(e.target.value)} required />
          </label>
          <FormError message={error} />
          <button className="btn btn-primary btn-lg" disabled={busy || !password || !repeat}>
            {busy && <Spinner size={16} />}
            Сохранить пароль
          </button>
        </form>
      )}
    </AuthFrame>
  );
}

export default function ResetPage() {
  return (
    <Suspense>
      <ResetForm />
    </Suspense>
  );
}
