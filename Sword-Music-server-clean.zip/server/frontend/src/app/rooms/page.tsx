"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { DoorOpen, Plus, Radio, Users } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Cover } from "@/components/ui/Cover";
import { Dialog } from "@/components/ui/Dialog";
import { EmptyState, ErrorState, RowsSkeleton, Spinner, Switch } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { count } from "@/lib/format";
import { toast } from "@/lib/toast";
import type { Track } from "@/lib/types";
import styles from "./rooms.module.css";

interface RoomRow {
  code: string;
  name: string;
  role: "owner" | "member";
  members: number;
  online: number;
  now: Track | null;
  playing: boolean;
}

export default function RoomsPage() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [memberQueue, setMemberQueue] = useState(false);
  const [suggestions, setSuggestions] = useState(true);
  const [code, setCode] = useState("");
  const q = useQuery({ queryKey: ["rooms"], queryFn: () => api.get<{ rooms: RoomRow[] }>("/api/rooms"), refetchInterval: 15_000 });
  const create = useMutation({
    mutationFn: () => api.post<{ code: string }>("/api/rooms", { name: name.trim(), allow_member_queue: memberQueue, allow_suggestions: suggestions }),
    onSuccess: (r) => router.push(`/room/?code=${r.code}`),
    onError: (e) => toast.error("Не удалось создать комнату", errorMessage(e)),
  });
  const join = useMutation({
    mutationFn: () => api.post<{ code: string }>(`/api/rooms/${code.trim().toUpperCase()}/join`),
    onSuccess: (r) => router.push(`/room/?code=${r.code}`),
    onError: (e) => toast.error("Не удалось войти", errorMessage(e)),
  });

  return (
    <div className="page">
      <h1 className="t-display">Комнаты</h1>
      <p className={styles.lead}>Слушайте вместе: общая очередь, предложения треков и синхронное воспроизведение у всех участников.</p>

      <div className={styles.top}>
        <button className="btn btn-primary" onClick={() => setOpen(true)}>
          <Plus size={16} /> Создать комнату
        </button>
        <form
          className={styles.join}
          onSubmit={(e) => {
            e.preventDefault();
            if (code.trim().length >= 4) join.mutate();
          }}
        >
          <input className="input" placeholder="Код комнаты" value={code} maxLength={12} onChange={(e) => setCode(e.target.value.toUpperCase())} aria-label="Код комнаты" />
          <button className="btn btn-quiet" disabled={code.trim().length < 4 || join.isPending}>
            {join.isPending ? <Spinner size={15} /> : <DoorOpen size={16} />} Войти
          </button>
        </form>
      </div>

      {q.isLoading && <RowsSkeleton rows={3} />}
      {q.error && <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />}
      {q.data && q.data.rooms.length === 0 && (
        <EmptyState icon={<Users size={28} />} title="Вы пока не в комнатах" text="Создайте комнату и отправьте друзьям ссылку или код — они присоединятся после входа в свой аккаунт." />
      )}
      <ul className={styles.list}>
        {q.data?.rooms.map((r) => (
          <li key={r.code}>
            <Link href={`/room/?code=${r.code}`} className={styles.room}>
              <span className={styles.roomArt}>
                {r.now ? <Cover src={r.now.artwork_small} seed={r.now.id} size={56} radius={14} /> : <Radio size={22} />}
              </span>
              <span className={styles.roomMeta}>
                <span className={styles.roomName}>{r.name}</span>
                <span className="t-small clamp1">{r.now ? `${r.playing ? "Играет" : "На паузе"}: ${r.now.artist} — ${r.now.title}` : "Тишина"}</span>
              </span>
              <span className={styles.roomStats}>
                <span className="t-small">{count(r.members, ["участник", "участника", "участников"])}</span>
                <span className={styles.online}>
                  <span className="dot" data-state={r.online ? "ok" : undefined} /> {r.online} в сети
                </span>
              </span>
              <span className={styles.role}>{r.role === "owner" ? "ваша" : r.code}</span>
            </Link>
          </li>
        ))}
      </ul>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Новая комната"
        footer={
          <>
            <button className="btn btn-line" onClick={() => setOpen(false)}>
              Отмена
            </button>
            <button className="btn btn-primary" disabled={!name.trim() || create.isPending} onClick={() => create.mutate()}>
              {create.isPending && <Spinner size={15} />} Создать
            </button>
          </>
        }
      >
        <div className="stack">
          <label className="field">
            <span className="field-label">Название</span>
            <input className="input" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} placeholder="Например, «Пятничный вечер»" />
          </label>
          <label className={styles.opt}>
            <span>
              Участники добавляют треки сразу
              <span className="t-tiny">Иначе их треки попадают в предложения, и вы решаете, что играть.</span>
            </span>
            <Switch checked={memberQueue} onChange={setMemberQueue} label="Участники добавляют треки сразу" />
          </label>
          <label className={styles.opt}>
            <span>
              Разрешить предложения
              <span className="t-tiny">Участники могут предлагать треки в очередь.</span>
            </span>
            <Switch checked={suggestions} onChange={setSuggestions} label="Разрешить предложения" />
          </label>
        </div>
      </Dialog>
    </div>
  );
}
