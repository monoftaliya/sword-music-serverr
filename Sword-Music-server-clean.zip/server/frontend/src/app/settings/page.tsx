"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, ImagePlus, LogOut, Trash2, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Cover } from "@/components/ui/Cover";
import { DiscordSettings } from "@/components/player/DiscordSettings";
import { Dialog } from "@/components/ui/Dialog";
import { Segmented, Slider, Spinner, Switch } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { confirmAction } from "@/lib/confirm";
import { getEngine } from "@/lib/player/engine";
import { applySettings } from "@/lib/settings";
import { toast } from "@/lib/toast";
import type { ProfileSummary, User, UserSettings } from "@/lib/types";
import { relativeTime } from "@/lib/format";
import styles from "./settings.module.css";

function Section({ id, title, children, lead }: { id: string; title: string; lead?: string; children: ReactNode }) {
  return (
    <section id={id} className={styles.section}>
      <div className={styles.sectionHead}>
        <h2 className="t-title">{title}</h2>
        {lead && <p className="t-small">{lead}</p>}
      </div>
      <div className={styles.sectionBody}>{children}</div>
    </section>
  );
}

function Row({ label, hint, children }: { label: string; hint?: ReactNode; children: ReactNode }) {
  return (
    <div className={styles.row}>
      <div className={styles.rowText}>
        <span>{label}</span>
        {hint && <span className="t-tiny">{hint}</span>}
      </div>
      <div className={styles.rowControl}>{children}</div>
    </div>
  );
}

export default function SettingsPage() {
  const { user, setUser, logout } = useAuth();
  const router = useRouter();
  const qc = useQueryClient();
  const avatarInput = useRef<HTMLInputElement>(null);
  const [name, setName] = useState(user?.display_name ?? "");
  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState({ current: "", next: "" });
  const [delOpen, setDelOpen] = useState(false);
  const [delPw, setDelPw] = useState("");
  const [canCrossfade, setCanCrossfade] = useState(true);
  const [desktopServer, setDesktopServer] = useState<string | null>(null);
  const s = user?.settings;

  useEffect(() => {
    window.swordDesktop?.currentServer().then(setDesktopServer).catch(() => undefined);
  }, []);

  useEffect(() => {
    try {
      setCanCrossfade(getEngine().canControlVolume);
    } catch {
      setCanCrossfade(true);
    }
  }, []);

  const patch = async (p: Partial<UserSettings>) => {
    if (!user) return;
    const optimistic = { ...user.settings, ...p };
    setUser({ ...user, settings: optimistic });
    applySettings(optimistic);
    try {
      const r = await api.patch<{ settings: UserSettings }>("/api/me/settings", p);
      setUser({ ...user, settings: r.settings });
    } catch (e) {
      setUser(user);
      applySettings(user.settings);
      toast.error("Не удалось сохранить настройку", errorMessage(e));
    }
  };

  const sessions = useQuery({
    queryKey: ["sessions"],
    queryFn: () => api.get<{ sessions: { id: string; user_agent: string; ip: string; last_used_at: string; current: boolean }[] }>("/api/auth/sessions"),
  });
  const profile = useQuery({ queryKey: ["wave-profile"], queryFn: () => api.get<ProfileSummary>("/api/wave/profile") });

  const saveName = useMutation({
    mutationFn: () => api.patch<{ user: User }>("/api/me", { display_name: name }),
    onSuccess: (r) => {
      setUser(r.user);
      toast.success("Имя обновлено");
    },
    onError: (e) => toast.error("Не удалось сохранить", errorMessage(e)),
  });
  const changePw = useMutation({
    mutationFn: () => api.post("/api/auth/password/change", { current_password: pw.current, new_password: pw.next }),
    onSuccess: () => {
      setPwOpen(false);
      setPw({ current: "", next: "" });
      toast.success("Пароль изменён", "Остальные устройства разлогинены.");
      void sessions.refetch();
    },
    onError: (e) => toast.error("Не удалось изменить пароль", errorMessage(e)),
  });

  if (!user || !s) return null;

  const onAvatar = async (file?: File) => {
    if (!file) return;
    try {
      const r = await api.upload<{ avatar_url: string }>("/api/me/avatar", file);
      setUser({ ...user, avatar_url: r.avatar_url });
    } catch (e) {
      toast.error("Не удалось загрузить аватар", errorMessage(e));
    }
  };

  const exportData = async () => {
    try {
      const data = await api.get("/api/me/export");
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "sword-music-data.json";
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    } catch (e) {
      toast.error("Не удалось выгрузить данные", errorMessage(e));
    }
  };

  return (
    <div className="page">
      <h1 className="t-display">Настройки</h1>
      <nav className={styles.toc} aria-label="Разделы настроек">
        {[
          ["profile", "Профиль"],
          ["look", "Оформление"],
          ["playback", "Воспроизведение"],
          ["discord", "Discord"],
          ["privacy", "Приватность"],
          ["recs", "Рекомендации"],
          ["devices", "Устройства"],
          ["account", "Аккаунт"],
        ].map(([id, label]) => (
          <a key={id} href={`#${id}`} className="chip">
            {label}
          </a>
        ))}
      </nav>

      <Section id="profile" title="Профиль">
        <div className={styles.profile}>
          <button className={styles.avatar} onClick={() => avatarInput.current?.click()} aria-label="Сменить аватар">
            <Cover src={user.avatar_url} seed={user.id} size={88} round />
            <span className={styles.avatarHint}>
              <ImagePlus size={16} />
            </span>
          </button>
          <input ref={avatarInput} type="file" accept="image/*" hidden onChange={(e) => void onAvatar(e.target.files?.[0])} />
          <div className={styles.profileFields}>
            <label className="field">
              <span className="field-label">Имя</span>
              <div className="row">
                <input className="input" value={name} maxLength={40} onChange={(e) => setName(e.target.value)} />
                <button className="btn btn-quiet" disabled={!name.trim() || name === user.display_name || saveName.isPending} onClick={() => saveName.mutate()}>
                  Сохранить
                </button>
              </div>
            </label>
            <div className="t-small">
              {user.email}
              {user.is_admin ? ", администратор" : ""}
            </div>
            <div className="row wrap">
              <button className="btn btn-line btn-sm" onClick={() => setPwOpen(true)}>
                Сменить пароль
              </button>
              {user.avatar_url && (
                <button
                  className="btn btn-line btn-sm"
                  onClick={async () => {
                    await api.del("/api/me/avatar");
                    setUser({ ...user, avatar_url: null });
                  }}
                >
                  Убрать аватар
                </button>
              )}
            </div>
          </div>
        </div>
      </Section>

      <Section id="look" title="Оформление">
        <Row label="Тема" hint="Все темы тёмные: музыка и обложки должны быть самым ярким на экране.">
          <Segmented size="sm" label="Тема" value={s.theme} onChange={(v) => void patch({ theme: v })} options={[{ value: "liquid", label: "Dark Liquid" }, { value: "oled", label: "OLED" }, { value: "midnight", label: "Midnight" }]} />
        </Row>
        <Row label="Акцент" hint="«По обложке» берёт цвета из обложки текущего трека.">
          <Segmented size="sm" label="Акцент" value={s.accent} onChange={(v) => void patch({ accent: v })} options={[{ value: "adaptive", label: "По обложке" }, { value: "violet", label: "Фиолетовый" }, { value: "blue", label: "Синий" }]} />
        </Row>
        <Row label="Визуальная интенсивность" hint="Живой фон, частицы и дыхание обложки. «Минимум» бережёт батарею.">
          <Segmented size="sm" label="Интенсивность" value={s.intensity} onChange={(v) => void patch({ intensity: v })} options={[{ value: "minimal", label: "Минимум" }, { value: "balanced", label: "Баланс" }, { value: "rich", label: "Максимум" }]} />
        </Row>
        <Row label="Анимации" hint="«Как в системе» следует настройке «Уменьшить движение» вашего устройства.">
          <Segmented size="sm" label="Анимации" value={s.motion} onChange={(v) => void patch({ motion: v })} options={[{ value: "system", label: "Как в системе" }, { value: "full", label: "Все" }, { value: "reduced", label: "Меньше" }, { value: "off", label: "Выкл." }]} />
        </Row>
      </Section>

      <Section id="playback" title="Воспроизведение">
        <Row
          label={`Плавный переход между треками${s.crossfade ? `: ${s.crossfade} с` : ""}`}
          hint={canCrossfade ? "Конец трека плавно смешивается с началом следующего. В комнатах отключено." : "На этом устройстве браузер не даёт менять громкость из приложения (iOS), поэтому crossfade недоступен."}
        >
          <Slider value={s.crossfade} min={0} max={12} step={1} onChange={(v) => setUser({ ...user, settings: { ...s, crossfade: v } })} onCommit={(v) => void patch({ crossfade: v })} label="Длительность crossfade" format={(v) => `${v} с`} className={styles.slider} />
        </Row>
        <Row label="Качество потока" hint="Влияет только на Jamendo (MP3 ~192 кбит/с или 96 кбит/с). Audius, Internet Archive и Wikimedia отдают один вариант.">
          <Segmented size="sm" label="Качество" value={s.quality} onChange={(v) => void patch({ quality: v })} options={[{ value: "high", label: "Высокое" }, { value: "data_saver", label: "Экономия трафика" }]} />
        </Row>
      </Section>

      <Section id="privacy" title="Приватность">
        <Row label="Записывать историю прослушиваний" hint="Без истории волна учится только на ваших лайках и оценках.">
          <Switch checked={s.history_enabled} onChange={(v) => void patch({ history_enabled: v })} label="Записывать историю" />
        </Row>
        <Row label="Показывать, что я слушаю, в комнатах">
          <Switch checked={s.show_listening_in_rooms} onChange={(v) => void patch({ show_listening_in_rooms: v })} label="Показывать в комнатах" />
        </Row>
        <div className={styles.actions}>
          <button
            className="btn btn-line btn-sm"
            onClick={async () => {
              if (!(await confirmAction({ title: "Очистить историю прослушиваний?", text: "Недавние треки и Echo Self начнутся с чистого листа.", confirmLabel: "Очистить", danger: true }))) return;
              await api.del("/api/me/history");
              void qc.invalidateQueries();
              toast.success("История очищена");
            }}
          >
            <Trash2 size={14} /> Очистить историю прослушиваний
          </button>
          <button
            className="btn btn-line btn-sm"
            onClick={async () => {
              await api.del("/api/search/history");
              toast.success("История поиска очищена");
            }}
          >
            <X size={14} /> Очистить историю поиска
          </button>
          <button className="btn btn-line btn-sm" onClick={() => void exportData()}>
            <Download size={14} /> Выгрузить мои данные
          </button>
        </div>
      </Section>

      <Section id="recs" title="Рекомендации" lead="Что волна знает о вашем вкусе — и как начать заново.">
        {profile.data && (
          <>
            <Row label="Сигналов учтено" hint="Лайки, оценки, прослушивания и пропуски.">
              <span className="num">{profile.data.signals}</span>
            </Row>
            {profile.data.excluded_artists.length > 0 && (
              <div className={styles.excluded}>
                <span className="t-small">Исключённые исполнители</span>
                <div className="row wrap">
                  {profile.data.excluded_artists.map((a) => (
                    <button
                      key={a.key}
                      className="chip"
                      onClick={async () => {
                        await api.del(`/api/wave/exclusions/${encodeURIComponent(a.key)}`);
                        void profile.refetch();
                      }}
                      title="Вернуть в рекомендации"
                    >
                      {a.name} <X size={13} />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
        <div className={styles.actions}>
          <button
            className="btn btn-danger btn-sm"
            onClick={async () => {
              if (!(await confirmAction({ title: "Сбросить рекомендации?", text: "Лайки и плейлисты останутся, но волна забудет оценки, предпочтения по звучанию и начнёт подбирать заново.", confirmLabel: "Сбросить", danger: true }))) return;
              await api.post("/api/wave/reset", { confirm: true });
              void qc.invalidateQueries();
              toast.success("Рекомендации начнутся с чистого листа");
            }}
          >
            Начать рекомендации заново
          </button>
        </div>
      </Section>

      <Section id="discord" title="Discord" lead="Rich Presence — музыка в вашем профиле Discord."><DiscordSettings /></Section>
      <Section id="devices" title="Устройства" lead="Где открыт ваш аккаунт. Очередь и позиция воспроизведения синхронизируются между ними.">
        <ul className={styles.sessions}>
          {sessions.data?.sessions.map((d) => (
            <li key={d.id} className={styles.session}>
              <span className={styles.sessionMeta}>
                <span className="clamp1">{describeAgent(d.user_agent)}</span>
                <span className="t-tiny">
                  {d.current ? "это устройство" : `активность ${relativeTime(d.last_used_at)}`}
                  {d.ip ? `, ${d.ip}` : ""}
                </span>
              </span>
              {!d.current && (
                <button
                  className="btn btn-line btn-sm"
                  onClick={async () => {
                    await api.del(`/api/auth/sessions/${d.id}`);
                    void sessions.refetch();
                  }}
                >
                  Завершить
                </button>
              )}
            </li>
          ))}
        </ul>
      </Section>

      <Section id="account" title="Аккаунт">
        {desktopServer && (
          <Row label="Сервер приложения" hint={desktopServer}>
            <button className="btn btn-line btn-sm" onClick={() => void window.swordDesktop?.changeServer()}>
              Сменить сервер
            </button>
          </Row>
        )}
        <div className={styles.actions}>
          <button
            className="btn btn-quiet"
            onClick={async () => {
              await logout();
              router.replace("/login/");
            }}
          >
            <LogOut size={16} /> Выйти
          </button>
          <button className="btn btn-danger btn-sm" onClick={() => setDelOpen(true)}>
            Удалить аккаунт
          </button>
        </div>
        <p className="t-tiny" style={{ marginTop: 12 }}>
          Sword Music 1.0. Музыка воспроизводится напрямую из источников: Audius, Jamendo, Internet Archive, Wikimedia Commons и YouTube.
          Треки YouTube играют в официальном плеере YouTube, поэтому действуют{" "}
          <a href="https://www.youtube.com/t/terms" target="_blank" rel="noreferrer">
            Условия использования YouTube
          </a>{" "}
          и{" "}
          <a href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">
            Политика конфиденциальности Google
          </a>
          .
        </p>
      </Section>

      <Dialog
        open={pwOpen}
        onClose={() => setPwOpen(false)}
        title="Смена пароля"
        footer={
          <button className="btn btn-primary" disabled={!pw.current || !pw.next || changePw.isPending} onClick={() => changePw.mutate()}>
            {changePw.isPending && <Spinner size={15} />} Сменить пароль
          </button>
        }
      >
        <div className="stack">
          <label className="field">
            <span className="field-label">Текущий пароль</span>
            <input className="input" type="password" autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
          </label>
          <label className="field">
            <span className="field-label">Новый пароль</span>
            <input className="input" type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
          </label>
        </div>
      </Dialog>

      <Dialog
        open={delOpen}
        onClose={() => setDelOpen(false)}
        title="Удалить аккаунт?"
        description="Удалятся профиль, плейлисты, избранное, история и загруженные файлы. Это необратимо."
        footer={
          <button
            className="btn btn-danger"
            disabled={!delPw}
            onClick={async () => {
              try {
                await api.post("/api/me/delete", { password: delPw });
                setUser(null);
                router.replace("/login/");
              } catch (e) {
                toast.error("Не удалось удалить аккаунт", errorMessage(e));
              }
            }}
          >
            Удалить навсегда
          </button>
        }
      >
        <label className="field">
          <span className="field-label">Пароль для подтверждения</span>
          <input className="input" type="password" value={delPw} onChange={(e) => setDelPw(e.target.value)} autoComplete="current-password" />
        </label>
      </Dialog>
    </div>
  );
}

function describeAgent(ua: string): string {
  if (!ua) return "Неизвестное устройство";
  const os = /Android/i.test(ua) ? "Android" : /iPhone|iPad/i.test(ua) ? "iOS" : /Windows/i.test(ua) ? "Windows" : /Mac OS X/i.test(ua) ? "macOS" : /Linux/i.test(ua) ? "Linux" : "";
  const br = /Electron\//.test(ua) ? "Приложение для компьютера" : /Edg\//.test(ua) ? "Edge" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "Браузер";
  return [br, os].filter(Boolean).join(", ");
}
