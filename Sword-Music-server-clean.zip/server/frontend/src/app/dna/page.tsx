"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { Dna, FlaskConical, Play, Shuffle } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useMemo, useState } from "react";
import { TrackList } from "@/components/music/TrackList";
import { TrackPicker } from "@/components/music/TrackPicker";
import { Cover } from "@/components/ui/Cover";
import { EmptyState, ErrorState, RowsSkeleton, Segmented, Slider, Spinner, Switch } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { usePlayer } from "@/lib/player/store";
import type { DnaData, Track } from "@/lib/types";
import styles from "./dna.module.css";

type Pick = "a" | "b" | "both";

interface FindResult {
  items: (Track & { match?: number })[];
  notes: string[];
}

function Helix({ count }: { count: number }) {
  const h = Math.max(1, count) * 54;
  const pts = (phase: number) =>
    Array.from({ length: 80 }, (_, i) => {
      const y = (i / 79) * h;
      const x = 18 + Math.sin((y / 54) * Math.PI + phase) * 12;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ");
  return (
    <svg className={styles.helix} width="36" height={h} viewBox={`0 0 36 ${h}`} aria-hidden>
      <polyline points={pts(0)} fill="none" stroke="url(#hx)" strokeWidth="1.2" />
      <polyline points={pts(Math.PI)} fill="none" stroke="url(#hx)" strokeWidth="1.2" opacity=".5" />
      <defs>
        <linearGradient id="hx" x1="0" y1="0" x2="0" y2={h} gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--dyn-accent)" />
          <stop offset="1" stopColor="var(--dyn-glow)" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function MoodMap({ v, e, a }: { v: number; e: number; a: number }) {
  const x = ((v + 1) / 2) * 100;
  const y = (1 - e) * 100;
  return (
    <div className={styles.map} role="img" aria-label={`Оценка настроения: ${v < -0.2 ? "мрачное" : v > 0.2 ? "светлое" : "нейтральное"}, ${e > 0.6 ? "энергичное" : e < 0.35 ? "спокойное" : "умеренное"}`}>
      <span className={styles.axisY1}>интенсивно</span>
      <span className={styles.axisY2}>спокойно</span>
      <span className={styles.axisX1}>мрачно</span>
      <span className={styles.axisX2}>светло</span>
      <span className={styles.cross} />
      <span className={styles.point} style={{ left: `${x}%`, top: `${y}%`, width: 10 + a * 26, height: 10 + a * 26 }} />
    </div>
  );
}

function DnaView({ data }: { data: DnaData }) {
  const params = data.params.filter((p) => p.key !== "tags");
  return (
    <div className={styles.view}>
      <div className={styles.strand}>
        <Helix count={params.length} />
        <ul className={styles.params}>
          {params.map((p) => (
            <li key={p.key} className={styles.param} data-kind={p.kind}>
              <span className={styles.pLabel}>{p.label}</span>
              <span className={styles.pValue}>
                {p.url ? (
                  <a href={p.url} target="_blank" rel="noopener noreferrer">
                    {p.value}
                  </a>
                ) : (
                  p.value
                )}
              </span>
              <span className={styles.pSource} title={p.source}>
                {p.kind === "measured" ? "измерено источником" : "метаданные"}
              </span>
            </li>
          ))}
        </ul>
      </div>
      <div className={styles.side}>
        {data.tags.length > 0 && (
          <div className={styles.block}>
            <h3 className="t-section">Состав</h3>
            <ul className={styles.bars}>
              {data.tags.slice(0, 8).map((t) => (
                <li key={t.key}>
                  <span className={styles.barLabel}>{t.label}</span>
                  <span className={styles.bar}>
                    <span style={{ width: `${Math.round(t.weight * 100)}%` }} />
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {data.mood && (
          <div className={styles.block}>
            <h3 className="t-section">Настроение</h3>
            <MoodMap v={data.mood.valence} e={data.mood.energy} a={data.mood.atmosphere} />
            <p className="t-tiny">{data.mood.note}</p>
          </div>
        )}
        {data.waveform && (
          <div className={styles.block}>
            <h3 className="t-section">Форма волны</h3>
            <div className={styles.wave}>
              {data.waveform.map((v, i) => (
                <span key={i} style={{ height: `${Math.max(4, v * 100)}%` }} />
              ))}
            </div>
            <p className="t-tiny">{data.waveform_source}</p>
          </div>
        )}
        {!data.tags.length && !data.mood && (
          <p className="t-small">Источник почти не передал характеристик для этого трека. Мы не додумываем то, чего в данных нет.</p>
        )}
      </div>
    </div>
  );
}

const GROUPS: { id: string; label: string }[] = [
  { id: "genre", label: "Жанр" },
  { id: "mood", label: "Настроение" },
  { id: "scene", label: "Образ" },
  { id: "texture", label: "Звучание" },
];

function CharacteristicsSearch() {
  const [tags, setTags] = useState<string[]>([]);
  const [bpmOn, setBpmOn] = useState(false);
  const [bpm, setBpm] = useState(120);
  const [vocal, setVocal] = useState<"any" | "instrumental" | "vocal">("any");
  const [energyOn, setEnergyOn] = useState(false);
  const [energy, setEnergy] = useState(0.5);
  const catalog = useQuery({ queryKey: ["tag-catalog"], queryFn: () => api.get<{ tags: { key: string; label: string; group: string }[] }>("/api/search/tags"), staleTime: Infinity });
  const find = useMutation({
    mutationFn: () =>
      api.get<FindResult>("/api/dna/search", {
        tags: tags.join(","),
        bpm_min: bpmOn ? bpm - 8 : undefined,
        bpm_max: bpmOn ? bpm + 8 : undefined,
        vocal: vocal === "any" ? undefined : vocal,
        energy: energyOn ? energy : undefined,
        count: 20,
      }),
  });
  const byGroup = useMemo(() => {
    const out: Record<string, { key: string; label: string }[]> = {};
    for (const t of catalog.data?.tags ?? []) (out[t.group] ??= []).push(t);
    return out;
  }, [catalog.data]);
  return (
    <section className="section">
      <h2 className="t-title">Поиск по сочетанию характеристик</h2>
      <p className={`t-small ${styles.intro}`}>Соберите звучание из параметров — подберём существующие треки из подключённых каталогов. Мы ничего не генерируем.</p>
      <div className={styles.builder}>
        {GROUPS.map((g) => (
          <div key={g.id} className={styles.group}>
            <span className="t-tiny">{g.label}</span>
            <div className={styles.chips}>
              {(byGroup[g.id] ?? []).map((t) => (
                <button
                  key={t.key}
                  className="chip"
                  data-active={tags.includes(t.key)}
                  aria-pressed={tags.includes(t.key)}
                  onClick={() => setTags((v) => (v.includes(t.key) ? v.filter((x) => x !== t.key) : [...v, t.key].slice(-6)))}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        ))}
        <div className={styles.controlsRow}>
          <label className={styles.ctl}>
            <Switch checked={bpmOn} onChange={setBpmOn} label="Учитывать темп" />
            <span>Темп</span>
            <Slider value={bpm} min={60} max={190} step={1} onChange={setBpm} label="Темп, BPM" className={styles.slider} format={(v) => `${v} BPM`} />
            <span className={`num ${styles.ctlVal}`} data-off={!bpmOn || undefined}>{bpm} BPM</span>
          </label>
          <label className={styles.ctl}>
            <Switch checked={energyOn} onChange={setEnergyOn} label="Учитывать энергию" />
            <span>Энергия</span>
            <Slider value={energy} min={0} max={1} step={0.05} onChange={setEnergy} label="Энергия" className={styles.slider} />
            <span className={`num ${styles.ctlVal}`} data-off={!energyOn || undefined}>{Math.round(energy * 100)}%</span>
          </label>
          <Segmented
            size="sm"
            label="Вокал"
            value={vocal}
            onChange={setVocal}
            options={[
              { value: "any", label: "Любой вокал" },
              { value: "instrumental", label: "Инструментал" },
              { value: "vocal", label: "С вокалом" },
            ]}
          />
        </div>
        <div>
          <button className="btn btn-primary" onClick={() => find.mutate()} disabled={find.isPending || (!tags.length && !bpmOn && !energyOn && vocal === "any")}>
            {find.isPending ? <Spinner size={15} /> : <FlaskConical size={16} />} Подобрать
          </button>
        </div>
      </div>
      {find.error && <ErrorState text={errorMessage(find.error)} />}
      {find.data && (find.data.items.length ? <TrackList tracks={find.data.items} context="dna" /> : <EmptyState title="Подходящих треков не нашлось" text="Ослабьте условия: уберите часть тегов или расширьте темп." />)}
    </section>
  );
}

function DnaInner() {
  const params = useSearchParams();
  const router = useRouter();
  const trackId = params.get("track");
  const current = usePlayer((s) => s.queue[s.order[s.pos]] ?? null);
  const playList = usePlayer((s) => s.playList);
  const [pickA, setPickA] = useState(false);
  const [pickB, setPickB] = useState(false);
  const [b, setB] = useState<Track | null>(null);
  const [atm, setAtm] = useState<Pick>("a");
  const [rhythm, setRhythm] = useState<Pick>("b");
  const [genre, setGenre] = useState<Pick | "none">("a");
  const dna = useQuery({ queryKey: ["dna", trackId], queryFn: () => api.get<DnaData>(`/api/dna/track/${encodeURIComponent(trackId!)}`), enabled: !!trackId });
  const blend = useMutation({
    mutationFn: () => api.post<FindResult>("/api/dna/blend", { a: trackId, b: b!.id, atmosphere: atm, rhythm, genre, count: 14 }),
  });

  return (
    <div className="page">
      <h1 className="t-display">Music DNA</h1>
      <p className={styles.lead}>Только то, что известно о треке из источника: темп и тональность из анализа аудио (если источник его делает), жанры, теги, инструменты и лицензия.</p>

      {!trackId && (
        <div className={styles.choose}>
          {current && (
            <button className="btn btn-primary" onClick={() => router.replace(`/dna/?track=${encodeURIComponent(current.id)}`)}>
              <Dna size={16} /> ДНК текущего трека
            </button>
          )}
          <button className="btn btn-line" onClick={() => setPickA(true)}>
            Выбрать трек
          </button>
        </div>
      )}

      {trackId && dna.isLoading && <RowsSkeleton rows={6} />}
      {dna.error && <ErrorState text={errorMessage(dna.error)} onRetry={() => dna.refetch()} />}
      {dna.data && (
        <>
          <div className={styles.trackHead}>
            <Cover src={dna.data.track.artwork || dna.data.track.artwork_small} seed={dna.data.track.id} size={88} radius={16} />
            <div className={styles.trackMeta}>
              <div className={styles.trackTitle}>{dna.data.track.title}</div>
              <div className="t-small">{dna.data.track.artist}</div>
              <div className={styles.complete}>
                <span className={styles.completeBar}>
                  <span style={{ width: `${dna.data.completeness * 100}%` }} />
                </span>
                <span className="t-tiny">полнота данных {Math.round(dna.data.completeness * 100)}%</span>
              </div>
            </div>
            <div className="row">
              <button className="icon-btn" onClick={() => playList([dna.data!.track], 0, "dna")} aria-label="Слушать">
                <Play size={18} fill="currentColor" />
              </button>
              <button className="btn btn-line btn-sm" onClick={() => setPickA(true)}>
                Другой трек
              </button>
            </div>
          </div>
          <DnaView data={dna.data} />

          <section className="section">
            <h2 className="t-title">Смешать с другим треком</h2>
            <p className={`t-small ${styles.intro}`}>Возьмите атмосферу одного трека и ритм другого — подберём существующие композиции с таким сочетанием.</p>
            <div className={styles.blend}>
              <div className={styles.slot}>
                <span className="t-tiny">A</span>
                <Cover src={dna.data.track.artwork_small} seed={dna.data.track.id} size={44} radius={9} />
                <span className="clamp1">{dna.data.track.title}</span>
              </div>
              <button className={styles.slot} onClick={() => setPickB(true)}>
                <span className="t-tiny">B</span>
                {b ? (
                  <>
                    <Cover src={b.artwork_small} seed={b.id} size={44} radius={9} />
                    <span className="clamp1">{b.title}</span>
                  </>
                ) : (
                  <span className={styles.slotEmpty}>
                    <Shuffle size={16} /> Выбрать второй трек
                  </span>
                )}
              </button>
            </div>
            <div className={styles.take}>
              <span className={styles.takeLabel}>Атмосфера</span>
              <Segmented size="sm" label="Атмосфера" value={atm} onChange={setAtm} options={[{ value: "a", label: "из A" }, { value: "b", label: "из B" }, { value: "both", label: "из обоих" }]} />
              <span className={styles.takeLabel}>Ритм</span>
              <Segmented size="sm" label="Ритм" value={rhythm} onChange={setRhythm} options={[{ value: "a", label: "из A" }, { value: "b", label: "из B" }, { value: "both", label: "из обоих" }]} />
              <span className={styles.takeLabel}>Жанр</span>
              <Segmented
                size="sm"
                label="Жанр"
                value={genre}
                onChange={setGenre}
                options={[{ value: "a", label: "из A" }, { value: "b", label: "из B" }, { value: "both", label: "оба" }, { value: "none", label: "любой" }]}
              />
            </div>
            <button className="btn btn-primary" disabled={!b || blend.isPending} onClick={() => blend.mutate()}>
              {blend.isPending ? <Spinner size={15} /> : <FlaskConical size={16} />} Найти сочетание
            </button>
            {blend.error && <ErrorState text={errorMessage(blend.error)} />}
            {blend.data && (
              <div className={styles.blendResult}>
                {blend.data.notes.length > 0 && <p className="t-small">Взято: {blend.data.notes.join("; ")}.</p>}
                {blend.data.items.length ? <TrackList tracks={blend.data.items} context="dna" /> : <EmptyState title="Такого сочетания в каталогах не нашлось" />}
              </div>
            )}
          </section>
        </>
      )}

      <CharacteristicsSearch />

      <TrackPicker open={pickA} onClose={() => setPickA(false)} onPick={(t) => router.replace(`/dna/?track=${encodeURIComponent(t.id)}`)} title="Трек для анализа" />
      <TrackPicker open={pickB} onClose={() => setPickB(false)} onPick={setB} title="Второй трек" exclude={trackId ? [trackId] : []} />
    </div>
  );
}

export default function DnaPage() {
  return (
    <Suspense>
      <DnaInner />
    </Suspense>
  );
}
