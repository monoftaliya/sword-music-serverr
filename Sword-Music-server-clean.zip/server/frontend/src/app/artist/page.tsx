"use client";

import { useQuery } from "@tanstack/react-query";
import { Infinity as InfinityIcon, Play } from "lucide-react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { CollectionHeader } from "@/components/music/CollectionHeader";
import { TrackList } from "@/components/music/TrackList";
import { Cover } from "@/components/ui/Cover";
import { EmptyState, ErrorState, RowsSkeleton } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { count } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import type { SourceStatus, Track } from "@/lib/types";

interface ArtistData {
  key: string;
  name: string;
  artwork: string | null;
  library: Track[];
  top: Track[];
  sources: SourceStatus[];
}

function ArtistInner() {
  const params = useSearchParams();
  const key = params.get("key") ?? "";
  const name = params.get("name") ?? "";
  const provider = params.get("provider") ?? undefined;
  const ref = params.get("ref") ?? undefined;
  const playList = usePlayer((s) => s.playList);
  const q = useQuery({
    queryKey: ["artist", key, provider, ref],
    queryFn: () => api.get<ArtistData>(`/api/artists/${encodeURIComponent(key)}`, { name, provider, ref }),
    enabled: !!key,
  });
  const d = q.data;
  const all = d ? [...d.library, ...d.top].filter((t) => t.playable) : [];
  const failed = d?.sources.filter((s) => s.status === "error") ?? [];
  return (
    <div className="page">
      <CollectionHeader
        round
        kicker="Исполнитель"
        title={d?.name ?? name ?? "Исполнитель"}
        art={<Cover src={d?.artwork ?? null} seed={key} size="100%" round priority />}
        meta={d ? `${count(d.library.length, ["трек", "трека", "треков"])} в вашей библиотеке` : undefined}
        actions={
          <>
            <button className="btn btn-primary" disabled={!all.length} onClick={() => playList(all, 0, `artist:${key}`)}>
              <Play size={16} fill="currentColor" /> Слушать
            </button>
            {all[0] && (
              <Link href={`/descent/?center=${encodeURIComponent(all[0].id)}`} className="btn btn-quiet">
                <InfinityIcon size={16} /> Похожие миры
              </Link>
            )}
          </>
        }
      />
      {q.isLoading && <RowsSkeleton rows={8} />}
      {q.error && <ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} />}
      {d && d.library.length > 0 && (
        <section className="section" style={{ marginTop: 0 }}>
          <div className="section-head">
            <h2 className="t-section">В вашей библиотеке</h2>
          </div>
          <TrackList tracks={d.library} context={`artist:${key}`} />
        </section>
      )}
      {d && (
        <section className="section">
          <div className="section-head">
            <h2 className="t-section">{d.library.length ? "Ещё у исполнителя" : "Треки исполнителя"}</h2>
          </div>
          {d.top.length ? (
            <TrackList tracks={d.top} context={`artist:${key}`} />
          ) : (
            <EmptyState
              title="В подключённых источниках других треков не нашлось"
              text={failed.length ? `Не ответили: ${failed.map((s) => s.name).join(", ")}. Попробуйте позже.` : "Возможно, исполнитель публикуется только на закрытых сервисах."}
            />
          )}
        </section>
      )}
    </div>
  );
}

export default function ArtistPage() {
  return (
    <Suspense>
      <ArtistInner />
    </Suspense>
  );
}
