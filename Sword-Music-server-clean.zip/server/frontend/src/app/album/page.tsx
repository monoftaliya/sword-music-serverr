"use client";

import { useQuery } from "@tanstack/react-query";
import { Play } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { CollectionHeader } from "@/components/music/CollectionHeader";
import { TrackList } from "@/components/music/TrackList";
import { Cover } from "@/components/ui/Cover";
import { ErrorState, RowsSkeleton } from "@/components/ui/controls";
import { api, errorMessage } from "@/lib/api";
import { count, totalDuration } from "@/lib/format";
import { usePlayer } from "@/lib/player/store";
import type { Track } from "@/lib/types";
import { artistHref } from "@/lib/ui";
import Link from "next/link";

function AlbumInner() {
  const key = useSearchParams().get("key") ?? "";
  const playList = usePlayer((s) => s.playList);
  const q = useQuery({
    queryKey: ["album", key],
    queryFn: () => api.get<{ key: string; name: string; artist: string; artwork: string | null; items: Track[] }>("/api/albums/view", { key }),
    enabled: !!key,
  });
  if (q.isLoading) return <div className="page"><RowsSkeleton rows={8} /></div>;
  if (q.error || !q.data) return <div className="page"><ErrorState text={errorMessage(q.error)} onRetry={() => q.refetch()} /></div>;
  const a = q.data;
  const playable = a.items.filter((t) => t.playable);
  const total = a.items.reduce((s, t) => s + (t.duration ?? 0), 0);
  const first = a.items[0];
  return (
    <div className="page">
      <CollectionHeader
        kicker="Альбом"
        title={a.name}
        art={<Cover src={a.artwork} seed={a.key} size="100%" radius={22} priority />}
        meta={
          <>
            {first ? (
              <Link href={artistHref(first)} style={{ color: "var(--ink-2)" }}>
                {a.artist}
              </Link>
            ) : (
              a.artist
            )}
            {", "}
            {count(a.items.length, ["трек", "трека", "треков"])}
            {total > 0 && `, ${totalDuration(total)}`}
          </>
        }
        actions={
          <button className="btn btn-primary" disabled={!playable.length} onClick={() => playList(playable, 0, `album:${a.key}`)}>
            <Play size={16} fill="currentColor" /> Слушать альбом
          </button>
        }
      />
      <TrackList tracks={a.items} context={`album:${a.key}`} numbered showSource={false} />
    </div>
  );
}

export default function AlbumPage() {
  return (
    <Suspense>
      <AlbumInner />
    </Suspense>
  );
}
