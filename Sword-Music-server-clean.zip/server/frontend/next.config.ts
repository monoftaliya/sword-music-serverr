import type { NextConfig } from "next";

const isDev = process.env.NODE_ENV !== "production";
const API = process.env.SWORD_API_ORIGIN || "http://127.0.0.1:8000";

const config: NextConfig = {
  // Production build is a static export served by the FastAPI backend (one origin, one process).
  output: isDev ? undefined : "export",
  trailingSlash: true,
  skipTrailingSlashRedirect: true,
  images: { unoptimized: true },
  reactStrictMode: true,
  poweredByHeader: false,
  ...(isDev
    ? {
        async rewrites() {
          return [
            { source: "/api/:path*", destination: `${API}/api/:path*` },
            { source: "/media/:path*", destination: `${API}/media/:path*` },
          ];
        },
      }
    : {}),
};

export default config;
