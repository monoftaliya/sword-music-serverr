"""Render the Sword mark into favicon/PWA icons (SVG source → PNG via headless Chromium).

Optional maintenance tool: the generated icons are already in public/icons.
Usage: pip install playwright && playwright install chromium && python scripts/make_icons.py public/icons
"""
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=True)

BLADE = "M7.2 27.6 25.1 3.4c.4-.5 1.2-.3 1.2.4l-.6 3.3a2 2 0 0 1-.4.8L9.2 28.6c-.3.4-.9.5-1.3.2l-.5-.3a.6.6 0 0 1-.2-.9Z"
WAVE = "M3 19.5c3.2-3.6 6.3-3.6 9.4 0s6.3 3.6 9.4 0 5.2-3.2 7.2-1.6"


def svg(size: int, *, mark_scale: float, radius: float, glow: bool = True) -> str:
    """mark_scale: fraction of the canvas the 32-unit mark occupies."""
    k = size * mark_scale / 32
    off = (size - 32 * k) / 2
    bg = f'<rect width="{size}" height="{size}" rx="{size * radius:.1f}" fill="#08090D"/>'
    glow_layer = ""
    if glow:
        glow_layer = (
            f'<rect width="{size}" height="{size}" rx="{size * radius:.1f}" fill="url(#g1)"/>'
            f'<rect width="{size}" height="{size}" rx="{size * radius:.1f}" fill="url(#g2)"/>'
        )
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">
  <defs>
    <radialGradient id="g1" cx="0.28" cy="0.78" r="0.62">
      <stop offset="0" stop-color="#8B5CFF" stop-opacity="0.30"/>
      <stop offset="1" stop-color="#8B5CFF" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="g2" cx="0.8" cy="0.18" r="0.55">
      <stop offset="0" stop-color="#5C8DFF" stop-opacity="0.20"/>
      <stop offset="1" stop-color="#5C8DFF" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="b" x1="6" y1="28" x2="26" y2="4" gradientUnits="userSpaceOnUse">
      <stop stop-color="#5C8DFF"/>
      <stop offset="1" stop-color="#8B5CFF"/>
    </linearGradient>
  </defs>
  {bg}{glow_layer}
  <g transform="translate({off:.2f} {off:.2f}) scale({k:.4f})">
    <path d="{BLADE}" fill="url(#b)"/>
    <path d="{WAVE}" stroke="#F4F5FA" stroke-width="1.6" stroke-linecap="round" fill="none" opacity=".92"/>
  </g>
</svg>"""


targets = {
    # name: (size, mark_scale, corner radius fraction)
    "icon-192.png": (192, 0.66, 0.22),
    "icon-512.png": (512, 0.66, 0.22),
    "maskable-512.png": (512, 0.5, 0.0),
    "maskable-192.png": (192, 0.5, 0.0),
    "apple-touch-icon.png": (180, 0.62, 0.0),
}

(OUT / "favicon.svg").write_text(svg(32, mark_scale=0.84, radius=0.22, glow=False).replace('width="32" height="32" viewBox', 'viewBox'))
(OUT / "icon.svg").write_text(svg(512, mark_scale=0.66, radius=0.22))

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    for name, (size, scale, radius) in targets.items():
        page = browser.new_page(viewport={"width": size, "height": size}, device_scale_factor=1)
        page.set_content(
            f'<html><body style="margin:0;background:transparent">{svg(size, mark_scale=scale, radius=radius)}</body></html>'
        )
        page.locator("svg").screenshot(path=str(OUT / name), omit_background=True)
        page.close()
    browser.close()
print(sorted(p.name for p in OUT.iterdir()))
