/* Spotify's official SDK needs eval. Its compatibility policy is scoped to this player page. */
(() => {
  const channel = "sword-spotify";
  const validUri = (uri) => typeof uri === "string" && /^spotify:track:[a-zA-Z0-9]{22}$/.test(uri);
  let controller = null;
  const report = (type, data = {}) => window.parent.postMessage({ channel, type, data }, window.location.origin);
  const uri = decodeURIComponent(window.location.hash.slice(1));
  if (!validUri(uri)) { report("error"); return; }
  window.onSpotifyIframeApiReady = (api) => {
    api.createController(document.getElementById("player"), { uri, width: "100%", height: 152 }, (instance) => {
      controller = instance;
      instance.addListener("ready", () => report("ready"));
      instance.addListener("playback_update", ({ data }) => report("update", {
        playingURI: data.playingURI, isPaused: !!data.isPaused, isBuffering: !!data.isBuffering,
        position: Number(data.position) || 0, duration: Number(data.duration) || 0,
      }));
    });
  };
  window.addEventListener("message", (event) => {
    if (event.source !== window.parent || event.origin !== window.location.origin || event.data?.channel !== channel || !controller) return;
    const { command, uri: nextUri } = event.data;
    if (command === "load" && validUri(nextUri)) controller.loadEntity(nextUri);
    else if (command === "play") controller.play();
    else if (command === "pause") controller.pause();
  });
  const script = document.createElement("script");
  script.src = "https://open.spotify.com/embed/iframe-api/v1";
  script.onerror = () => report("error");
  document.head.appendChild(script);
})();
