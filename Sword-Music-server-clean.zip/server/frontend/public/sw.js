/*
 * Sword Music service worker.
 * Caches only the application shell (HTML pages, hashed JS/CSS/fonts, icons) so the app opens
 * instantly and shows a clear offline state. It never caches /api, /media or audio: music always
 * streams from its source, nothing is stored for offline listening.
 */
const VERSION = "sword-music-v4";
const SHELL = `${VERSION}-shell`;
const STATIC = `${VERSION}-static`;
const PRECACHE = ["/", "/search/", "/wave/", "/library/", "/login/", "/manifest.webmanifest", "/icons/favicon.svg", "/icons/icon-192.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL)
      .then((c) => Promise.all(PRECACHE.map((url) => c.add(new Request(url, { cache: "reload" })).catch(() => undefined))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

function isBypassed(url, request) {
  if (request.method !== "GET") return true;
  if (url.origin !== self.location.origin) return true; // audio & artwork from music sources
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/media/")) return true;
  if (request.headers.has("range")) return true;
  return false;
}

async function networkFirstPage(request) {
  const cache = await caches.open(SHELL);
  try {
    const response = await fetch(request);
    if (response.ok && response.type === "basic") cache.put(request, response.clone());
    return response;
  } catch {
    const cached = (await cache.match(request, { ignoreSearch: true })) || (await cache.match("/", { ignoreSearch: true }));
    if (cached) return cached;
    return new Response(
      "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width'><title>Sword Music</title>" +
        "<body style='margin:0;min-height:100vh;display:grid;place-items:center;background:#08090D;color:#F4F5FA;font:15px system-ui'>" +
        "<p>Нет соединения. Откройте Sword Music, когда интернет появится.</p>",
      { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } },
    );
  }
}

async function cacheFirst(request) {
  const cache = await caches.open(STATIC);
  const cached = await cache.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok && response.type === "basic") cache.put(request, response.clone());
  return response;
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(STATIC);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((response) => {
      if (response.ok && response.type === "basic") cache.put(request, response.clone());
      return response;
    })
    .catch(() => cached);
  return cached || network;
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (isBypassed(url, request)) return;
  // Flight payload names are stable across builds. Bypass even an old HTTP-cache
  // entry: a payload from a different build makes Next reload the entire document.
  if (request.headers.get("RSC") === "1" || /\/(?:index|__next\.[^/]*)\.txt$/.test(url.pathname) || url.pathname.includes("/__next.")) {
    event.respondWith(fetch(request, { cache: "no-store" }));
  } else if (request.mode === "navigate") {
    event.respondWith(networkFirstPage(request));
  } else if (url.pathname.startsWith("/_next/static/")) {
    event.respondWith(cacheFirst(request));
  } else if (url.pathname.startsWith("/icons/") || url.pathname === "/manifest.webmanifest") {
    event.respondWith(staleWhileRevalidate(request));
  }
});
